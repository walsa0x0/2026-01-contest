# Lottura - Feb 26th 2026 collaborative audit details

- Join [Sherlock Discord](https://discord.gg/MABEWyASkp)
- Submit findings using the issue page (label issues as `Medium`, `High`, `Low/Info` or `General Health`)
- [Read for more details](https://docs.sherlock.xyz/audits/watsons)

## Audit Scope

[lottura-contracts @ d6032c17033097ed5ec0ac0839fca979634a6621](https://github.com/dOrgTech/lottura-contracts/tree/d6032c17033097ed5ec0ac0839fca979634a6621)
- [lottura-contracts/contracts/libraries/Common.sol](lottura-contracts/contracts/libraries/Common.sol)
- [lottura-contracts/contracts/libraries/NumberConversionLib.sol](lottura-contracts/contracts/libraries/NumberConversionLib.sol)
- [lottura-contracts/contracts/libraries/ONFT721MsgCodecExtended.sol](lottura-contracts/contracts/libraries/ONFT721MsgCodecExtended.sol)
- [lottura-contracts/contracts/LotturaCore.sol](lottura-contracts/contracts/LotturaCore.sol)
- [lottura-contracts/contracts/LotturaHub.sol](lottura-contracts/contracts/LotturaHub.sol)
- [lottura-contracts/contracts/LotturaTicketNFT.sol](lottura-contracts/contracts/LotturaTicketNFT.sol)


