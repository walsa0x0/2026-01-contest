import { assert } from 'chai'
import { loadFixture } from '@nomicfoundation/hardhat-network-helpers'
import { Hex, pad } from 'viem'
import { Options } from '@layerzerolabs/lz-v2-utilities'
import { deploy } from './fixtures'

describe('LotturaTicketNFT Tests', function () {
  describe('Success Cases', function () {
    it('Should send the ticket NFT from chain A to chain B', async function () {
      const {
        eidB,
        lotturaTicketNFTA,
        lotturaTicketNFTB,
        ownerA,
        ownerB,
        minter,
      } = await loadFixture(deploy)

      await lotturaTicketNFTA.write.mint(
        [
          ownerA.account.address,
          {
            numbers: [0, 0, 0, 0, 0, 0],
            drawId: 5n,
            timestamp: 0,
          },
        ],
        { account: minter.account },
      )

      const events = await lotturaTicketNFTA.getEvents.TicketMinted()

      const tokenId = events[0].args.tokenId!

      const options = Options.newOptions()
        .addExecutorLzReceiveOption(300000, 0)
        .toHex() as Hex

      const toAddressBytes32 = pad(ownerB.account.address, { size: 32 })

      const sendParam = {
        dstEid: eidB,
        to: toAddressBytes32,
        tokenId: tokenId,
        extraOptions: options,
        composeMsg: '0x' as Hex,
        onftCmd: '0x' as Hex,
      }

      const { nativeFee } = await lotturaTicketNFTA.read.quoteSend([
        sendParam,
        false,
      ])

      await lotturaTicketNFTA.write.send(
        [sendParam, { nativeFee, lzTokenFee: 0n }, ownerA.account.address],
        { value: nativeFee, account: ownerA.account },
      )

      assert.equal(
        await lotturaTicketNFTA.read.balanceOf([ownerA.account.address]),
        0n,
      )

      assert.equal(
        await lotturaTicketNFTB.read.balanceOf([ownerB.account.address]),
        1n,
      )
    })
  })

  describe('Failure Cases', function () {
    it('Should reject send from non-owner', async function () {
      const {
        eidB,
        lotturaTicketNFTA,
        ownerA,
        ownerB,
        minter,
      } = await loadFixture(deploy)

      // Mint ticket to ownerA
      await lotturaTicketNFTA.write.mint(
        [
          ownerA.account.address,
          {
            numbers: [0, 0, 0, 0, 0, 0],
            drawId: 5n,
            timestamp: 0,
          },
        ],
        { account: minter.account },
      )

      const events = await lotturaTicketNFTA.getEvents.TicketMinted()
      const tokenId = events[0].args.tokenId!

      const options = Options.newOptions()
        .addExecutorLzReceiveOption(300000, 0)
        .toHex() as Hex

      const toAddressBytes32 = pad(ownerB.account.address, { size: 32 })

      const sendParam = {
        dstEid: eidB,
        to: toAddressBytes32,
        tokenId: tokenId,
        extraOptions: options,
        composeMsg: '0x' as Hex,
        onftCmd: '0x' as Hex,
      }

      const { nativeFee } = await lotturaTicketNFTA.read.quoteSend([
        sendParam,
        false,
      ])

      // Try to send from ownerB (not the owner)
      await assert.isRejected(
        lotturaTicketNFTA.write.send(
          [sendParam, { nativeFee, lzTokenFee: 0n }, ownerB.account.address],
          { value: nativeFee, account: ownerB.account },
        ),
      )
    })

    it('Should reject send with insufficient native fee', async function () {
      const {
        eidB,
        lotturaTicketNFTA,
        ownerA,
        ownerB,
        minter,
      } = await loadFixture(deploy)

      await lotturaTicketNFTA.write.mint(
        [
          ownerA.account.address,
          {
            numbers: [0, 0, 0, 0, 0, 0],
            drawId: 5n,
            timestamp: 0,
          },
        ],
        { account: minter.account },
      )

      const events = await lotturaTicketNFTA.getEvents.TicketMinted()
      const tokenId = events[0].args.tokenId!

      const options = Options.newOptions()
        .addExecutorLzReceiveOption(300000, 0)
        .toHex() as Hex

      const toAddressBytes32 = pad(ownerB.account.address, { size: 32 })

      const sendParam = {
        dstEid: eidB,
        to: toAddressBytes32,
        tokenId: tokenId,
        extraOptions: options,
        composeMsg: '0x' as Hex,
        onftCmd: '0x' as Hex,
      }

      // Try to send with insufficient fee (0)
      await assert.isRejected(
        lotturaTicketNFTA.write.send(
          [sendParam, { nativeFee: 0n, lzTokenFee: 0n }, ownerA.account.address],
          { value: 0n, account: ownerA.account },
        ),
      )
    })

    it('Should reject mint from non-minter', async function () {
      const { lotturaTicketNFTA, ownerA, ownerB } = await loadFixture(deploy)

      // Try to mint from ownerB (not a minter)
      await assert.isRejected(
        lotturaTicketNFTA.write.mint(
          [
            ownerA.account.address,
            {
              numbers: [0, 0, 0, 0, 0, 0],
              drawId: 5n,
              timestamp: 0,
            },
          ],
          { account: ownerB.account },
        ),
      )
    })

    it('Should reject send of non-existent token', async function () {
      const { eidB, lotturaTicketNFTA, ownerA, ownerB } =
        await loadFixture(deploy)

      const options = Options.newOptions()
        .addExecutorLzReceiveOption(300000, 0)
        .toHex() as Hex

      const toAddressBytes32 = pad(ownerB.account.address, { size: 32 })

      const sendParam = {
        dstEid: eidB,
        to: toAddressBytes32,
        tokenId: 999999n, // Non-existent token
        extraOptions: options,
        composeMsg: '0x' as Hex,
        onftCmd: '0x' as Hex,
      }

      const { nativeFee } = await lotturaTicketNFTA.read.quoteSend([
        sendParam,
        false,
      ])

      // Try to send non-existent token
      await assert.isRejected(
        lotturaTicketNFTA.write.send(
          [sendParam, { nativeFee, lzTokenFee: 0n }, ownerA.account.address],
          { value: nativeFee, account: ownerA.account },
        ),
      )
    })
  })
})
