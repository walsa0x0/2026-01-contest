import hre from 'hardhat'
import { pad } from 'viem'

export const deploy = async () => {
  const eidA = 1
  const eidB = 2

  const [deployer, ownerA, ownerB, minter] = await hre.viem.getWalletClients()

  const endpointV2MockA = await hre.viem.deployContract('EndpointV2Mock', [
    eidA,
  ])

  const endpointV2MockB = await hre.viem.deployContract('EndpointV2Mock', [
    eidB,
  ])

  const lotturaTicketNFTA = await hre.viem.deployContract('LotturaTicketNFT', [
    'LotturaTicketNFTA',
    'LotturaTicketNFTA',
    endpointV2MockA.address,
    ownerA.account.address,
  ])

  const lotturaTicketNFTB = await hre.viem.deployContract('LotturaTicketNFT', [
    'LotturaTicketNFTB',
    'LotturaTicketNFTB',
    endpointV2MockB.address,
    ownerB.account.address,
  ])

  await endpointV2MockA.write.setDestLzEndpoint([
    lotturaTicketNFTB.address,
    endpointV2MockB.address,
  ])

  await endpointV2MockB.write.setDestLzEndpoint([
    lotturaTicketNFTA.address,
    endpointV2MockA.address,
  ])

  await lotturaTicketNFTA.write.setPeer(
    [eidB, pad(lotturaTicketNFTB.address, { size: 32 })],
    { account: ownerA.account },
  )

  await lotturaTicketNFTB.write.setPeer(
    [eidA, pad(lotturaTicketNFTA.address, { size: 32 })],
    { account: ownerB.account },
  )

  await lotturaTicketNFTA.write.setMinter([minter.account.address], {
    account: ownerA.account,
  })

  await lotturaTicketNFTB.write.setMinter([minter.account.address], {
    account: ownerB.account,
  })

  return {
    eidA,
    eidB,
    endpointV2MockA,
    endpointV2MockB,
    lotturaTicketNFTA,
    lotturaTicketNFTB,
    deployer,
    ownerA,
    ownerB,
    minter,
  }
}
