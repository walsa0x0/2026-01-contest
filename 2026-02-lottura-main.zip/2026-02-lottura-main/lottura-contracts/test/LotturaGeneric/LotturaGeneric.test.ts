import { expect } from 'chai'
import { loadFixture, time } from '@nomicfoundation/hardhat-network-helpers'
import { Hash, pad, parseEther, parseUnits, zeroAddress } from 'viem'
import { deploy } from './fixture'
import {
  LotturaCoreInvalidParams,
  LotturaHubInvalidParams,
  formatInvalidParamError,
} from './test-enums'

describe('Lottura Generic Tests', function () {
  describe('Deployment', function () {
    it('Should deploy LotturaCore with correct configuration', async function () {
      const { lotturaCore } = await loadFixture(deploy)

      const config = await lotturaCore.read.getLotturaConfig()

      expect(config.drawInterval).to.equal(3600) // 1 hour
      expect(config.minNumber).to.equal(1)
      expect(config.maxNumber).to.equal(50)
      expect(config.numbersPerTicket).to.equal(6)
    })

    it('Should create first draw on deployment', async function () {
      const { lotturaCore } = await loadFixture(deploy)

      const currentDrawId = await lotturaCore.read.currentDrawId()

      expect(currentDrawId).to.equal(1n)

      const draw = await lotturaCore.read.getDraw([1n])

      expect(draw.status).to.equal(0) // status: OPEN

      // Verify startTime is set to a reasonable timestamp (after 2020)
      const minTimestamp = 1577836800n // Jan 1, 2020
      expect(draw.startTime).to.be.greaterThanOrEqual(minTimestamp)
    })
  })

  describe('VRF Mock Verification', function () {
    it('Should work end-to-end with LotturaCore', async function () {
      const fixture = await loadFixture(deploy)

      // Fund LotturaCore
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets
      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Verify VRF coordinator address in LotturaCore
      const vrfWrapperInCore = await fixture.lotturaCore.read.vrfV2PlusWrapper()
      expect(vrfWrapperInCore.toLowerCase()).to.equal(
        fixture.vrfCoordinator.address.toLowerCase(),
      )

      // Execute draw (this calls VRF mock)
      const draw = await fixture.lotturaCore.read.getDraw([1n])

      expect(draw.ticketsSold).to.equal(10n)

      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      // Check VRF request was created
      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId
      expect(vrfRequestId).to.equal(1n) // First request ID should be 1

      // Check what lastRequestId is in VRF mock
      const lastRequestId = await fixture.vrfCoordinator.read.lastRequestId()
      expect(vrfRequestId).to.equal(lastRequestId)

      // The vrfRequestId should match lastRequestId
      expect(vrfRequestId).to.equal(lastRequestId)

      // Check request exists in VRF mock
      const request = await fixture.vrfCoordinator.read.getRequest([
        vrfRequestId,
      ])
      expect(request[0].toLowerCase()).to.equal(
        fixture.lotturaCore.address.toLowerCase(),
      )
      expect(request[2]).to.equal(false) // not fulfilled yet

      // Fulfill the request
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      // Verify draw was updated
      const drawAfterFulfillment = await fixture.lotturaCore.read.getDraw([1n])
      // Winning numbers should be [48, 11, 39, 9, 12, 49] = packed 481139091249
      expect(drawAfterFulfillment.winningNumbers).to.equal(481139091249n)
      expect(drawAfterFulfillment.status).to.equal(2) // status: PROCESSING_WINNERS
    })
  })

  describe('Ticket Purchase - Basic', function () {
    it('Should purchase single ticket', async function () {
      const { lotturaCore, lotturaHubA, lotturaTicketNFTA, user1 } =
        await loadFixture(deploy)

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      // Verify 1 ticket was purchased
      const draw = await lotturaCore.read.getDraw([1n])
      expect(draw.ticketsSold).to.equal(1) // ticketsSold

      // Verify NFT was minted
      expect(
        await lotturaTicketNFTA.read.balanceOf([user1.account.address]),
      ).to.equal(1n)
    })

    it('Should purchase multiple tickets in single transaction', async function () {
      const { lotturaCore, lotturaHubA, lotturaTicketNFTA, user1 } =
        await loadFixture(deploy)

      await lotturaHubA.write.purchaseTickets(
        [
          [
            [1, 2, 3, 4, 5, 6],
            [7, 8, 9, 10, 11, 12],
          ],
          1n,
          [
            pad('0x0000000000000000000000000000000000000001', { size: 32 }),
            pad('0x0000000000000000000000000000000000000002', { size: 32 }),
          ],
        ],
        { account: user1.account },
      )

      const lotturaHubATokenPurchasedEvents =
        await lotturaHubA.getEvents.TokenPurchased()

      const tokenOwner = lotturaHubATokenPurchasedEvents[0].args.owner!

      expect(tokenOwner.toLowerCase()).to.equal(
        user1.account.address.toLowerCase(),
      )

      const lotturaCorePurchaseTicketEvents =
        await lotturaCore.getEvents.TicketPurchased()

      const lotturaCoreTicketBuyer =
        lotturaCorePurchaseTicketEvents[0].args.buyer!

      expect(lotturaCoreTicketBuyer.toLowerCase()).to.equal(
        user1.account.address.toLowerCase(),
      )

      expect(
        await lotturaTicketNFTA.read.balanceOf([user1.account.address]),
      ).to.equal(2n)
    })

    it('Should purchase multiple tickets with different numbers', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      const ticketNumbers = [
        [1, 2, 3, 4, 5, 6],
        [7, 8, 9, 10, 11, 12],
        [13, 14, 15, 16, 17, 18],
      ]

      for (let i = 0; i < ticketNumbers.length; i++) {
        await lotturaHubA.write.purchaseTickets(
          [
            [
              ticketNumbers[i] as [
                number,
                number,
                number,
                number,
                number,
                number,
              ],
            ],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: user1.account },
        )
      }

      const draw = await lotturaCore.read.getDraw([1n])
      expect(draw.ticketsSold).to.equal(3) // ticketsSold should be 3
    })

    it('Should correctly store ticket data', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      const numbers: [number, number, number, number, number, number] = [
        5, 12, 23, 34, 41, 48,
      ]

      await lotturaHubA.write.purchaseTickets(
        [
          [numbers],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      // Get the draw to verify tickets were added
      const draw = await lotturaCore.read.getDraw([1n])
      expect(draw.ticketsSold).to.equal(1) // ticketsSold should be 1

      // Get the draw tickets
      const ticketsLength = await lotturaCore.read.getDrawTicketsLength([1n])
      expect(ticketsLength).to.equal(1)

      // Get first ticket
      const drawTickets = await lotturaCore.read.getDrawTicketsPage([
        1n,
        0n,
        1n,
      ])
      expect(drawTickets.length).to.equal(1)

      // Verify the ticket exists and is retrievable
      const tokenId = drawTickets[0]
      expect(tokenId).to.not.equal(0n) // Token ID should be non-zero

      // Get ticket and check basic properties exist
      const ticket = await lotturaCore.read.getTicket([tokenId])

      expect(ticket.id).greaterThan(0n)

      expect(ticket.numbers).to.equal(51223344148)
    })

    it('Should update draw prize pool correctly', async function () {
      const { lotturaCore, lotturaHubA, user1, TICKET_PRICE } =
        await loadFixture(deploy)

      const drawBefore = await lotturaCore.read.getDraw([1n])
      const prizePoolBefore = drawBefore.prizePool

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const drawAfter = await lotturaCore.read.getDraw([1n])
      const prizePoolAfter = drawAfter.prizePool

      // Prize pool should increase by (ticketPrice - commission)
      // Commission is 10% (1000 basis points), so 90% goes to prize pool
      const expectedIncrease = (TICKET_PRICE * 9000n) / 10000n

      expect(prizePoolAfter - prizePoolBefore).to.equal(expectedIncrease)

      expect(await lotturaCore.read.accumulatedCommission()).to.equal(
        (TICKET_PRICE * 1000n) / 10000n,
      )
    })

    it('Should increment tickets sold counter', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      const drawBefore = await lotturaCore.read.getDraw([1n])
      const ticketsSoldBefore = drawBefore.ticketsSold

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const drawAfter = await lotturaCore.read.getDraw([1n])
      const ticketsSoldAfter = drawAfter.ticketsSold

      expect(ticketsSoldAfter).to.equal(ticketsSoldBefore + 1)
    })

    it('Should accumulate commission correctly', async function () {
      const { lotturaCore, lotturaHubA, user1, TICKET_PRICE } =
        await loadFixture(deploy)

      const commissionBefore = await lotturaCore.read.accumulatedCommission()

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const commissionAfter = await lotturaCore.read.accumulatedCommission()

      // Commission is 10% (1000 basis points)
      const expectedCommission = (TICKET_PRICE * 1000n) / 10000n

      expect(commissionAfter - commissionBefore).to.equal(expectedCommission)
    })

    it('Should transfer USDT from user to LotturaCore', async function () {
      const { lotturaCore, lotturaHubA, mockUSDT0A, user1, TICKET_PRICE } =
        await loadFixture(deploy)

      const userBalanceBefore = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])
      const coreBalanceBefore = await mockUSDT0A.read.balanceOf([
        lotturaCore.address,
      ])

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const userBalanceAfter = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])
      const coreBalanceAfter = await mockUSDT0A.read.balanceOf([
        lotturaCore.address,
      ])

      expect(userBalanceBefore - userBalanceAfter).to.equal(TICKET_PRICE)
      expect(coreBalanceAfter - coreBalanceBefore).to.equal(TICKET_PRICE)
    })

    it('Should mint NFT to user', async function () {
      const { lotturaHubA, lotturaTicketNFTA, user1 } =
        await loadFixture(deploy)

      const balanceBefore = await lotturaTicketNFTA.read.balanceOf([
        user1.account.address,
      ])

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const balanceAfter = await lotturaTicketNFTA.read.balanceOf([
        user1.account.address,
      ])

      expect(balanceAfter - balanceBefore).to.equal(1n)
    })

    it('Should emit TicketPurchased event', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const events = await lotturaCore.getEvents.TicketPurchased()

      expect(events.length).to.equal(1)
      expect(events[0].args.buyer!.toLowerCase()).to.equal(
        user1.account.address.toLowerCase(),
      )
      expect(events[0].args.drawId).to.equal(1n)
    })

    it('Should commit randomness correctly', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      const hashedRandomness = pad(
        '0x0000000000000000000000000000000000000001',
        { size: 32 },
      )

      await lotturaHubA.write.purchaseTickets(
        [[[1, 2, 3, 4, 5, 6]], 1n, [hashedRandomness]],
        { account: user1.account },
      )

      const events = await lotturaCore.getEvents.RandomnessCommitted()

      expect(events.length).to.equal(1)
      expect(events[0].args.hashedRandomness).to.equal(hashedRandomness)

      // Verify combined randomness was set (XOR of all committed randomness values)
      const combinedRandomness = (await lotturaCore.read.getDraw([1n]))
        .combinedCommittedRandomness
      expect(combinedRandomness).to.not.equal(0n)
    })
  })

  describe('Ticket Purchase - Validation', function () {
    it('Should reject numbers out of range (below minimum)', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[0, 2, 3, 4, 5, 6]], // 0 is invalid
            1n,
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(
          LotturaHubInvalidParams.TicketNumbersOutOfRange,
        ),
      )
    })

    it('Should reject numbers out of range (above maximum)', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 51]], // 51 > 50 (max)
            1n,
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(
          LotturaHubInvalidParams.TicketNumbersOutOfRange,
        ),
      )
    })

    it('Should reject duplicate numbers', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[1, 1, 3, 4, 5, 6]], // Duplicate 1
            1n,
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.TicketNumbersDuplicate),
      )
    })

    it('Should reject zero drawId', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6]],
            0n, // Invalid drawId
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.DrawIdZero),
      )
    })

    it('Should reject zero hashed randomness', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6]],
            1n,
            [pad('0x0000000000000000000000000000000000000000', { size: 32 })], // Zero hash
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.ZeroHashedRandomness),
      )
    })

    it('Should reject purchase when paused', async function () {
      const { lotturaHubA, user1, ownerA } = await loadFixture(deploy)

      await lotturaHubA.write.pause({ account: ownerA.account })

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6]],
            1n,
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith('EnforcedPause')
    })

    it('Should reject purchase after draw ends', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      const draw = await lotturaCore.read.getDraw([1n])
      const endTime = draw.endTime

      await time.increaseTo(Number(endTime) + 1)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6]],
            1n,
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith('DrawAlreadyEnded')
    })

    it('Should reject purchase without sufficient USDT balance', async function () {
      const { lotturaHubA, mockUSDT0A, walletClients } =
        await loadFixture(deploy)

      // Use a new user with no balance but with approval
      const newUser = walletClients[7]

      // Approve but don't mint (no balance)
      const maxUint256 = 2n ** 256n - 1n
      await mockUSDT0A.write.approve([lotturaHubA.address, maxUint256], {
        account: newUser.account,
      })

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6]],
            1n,
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
          ],
          { account: newUser.account },
        ),
      ).to.be.rejectedWith('ERC20InsufficientBalance')
    })

    it('Should reject purchase without USDT approval', async function () {
      const { lotturaHubA, mockUSDT0A, walletClients, INITIAL_BALANCE } =
        await loadFixture(deploy)

      const newUser = walletClients[7]

      // Mint tokens but don't approve
      await mockUSDT0A.write.mint([newUser.account.address, INITIAL_BALANCE])

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6]],
            1n,
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
          ],
          { account: newUser.account },
        ),
      ).to.be.rejectedWith('ERC20InsufficientAllowance')
    })
  })

  describe('Ticket Purchase - Edge Cases', function () {
    it('Should purchase maximum batch size (stress test)', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      // Purchase 50 tickets in single transaction
      const batchSize = 50
      const numbersList: [number, number, number, number, number, number][] = []
      const hashesList: Hash[] = []

      for (let i = 0; i < batchSize; i++) {
        const base = ((i * 6) % 45) + 1
        numbersList.push([
          base,
          base + 1,
          base + 2,
          base + 3,
          base + 4,
          base + 5,
        ] as [number, number, number, number, number, number])
        hashesList.push(
          pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 }),
        )
      }

      await lotturaHubA.write.purchaseTickets([numbersList, 1n, hashesList], {
        account: user1.account,
      })

      const draw = await lotturaCore.read.getDraw([1n])
      expect(draw.ticketsSold).to.equal(batchSize) // ticketsSold
    })

    it('Should handle batch with duplicate numbers across different tickets', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      // Same numbers for different tickets is allowed
      await lotturaHubA.write.purchaseTickets(
        [
          [
            [1, 2, 3, 4, 5, 6],
            [1, 2, 3, 4, 5, 6], // Same numbers, different ticket
            [1, 2, 3, 4, 5, 6],
          ],
          1n,
          [
            pad('0x0000000000000000000000000000000000000001', { size: 32 }),
            pad('0x0000000000000000000000000000000000000002', { size: 32 }),
            pad('0x0000000000000000000000000000000000000003', { size: 32 }),
          ],
        ],
        { account: user1.account },
      )

      const events = await lotturaHubA.getEvents.TokenPurchased()
      expect(events.length).to.equal(3)
    })

    it('Should handle batch with all different randomness values', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      await lotturaHubA.write.purchaseTickets(
        [
          [
            [1, 2, 3, 4, 5, 6],
            [7, 8, 9, 10, 11, 12],
          ],
          1n,
          [
            pad(
              '0x1111111111111111111111111111111111111111111111111111111111111111',
              {
                size: 32,
              },
            ),
            pad(
              '0x2222222222222222222222222222222222222222222222222222222222222222',
              {
                size: 32,
              },
            ),
          ],
        ],
        { account: user1.account },
      )

      // Verify randomness was committed correctly
      const events = await lotturaCore.getEvents.RandomnessCommitted()
      expect(events.length).to.equal(2)
    })

    it('Should reject batch if ANY ticket has invalid numbers', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [
              [1, 2, 3, 4, 5, 6], // Valid
              [7, 8, 9, 10, 11, 51], // Invalid - 51 > 50
              [13, 14, 15, 16, 17, 18], // Valid
            ],
            1n,
            [
              pad('0x0000000000000000000000000000000000000001', { size: 32 }),
              pad('0x0000000000000000000000000000000000000002', { size: 32 }),
              pad('0x0000000000000000000000000000000000000003', { size: 32 }),
            ],
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(
          LotturaHubInvalidParams.TicketNumbersOutOfRange,
        ),
      )
    })

    it('Should reject batch if ANY hash is zero', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [
              [1, 2, 3, 4, 5, 6],
              [7, 8, 9, 10, 11, 12],
            ],
            1n,
            [
              pad('0x0000000000000000000000000000000000000001', { size: 32 }),
              pad('0x0000000000000000000000000000000000000000', { size: 32 }), // Zero hash
            ],
          ],
          { account: user1.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.ZeroHashedRandomness),
      )
    })

    it('Should handle batch purchase with insufficient balance', async function () {
      const { lotturaHubA, mockUSDT0A, walletClients } =
        await loadFixture(deploy)

      const newUser = walletClients[7]
      const maxUint256 = 2n ** 256n - 1n

      // Approve but don't mint (no balance)
      await mockUSDT0A.write.approve([lotturaHubA.address, maxUint256], {
        account: newUser.account,
      })

      // Try to purchase 10 tickets with no balance
      const numbersList: [number, number, number, number, number, number][] = []
      const hashesList: Hash[] = []
      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        numbersList.push([
          base,
          base + 1,
          base + 2,
          base + 3,
          base + 4,
          base + 5,
        ])
        hashesList.push(
          pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 }),
        )
      }

      await expect(
        lotturaHubA.write.purchaseTickets([numbersList, 1n, hashesList], {
          account: newUser.account,
        }),
      ).to.be.rejectedWith('ERC20InsufficientBalance')
    })

    it('Should calculate correct total price for batch purchase', async function () {
      const { mockUSDT0A, lotturaHubA, user1, TICKET_PRICE } =
        await loadFixture(deploy)

      const balanceBefore = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])

      // Purchase 5 tickets
      await lotturaHubA.write.purchaseTickets(
        [
          [
            [1, 2, 3, 4, 5, 6],
            [7, 8, 9, 10, 11, 12],
            [13, 14, 15, 16, 17, 18],
            [19, 20, 21, 22, 23, 24],
            [25, 26, 27, 28, 29, 30],
          ],
          1n,
          [
            pad('0x0000000000000000000000000000000000000001', { size: 32 }),
            pad('0x0000000000000000000000000000000000000002', { size: 32 }),
            pad('0x0000000000000000000000000000000000000003', { size: 32 }),
            pad('0x0000000000000000000000000000000000000004', { size: 32 }),
            pad('0x0000000000000000000000000000000000000005', { size: 32 }),
          ],
        ],
        { account: user1.account },
      )

      const balanceAfter = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])
      const totalPaid = balanceBefore - balanceAfter

      // Should pay exactly ticketPrice * 5
      expect(totalPaid).to.equal(TICKET_PRICE * 5n)
    })

    it('Should emit correct number of events for batch purchase', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      await lotturaHubA.write.purchaseTickets(
        [
          [
            [1, 2, 3, 4, 5, 6],
            [7, 8, 9, 10, 11, 12],
            [13, 14, 15, 16, 17, 18],
          ],
          1n,
          [
            pad('0x0000000000000000000000000000000000000001', { size: 32 }),
            pad('0x0000000000000000000000000000000000000002', { size: 32 }),
            pad('0x0000000000000000000000000000000000000003', { size: 32 }),
          ],
        ],
        { account: user1.account },
      )

      // Should emit 3 TokenPurchased events
      const hubEvents = await lotturaHubA.getEvents.TokenPurchased()
      expect(hubEvents.length).to.equal(3)

      // Should emit 3 TicketPurchased events from core
      const coreEvents = await lotturaCore.getEvents.TicketPurchased()
      expect(coreEvents.length).to.equal(3)

      // Should emit 3 RandomnessCommitted events
      const randomnessEvents = await lotturaCore.getEvents.RandomnessCommitted()
      expect(randomnessEvents.length).to.equal(3)
    })

    it('Should handle minimum valid numbers (all 1s)', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      // All different positions with value 1 is impossible, so test edge values
      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const events = await lotturaHubA.getEvents.TokenPurchased()
      expect(events.length).to.equal(1)
    })

    it('Should handle maximum valid numbers (all 50s)', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      // Can't have all 50s, but test high values
      await lotturaHubA.write.purchaseTickets(
        [
          [[45, 46, 47, 48, 49, 50]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const events = await lotturaHubA.getEvents.TokenPurchased()
      expect(events.length).to.equal(1)
    })

    it('Should handle sequential numbers', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const events = await lotturaHubA.getEvents.TokenPurchased()
      expect(events.length).to.equal(1)
    })

    it('Should handle non-sequential numbers', async function () {
      const { lotturaHubA, user1 } = await loadFixture(deploy)

      await lotturaHubA.write.purchaseTickets(
        [
          [[50, 1, 25, 13, 37, 42]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const events = await lotturaHubA.getEvents.TokenPurchased()
      expect(events.length).to.equal(1)
    })

    it('Should handle large number of tickets from same user', async function () {
      const { lotturaCore, lotturaHubA, user1 } = await loadFixture(deploy)

      const ticketCount = 20

      for (let i = 0; i < ticketCount; i++) {
        // Generate unique numbers for each ticket
        const base = (i * 6) % 45
        const numbers: [number, number, number, number, number, number] = [
          base + 1,
          base + 2,
          base + 3,
          base + 4,
          base + 5,
          base + 6,
        ]

        await lotturaHubA.write.purchaseTickets(
          [
            [numbers],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: user1.account },
        )
      }

      const draw = await lotturaCore.read.getDraw([1n])
      expect(draw.ticketsSold).to.equal(ticketCount) // ticketsSold
    })

    it('Should handle tickets from multiple users', async function () {
      const { lotturaCore, lotturaHubA, user1, user2, user3 } =
        await loadFixture(deploy)

      await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      await lotturaHubA.write.purchaseTickets(
        [
          [[7, 8, 9, 10, 11, 12]],
          1n,
          [pad('0x0000000000000000000000000000000000000002', { size: 32 })],
        ],
        { account: user2.account },
      )

      await lotturaHubA.write.purchaseTickets(
        [
          [[13, 14, 15, 16, 17, 18]],
          1n,
          [pad('0x0000000000000000000000000000000000000003', { size: 32 })],
        ],
        { account: user3.account },
      )

      const draw = await lotturaCore.read.getDraw([1n])
      expect(draw.ticketsSold).to.equal(3) // ticketsSold
    })
  })

  describe('Draw Execution', function () {
    async function deployWithTickets() {
      const fixture = await deploy()

      // Fund LotturaCore with native tokens for VRF
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase minimum required tickets (10)
      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      return fixture
    }

    it('Should execute draw after end time with enough tickets', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deployWithTickets)

      const draw = await lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)

      await lotturaCore.write.executeDraw([1n], { account: ownerA.account })

      const updatedDraw = await lotturaCore.read.getDraw([1n])
      expect(updatedDraw.status).to.equal(1) // status: DRAWING
    })

    it('Should reject draw execution before end time', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deployWithTickets)

      await expect(
        lotturaCore.write.executeDraw([1n], { account: ownerA.account }),
      ).to.be.rejectedWith('DrawNotEnded')
    })

    it('Should reject draw execution from non-operator', async function () {
      const { lotturaCore, user1 } = await loadFixture(deployWithTickets)

      const draw = await lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)

      await expect(
        lotturaCore.write.executeDraw([1n], { account: user1.account }),
      ).to.be.rejectedWith('AccessControlUnauthorizedAccount')
    })

    it('Should request VRF randomness', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deployWithTickets)

      const draw = await lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)

      await lotturaCore.write.executeDraw([1n], { account: ownerA.account })

      const updatedDraw = await lotturaCore.read.getDraw([1n])
      expect(updatedDraw.vrfRequestId).to.equal(1n) // First VRF request ID
    })

    it('Should emit DrawExecutionStarted event', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deployWithTickets)

      const draw = await lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)

      await lotturaCore.write.executeDraw([1n], { account: ownerA.account })

      const events = await lotturaCore.getEvents.DrawExecutionStarted()
      expect(events.length).to.equal(1)
      expect(events[0].args.drawId).to.equal(1n)
    })

    it('Should reject executing same draw twice', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deployWithTickets)

      const draw = await lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)

      await lotturaCore.write.executeDraw([1n], { account: ownerA.account })

      await expect(
        lotturaCore.write.executeDraw([1n], { account: ownerA.account }),
      ).to.be.rejectedWith('InvalidDrawStatus')
    })
  })

  describe('VRF Fulfillment and Winner Processing', function () {
    it('Should fulfill VRF, generate winning numbers, and emit event', async function () {
      const fixture = await loadFixture(deploy)

      // Fund LotturaCore with native tokens for VRF
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets
      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Execute draw
      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      // Get VRF request ID
      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId

      // Fulfill VRF with same instance
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      const updatedDraw = await fixture.lotturaCore.read.getDraw([1n])
      // Winning numbers should be [48, 11, 39, 9, 12, 49] = packed 481139091249
      expect(updatedDraw.winningNumbers).to.equal(481139091249n)
      expect(updatedDraw.status).to.equal(2) // status: PROCESSING_WINNERS

      // Check event was emitted
      const events = await fixture.lotturaCore.getEvents.DrawProcessingWinners()
      expect(events.length).to.equal(1)
    })

    it('Should reject VRF fulfillment from non-coordinator', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId

      await expect(
        fixture.lotturaCore.write.rawFulfillRandomWords(
          [vrfRequestId, [123456789n]],
          { account: fixture.user1.account },
        ),
      ).to.be.rejectedWith('OnlyVRFCoordinator')
    })
  })

  describe('Set Winning Tickets and Complete Draw', function () {
    async function setupDrawForCompletion(
      fixture: Awaited<ReturnType<typeof deploy>>,
    ) {
      // Fund LotturaCore with native tokens for VRF
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets
      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Execute draw
      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      // Fulfill VRF
      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])
    }

    it('Should set winning tickets counts and complete draw', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawForCompletion(fixture)

      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [1, 2, 3]], // 1 winner for 4 matches, 2 for 5, 3 for 6
        { account: fixture.ownerA.account },
      )

      const draw = await fixture.lotturaCore.read.getDraw([1n])
      expect(draw.status).to.equal(3) // status: COMPLETED
    })

    it('Should calculate prizes per winner correctly', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawForCompletion(fixture)

      // Get draw before setting winners
      const drawBefore = await fixture.lotturaCore.read.getDraw([1n])
      const prizePool = drawBefore.prizePool
      const rolloverAmounts = drawBefore.rolloverAmount

      // Calculate total prize pool including rollovers
      const totalPrizePool =
        prizePool + rolloverAmounts[0] + rolloverAmounts[1] + rolloverAmounts[2]

      // Get prize distribution percentages
      const distribution = await fixture.lotturaCore.read.prizeDistribution()

      // Set 1 winner per tier
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [1, 1, 1]], // 1 winner each tier (4, 5, 6 matches)
        { account: fixture.ownerA.account },
      )

      // Get draw after setting winners
      const drawAfter = await fixture.lotturaCore.read.getDraw([1n])

      // Calculate expected prizes per winner for each tier
      const expectedTier4Prize =
        (totalPrizePool * BigInt(distribution[0])) / 10000n / 1n // tier 4: 15% / 1 winner
      const expectedTier5Prize =
        (totalPrizePool * BigInt(distribution[1])) / 10000n / 1n // tier 5: 25% / 1 winner
      const expectedTier6Prize =
        (totalPrizePool * BigInt(distribution[2])) / 10000n / 1n // tier 6: 60% / 1 winner

      // Verify prizes per winner are calculated correctly
      expect(drawAfter.prizesPerWinner[0]).to.equal(expectedTier4Prize)
      expect(drawAfter.prizesPerWinner[1]).to.equal(expectedTier5Prize)
      expect(drawAfter.prizesPerWinner[2]).to.equal(expectedTier6Prize)

      // Verify draw completed status
      expect(drawAfter.status).to.equal(3) // status: COMPLETED

      // Verify DrawCompleted event was emitted
      const events = await fixture.lotturaCore.getEvents.DrawCompleted()
      expect(events.length).to.equal(1)
    })

    it('Should handle zero winners in a tier', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawForCompletion(fixture)

      // Should successfully complete draw even with zero winners in some tiers
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [0, 1, 2]], // No winners for tier 4
        { account: fixture.ownerA.account },
      )

      const draw = await fixture.lotturaCore.read.getDraw([1n])
      expect(draw.status).to.equal(3) // status: COMPLETED
    })

    it('Should emit DrawCompleted event', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawForCompletion(fixture)

      await fixture.lotturaCore.write.setWinningTicketsCounts([1n, [1, 2, 3]], {
        account: fixture.ownerA.account,
      })

      const events = await fixture.lotturaCore.getEvents.DrawCompleted()
      expect(events.length).to.equal(1)
    })

    it('Should create new draw after completion', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawForCompletion(fixture)

      await fixture.lotturaCore.write.setWinningTicketsCounts([1n, [1, 2, 3]], {
        account: fixture.ownerA.account,
      })

      const currentDrawId = await fixture.lotturaCore.read.currentDrawId()
      expect(currentDrawId).to.equal(2n)

      const newDraw = await fixture.lotturaCore.read.getDraw([2n])
      expect(newDraw.status).to.equal(0) // status: OPEN
    })

    it('Should reject from non-operator', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawForCompletion(fixture)

      await expect(
        fixture.lotturaCore.write.setWinningTicketsCounts([1n, [1, 2, 3]], {
          account: fixture.user1.account,
        }),
      ).to.be.rejectedWith('AccessControlUnauthorizedAccount')
    })

    it('Should reject if draw not in PROCESSING_WINNERS status', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.setWinningTicketsCounts([1n, [1, 2, 3]], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith('InvalidDrawStatus')
    })
  })

  describe('Prize Claims - Comprehensive', function () {
    /**
     * Setup function that creates a draw with KNOWN winning tickets
     * VRF Mock now returns FIXED winning numbers: [48, 11, 39, 9, 12, 49]
     * This makes testing predictable and reliable
     */
    async function setupWinningTickets(
      fixture: Awaited<ReturnType<typeof deploy>>,
    ) {
      // Fund LotturaCore with native tokens for VRF
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // FIXED WINNING NUMBERS: [48, 11, 39, 9, 12, 49]
      // Purchase tickets with known match counts for predictable testing
      const testTickets = [
        [48, 11, 39, 9, 12, 49], // 6 matches - JACKPOT
        [48, 11, 39, 9, 12, 50], // 5 matches - Tier 5
        [48, 11, 39, 9, 47, 50], // 4 matches - Tier 4
        [48, 11, 39, 46, 47, 50], // 3 matches - NO PRIZE
        [48, 11, 44, 45, 46, 47], // 2 matches - NO PRIZE
        [48, 2, 3, 4, 5, 6], // 1 match - NO PRIZE
        [1, 3, 5, 7, 13, 14], // 0 matches - NO PRIZE
        [13, 14, 15, 16, 17, 18], // 0 matches - NO PRIZE
        [19, 20, 21, 22, 23, 24], // 0 matches - NO PRIZE
        [25, 26, 28, 29, 31, 32], // 0 matches - NO PRIZE
      ]

      const tokenIds: bigint[] = []

      for (let i = 0; i < testTickets.length; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [
              testTickets[i] as [
                number,
                number,
                number,
                number,
                number,
                number,
              ],
            ],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Get token IDs
      const drawTickets = await fixture.lotturaCore.read.getDrawTicketsPage([
        1n,
        0n,
        10n,
      ])
      tokenIds.push(...drawTickets)

      // Execute draw
      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      // Fulfill VRF - this will generate FIXED winning numbers [48, 11, 39, 9, 12, 49]
      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      // Complete draw with winner counts
      // We know: 1 winner with 6 matches, 1 with 5 matches, 1 with 4 matches
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [1, 1, 1]], // 1 winner for each tier
        { account: fixture.ownerA.account },
      )

      return { ...fixture, tokenIds }
    }

    it('Should successfully claim prize for 6-match winning ticket (jackpot)', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaCore, lotturaHubA, mockUSDT0A, user1, tokenIds } =
        fixtureWithTokens

      // First ticket has 6 matches [48, 11, 39, 9, 12, 49]
      const tokenId = tokenIds[0]

      // Get user balance before claim
      const balanceBefore = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])

      // Get expected prize amount (60% of prize pool for tier 6)
      const draw = await lotturaCore.read.getDraw([1n])
      const expectedPrize = draw.prizesPerWinner[2] // Tier 6 (index 2)

      expect(expectedPrize).equal(27000000)

      // Claim the jackpot ticket
      await lotturaHubA.write.claimTicket([tokenId], {
        account: user1.account,
      })

      // Verify balance increased by exact prize amount
      const balanceAfter = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])
      expect(balanceAfter - balanceBefore).to.equal(expectedPrize)

      // Verify ticket status changed to PAID
      const ticketAfter = await lotturaCore.read.getTicket([tokenId])
      expect(ticketAfter.status).to.equal(1) // PAID

      // Verify PrizePaid event was emitted
      const events = await lotturaCore.getEvents.PrizePaid()
      expect(events.length).to.equal(1) // Exactly 1 event for this claim

      // Verify event contains correct token ID
      const event = events[0]

      expect(event.args.ticketId).to.equal(tokenId)
    })

    it('Should successfully claim prize for 5-match winning ticket', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaCore, lotturaHubA, mockUSDT0A, user1, tokenIds } =
        fixtureWithTokens

      // Second ticket has 5 matches [48, 11, 39, 9, 12, 50]
      const tokenId = tokenIds[1]

      const balanceBefore = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])

      // Get expected prize amount (25% of prize pool for tier 5)
      const draw = await lotturaCore.read.getDraw([1n])
      const expectedPrize = draw.prizesPerWinner[1] // Tier 5 (index 1)

      expect(expectedPrize).equal(11250000)

      await lotturaHubA.write.claimTicket([tokenId], {
        account: user1.account,
      })

      const balanceAfter = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])
      expect(balanceAfter - balanceBefore).to.equal(expectedPrize)

      const ticketAfter = await lotturaCore.read.getTicket([tokenId])
      expect(ticketAfter.status).to.equal(1) // PAID
    })

    it('Should successfully claim prize for 4-match winning ticket', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaCore, lotturaHubA, mockUSDT0A, user1, tokenIds } =
        fixtureWithTokens

      // Third ticket has 4 matches [48, 11, 39, 9, 47, 50]
      const tokenId = tokenIds[2]

      const balanceBefore = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])

      // Get expected prize amount (15% of prize pool for tier 4)
      const draw = await lotturaCore.read.getDraw([1n])
      const expectedPrize = draw.prizesPerWinner[0] // Tier 4 (index 0)

      expect(expectedPrize).equal(6750000)

      await lotturaHubA.write.claimTicket([tokenId], {
        account: user1.account,
      })

      const balanceAfter = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])
      expect(balanceAfter - balanceBefore).to.equal(expectedPrize)

      const ticketAfter = await lotturaCore.read.getTicket([tokenId])
      expect(ticketAfter.status).to.equal(1) // PAID
    })

    it('Should calculate and distribute prizes correctly for multiple tiers', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaCore } = fixtureWithTokens

      // Get draw info
      const draw = await lotturaCore.read.getDraw([1n])
      const prizePool = draw.prizePool
      const rolloverAmounts = draw.rolloverAmount
      const totalPrizePool =
        prizePool + rolloverAmounts[0] + rolloverAmounts[1] + rolloverAmounts[2]

      // Get prize distribution
      const distribution = await lotturaCore.read.prizeDistribution()

      // Calculate expected prizes
      const expectedTier4 = (totalPrizePool * BigInt(distribution[0])) / 10000n
      const expectedTier5 = (totalPrizePool * BigInt(distribution[1])) / 10000n
      const expectedTier6 = (totalPrizePool * BigInt(distribution[2])) / 10000n

      // Verify total distribution equals 100%
      const totalDistribution =
        BigInt(distribution[0]) +
        BigInt(distribution[1]) +
        BigInt(distribution[2])
      expect(totalDistribution).to.equal(10000n) // 100%

      // Verify prizes per winner are set correctly
      expect(draw.prizesPerWinner[0]).to.equal(expectedTier4 / 1n) // 1 winner
      expect(draw.prizesPerWinner[1]).to.equal(expectedTier5 / 1n) // 1 winner
      expect(draw.prizesPerWinner[2]).to.equal(expectedTier6 / 1n) // 1 winner

      // Verify sum of all prizes equals total prize pool
      const totalPrizesDistributed =
        draw.prizesPerWinner[0] +
        draw.prizesPerWinner[1] +
        draw.prizesPerWinner[2]
      expect(totalPrizesDistributed).to.equal(totalPrizePool)
    })

    it('Should track winners correctly after all claims', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaCore, lotturaHubA, mockUSDT0A, user1, tokenIds } =
        fixtureWithTokens

      // Get initial balance
      const balanceBefore = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])

      // Get expected total prize amount (all 3 tiers)
      const draw = await lotturaCore.read.getDraw([1n])
      const expectedTotalPrize =
        draw.prizesPerWinner[0] + // Tier 4
        draw.prizesPerWinner[1] + // Tier 5
        draw.prizesPerWinner[2] // Tier 6

      // Claim all 3 winning tickets (indices 0, 1, 2)
      await lotturaHubA.write.claimTicket([tokenIds[0]], {
        account: user1.account,
      })

      await lotturaHubA.write.claimTicket([tokenIds[1]], {
        account: user1.account,
      })

      await lotturaHubA.write.claimTicket([tokenIds[2]], {
        account: user1.account,
      })

      // Verify balance increased by exact total prize amount
      const balanceAfter = await mockUSDT0A.read.balanceOf([
        user1.account.address,
      ])
      expect(balanceAfter - balanceBefore).to.equal(expectedTotalPrize)

      // Verify all 3 tickets are now PAID
      const ticket0 = await lotturaCore.read.getTicket([tokenIds[0]])
      const ticket1 = await lotturaCore.read.getTicket([tokenIds[1]])
      const ticket2 = await lotturaCore.read.getTicket([tokenIds[2]])

      expect(ticket0.status).to.equal(1) // PAID
      expect(ticket1.status).to.equal(1) // PAID
      expect(ticket2.status).to.equal(1) // PAID
    })

    it('Should reject double claim of same ticket', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaHubA, user1, tokenIds } = fixtureWithTokens

      // Claim the jackpot ticket
      const tokenId = tokenIds[0]
      await lotturaHubA.write.claimTicket([tokenId], {
        account: user1.account,
      })

      // Try to claim it again - should fail
      await expect(
        lotturaHubA.write.claimTicket([tokenId], {
          account: user1.account,
        }),
      ).to.be.rejectedWith('InvalidTicketStatus')
    })

    it('Should reject claim of non-winning ticket (3 matches)', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaHubA, user1, tokenIds } = fixtureWithTokens

      // Fourth ticket has only 3 matches [48, 11, 39, 46, 47, 50] - NO PRIZE
      const tokenId = tokenIds[3]

      await expect(
        lotturaHubA.write.claimTicket([tokenId], {
          account: user1.account,
        }),
      ).to.be.rejectedWith('TicketNotWon')
    })

    it('Should reject claim of non-winning ticket (0 matches)', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaHubA, user1, tokenIds } = fixtureWithTokens

      // Seventh ticket has 0 matches [1, 3, 5, 7, 9, 11] - NO PRIZE
      const tokenId = tokenIds[6]

      await expect(
        lotturaHubA.write.claimTicket([tokenId], {
          account: user1.account,
        }),
      ).to.be.rejectedWith('TicketNotWon')
    })

    it('Should emit PrizePaid event with correct details', async function () {
      const fixtureWithTokens = await setupWinningTickets(
        await loadFixture(deploy),
      )
      const { lotturaCore, lotturaHubA, user1, tokenIds } = fixtureWithTokens

      // Get expected prize amount
      const draw = await lotturaCore.read.getDraw([1n])
      const expectedPrize = draw.prizesPerWinner[2] // Tier 6 (index 2)

      // Claim jackpot ticket
      const tokenId = tokenIds[0]
      await lotturaHubA.write.claimTicket([tokenId], {
        account: user1.account,
      })

      // Get the PrizePaid event
      const events = await lotturaCore.getEvents.PrizePaid()
      expect(events.length).to.equal(1) // Exactly 1 event for this claim

      const event = events[events.length - 1] // Get most recent event

      // Verify event details with precise values
      expect(event.args.ticketId).to.equal(tokenId)

      if (event.args.winner) {
        expect(event.args.winner.toLowerCase()).to.equal(
          user1.account.address.toLowerCase(),
        )
      }
      if (event.args.amount) {
        expect(event.args.amount).to.equal(expectedPrize) // Exact prize amount
      }
      if (event.args.tier !== undefined) {
        // Tier is the tierIndex (0, 1, or 2) for 4, 5, 6 matches respectively
        // For 6 matches (jackpot), tierIndex = 6 - 4 = 2
        expect(event.args.tier).to.equal(2)
      }
    })

    it('Should handle prize claims with different tier winners', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets with known winning numbers [48, 11, 39, 9, 12, 49]
      const tickets = [
        [48, 11, 39, 9, 47, 50], // 4 matches - Tier 4
        [48, 11, 39, 9, 46, 47], // 4 matches - Tier 4
        [48, 11, 39, 9, 12, 50], // 5 matches - Tier 5
        [48, 11, 39, 9, 12, 47], // 5 matches - Tier 5
        [48, 11, 39, 9, 12, 46], // 5 matches - Tier 5
        [48, 11, 39, 9, 12, 49], // 6 matches - Tier 6 (jackpot)
        [1, 3, 5, 7, 13, 14], // No matches
        [13, 14, 15, 16, 17, 18], // No matches
        [19, 20, 21, 22, 23, 24], // No matches
        [25, 26, 28, 29, 31, 32], // No matches
      ]

      for (let i = 0; i < tickets.length; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [tickets[i] as [number, number, number, number, number, number]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Execute and complete draw
      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      // Set multiple winners in different tiers
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [2, 3, 1]], // 2 winners tier 4, 3 winners tier 5, 1 winner tier 6
        { account: fixture.ownerA.account },
      )

      const completedDraw = await fixture.lotturaCore.read.getDraw([1n])

      // Verify prizes per winner are divided correctly
      const prizePool = completedDraw.prizePool
      const distribution = await fixture.lotturaCore.read.prizeDistribution()

      const tier4Pool = (prizePool * BigInt(distribution[0])) / 10000n
      const tier5Pool = (prizePool * BigInt(distribution[1])) / 10000n
      const tier6Pool = (prizePool * BigInt(distribution[2])) / 10000n

      const expectedTier4Prize = tier4Pool / 2n // 2 winners
      const expectedTier5Prize = tier5Pool / 3n // 3 winners
      const expectedTier6Prize = tier6Pool / 1n // 1 winner

      expect(completedDraw.prizesPerWinner[0]).to.equal(expectedTier4Prize)
      expect(completedDraw.prizesPerWinner[1]).to.equal(expectedTier5Prize)
      expect(completedDraw.prizesPerWinner[2]).to.equal(expectedTier6Prize)

      // Get all token IDs from draw 1
      const tokenIds = await fixture.lotturaCore.read.getDrawTicketsPage([
        1n,
        0n,
        10n,
      ])

      // Get initial balance
      const initialBalance = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user1.account.address,
      ])

      // Claim all winning tickets and track amounts
      let totalClaimedAmount = 0n
      let tier4Claims = 0
      let tier5Claims = 0
      let tier6Claims = 0

      // Claim first two tickets (Tier 4 - 4 matches each)
      for (let i = 0; i < 2; i++) {
        const balanceBefore = await fixture.mockUSDT0A.read.balanceOf([
          fixture.user1.account.address,
        ])

        await fixture.lotturaHubA.write.claimTicket([tokenIds[i]], {
          account: fixture.user1.account,
        })

        const balanceAfter = await fixture.mockUSDT0A.read.balanceOf([
          fixture.user1.account.address,
        ])

        const claimedAmount = balanceAfter - balanceBefore

        expect(claimedAmount).to.equal(expectedTier4Prize)

        expect(claimedAmount).to.equal(3375000)

        totalClaimedAmount += claimedAmount

        tier4Claims++
      }

      expect(totalClaimedAmount).to.equal(6750000)

      // Claim next three tickets (Tier 5 - 5 matches each)
      for (let i = 2; i < 5; i++) {
        const balanceBefore = await fixture.mockUSDT0A.read.balanceOf([
          fixture.user1.account.address,
        ])

        await fixture.lotturaHubA.write.claimTicket([tokenIds[i]], {
          account: fixture.user1.account,
        })

        const balanceAfter = await fixture.mockUSDT0A.read.balanceOf([
          fixture.user1.account.address,
        ])

        const claimedAmount = balanceAfter - balanceBefore

        expect(claimedAmount).to.equal(expectedTier5Prize)

        expect(expectedTier5Prize).to.equal(3750000)

        totalClaimedAmount += claimedAmount

        tier5Claims++
      }

      expect(totalClaimedAmount).to.equal(6750000 + 11250000)

      // Claim jackpot ticket (Tier 6 - 6 matches)
      const balanceBefore = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user1.account.address,
      ])

      await fixture.lotturaHubA.write.claimTicket([tokenIds[5]], {
        account: fixture.user1.account,
      })

      const balanceAfter = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user1.account.address,
      ])

      const claimedAmount = balanceAfter - balanceBefore

      expect(claimedAmount).to.equal(expectedTier6Prize)

      expect(expectedTier6Prize).to.equal(27000000)

      totalClaimedAmount += claimedAmount

      tier6Claims++

      expect(totalClaimedAmount).to.equal(6750000 + 11250000 + 27000000)

      // Verify final balance equals initial + all prizes
      const finalBalance = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user1.account.address,
      ])
      expect(finalBalance - initialBalance).to.equal(totalClaimedAmount)

      // Verify total claimed equals sum of all expected prizes
      const expectedTotalPrize =
        expectedTier4Prize * 2n + // 2 tier 4 winners
        expectedTier5Prize * 3n + // 3 tier 5 winners
        expectedTier6Prize * 1n // 1 tier 6 winner

      expect(totalClaimedAmount).to.equal(expectedTotalPrize)

      // Verify claim counts
      expect(tier4Claims).to.equal(2)
      expect(tier5Claims).to.equal(3)
      expect(tier6Claims).to.equal(1)

      // Verify all winning tickets are now marked as PAID
      for (let i = 0; i < 6; i++) {
        const ticket = await fixture.lotturaCore.read.getTicket([tokenIds[i]])
        expect(ticket.status).to.equal(1) // TicketStatus.PAID
      }

      // Verify non-winning tickets cannot be claimed
      await expect(
        fixture.lotturaHubA.write.claimTicket([tokenIds[6]], {
          account: fixture.user1.account,
        }),
      ).to.be.rejectedWith('TicketNotWon')

      // Verify total distributed equals prize pool
      expect(totalClaimedAmount).to.equal(prizePool)
    })

    it('Should handle prize claims with rollover across multiple draws', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // ========== DRAW 1: Partial Winners (only Tier 6) ==========

      // Purchase 10 tickets for draw 1
      const draw1Tickets = [
        [48, 11, 39, 12, 9, 49], // 6 matches - Tier 6 (jackpot)
        [1, 3, 5, 7, 13, 14], // No matches
        [13, 14, 15, 16, 17, 18], // No matches
        [19, 20, 21, 22, 23, 24], // No matches
        [25, 26, 28, 29, 31, 32], // No matches
        [33, 34, 35, 36, 37, 38], // No matches
        [40, 41, 42, 43, 44, 45], // No matches
        [46, 47, 50, 1, 2, 3], // No matches
        [3, 4, 5, 6, 7, 8], // No matches
        [10, 13, 14, 15, 16, 17], // No matches
      ]

      for (let i = 0; i < draw1Tickets.length; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [
              draw1Tickets[i] as [
                number,
                number,
                number,
                number,
                number,
                number,
              ],
            ],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Execute and complete draw 1
      const draw1 = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw1.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      const draw1AfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId1 = draw1AfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId1,
        fixture.lotturaCore.address,
      ])

      // Set winners: only 1 winner in tier 6, tiers 4 and 5 roll over
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [0, 0, 1]], // 0 winners tier 4, 0 winners tier 5, 1 winner tier 6
        { account: fixture.ownerA.account },
      )

      const completedDraw1 = await fixture.lotturaCore.read.getDraw([1n])

      // Wait a bit to ensure draw 2 is created and open
      await time.increase(1)
      const prizePool1 = completedDraw1.prizePool
      const distribution = await fixture.lotturaCore.read.prizeDistribution()

      // Calculate draw 1 prizes
      const tier4Pool1 = (prizePool1 * BigInt(distribution[0])) / 10000n
      const tier5Pool1 = (prizePool1 * BigInt(distribution[1])) / 10000n
      const tier6Pool1 = (prizePool1 * BigInt(distribution[2])) / 10000n

      // Only tier 6 has a winner, so tier 4 and 5 should roll over
      const expectedRolloverTier4 = tier4Pool1

      expect(expectedRolloverTier4).to.equal(6750000n)

      const expectedRolloverTier5 = tier5Pool1

      expect(expectedRolloverTier5).to.equal(11250000n)

      expect(completedDraw1.rolloverAmount[0]).to.equal(0n)

      expect(completedDraw1.rolloverAmount[1]).to.equal(0n)

      expect(completedDraw1.rolloverAmount[2]).to.equal(0n)

      // Get all token IDs from draw 1
      const draw1TokenIds = await fixture.lotturaCore.read.getDrawTicketsPage([
        1n,
        0n,
        10n,
      ])

      const balanceBeforeDraw1Claim = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user1.account.address,
      ])

      await fixture.lotturaHubA.write.claimTicket([draw1TokenIds[0]], {
        account: fixture.user1.account,
      })

      const balanceAfterDraw1Claim = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user1.account.address,
      ])

      const draw1ClaimedAmount =
        balanceAfterDraw1Claim - balanceBeforeDraw1Claim
      expect(draw1ClaimedAmount).to.equal(tier6Pool1)

      // ========== DRAW 2: Multiple Winners with Rollover ==========

      // Purchase 10 tickets for draw 2
      const draw2Tickets = [
        [48, 11, 39, 9, 47, 50], // 4 matches - Tier 4
        [48, 11, 39, 46, 9, 47], // 4 matches - Tier 4
        [48, 11, 39, 9, 12, 50], // 5 matches - Tier 5
        [48, 11, 39, 9, 12, 47], // 5 matches - Tier 5
        [48, 11, 49, 9, 12, 39], // 6 matches - Tier 6 (jackpot)
        [1, 3, 5, 7, 13, 14], // No matches
        [13, 14, 15, 16, 17, 18], // No matches
        [19, 20, 21, 22, 23, 24], // No matches
        [25, 26, 28, 29, 31, 32], // No matches
        [33, 34, 35, 36, 37, 38], // No matches
      ]

      for (let i = 0; i < draw2Tickets.length; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [
              draw2Tickets[i] as [
                number,
                number,
                number,
                number,
                number,
                number,
              ],
            ],
            2n, // Draw 2
            [
              pad(`0x${(100 + i + 1).toString(16).padStart(64, '0')}`, {
                size: 32,
              }),
            ],
          ],
          { account: fixture.user2.account },
        )
      }

      // Execute and complete draw 2
      const draw2 = await fixture.lotturaCore.read.getDraw([2n])
      await time.increaseTo(Number(draw2.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([2n], {
        account: fixture.ownerA.account,
      })

      const draw2AfterExecution = await fixture.lotturaCore.read.getDraw([2n])
      const vrfRequestId2 = draw2AfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId2,
        fixture.lotturaCore.address,
      ])

      // Set winners: 2 tier 4, 2 tier 5, 1 tier 6
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [2n, [2, 2, 1]], // 2 winners tier 4, 2 winners tier 5, 1 winner tier 6
        { account: fixture.ownerA.account },
      )

      const completedDraw2 = await fixture.lotturaCore.read.getDraw([2n])

      expect(completedDraw2.prizePool).equal(45000000n)

      expect(completedDraw2.rolloverAmount[0]).to.equal(2700000)

      expect(completedDraw2.rolloverAmount[1]).to.equal(4500000)

      expect(completedDraw2.rolloverAmount[2]).to.equal(10800000n)

      const prizePool2 =
        completedDraw2.prizePool +
        completedDraw2.rolloverAmount[0] +
        completedDraw2.rolloverAmount[1] +
        completedDraw2.rolloverAmount[2]

      expect(prizePool2).to.equal(63000000n)

      // Get expected prizes from draw 2 (already calculated by contract)
      const expectedTier4Prize2 = completedDraw2.prizesPerWinner[0]
      const expectedTier5Prize2 = completedDraw2.prizesPerWinner[1]
      const expectedTier6Prize2 = completedDraw2.prizesPerWinner[2]

      // Verify prizes are set
      expect(expectedTier4Prize2).equal(4725000)
      expect(expectedTier5Prize2).equal(7875000)
      expect(expectedTier6Prize2).equal(37800000)

      // Get all token IDs from draw 2
      const draw2TokenIds = await fixture.lotturaCore.read.getDrawTicketsPage([
        2n,
        0n,
        10n,
      ])

      const initialBalanceUser2 = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user2.account.address,
      ])

      let totalClaimedDraw2 = 0n

      // Claim 2 tier 4 prizes
      for (let i = 0; i < 2; i++) {
        const balanceBefore = await fixture.mockUSDT0A.read.balanceOf([
          fixture.user2.account.address,
        ])

        await fixture.lotturaHubA.write.claimTicket([draw2TokenIds[i]], {
          account: fixture.user2.account,
        })

        const balanceAfter = await fixture.mockUSDT0A.read.balanceOf([
          fixture.user2.account.address,
        ])

        const claimedAmount = balanceAfter - balanceBefore
        expect(claimedAmount).to.equal(expectedTier4Prize2)
        totalClaimedDraw2 += claimedAmount
      }

      // Claim 2 tier 5 prizes
      for (let i = 2; i < 4; i++) {
        const balanceBefore = await fixture.mockUSDT0A.read.balanceOf([
          fixture.user2.account.address,
        ])

        await fixture.lotturaHubA.write.claimTicket([draw2TokenIds[i]], {
          account: fixture.user2.account,
        })

        const balanceAfter = await fixture.mockUSDT0A.read.balanceOf([
          fixture.user2.account.address,
        ])

        const claimedAmount = balanceAfter - balanceBefore
        expect(claimedAmount).to.equal(expectedTier5Prize2)
        totalClaimedDraw2 += claimedAmount
      }

      // Claim 1 tier 6 prize (jackpot)
      const balanceBeforeTier6 = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user2.account.address,
      ])

      await fixture.lotturaHubA.write.claimTicket([draw2TokenIds[4]], {
        account: fixture.user2.account,
      })

      const balanceAfterTier6 = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user2.account.address,
      ])

      const claimedTier6 = balanceAfterTier6 - balanceBeforeTier6
      expect(claimedTier6).to.equal(expectedTier6Prize2)
      totalClaimedDraw2 += claimedTier6

      // Verify total claimed in draw 2 equals prize pool + rollover
      const expectedTotalDraw2 =
        expectedTier4Prize2 * 2n +
        expectedTier5Prize2 * 2n +
        expectedTier6Prize2 * 1n

      expect(totalClaimedDraw2).to.equal(expectedTotalDraw2)

      // Verify final balance
      const finalBalanceUser2 = await fixture.mockUSDT0A.read.balanceOf([
        fixture.user2.account.address,
      ])
      expect(finalBalanceUser2 - initialBalanceUser2).to.equal(
        totalClaimedDraw2,
      )

      // Verify all winning tickets are marked as PAID
      for (let i = 0; i < 5; i++) {
        const ticket = await fixture.lotturaCore.read.getTicket([
          draw2TokenIds[i],
        ])
        expect(ticket.status).to.equal(1) // TicketStatus.PAID
      }

      const nextDraw = await fixture.lotturaCore.read.getDraw([3n])
      expect(nextDraw.id).to.equal(3n)

      expect(nextDraw.rolloverAmount[0]).to.equal(0n)
      expect(nextDraw.rolloverAmount[1]).to.equal(0n)
      expect(nextDraw.rolloverAmount[2]).to.equal(0n)
    })
  })

  describe('InvalidParams Validation - LotturaCore', function () {
    it('Should reject ZeroAddressImplementation on upgrade', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.upgradeToAndCall([zeroAddress, '0x'], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(
          LotturaCoreInvalidParams.ZeroAddressImplementation,
        ),
      )
    })

    it('Should reject ZeroDrawInterval', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.setDrawInterval([0], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.ZeroDrawInterval),
      )
    })

    it('Should reject SameDrawInterval', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      const config = await lotturaCore.read.getLotturaConfig()
      const currentInterval = config.drawInterval

      await expect(
        lotturaCore.write.setDrawInterval([currentInterval], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.SameDrawInterval),
      )
    })

    it('Should reject ZeroChainId in setHubAddress', async function () {
      const { lotturaCore, ownerA, lotturaHubA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.setHubAddress([0n, lotturaHubA.address], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.ZeroChainId),
      )
    })

    it('Should reject ZeroHubAddress in setHubAddress', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.setHubAddress(
          [1n, '0x0000000000000000000000000000000000000000'],
          {
            account: ownerA.account,
          },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.ZeroHubAddress),
      )
    })

    it('Should reject ZeroChainEid in setChainEidForChainId', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.setChainEidForChainId([1n, 0], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.ZeroChainEid),
      )
    })

    it('Should reject InvalidReserveAmount (zero)', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.allocateReserve([0n], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.InvalidReserveAmount),
      )
    })

    it('Should reject InvalidGasAmount (zero) in fundGas', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.fundGas({
          account: ownerA.account,
          value: 0n,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.InvalidGasAmount),
      )
    })

    it('Should reject ZeroAmount in tokensEmergencyWithdraw', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.tokensEmergencyWithdraw([0n], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.ZeroAmount),
      )
    })

    it('Should reject NotEnoughBalance in nativeEmergencyWithdraw', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      // Try to withdraw more than available
      const hugeAmount = parseEther('1000')

      await expect(
        lotturaCore.write.nativeEmergencyWithdraw([hugeAmount], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaCoreInvalidParams.NotEnoughBalance),
      )
    })
  })

  describe('InvalidParams Validation - LotturaHub', function () {
    it('Should reject ZeroAmount in fundGas', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.fundGas({
          account: ownerA.account,
          value: 0n,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.InvalidGasAmount),
      )
    })

    it('Should reject ZeroAmount in tokensEmergencyWithdraw', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.tokensEmergencyWithdraw([0n], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.ZeroAmount),
      )
    })

    it('Should reject NotEnoughBalance in nativeEmergencyWithdraw', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      const hugeAmount = parseEther('1000')

      await expect(
        lotturaHubA.write.nativeEmergencyWithdraw([hugeAmount], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.NotEnoughBalance),
      )
    })

    it('Should reject ZeroAddressImplementation on upgrade', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.upgradeToAndCall([zeroAddress, '0x'], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(
          LotturaHubInvalidParams.ZeroAddressImplementation,
        ),
      )
    })

    it('Should reject ZeroTicketPrice in updateTicketPrice', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.updateTicketPrice([0n], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.ZeroTicketPrice),
      )
    })

    it('Should reject ZeroAddressPaymentToken in updatePaymentToken', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.updatePaymentToken([zeroAddress], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(
          LotturaHubInvalidParams.ZeroAddressPaymentToken,
        ),
      )
    })

    it('Should reject ZeroAddressLotturaCore in updateLotturaCore', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.updateLotturaCore([zeroAddress, 1], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.ZeroAddressLotturaCore),
      )
    })

    it('Should reject ZeroLotturaCoreEid in updateLotturaCore', async function () {
      const { lotturaHubA, ownerA, lotturaCore } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.updateLotturaCore([lotturaCore.address, 0], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.ZeroLotturaCoreEid),
      )
    })

    it('Should reject ZeroAddressTicketNFT in updateTicketNFT', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.updateTicketNFT([zeroAddress], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.ZeroAddressTicketNFT),
      )
    })

    it('Should reject NoTickets (empty array)', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [], // Empty array - no tickets
            1n,
            [],
          ],
          { account: ownerA.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.NoTickets),
      )
    })

    it('Should reject ArrayLengthMismatch', async function () {
      const { lotturaHubA, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaHubA.write.purchaseTickets(
          [
            [
              [1, 2, 3, 4, 5, 6],
              [7, 8, 9, 10, 11, 12],
            ], // 2 tickets
            1n,
            [pad('0x0000000000000000000000000000000000000001', { size: 32 })], // Only 1 hash
          ],
          { account: ownerA.account },
        ),
      ).to.be.rejectedWith(
        formatInvalidParamError(LotturaHubInvalidParams.ArrayLengthMismatch),
      )
    })

    // Note: TicketNumbersOutOfRange, TicketNumbersDuplicate, DrawIdZero,
    // ZeroHashedRandomness are already tested in "Ticket Purchase - Validation"
  })

  describe('Admin Functions', function () {
    it('Should update draw interval', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      const newInterval = 14 * 24 * 60 * 60 // 14 days

      await lotturaCore.write.setDrawInterval([newInterval], {
        account: ownerA.account,
      })

      const config = await lotturaCore.read.getLotturaConfig()
      expect(config.drawInterval).to.equal(newInterval)
    })

    it('Should update prize distribution', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      const newDistribution: [number, number, number] = [2000, 3000, 5000] // 20%, 30%, 50%

      await lotturaCore.write.setPrizeDistribution([newDistribution], {
        account: ownerA.account,
      })

      const distribution = await lotturaCore.read.prizeDistribution()
      expect(distribution[0]).to.equal(2000)
      expect(distribution[1]).to.equal(3000)
      expect(distribution[2]).to.equal(5000)
    })

    it('Should reject invalid prize distribution (not 100%)', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      const invalidDistribution: [number, number, number] = [2000, 3000, 4000] // Only 90%

      await expect(
        lotturaCore.write.setPrizeDistribution([invalidDistribution], {
          account: ownerA.account,
        }),
      ).to.be.rejectedWith('InvalidPrizeDistribution')
    })

    it('Should withdraw commission', async function () {
      const { lotturaCore, mockUSDT0A, lotturaHubA, user1, ownerA } =
        await loadFixture(deploy)

      // Purchase tickets to generate commission
      for (let i = 0; i < 5; i++) {
        const base = i * 6 + 1
        await lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: user1.account },
        )
      }

      await lotturaCore.write.withdrawCommission({ account: ownerA.account })

      const balanceAfter = await mockUSDT0A.read.balanceOf([
        ownerA.account.address,
      ])

      expect(balanceAfter).to.equal(2500000)
    })

    it('Should reject commission withdrawal when none available', async function () {
      const { lotturaCore, ownerA } = await loadFixture(deploy)

      await expect(
        lotturaCore.write.withdrawCommission({ account: ownerA.account }),
      ).to.be.rejectedWith('NoCommissionAvailable')
    })
  })

  describe('Prize Claims', function () {
    async function setupCompletedDraw(
      fixture: Awaited<ReturnType<typeof deploy>>,
    ) {
      // Fund LotturaCore with native tokens for VRF
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets with known numbers
      const testTickets = [
        [1, 2, 3, 4, 5, 6],
        [1, 2, 3, 4, 5, 7],
        [1, 2, 3, 4, 8, 9],
        [1, 2, 3, 10, 11, 12],
        [1, 2, 13, 14, 15, 16],
        [1, 17, 18, 19, 20, 21],
        [22, 23, 24, 25, 26, 27],
        [28, 29, 30, 31, 32, 33],
        [34, 35, 36, 37, 38, 39],
        [40, 41, 42, 43, 44, 45],
      ]

      for (let i = 0; i < testTickets.length; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [
              testTickets[i] as [
                number,
                number,
                number,
                number,
                number,
                number,
              ],
            ],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Execute draw
      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      // Fulfill VRF
      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      // Complete draw with winner counts
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [1, 1, 1]], // 1 winner for each tier (4, 5, 6 matches)
        { account: fixture.ownerA.account },
      )
    }

    it('Should reject claim before draw is completed', async function () {
      const fixture = await deploy()

      await fixture.lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: fixture.user1.account },
      )

      const drawTickets = await fixture.lotturaCore.read.getDrawTicketsPage([
        1n,
        0n,
        10n,
      ])
      const tokenId = drawTickets[0]

      // Try to claim before draw is completed
      await expect(
        fixture.lotturaHubA.write.claimTicket([tokenId], {
          account: fixture.user1.account,
        }),
      ).to.be.rejectedWith('InvalidDrawStatus')
    })

    it('Should reject claim from non-owner', async function () {
      const fixture = await loadFixture(deploy)
      await setupCompletedDraw(fixture)

      const drawTickets = await fixture.lotturaCore.read.getDrawTicketsPage([
        1n,
        0n,
        10n,
      ])
      const tokenId = drawTickets[0]

      await expect(
        fixture.lotturaHubA.write.claimTicket([tokenId], {
          account: fixture.user2.account,
        }),
      ).to.be.rejectedWith('NotTokenOwner')
    })

    it('Should reject execution of invalid draw', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      const draw = await fixture.lotturaCore.read.getDraw([1n])

      await time.increaseTo(Number(draw.endTime) + 1)

      await expect(
        fixture.lotturaCore.write.executeDraw([2n], {
          account: fixture.ownerA.account,
        }),
      ).to.be.rejectedWith('InvalidDrawStatus')
    })
  })

  describe('Rollover Mechanism', function () {
    async function setupDrawWithNoWinners(
      fixture: Awaited<ReturnType<typeof deploy>>,
    ) {
      // Fund LotturaCore with native tokens for VRF
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets
      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Execute draw
      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      // Fulfill VRF
      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      // Complete draw with NO winners
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [0, 0, 0]], // No winners in any tier
        { account: fixture.ownerA.account },
      )
    }

    it('Should rollover prize pool when no winners exist', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawWithNoWinners(fixture)

      // Check first draw
      const draw1 = await fixture.lotturaCore.read.getDraw([1n])
      const prizePool1 = draw1.prizePool

      // Prize pool should be 90% of (10 tickets × ticket price)
      const TICKET_PRICE = 5000000n // 5 USDT (6 decimals)
      const expectedPrizePool = (10n * TICKET_PRICE * 9000n) / 10000n
      expect(prizePool1).to.equal(expectedPrizePool)

      // Check RolloverAdded events were emitted
      const rolloverEvents = await fixture.lotturaCore.getEvents.RolloverAdded()
      expect(rolloverEvents.length).to.equal(3) // One for each tier

      // Verify rollover amounts equal the full prize pool (no winners)
      let totalRollover = 0n
      for (const event of rolloverEvents) {
        if (event.args.amount) {
          totalRollover += event.args.amount
        }
      }
      expect(totalRollover).to.equal(prizePool1) // All prizes rolled over
    })

    it('Should emit RolloverAdded events', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawWithNoWinners(fixture)

      const events = await fixture.lotturaCore.getEvents.RolloverAdded()

      // Should have 3 events (one for each tier: 4, 5, 6 matches)
      expect(events.length).to.equal(3)
    })

    it('Should distribute rollover proportionally across tiers', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawWithNoWinners(fixture)

      const draw1 = await fixture.lotturaCore.read.getDraw([1n])
      const prizePool1 = draw1.prizePool

      // Get prize distribution percentages (15%, 25%, 60%)
      const distribution = await fixture.lotturaCore.read.prizeDistribution()

      // Calculate expected rollover per tier
      const expectedTier4 = (prizePool1 * BigInt(distribution[0])) / 10000n
      const expectedTier5 = (prizePool1 * BigInt(distribution[1])) / 10000n
      const expectedTier6 = (prizePool1 * BigInt(distribution[2])) / 10000n

      // Verify via RolloverAdded events
      const rolloverEvents = await fixture.lotturaCore.getEvents.RolloverAdded()
      expect(rolloverEvents.length).to.equal(3)

      // Events should contain the expected tier amounts
      const amounts = rolloverEvents.map((e) => e.args.amount || 0n)
      const totalRollover = amounts.reduce((a, b) => a + b, 0n)
      const expectedTotal = expectedTier4 + expectedTier5 + expectedTier6
      expect(totalRollover).to.equal(expectedTotal)
    })

    it('Should handle partial winners with rollover', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets
      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      // Complete draw with only tier 6 winner (tiers 4 and 5 should rollover)
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [0, 0, 1]], // Only 1 winner in tier 6
        { account: fixture.ownerA.account },
      )

      // Check RolloverAdded events - tiers 4 and 5 should have rollover
      const rolloverEvents = await fixture.lotturaCore.getEvents.RolloverAdded()

      // With 1 winner in tier 6, tiers 4 and 5 should rollover
      // There might be a small rounding amount from tier 6 as well
      expect(rolloverEvents.length).to.be.greaterThanOrEqual(2)
      expect(rolloverEvents.length).to.be.lessThanOrEqual(3)
    })

    it('Should accumulate rollover across multiple draws', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('2'),
      })

      // First draw with no winners
      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      let draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      let drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      let vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [0, 0, 0]], // No winners
        { account: fixture.ownerA.account },
      )

      // Second draw with no winners (should accumulate)
      for (let i = 0; i < 10; i++) {
        const base = (((i + 10) * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            2n,
            [pad(`0x${(i + 11).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      draw = await fixture.lotturaCore.read.getDraw([2n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([2n], {
        account: fixture.ownerA.account,
      })

      drawAfterExecution = await fixture.lotturaCore.read.getDraw([2n])
      vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [2n, [0, 0, 0]], // No winners again
        { account: fixture.ownerA.account },
      )

      // Verify rollover events were emitted for second draw
      const rolloverEventsAfterDraw2 =
        await fixture.lotturaCore.getEvents.RolloverAdded()
      // Should have 6 events total (3 from draw 1 + 3 from draw 2)
      // But may have fewer if some tiers had zero amounts
      expect(rolloverEventsAfterDraw2.length).to.be.greaterThanOrEqual(3)
      expect(rolloverEventsAfterDraw2.length).to.be.lessThanOrEqual(6)

      // Verify third draw was created (currentDrawId should be 3)
      const currentDrawId = await fixture.lotturaCore.read.currentDrawId()
      expect(currentDrawId).to.equal(3n)
    })

    it('Should calculate correct total prize pool with rollover', async function () {
      const fixture = await loadFixture(deploy)
      await setupDrawWithNoWinners(fixture)

      // Get draw 1 prize pool (completed with no winners)
      const draw1 = await fixture.lotturaCore.read.getDraw([1n])
      const prizePool1 = draw1.prizePool

      // Draw 2 should have rollover amounts from draw 1
      /*const draw2 = await fixture.lotturaCore.read.getDraw([2n])
      const rolloverAmounts = draw2.rolloverAmount
      const totalRollover =
        rolloverAmounts[0] + rolloverAmounts[1] + rolloverAmounts[2]*/

      // Verify draw 1 had a prize pool
      const TICKET_PRICE = 5000000n // 5 USDT
      const expectedPrizePool1 = (10n * TICKET_PRICE * 9000n) / 10000n
      expect(prizePool1).to.equal(expectedPrizePool1)

      // Verify rollover was calculated (stored in events)
      // Note: rolloverAmount in draw struct may be 0 until tickets are purchased in draw 2
      // The rollover is tracked via RolloverAdded events
      const rolloverEvents = await fixture.lotturaCore.getEvents.RolloverAdded()
      expect(rolloverEvents.length).to.equal(3) // One for each tier

      // Calculate total rollover from events
      let totalRolloverFromEvents = 0n
      for (const event of rolloverEvents) {
        if (event.args.amount) {
          totalRolloverFromEvents += event.args.amount
        }
      }
      expect(totalRolloverFromEvents).to.equal(prizePool1)
    })

    it('Should not rollover if all prizes are claimed', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      for (let i = 0; i < 10; i++) {
        const base = ((i * 6) % 45) + 1
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[base, base + 1, base + 2, base + 3, base + 4, base + 5]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      const vrfRequestId = drawAfterExecution.vrfRequestId
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        vrfRequestId,
        fixture.lotturaCore.address,
      ])

      // Set winners that would claim all prizes
      await fixture.lotturaCore.write.setWinningTicketsCounts(
        [1n, [3, 3, 4]], // Multiple winners in each tier
        { account: fixture.ownerA.account },
      )

      // Check rollover events - should be minimal or zero
      const rolloverEvents = await fixture.lotturaCore.getEvents.RolloverAdded()
      let totalRollover = 0n
      for (const event of rolloverEvents) {
        if (event.args.amount) {
          totalRollover += event.args.amount
        }
      }

      // With many winners, most of the prize pool should be distributed
      // Some small amount might rollover due to rounding
      expect(totalRollover).to.be.lessThan(parseUnits('1', 6)) // Less than 1 USDT
    })
  })

  describe('Gas Optimization', function () {
    it('Should use reasonable gas for ticket purchase', async function () {
      const { lotturaHubA, user1, publicClient } = await loadFixture(deploy)

      const hash = await lotturaHubA.write.purchaseTickets(
        [
          [[1, 2, 3, 4, 5, 6]],
          1n,
          [pad('0x0000000000000000000000000000000000000001', { size: 32 })],
        ],
        { account: user1.account },
      )

      const receipt = await publicClient.waitForTransactionReceipt({ hash })
      console.log('Gas used for ticket purchase:', receipt.gasUsed)

      // Ensure gas usage is reasonable (adjust threshold as needed)
      expect(receipt.gasUsed).to.be.lessThan(1000000n)
    })
  })

  describe('Emergency Withdraw Functions', function () {
    it('Should successfully withdraw native tokens (nativeEmergencyWithdraw)', async function () {
      const fixture = await loadFixture(deploy)

      // Send some native tokens to LotturaCore using fundGas
      const depositAmount = parseEther('5')
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: depositAmount,
      })

      // Verify balance before withdrawal
      const balanceBefore = await fixture.publicClient.getBalance({
        address: fixture.lotturaCore.address,
      })
      expect(balanceBefore).to.be.greaterThanOrEqual(depositAmount)

      // Get owner balance before
      const ownerBalanceBefore = await fixture.publicClient.getBalance({
        address: fixture.ownerA.account.address,
      })

      // Withdraw 2 ETH
      const withdrawAmount = parseEther('2')
      await fixture.lotturaCore.write.nativeEmergencyWithdraw(
        [withdrawAmount],
        {
          account: fixture.ownerA.account,
        },
      )

      // Verify contract balance decreased
      const balanceAfter = await fixture.publicClient.getBalance({
        address: fixture.lotturaCore.address,
      })
      expect(balanceBefore - balanceAfter).to.equal(withdrawAmount)

      const ownerBalanceAfter = await fixture.publicClient.getBalance({
        address: fixture.ownerA.account.address,
      })

      expect(ownerBalanceAfter - ownerBalanceBefore).greaterThan(0n)

      // Verify NativeEmergencyWithdraw event was emitted
      const events =
        await fixture.lotturaCore.getEvents.NativeEmergencyWithdraw()
      expect(events.length).to.be.greaterThanOrEqual(1)
      const lastEvent = events[events.length - 1]
      expect(lastEvent.args.owner?.toLowerCase()).to.equal(
        fixture.ownerA.account.address.toLowerCase(),
      )
      expect(lastEvent.args.nativeAmount).to.equal(withdrawAmount)
    })

    it('Should successfully withdraw tokens (tokensEmergencyWithdraw)', async function () {
      const fixture = await loadFixture(deploy)

      // LotturaCore needs USDT - simulate by having users purchase tickets
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets to get USDT into the system
      for (let i = 0; i < 10; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6 + i]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Check LotturaCore USDT balance
      const balanceBefore = await fixture.mockUSDT0A.read.balanceOf([
        fixture.lotturaCore.address,
      ])
      expect(balanceBefore).equal(50000000n)

      // Get owner balance before
      const ownerBalanceBefore = await fixture.mockUSDT0A.read.balanceOf([
        fixture.ownerA.account.address,
      ])

      // Withdraw half of the balance
      const withdrawAmount = balanceBefore / 2n
      await fixture.lotturaCore.write.tokensEmergencyWithdraw(
        [withdrawAmount],
        {
          account: fixture.ownerA.account,
        },
      )

      // Verify contract balance decreased
      const balanceAfter = await fixture.mockUSDT0A.read.balanceOf([
        fixture.lotturaCore.address,
      ])
      expect(balanceBefore - balanceAfter).to.equal(withdrawAmount)

      // Verify owner received the tokens
      const ownerBalanceAfter = await fixture.mockUSDT0A.read.balanceOf([
        fixture.ownerA.account.address,
      ])
      expect(ownerBalanceAfter - ownerBalanceBefore).to.equal(withdrawAmount)

      // Verify TokensEmergencyWithdraw event was emitted
      const events =
        await fixture.lotturaCore.getEvents.TokensEmergencyWithdraw()
      expect(events.length).to.be.greaterThanOrEqual(1)
      const lastEvent = events[events.length - 1]
      expect(lastEvent.args.owner?.toLowerCase()).to.equal(
        fixture.ownerA.account.address.toLowerCase(),
      )
      expect(lastEvent.args.tokenAmount).to.equal(withdrawAmount)
    })
  })

  describe('Reserve Allocation', function () {
    it('Should successfully allocate reserve across 2 draws', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('2'),
      })

      // Mint USDT to ownerA for reserve allocation
      const ownerUSDT = parseUnits('500', 6) // 500 USDT
      await fixture.mockUSDT0A.write.mint([
        fixture.ownerA.account.address,
        ownerUSDT,
      ])

      // ========== DRAW 1 ==========

      // Allocate reserve to draw 1
      const reserveAmount1 = parseUnits('100', 6) // 100 USDT

      // Approve LotturaCore to spend tokens
      await fixture.mockUSDT0A.write.approve(
        [fixture.lotturaCore.address, reserveAmount1],
        { account: fixture.ownerA.account },
      )

      // Allocate reserve
      await fixture.lotturaCore.write.allocateReserve([reserveAmount1], {
        account: fixture.ownerA.account,
      })

      // Verify draw 1 rollover amounts were updated (reserve is distributed across tiers)
      const draw1 = await fixture.lotturaCore.read.getDraw([1n])
      const totalRollover1 =
        draw1.rolloverAmount[0] +
        draw1.rolloverAmount[1] +
        draw1.rolloverAmount[2]
      expect(totalRollover1).to.equal(reserveAmount1)

      expect(totalRollover1).to.equal(100000000n)

      // Purchase tickets for draw 1 (minimum 10 required)
      for (let i = 0; i < 10; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6 + i]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Complete draw 1
      await time.increaseTo(Number(draw1.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      const draw1AfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        draw1AfterExecution.vrfRequestId,
        fixture.lotturaCore.address,
      ])

      await fixture.lotturaCore.write.setWinningTicketsCounts([1n, [0, 0, 0]], {
        account: fixture.ownerA.account,
      })

      // Verify draw 1 completed successfully
      const draw1Completed = await fixture.lotturaCore.read.getDraw([1n])
      expect(draw1Completed.status).to.equal(3) // COMPLETED

      // ========== DRAW 2 ==========

      await time.increase(1)

      // Allocate reserve to draw 2
      const reserveAmount2 = parseUnits('200', 6) // 200 USDT

      // Approve LotturaCore to spend tokens
      await fixture.mockUSDT0A.write.approve(
        [fixture.lotturaCore.address, reserveAmount2],
        { account: fixture.ownerA.account },
      )

      const draw2BeforeAllocation = await fixture.lotturaCore.read.getDraw([2n])

      expect(
        draw2BeforeAllocation.rolloverAmount[0] +
          draw2BeforeAllocation.rolloverAmount[1] +
          draw2BeforeAllocation.rolloverAmount[2],
      ).to.equal(145000000n)

      // Allocate reserve
      await fixture.lotturaCore.write.allocateReserve([reserveAmount2], {
        account: fixture.ownerA.account,
      })

      // Verify draw 2 was created
      const draw2 = await fixture.lotturaCore.read.getDraw([2n])
      expect(draw2.status).to.equal(0) // OPEN

      // Purchase tickets for draw 2 (minimum 10 required)
      for (let i = 0; i < 10; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[10, 11, 12, 13, 14, 15 + i]],
            2n,
            [
              pad(`0x${(100 + i + 1).toString(16).padStart(64, '0')}`, {
                size: 32,
              }),
            ],
          ],
          { account: fixture.user2.account },
        )
      }

      // Complete draw 2
      await time.increaseTo(Number(draw2.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([2n], {
        account: fixture.ownerA.account,
      })

      const draw2AfterExecution = await fixture.lotturaCore.read.getDraw([2n])
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        draw2AfterExecution.vrfRequestId,
        fixture.lotturaCore.address,
      ])

      await fixture.lotturaCore.write.setWinningTicketsCounts([2n, [0, 0, 0]], {
        account: fixture.ownerA.account,
      })

      // Verify draw 2 rollover amounts were updated (includes reserve + rollover from draw 1)
      const draw2AfterReserve = await fixture.lotturaCore.read.getDraw([2n])
      const totalRollover2AfterReserve =
        draw2AfterReserve.rolloverAmount[0] +
        draw2AfterReserve.rolloverAmount[1] +
        draw2AfterReserve.rolloverAmount[2]
      // Should be at least the reserve amount (may include rollover from draw 1)
      expect(totalRollover2AfterReserve).equal(345000000n)

      // Verify both draws received their reserve allocations
      const draw3 = await fixture.lotturaCore.read.getDraw([3n])

      // Draw 2 should have reserve allocation
      const draw3TotalRollover =
        draw3.rolloverAmount[0] +
        draw3.rolloverAmount[1] +
        draw3.rolloverAmount[2]
      expect(draw3TotalRollover).equal(390000000n)
    })
  })

  describe('Winners Pagination Functions', function () {
    async function setupDrawWithWinners(
      fixture: Awaited<ReturnType<typeof deploy>>,
    ) {
      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets with known winning numbers [48, 11, 39, 9, 12, 49]
      const tickets = [
        [48, 11, 39, 9, 1, 2], // 4 matches - Tier 4
        [48, 11, 39, 9, 3, 4], // 4 matches - Tier 4
        [48, 11, 39, 9, 5, 6], // 4 matches - Tier 4
        [48, 11, 39, 9, 12, 1], // 5 matches - Tier 5
        [48, 11, 39, 9, 12, 2], // 5 matches - Tier 5
        [48, 11, 39, 9, 12, 49], // 6 matches - Tier 6 (jackpot)
        [48, 11, 39, 9, 12, 49], // 6 matches - Tier 6 (jackpot) - duplicate for 2nd winner
        [1, 3, 5, 7, 13, 15], // No matches
        [17, 19, 21, 23, 25, 27], // No matches
        [29, 31, 33, 35, 37, 41], // No matches
      ]

      for (let i = 0; i < tickets.length; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [tickets[i] as [number, number, number, number, number, number]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Execute and complete draw
      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        drawAfterExecution.vrfRequestId,
        fixture.lotturaCore.address,
      ])

      // Set winners: 3 tier 4, 2 tier 5, 2 tier 6
      await fixture.lotturaCore.write.setWinningTicketsCounts([1n, [3, 2, 2]], {
        account: fixture.ownerA.account,
      })

      // Claim all winning tickets to populate _winnersByTier mapping
      const tokenIds = await fixture.lotturaCore.read.getDrawTicketsPage([
        1n,
        0n,
        10n,
      ])

      // Claim first 7 tickets (all winners)
      for (let i = 0; i < 7; i++) {
        await fixture.lotturaHubA.write.claimTicket([tokenIds[i]], {
          account: fixture.user1.account,
        })
      }

      return fixture
    }

    it('Should return correct winner count for getWinnersByTierLength', async function () {
      const fixture = await setupDrawWithWinners(await loadFixture(deploy))

      // Check tier 4 (4 matches) - should have 3 winners
      const tier4Length = await fixture.lotturaCore.read.getWinnersByTierLength(
        [1n, 4],
      )
      expect(tier4Length).to.equal(3)

      // Check tier 5 (5 matches) - should have 2 winners
      const tier5Length = await fixture.lotturaCore.read.getWinnersByTierLength(
        [1n, 5],
      )
      expect(tier5Length).to.equal(2)

      // Check tier 6 (6 matches) - should have 2 winners
      const tier6Length = await fixture.lotturaCore.read.getWinnersByTierLength(
        [1n, 6],
      )
      expect(tier6Length).to.equal(2)

      // Verify total winners
      const totalWinners =
        Number(tier4Length) + Number(tier5Length) + Number(tier6Length)
      expect(totalWinners).to.equal(7)
    })

    it('Should return correct winners page for getWinnersByTierPage', async function () {
      const fixture = await setupDrawWithWinners(await loadFixture(deploy))

      // Get all tier 4 winners (3 winners)
      const tier4Winners = await fixture.lotturaCore.read.getWinnersByTierPage([
        1n,
        4,
        0n,
        10n,
      ])
      expect(tier4Winners.length).to.equal(3)

      // Verify all are valid token IDs
      for (const tokenId of tier4Winners) {
        expect(tokenId).to.be.greaterThan(0n)
      }

      // Get all tier 5 winners (2 winners)
      const tier5Winners = await fixture.lotturaCore.read.getWinnersByTierPage([
        1n,
        5,
        0n,
        10n,
      ])
      expect(tier5Winners.length).to.equal(2)

      // Get all tier 6 winners (2 winners)
      const tier6Winners = await fixture.lotturaCore.read.getWinnersByTierPage([
        1n,
        6,
        0n,
        10n,
      ])
      expect(tier6Winners.length).to.equal(2)

      // Test pagination - get first 2 tier 4 winners
      const tier4Page1 = await fixture.lotturaCore.read.getWinnersByTierPage([
        1n,
        4,
        0n,
        2n,
      ])
      expect(tier4Page1.length).to.equal(2)

      // Get remaining tier 4 winner
      const tier4Page2 = await fixture.lotturaCore.read.getWinnersByTierPage([
        1n,
        4,
        2n,
        2n,
      ])
      expect(tier4Page2.length).to.equal(1)

      // Verify no overlap between pages
      expect(tier4Page1[0]).to.not.equal(tier4Page2[0])
      expect(tier4Page1[1]).to.not.equal(tier4Page2[0])

      // Verify all token IDs are unique
      const allTier4Ids = [...tier4Page1, ...tier4Page2]
      const uniqueIds = new Set(allTier4Ids.map((id) => id.toString()))
      expect(uniqueIds.size).to.equal(3)
    })

    it('Should return empty array for tier with no winners', async function () {
      const fixture = await loadFixture(deploy)

      await fixture.lotturaCore.write.fundGas({
        account: fixture.ownerA.account,
        value: parseEther('1'),
      })

      // Purchase tickets (minimum 10 required)
      for (let i = 0; i < 10; i++) {
        await fixture.lotturaHubA.write.purchaseTickets(
          [
            [[1, 2, 3, 4, 5, 6 + i]],
            1n,
            [pad(`0x${(i + 1).toString(16).padStart(64, '0')}`, { size: 32 })],
          ],
          { account: fixture.user1.account },
        )
      }

      // Complete draw with NO winners
      const draw = await fixture.lotturaCore.read.getDraw([1n])
      await time.increaseTo(Number(draw.endTime) + 1)
      await fixture.lotturaCore.write.executeDraw([1n], {
        account: fixture.ownerA.account,
      })

      const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])
      await fixture.vrfCoordinator.write.fulfillRandomWords([
        drawAfterExecution.vrfRequestId,
        fixture.lotturaCore.address,
      ])

      await fixture.lotturaCore.write.setWinningTicketsCounts([1n, [0, 0, 0]], {
        account: fixture.ownerA.account,
      })

      // Check all tiers have 0 winners
      const tier4Length = await fixture.lotturaCore.read.getWinnersByTierLength(
        [1n, 4],
      )
      const tier5Length = await fixture.lotturaCore.read.getWinnersByTierLength(
        [1n, 5],
      )
      const tier6Length = await fixture.lotturaCore.read.getWinnersByTierLength(
        [1n, 6],
      )

      expect(tier4Length).to.equal(0)
      expect(tier5Length).to.equal(0)
      expect(tier6Length).to.equal(0)

      // Get winners page should return empty array
      const tier4Winners = await fixture.lotturaCore.read.getWinnersByTierPage([
        1n,
        4,
        0n,
        10n,
      ])
      expect(tier4Winners.length).to.equal(0)
    })
  })

  it('Should execute multiple draws without tickets and then one single winning ticket in draw 3', async function () {
    const fixture = await loadFixture(deploy)

    await fixture.lotturaCore.write.fundGas({
      account: fixture.ownerA.account,
      value: parseEther('1'),
    })

    const draw = await fixture.lotturaCore.read.getDraw([1n])

    await time.increaseTo(Number(draw.endTime) + 1)

    await fixture.lotturaCore.write.executeDraw([1n], {
      account: fixture.ownerA.account,
    })

    const drawAfterExecution = await fixture.lotturaCore.read.getDraw([1n])

    await fixture.vrfCoordinator.write.fulfillRandomWords([
      drawAfterExecution.vrfRequestId,
      fixture.lotturaCore.address,
    ])

    await fixture.lotturaCore.write.setWinningTicketsCounts([1n, [0, 0, 0]], {
      account: fixture.ownerA.account,
    })

    const drawAfterComplete = await fixture.lotturaCore.read.getDraw([1n])

    expect(drawAfterComplete.status).to.equal(3) // COMPLETED

    const draw2 = await fixture.lotturaCore.read.getDraw([2n])

    expect(draw2.endTime).to.be.greaterThan(0n)

    await time.increaseTo(Number(draw2.endTime) + 1)

    await fixture.lotturaCore.write.executeDraw([2n], {
      account: fixture.ownerA.account,
    })

    const draw2AfterExecution = await fixture.lotturaCore.read.getDraw([2n])

    await fixture.vrfCoordinator.write.fulfillRandomWords([
      draw2AfterExecution.vrfRequestId,
      fixture.lotturaCore.address,
    ])

    await fixture.lotturaCore.write.setWinningTicketsCounts([2n, [0, 0, 0]], {
      account: fixture.ownerA.account,
    })

    const draw2AfterComplete = await fixture.lotturaCore.read.getDraw([2n])

    expect(draw2AfterComplete.status).to.equal(3) // COMPLETED

    await fixture.lotturaHubA.write.purchaseTickets(
      [
        [[42, 36, 38, 40, 37, 44]],
        3n,
        [pad(`0x${(1).toString(16).padStart(64, '0')}`, { size: 32 })],
      ],
      { account: fixture.user1.account },
    )

    const draw3 = await fixture.lotturaCore.read.getDraw([3n])

    await time.increaseTo(Number(draw3.endTime) + 1)

    await fixture.lotturaCore.write.executeDraw([3n], {
      account: fixture.ownerA.account,
    })

    const draw3AfterExecution = await fixture.lotturaCore.read.getDraw([3n])

    await fixture.vrfCoordinator.write.fulfillRandomWords([
      draw3AfterExecution.vrfRequestId,
      fixture.lotturaCore.address,
    ])

    await fixture.lotturaCore.write.setWinningTicketsCounts([3n, [0, 0, 1]], {
      account: fixture.ownerA.account,
    })

    const draw3AfterComplete = await fixture.lotturaCore.read.getDraw([3n])

    expect(draw3AfterComplete.status).to.equal(3) // COMPLETED

    const tokenIds = await fixture.lotturaCore.read.getDrawTicketsPage([
      3n,
      0n,
      10n,
    ])

    expect(tokenIds.length).to.equal(1n)

    const balanceBefore = await fixture.mockUSDT0A.read.balanceOf([
      fixture.user1.account.address,
    ])

    await fixture.lotturaHubA.write.claimTicket([tokenIds[0]], {
      account: fixture.user1.account,
    })

    const balanceAfter = await fixture.mockUSDT0A.read.balanceOf([
      fixture.user1.account.address,
    ])
    expect(balanceAfter - balanceBefore).to.equal(2700000)
  })

  describe('NumberConversionLib - generateRandomNumbers Stress Test', function () {
    it('Should generate valid numbers for many different seeds', async function () {
      const { numberConversionTest } = await loadFixture(deploy)

      // Test with 100 different seeds
      const testSeeds = []
      for (let i = 0; i < 100; i++) {
        testSeeds.push(BigInt(i) * 123456789n + 987654321n)
      }

      for (const seed of testSeeds) {
        const numbers = await numberConversionTest.read.generateRandomNumbers([
          seed,
        ])

        // Verify we got 6 numbers
        expect(numbers.length).to.equal(6)

        // Verify all numbers are in range 1-50
        for (const num of numbers) {
          expect(num).to.be.greaterThanOrEqual(1)
          expect(num).to.be.lessThanOrEqual(50)
        }

        // Verify all numbers are unique
        const uniqueNumbers = new Set(numbers.map((n) => Number(n)))
        expect(uniqueNumbers.size).to.equal(6)
      }
    })

    it('Should generate different numbers for different seeds', async function () {
      const { numberConversionTest } = await loadFixture(deploy)

      const seed1 = 12345n
      const seed2 = 67890n

      const numbers1 = await numberConversionTest.read.generateRandomNumbers([
        seed1,
      ])
      const numbers2 = await numberConversionTest.read.generateRandomNumbers([
        seed2,
      ])

      // Convert to strings for comparison
      const str1 = numbers1.join(',')
      const str2 = numbers2.join(',')

      // Different seeds should produce different results
      expect(str1).to.not.equal(str2)
    })

    it('Should generate consistent numbers for same seed', async function () {
      const { numberConversionTest } = await loadFixture(deploy)

      const seed = 999888777n

      const numbers1 = await numberConversionTest.read.generateRandomNumbers([
        seed,
      ])
      const numbers2 = await numberConversionTest.read.generateRandomNumbers([
        seed,
      ])

      // Same seed should produce same results
      expect(numbers1.length).to.equal(numbers2.length)
      for (let i = 0; i < numbers1.length; i++) {
        expect(numbers1[i]).to.equal(numbers2[i])
      }
    })

    it('Should handle edge case seeds', async function () {
      const { numberConversionTest } = await loadFixture(deploy)

      const edgeCaseSeeds = [
        0n, // Zero
        1n, // One
        2n ** 256n - 1n, // Max uint256
        123n, // Small number
        BigInt('0x' + 'f'.repeat(64)), // Max hex
      ]

      for (const seed of edgeCaseSeeds) {
        const numbers = await numberConversionTest.read.generateRandomNumbers([
          seed,
        ])

        // Verify basic properties
        expect(numbers.length).to.equal(6)

        // All in range
        for (const num of numbers) {
          expect(num).to.be.greaterThanOrEqual(1)
          expect(num).to.be.lessThanOrEqual(50)
        }

        // All unique
        const uniqueNumbers = new Set(numbers.map((n) => Number(n)))
        expect(uniqueNumbers.size).to.equal(6)
      }
    })

    it('Should have good distribution across range', async function () {
      const { numberConversionTest } = await loadFixture(deploy)

      // Generate 50 sets of numbers
      const allNumbers: number[] = []
      for (let i = 0; i < 50; i++) {
        const seed = BigInt(i) * 111111n
        const numbers = await numberConversionTest.read.generateRandomNumbers([
          seed,
        ])
        allNumbers.push(...numbers.map((n) => Number(n)))
      }

      // Count frequency of each number (1-50)
      const frequency = new Array(51).fill(0)
      for (const num of allNumbers) {
        frequency[num]++
      }

      // Check that all numbers 1-50 appear at least once
      // (with 50 draws of 6 numbers = 300 total numbers, this should happen)
      let numbersAppeared = 0
      for (let i = 1; i <= 50; i++) {
        if (frequency[i] > 0) {
          numbersAppeared++
        }
      }

      // At least 40 different numbers should appear (80% coverage)
      expect(numbersAppeared).to.be.greaterThanOrEqual(40)

      // No number should appear too frequently (max 10% of total)
      const maxExpected = Math.floor(allNumbers.length * 0.15) // 15% tolerance
      for (let i = 1; i <= 50; i++) {
        expect(frequency[i]).to.be.lessThanOrEqual(maxExpected)
      }
    })
  })
})
