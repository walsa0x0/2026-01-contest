import hre, { ethers, upgrades } from 'hardhat'
import { pad, parseUnits, type Address } from 'viem'

const TICKET_PRICE = parseUnits('5', 6) // 5 USDT
const INITIAL_BALANCE = parseUnits('1000', 6) // 1000 USDT

export const deploy = async () => {
  const eidA = 1
  const eidB = 2

  const endpointV2MockA = await hre.viem.deployContract('EndpointV2Mock', [
    eidA,
  ])

  const endpointV2MockB = await hre.viem.deployContract('EndpointV2Mock', [
    eidB,
  ])

  const walletClients = await hre.viem.getWalletClients()

  const publicClient = await hre.viem.getPublicClient()

  const chainId = await publicClient.getChainId()

  const ownerA = walletClients[0]
  const ownerB = walletClients[1]
  const multiSigA = walletClients[2]
  const multiSigB = walletClients[3]
  const user1 = walletClients[4]
  const user2 = walletClients[5]
  const user3 = walletClients[6]

  // **** MockVRFCoordinator deployment ****
  const vrfCoordinator = await hre.viem.deployContract('MockVRFV2PlusWrapper')

  // **** NumberConversionTest deployment ****
  const numberConversionTest = await hre.viem.deployContract('NumberConversionTest')

  // **** MockUSDT0 deployments ****

  const mockUSDT0A = await hre.viem.deployContract('MockUSDT0', [
    'MockUSDT0A',
    'USDT0A',
    endpointV2MockA.address,
    multiSigA.account.address,
  ])

  const mockUSDT0B = await hre.viem.deployContract('MockUSDT0', [
    'MockUSDT0B',
    'USDT0B',
    endpointV2MockB.address,
    multiSigB.account.address,
  ])

  // **** LotturaTicketNFT deployments and setup ****

  const lotturaTicketNFTA = await hre.viem.deployContract('LotturaTicketNFT', [
    'LotturaTicketNFTA',
    'LotturaTicketNFTA',
    endpointV2MockA.address,
    ownerA.account.address,
  ])

  const lotturaTicketNFTB = await hre.viem.deployContract('LotturaTicketNFT', [
    'LotturaTicketNFTB',
    'LotturaTicketNFTB',
    endpointV2MockB.address,
    ownerB.account.address,
  ])

  await endpointV2MockA.write.setDestLzEndpoint([
    lotturaTicketNFTB.address,
    endpointV2MockB.address,
  ])

  await endpointV2MockB.write.setDestLzEndpoint([
    lotturaTicketNFTA.address,
    endpointV2MockA.address,
  ])

  await lotturaTicketNFTA.write.setPeer(
    [eidB, pad(lotturaTicketNFTB.address, { size: 32 })],
    { account: ownerA.account },
  )

  await lotturaTicketNFTB.write.setPeer(
    [eidA, pad(lotturaTicketNFTA.address, { size: 32 })],
    { account: ownerB.account },
  )

  // **** LotturaHub deployments ****

  const LotturaHubFactory = await ethers.getContractFactory('LotturaHub')

  const lotturaHubProxyA = await upgrades.deployProxy(
    LotturaHubFactory,
    [
      mockUSDT0A.address,
      TICKET_PRICE, // Ticket price: 5 USDT
      1000, // Commission: 10%,
      true, // isOnPolygonChain
    ],
    {
      initializer: 'initialize',
      kind: 'uups',
      constructorArgs: [endpointV2MockA.address],
      unsafeAllow: [
        'constructor',
        'state-variable-immutable',
        'missing-initializer-call',
      ],
    },
  )

  await lotturaHubProxyA.waitForDeployment()

  const lotturaHubA = await hre.viem.getContractAt(
    'LotturaHub',
    (await lotturaHubProxyA.getAddress()) as Address,
  )

  const lotturaHubProxyB = await upgrades.deployProxy(
    LotturaHubFactory,
    [
      mockUSDT0B.address,
      TICKET_PRICE, // Ticket price: 5 USDT
      1000, // Commission: 10%
      false, // isOnPolygonChain
    ],
    {
      initializer: 'initialize',
      kind: 'uups',
      constructorArgs: [endpointV2MockB.address],
      unsafeAllow: [
        'constructor',
        'state-variable-immutable',
        'missing-initializer-call',
      ],
    },
  )

  await lotturaHubProxyB.waitForDeployment()

  const lotturaHubB = await hre.viem.getContractAt(
    'LotturaHub',
    (await lotturaHubProxyB.getAddress()) as Address,
  )

  // **** LotturaTicketNFT additional setup ****

  await lotturaTicketNFTA.write.setMinter([lotturaHubA.address], {
    account: ownerA.account,
  })

  await lotturaTicketNFTB.write.setMinter([lotturaHubB.address], {
    account: ownerB.account,
  })

  // **** LotturaCore deployment ****

  const LotturaCoreFactory = await ethers.getContractFactory('LotturaCore')

  const lotturaCoreProxy = await upgrades.deployProxy(
    LotturaCoreFactory,
    [mockUSDT0A.address, vrfCoordinator.address],
    {
      initializer: 'initialize',
      kind: 'uups',
      constructorArgs: [endpointV2MockA.address],
      unsafeAllow: [
        'constructor',
        'state-variable-immutable',
        'missing-initializer-call',
      ],
    },
  )

  await lotturaCoreProxy.waitForDeployment()

  const lotturaCore = await hre.viem.getContractAt(
    'LotturaCore',
    (await lotturaCoreProxy.getAddress()) as Address,
  )

  // **** LotturaHub additional setup ****

  await lotturaHubA.write.updateLotturaCore([lotturaCore.address, eidA])
  await lotturaHubA.write.updateTicketNFT([lotturaTicketNFTA.address])

  await lotturaHubB.write.updateLotturaCore([lotturaCore.address, eidA])
  await lotturaHubB.write.updateTicketNFT([lotturaTicketNFTB.address])

  // **** LotturaCore additional setup ****

  await lotturaCore.write.setHubAddress([BigInt(chainId), lotturaHubA.address])
  await lotturaCore.write.setHubAddress([BigInt(eidB), lotturaHubB.address])

  // **** Mint USDT0 tokens ****

  // **** Cross-chain peer configuration for MockUSDT0 ****
  await mockUSDT0A.write.setPeer(
    [eidB, pad(mockUSDT0B.address, { size: 32 })],
    { account: multiSigA.account },
  )

  await mockUSDT0B.write.setPeer(
    [eidA, pad(mockUSDT0A.address, { size: 32 })],
    { account: multiSigB.account },
  )

  await endpointV2MockA.write.setDestLzEndpoint([
    mockUSDT0B.address,
    endpointV2MockB.address,
  ])

  await endpointV2MockB.write.setDestLzEndpoint([
    mockUSDT0A.address,
    endpointV2MockA.address,
  ])

  // **** Cross-chain peer configuration for LotturaHub ****
  await lotturaHubA.write.setPeer(
    [eidB, pad(lotturaHubB.address, { size: 32 })],
  )

  await lotturaHubB.write.setPeer(
    [eidA, pad(lotturaHubA.address, { size: 32 })],
  )

  await endpointV2MockA.write.setDestLzEndpoint([
    lotturaHubB.address,
    endpointV2MockB.address,
  ])

  await endpointV2MockB.write.setDestLzEndpoint([
    lotturaHubA.address,
    endpointV2MockA.address,
  ])

  // **** LotturaHub to LotturaCore cross-chain communication ****
  await lotturaHubA.write.setPeer(
    [eidA, pad(lotturaCore.address, { size: 32 })],
  )

  await lotturaHubB.write.setPeer(
    [eidA, pad(lotturaCore.address, { size: 32 })],
  )

  await endpointV2MockB.write.setDestLzEndpoint([
    lotturaCore.address,
    endpointV2MockA.address,
  ])

  // **** Mint initial USDT balances ****
  await mockUSDT0A.write.mint([user1.account.address, INITIAL_BALANCE])
  await mockUSDT0A.write.mint([user2.account.address, INITIAL_BALANCE])
  await mockUSDT0A.write.mint([user3.account.address, INITIAL_BALANCE])

  await mockUSDT0B.write.mint([user1.account.address, INITIAL_BALANCE])
  await mockUSDT0B.write.mint([user2.account.address, INITIAL_BALANCE])
  await mockUSDT0B.write.mint([user3.account.address, INITIAL_BALANCE])

  // Approve lottery to spend USDT
  const maxUint256 = 2n ** 256n - 1n

  await mockUSDT0A.write.approve([lotturaHubA.address, maxUint256], {
    account: user1.account,
  })
  await mockUSDT0A.write.approve([lotturaHubA.address, maxUint256], {
    account: user2.account,
  })
  await mockUSDT0A.write.approve([lotturaHubA.address, maxUint256], {
    account: user3.account,
  })

  await mockUSDT0B.write.approve([lotturaHubB.address, maxUint256], {
    account: user1.account,
  })
  await mockUSDT0B.write.approve([lotturaHubB.address, maxUint256], {
    account: user2.account,
  })
  await mockUSDT0B.write.approve([lotturaHubB.address, maxUint256], {
    account: user3.account,
  })

  return {
    lotturaCore,
    mockUSDT0A,
    mockUSDT0B,
    lotturaHubA,
    lotturaHubB,
    lotturaTicketNFTA,
    lotturaTicketNFTB,
    endpointV2MockA,
    endpointV2MockB,
    vrfCoordinator,
    numberConversionTest,
    publicClient,
    walletClients,
    ownerA,
    ownerB,
    multiSigA,
    multiSigB,
    user1,
    user2,
    user3,
    TICKET_PRICE,
    INITIAL_BALANCE,
  }
}
