/**
 * Test Enums matching smart contract error enums
 * These must be kept in sync with the contract enums
 */

/**
 * LotturaCore InvalidParams enum
 * @see contracts/LotturaCore.sol
 */
export enum LotturaCoreInvalidParams {
  ZeroAddressImplementation = 0,
  InvalidCrossChainMessageType = 1,
  ZeroAddressPaymentToken = 2,
  ZeroAddressVRFV2PlusWrapper = 3,
  InvalidReserveAmount = 4,
  InvalidGasAmount = 5,
  ZeroDrawInterval = 6,
  SameDrawInterval = 7,
  ZeroChainId = 8,
  ZeroChainEid = 9,
  InvalidWinningTicketsCountsArrayLength = 10,
  ZeroAmount = 11,
  NotEnoughBalance = 12,
  ZeroHubAddress = 13,
}

/**
 * LotturaHub InvalidParams enum
 * @see contracts/LotturaHub.sol
 */
export enum LotturaHubInvalidParams {
  ZeroAmount = 0,
  DrawIdZero = 1,
  TicketNumbersOutOfRange = 2,
  TicketNumbersDuplicate = 3,
  ZeroAddressLotturaCore = 4,
  ZeroLotturaCoreEid = 5,
  ZeroAddressPaymentToken = 6,
  ZeroTicketPrice = 7,
  ZeroAddressImplementation = 8,
  ZeroAddressTicketNFT = 9,
  ZeroHashedRandomness = 10,
  InvalidGasAmount = 11,
  NotEnoughBalance = 12,
  NoTickets = 13,
  ArrayLengthMismatch = 14,
}

/**
 * Helper function to format InvalidParam error message
 */
export function formatInvalidParamError(paramValue: number): string {
  return `InvalidParam(${paramValue})`
}
