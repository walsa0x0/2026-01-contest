import { expect } from 'chai'
import hre from 'hardhat'

describe('NumberConversionLib', function () {
  let numberConversionTest: any

  before(async function () {
    // Deploy test contract that uses the library
    numberConversionTest = await hre.viem.deployContract('NumberConversionTest')
  })

  describe('numbersToUint48', function () {
    it('Should convert [5, 12, 23, 34, 41, 48] to 051223344148', async function () {
      const numbers = [5, 12, 23, 34, 41, 48]
      const packed = await numberConversionTest.read.numbersToUint48([numbers])
      expect(packed).to.equal(51223344148n) // Leading zero dropped in uint48
    })

    it('Should convert [1, 2, 3, 4, 5, 6] to 010203040506', async function () {
      const numbers = [1, 2, 3, 4, 5, 6]
      const packed = await numberConversionTest.read.numbersToUint48([numbers])
      expect(packed).to.equal(10203040506n)
    })

    it('Should convert [50, 49, 48, 47, 46, 45] to 504948474645', async function () {
      const numbers = [50, 49, 48, 47, 46, 45]
      const packed = await numberConversionTest.read.numbersToUint48([numbers])
      expect(packed).to.equal(504948474645n)
    })

    it('Should reject number below range (0)', async function () {
      const numbers = [0, 12, 23, 34, 41, 48]
      await expect(
        numberConversionTest.read.numbersToUint48([numbers]),
      ).to.be.rejectedWith('InvalidNumberRange')
    })

    it('Should reject number above range (51)', async function () {
      const numbers = [5, 12, 23, 34, 41, 51]
      await expect(
        numberConversionTest.read.numbersToUint48([numbers]),
      ).to.be.rejectedWith('InvalidNumberRange')
    })

    it('Should reject duplicate numbers', async function () {
      const numbers = [5, 12, 12, 34, 41, 48]
      await expect(
        numberConversionTest.read.numbersToUint48([numbers]),
      ).to.be.rejectedWith('DuplicateNumber')
    })
  })

  describe('uint48ToNumbers', function () {
    it('Should convert 051223344148 to [5, 12, 23, 34, 41, 48]', async function () {
      const packed = 51223344148n
      const numbers = await numberConversionTest.read.uint48ToNumbers([packed])
      expect(numbers).to.deep.equal([5, 12, 23, 34, 41, 48])
    })

    it('Should convert 010203040506 to [1, 2, 3, 4, 5, 6]', async function () {
      const packed = 10203040506n
      const numbers = await numberConversionTest.read.uint48ToNumbers([packed])
      expect(numbers).to.deep.equal([1, 2, 3, 4, 5, 6])
    })

    it('Should convert 504948474645 to [50, 49, 48, 47, 46, 45]', async function () {
      const packed = 504948474645n
      const numbers = await numberConversionTest.read.uint48ToNumbers([packed])
      expect(numbers).to.deep.equal([50, 49, 48, 47, 46, 45])
    })
  })

  describe('Round-trip conversion', function () {
    it('Should maintain values through round-trip conversion', async function () {
      const originalNumbers = [15, 22, 30, 37, 44, 50]

      // Convert to uint48
      const packed = await numberConversionTest.read.numbersToUint48([
        originalNumbers,
      ])

      // Convert back to array
      const convertedNumbers = await numberConversionTest.read.uint48ToNumbers([
        packed,
      ])

      expect(convertedNumbers).to.deep.equal(originalNumbers)
    })

    it('Should handle multiple round-trips', async function () {
      const testCases = [
        [1, 2, 3, 4, 5, 6],
        [5, 12, 23, 34, 41, 48],
        [10, 20, 30, 40, 50, 1],
        [50, 49, 48, 47, 46, 45],
      ]

      for (const numbers of testCases) {
        const packed = await numberConversionTest.read.numbersToUint48([
          numbers,
        ])
        const converted = await numberConversionTest.read.uint48ToNumbers([
          packed,
        ])
        expect(converted).to.deep.equal(numbers)
      }
    })
  })

  describe('countMatches', function () {
    it('Should count 6 matches for identical numbers', async function () {
      const ticket = await numberConversionTest.read.numbersToUint48([
        [5, 12, 23, 34, 41, 48],
      ])
      const winning = await numberConversionTest.read.numbersToUint48([
        [5, 12, 23, 34, 41, 48],
      ])

      const matches = await numberConversionTest.read.countMatches([
        ticket,
        winning,
      ])
      expect(matches).to.equal(6)
    })

    it('Should count 5 matches when last number differs', async function () {
      const ticket = await numberConversionTest.read.numbersToUint48([
        [5, 12, 23, 34, 41, 48],
      ])
      const winning = await numberConversionTest.read.numbersToUint48([
        [5, 12, 23, 34, 41, 50],
      ])

      const matches = await numberConversionTest.read.countMatches([
        ticket,
        winning,
      ])
      expect(matches).to.equal(5)
    })

    it('Should count 4 matches not considering order', async function () {
      const ticket = await numberConversionTest.read.numbersToUint48([
        [5, 12, 23, 34, 41, 48],
      ])
      const winning = await numberConversionTest.read.numbersToUint48([
        [5, 12, 23, 50, 49, 48],
      ])

      const matches = await numberConversionTest.read.countMatches([
        ticket,
        winning,
      ])
      expect(matches).to.equal(4)
    })

    it('Should count 1 match when only one number matches', async function () {
      const ticket = await numberConversionTest.read.numbersToUint48([
        [34, 12, 23, 5, 41, 48],
      ])
      const winning = await numberConversionTest.read.numbersToUint48([
        [5, 50, 49, 47, 46, 45],
      ])

      const matches = await numberConversionTest.read.countMatches([
        ticket,
        winning,
      ])
      expect(matches).to.equal(1)
    })

    it('Should count 0 matches when no match found', async function () {
      const ticket = await numberConversionTest.read.numbersToUint48([
        [5, 13, 24, 45, 42, 49],
      ])
      const winning = await numberConversionTest.read.numbersToUint48([
        [50, 12, 23, 34, 41, 48],
      ])

      const matches = await numberConversionTest.read.countMatches([
        ticket,
        winning,
      ])
      expect(matches).to.equal(0)
    })
  })
})
