import hre, { ethers, upgrades } from 'hardhat'
import { privateKeyToAccount } from 'viem/accounts'
import { LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  console.log('Deploying LotturaCore on:', hre.network.name)

  console.log('Deployer address:', deployerAddress)

  const chainId = await publicClient.getChainId()

  console.log('Chain ID:', chainId)

  console.log('Current chain data:', LAYERZERO_ENDPOINTSDATA[chainId])

  const LotturaCoreFactory = await ethers.getContractFactory('LotturaCore')

  const lotturaCoreProxy = await upgrades.deployProxy(
    LotturaCoreFactory,
    [
      LAYERZERO_ENDPOINTSDATA[chainId].usdt0Address,
      LAYERZERO_ENDPOINTSDATA[chainId].vrfWrapperAddress,
    ],
    {
      initializer: 'initialize',
      kind: 'uups',
      constructorArgs: [LAYERZERO_ENDPOINTSDATA[chainId].endpointV2],
      unsafeAllow: [
        'constructor',
        'state-variable-immutable',
        'missing-initializer-call',
      ],
    },
  )

  await lotturaCoreProxy.waitForDeployment()

  console.log(`LotturaCore deployed at: ${await lotturaCoreProxy.getAddress()}`)
}

main()
  .then()
  .catch((e) => console.error(e))
