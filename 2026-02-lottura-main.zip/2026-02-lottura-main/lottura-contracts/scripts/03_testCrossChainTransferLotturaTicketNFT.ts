import hre from 'hardhat'
import {
  createWalletClient,
  getContract,
  Hex,
  http,
  pad,
  zeroAddress,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { Options } from '@layerzerolabs/lz-v2-utilities'
import { chainByName, LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

async function main() {
  const DESTINATION_CHAIN_ID = 421614

  const publicClient = await hre.viem.getPublicClient()

  const minter = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const minterAddress = minter.address

  const walletClient = createWalletClient({
    account: minter,
    chain: chainByName[hre.network.name],
    transport: http(),
  })

  const chainId = await publicClient.getChainId()

  const chainData = LAYERZERO_ENDPOINTSDATA[chainId]

  if (!chainData) {
    throw new Error(`Unsupported chainId ${chainId}`)
  }

  if (chainData.lotturaTicketNftAddress === zeroAddress) {
    throw new Error(`Missing lotturaTicketNftAddress for chainId ${chainId}`)
  }

  console.log('Configuring LotturaTicketNFT')
  console.log('Network: ', hre.network.name)
  console.log('Chain ID: ', chainId)
  console.log('Local ONFT: ', chainData.lotturaTicketNftAddress)
  console.log('Minter Address: ', minterAddress)

  const lotturaTicketNFTArtifact =
    await hre.artifacts.readArtifact('LotturaTicketNFT')

  const lotturaTicketNFT = getContract({
    address: chainData.lotturaTicketNftAddress,
    abi: lotturaTicketNFTArtifact.abi,
    client: walletClient,
  })

  const mintTxHash = await lotturaTicketNFT.write.mint(
    [
      minterAddress,
      {
        numbers: [0, 0, 0, 0, 0, 0],
        drawId: 5n,
        timestamp: 0,
      },
    ],
    { account: minter },
  )

  await publicClient.waitForTransactionReceipt({
    hash: mintTxHash,
  })

  const events = await lotturaTicketNFT.getEvents.TicketMinted()

  const tokenId = events[0].args.tokenId!

  const options = Options.newOptions()
    .addExecutorLzReceiveOption(300000, 0)
    .toHex() as Hex

  const toAddressBytes32 = pad(minterAddress, { size: 32 })

  const sendParam = {
    dstEid: LAYERZERO_ENDPOINTSDATA[DESTINATION_CHAIN_ID].endpointId,
    to: toAddressBytes32,
    tokenId: tokenId,
    extraOptions: options,
    composeMsg: '0x' as Hex,
    onftCmd: '0x' as Hex,
  }

  const { nativeFee } = await lotturaTicketNFT.read.quoteSend([
    sendParam,
    false,
  ])

  const sendTxHash = await lotturaTicketNFT.write.send(
    [sendParam, { nativeFee, lzTokenFee: 0n }, minterAddress],
    { value: nativeFee, account: minter },
  )

  await publicClient.waitForTransactionReceipt({
    hash: sendTxHash,
  })

  console.log('✅ NFT sent successfully')
}

main()
  .then()
  .catch((e) => console.error(e))
