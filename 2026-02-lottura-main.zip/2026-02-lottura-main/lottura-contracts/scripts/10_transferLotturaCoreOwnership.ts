import hre from 'hardhat'
import {
  createWalletClient,
  getContract,
  http,
  keccak256,
  toBytes,
  zeroAddress,
} from 'viem'
import { Address, privateKeyToAccount } from 'viem/accounts'
import { chainByName, LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

const NEW_OWNER_ADDRESS: Address = '0x00000000000000000000000000000000000000000'
const ADMIN_ROLE = keccak256(toBytes('ADMIN_ROLE'))
const OPERATOR_ROLE = keccak256(toBytes('OPERATOR_ROLE'))
const UPGRADER_ROLE = keccak256(toBytes('UPGRADER_ROLE'))

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  const walletClient = createWalletClient({
    account: deployer,
    chain: chainByName[hre.network.name],
    transport: http(),
  })

  const chainId = await publicClient.getChainId()

  const chainData = LAYERZERO_ENDPOINTSDATA[chainId]

  if (!chainData) {
    throw new Error(`Unsupported chainId ${chainId}`)
  }

  if (chainData.lotturaCoreAddress === zeroAddress) {
    throw new Error(`Missing lotturaCore for chainId ${chainId}`)
  }

  console.log('Transferring LotturaCore ownership')
  console.log('Network: ', hre.network.name)
  console.log('Chain ID: ', chainId)
  console.log('Deployer Address: ', deployerAddress)

  const lotturaCoreArtifact = await hre.artifacts.readArtifact('LotturaCore')

  const lotturaCore = getContract({
    address: chainData.lotturaCoreAddress!,
    abi: lotturaCoreArtifact.abi,
    client: walletClient,
  })

  const transferOwnershipTxHash = await lotturaCore.write.transferOwnership([
    NEW_OWNER_ADDRESS,
  ])

  await publicClient.waitForTransactionReceipt({
    hash: transferOwnershipTxHash,
  })

  const accessControlAdminRoleTxHash = await lotturaCore.write.grantRole([
    ADMIN_ROLE,
    NEW_OWNER_ADDRESS,
  ])

  await publicClient.waitForTransactionReceipt({
    hash: accessControlAdminRoleTxHash,
  })

  const accessControlRenounceAdminRoleTxHash =
    await lotturaCore.write.renounceRole([ADMIN_ROLE, deployerAddress])

  await publicClient.waitForTransactionReceipt({
    hash: accessControlRenounceAdminRoleTxHash,
  })

  const accessControlOperatorRoleTxHash = await lotturaCore.write.grantRole([
    OPERATOR_ROLE,
    NEW_OWNER_ADDRESS,
  ])

  await publicClient.waitForTransactionReceipt({
    hash: accessControlOperatorRoleTxHash,
  })

  const accessControlRenounceOperatorRoleTxHash =
    await lotturaCore.write.renounceRole([OPERATOR_ROLE, deployerAddress])

  await publicClient.waitForTransactionReceipt({
    hash: accessControlRenounceOperatorRoleTxHash,
  })

  const accessControlUpgraderRoleTxHash = await lotturaCore.write.grantRole([
    UPGRADER_ROLE,
    NEW_OWNER_ADDRESS,
  ])

  await publicClient.waitForTransactionReceipt({
    hash: accessControlUpgraderRoleTxHash,
  })

  const accessControlRenounceUpgraderRoleTxHash =
    await lotturaCore.write.renounceRole([UPGRADER_ROLE, deployerAddress])

  await publicClient.waitForTransactionReceipt({
    hash: accessControlRenounceUpgraderRoleTxHash,
  })

  console.log('✅ Ownership transferred successfully')
}

main()
  .then()
  .catch((e) => console.error(e))
