import hre from 'hardhat'
import { createWalletClient, getContract, http, zeroAddress, pad } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { chainByName, LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

const LOTTURACORE_CHAIN_ID: number = 80002

async function main() {
  if (LOTTURACORE_CHAIN_ID === 0) {
    throw new Error('LOTTURACORE_CHAIN_ID cannot be 0')
  }

  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  const walletClient = createWalletClient({
    account: deployer,
    chain: chainByName[hre.network.name],
    transport: http(),
  })

  const chainId = await publicClient.getChainId()

  const chainData = LAYERZERO_ENDPOINTSDATA[chainId]

  if (!chainData) {
    throw new Error(`Unsupported chainId ${chainId}`)
  }

  if (chainData.lotturaTicketNftAddress === zeroAddress) {
    throw new Error(`Missing lotturaTicketNftAddress for chainId ${chainId}`)
  }

  if (chainData.lotturaHubAddress === zeroAddress) {
    throw new Error(`Missing lotturaHubAddress for chainId ${chainId}`)
  }

  if (
    LAYERZERO_ENDPOINTSDATA[LOTTURACORE_CHAIN_ID].lotturaCoreAddress ===
    undefined
  ) {
    throw new Error(
      `Missing lotturaCoreAddress for chainId ${LOTTURACORE_CHAIN_ID}`,
    )
  }

  let nonce = await publicClient.getTransactionCount({
    address: deployerAddress,
  })

  console.log('Wiring LotturaTicketNFT and LotturaHub')
  console.log('Network: ', hre.network.name)
  console.log('Chain ID: ', chainId)
  console.log('Deployer Address: ', deployerAddress)

  const lotturaTicketNFTArtifact =
    await hre.artifacts.readArtifact('LotturaTicketNFT')

  const lotturaTicketNFT = getContract({
    address: chainData.lotturaTicketNftAddress,
    abi: lotturaTicketNFTArtifact.abi,
    client: walletClient,
  })

  const lotturaHubArtifact = await hre.artifacts.readArtifact('LotturaHub')

  const lotturaHub = getContract({
    address: chainData.lotturaHubAddress,
    abi: lotturaHubArtifact.abi,
    client: walletClient,
  })

  const setMinterTxHash = await lotturaTicketNFT.write.setMinter(
    [lotturaHub.address],
    { nonce },
  )

  await publicClient.waitForTransactionReceipt({
    hash: setMinterTxHash,
  })

  nonce++

  const updateTicketNFTTxHash = await lotturaHub.write.updateTicketNFT(
    [lotturaTicketNFT.address],
    { nonce },
  )

  await publicClient.waitForTransactionReceipt({
    hash: updateTicketNFTTxHash,
  })

  nonce++

  const remoteChainData = LAYERZERO_ENDPOINTSDATA[LOTTURACORE_CHAIN_ID]

  const updateLotturaCoreTxHash = await lotturaHub.write.updateLotturaCore(
    [remoteChainData.lotturaCoreAddress!, remoteChainData.endpointId],
    { nonce },
  )

  await publicClient.waitForTransactionReceipt({
    hash: updateLotturaCoreTxHash,
  })

  if (LOTTURACORE_CHAIN_ID != chainId) {
    nonce++

    const setPeerTxHash = await lotturaHub.write.setPeer(
      [
        remoteChainData.endpointId,
        pad(remoteChainData.lotturaCoreAddress!, { size: 32 }),
      ],
      { nonce },
    )

    await publicClient.waitForTransactionReceipt({
      hash: setPeerTxHash,
    })
  }

  console.log('✅ LotturaTicketNFT and LotturaHub wired successfully')
}

main()
  .then()
  .catch((e) => console.error(e))
