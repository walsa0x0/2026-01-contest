import hre from 'hardhat'
import { createWalletClient, getContract, http, zeroAddress, pad } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { chainByName, LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

const LOTTURAHUB_CHAIN_ID: number = 421614

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  const walletClient = createWalletClient({
    account: deployer,
    chain: chainByName[hre.network.name],
    transport: http(),
  })

  const chainId = await publicClient.getChainId()

  const chainData = LAYERZERO_ENDPOINTSDATA[chainId]

  if (!chainData) {
    throw new Error(`Unsupported chainId ${chainId}`)
  }

  if (chainData.lotturaCoreAddress === zeroAddress) {
    throw new Error(`Missing lotturaCoreAddress for chainId ${chainId}`)
  }

  console.log('Configuring LotturaCore')
  console.log('Network: ', hre.network.name)
  console.log('Chain ID: ', chainId)
  console.log('Deployer Address: ', deployerAddress)

  const lotturaCoreArtifact = await hre.artifacts.readArtifact('LotturaCore')

  const lotturaCore = getContract({
    address: chainData.lotturaCoreAddress!,
    abi: lotturaCoreArtifact.abi,
    client: walletClient,
  })

  const remoteChainData = LAYERZERO_ENDPOINTSDATA[LOTTURAHUB_CHAIN_ID]

  const setHubAddressTxHash = await lotturaCore.write.setHubAddress([
    BigInt(LOTTURAHUB_CHAIN_ID),
    remoteChainData.lotturaHubAddress,
  ])

  await publicClient.waitForTransactionReceipt({
    hash: setHubAddressTxHash,
  })

  if (LOTTURAHUB_CHAIN_ID != chainId) {
    const setPeerTxHash = await lotturaCore.write.setPeer([
      remoteChainData.endpointId,
      pad(remoteChainData.lotturaHubAddress, { size: 32 }),
    ])

    await publicClient.waitForTransactionReceipt({
      hash: setPeerTxHash,
    })

    const setChainEidTxHash = await lotturaCore.write.setChainEidForChainId([
      BigInt(LOTTURAHUB_CHAIN_ID),
      remoteChainData.endpointId,
    ])

    await publicClient.waitForTransactionReceipt({
      hash: setChainEidTxHash,
    })
  }

  console.log('✅ LotturaCore wired successfully')
}

main()
  .then()
  .catch((e) => console.error(e))
