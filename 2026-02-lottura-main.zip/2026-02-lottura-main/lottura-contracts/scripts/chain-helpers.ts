import { Address, type Chain } from 'viem'
import {
  mainnet,
  sepolia,
  arbitrum,
  arbitrumSepolia,
  polygon,
  polygonAmoy,
} from 'viem/chains'

export type LayerZeroChainData = {
  endpointId: number
  endpointV2: Address
  testnet: boolean
  lotturaTicketNftAddress: Address
  lotturaHubAddress: Address
  lotturaCoreAddress?: Address
  usdt0Address: Address
  vrfWrapperAddress?: Address
}

export const chainByName: Record<string, Chain> = {
  mainnet,
  sepolia,
  arbitrum,
  arbitrumSepolia,
  polygon,
  polygonAmoy,
}

export const LAYERZERO_ENDPOINTSDATA: Record<number, LayerZeroChainData> = {
  1: {
    // Mainnet
    endpointId: 30101,
    endpointV2: '0x1a44076050125825900e736c501f859c50fE728c',
    testnet: false,
    lotturaTicketNftAddress: '0x00000000000000000000000000000000000000000',
    lotturaHubAddress: '0x0000000000000000000000000000000000000000',
    usdt0Address: '0x0000000000000000000000000000000000000000',
  },
  /* 11155111: {
    // Sepolia
    endpointId: 40161,
    endpointV2: '0x6EDCE65403992e310A62460808c4b910D972f10f',
    testnet: true,
    lotturaTicketNftAddress: '0x00000000000000000000000000000000000000000',
    lotturaHubAddress: '0x00000000000000000000000000000000000000000',
    usdt0Address: '0x00000000000000000000000000000000000000000',
  },*/
  42161: {
    // Arbitrum
    endpointId: 30110,
    endpointV2: '0x1a44076050125825900e736c501f859c50fE728c',
    testnet: false,
    lotturaTicketNftAddress: '0x00000000000000000000000000000000000000000',
    lotturaHubAddress: '0x0000000000000000000000000000000000000000',
    usdt0Address: '0x0000000000000000000000000000000000000000',
  },
  /*421614: {
    // Arbitrum Sepolia
    endpointId: 40231,
    endpointV2: '0x6EDCE65403992e310A62460808c4b910D972f10f',
    testnet: true,
    lotturaTicketNftAddress: '0x0000000000000000000000000000000000000000',
    lotturaHubAddress: '0x0000000000000000000000000000000000000000',
    usdt0Address: '0x0000000000000000000000000000000000000000',
  },*/
  137: {
    // Polygon
    endpointId: 30109,
    endpointV2: '0x1a44076050125825900e736c501f859c50fE728c',
    testnet: false,
    lotturaTicketNftAddress: '0x00000000000000000000000000000000000000000',
    lotturaHubAddress: '0x0000000000000000000000000000000000000000',
    lotturaCoreAddress: '0x0000000000000000000000000000000000000000',
    usdt0Address: '0x0000000000000000000000000000000000000000',
    vrfWrapperAddress: '0x0000000000000000000000000000000000000000',
  },
  80002: {
    // Polygon Amoy
    endpointId: 40267,
    endpointV2: '0x6EDCE65403992e310A62460808c4b910D972f10f',
    testnet: true,
    lotturaTicketNftAddress: '0x68a524034b33463b50a4b7ccf179639f8d983e15',
    lotturaHubAddress: '0xC59A250f6E1D86396fe2cd7A1977ad62743A1644',
    lotturaCoreAddress: '0xcb92970Fb2895734A0146aCcD28140C58a152e19',
    usdt0Address: '0x45367e0a26bde64233df6dda37a8a5bf575cd73f',
    vrfWrapperAddress: '0x6e6c366a1cd1F92ba87Fd6f96F743B0e6c967Bf0',
  },
}
