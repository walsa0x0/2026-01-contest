import hre from 'hardhat'
import {
  createWalletClient,
  getContract,
  Hex,
  http,
  pad,
  zeroAddress,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { Options, ExecutorOptionType } from '@layerzerolabs/lz-v2-utilities'
import { chainByName, LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const delegate = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const delegateAddress = delegate.address

  const walletClient = createWalletClient({
    account: delegate,
    chain: chainByName[hre.network.name],
    transport: http(),
  })

  const chainId = await publicClient.getChainId()

  const chainData = LAYERZERO_ENDPOINTSDATA[chainId]

  if (!chainData) {
    throw new Error(`Unsupported chainId ${chainId}`)
  }

  if (chainData.lotturaTicketNftAddress === zeroAddress) {
    throw new Error(`Missing lotturaTicketNftAddress for chainId ${chainId}`)
  }

  let nonce = await publicClient.getTransactionCount({
    address: delegateAddress,
  })

  console.log('Configuring LotturaTicketNFT')
  console.log('Network: ', hre.network.name)
  console.log('Chain ID: ', chainId)
  console.log('Local ONFT: ', chainData.lotturaTicketNftAddress)
  console.log('Delegate Address: ', delegateAddress)

  const lotturaTicketNFTArtifact =
    await hre.artifacts.readArtifact('LotturaTicketNFT')

  const lotturaTicketNFT = getContract({
    address: chainData.lotturaTicketNftAddress,
    abi: lotturaTicketNFTArtifact.abi,
    client: walletClient,
  })

  const enforcedOptions: { eid: number; msgType: number; options: Hex }[] = []

  for (const [remoteChainIdStr, remoteChainData] of Object.entries(
    LAYERZERO_ENDPOINTSDATA,
  )) {
    const remoteChainId = Number(remoteChainIdStr)

    if (remoteChainId === chainId) continue

    if (remoteChainData.testnet !== chainData.testnet) {
      console.log(`↷ Skipping ${remoteChainId} (testnet mismatch)`)

      continue
    }

    if (remoteChainData.lotturaTicketNftAddress === zeroAddress) {
      throw new Error(
        `Missing lotturaTicketNftAddress for chainId ${remoteChainId}`,
      )
    }

    console.log(
      `→ Setting peer: chainId=${remoteChainId} eid=${remoteChainData.endpointId}`,
    )

    const setPeerTxHash = await lotturaTicketNFT.write.setPeer(
      [
        remoteChainData.endpointId,
        pad(remoteChainData.lotturaTicketNftAddress, { size: 32 }),
      ],
      { nonce },
    )

    await publicClient.waitForTransactionReceipt({ hash: setPeerTxHash })

    nonce++

    enforcedOptions.push({
      eid: remoteChainData.endpointId,
      msgType: ExecutorOptionType.LZ_RECEIVE,
      options: Options.newOptions()
        .addExecutorLzReceiveOption(300000, 0)
        .toHex() as Hex,
    })
  }

  const setEnforcedOptionsTxHash =
    await lotturaTicketNFT.write.setEnforcedOptions([enforcedOptions], {
      nonce,
    })

  await publicClient.waitForTransactionReceipt({
    hash: setEnforcedOptionsTxHash,
  })

  console.log('✅ Peers configured successfully')
}

main()
  .then()
  .catch((e) => console.error(e))
