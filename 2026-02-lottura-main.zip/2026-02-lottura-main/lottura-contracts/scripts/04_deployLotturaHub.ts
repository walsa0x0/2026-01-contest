import hre, { ethers, upgrades } from 'hardhat'
import { privateKeyToAccount } from 'viem/accounts'
import { LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

const INIT_TICKET_PRICE = 5_000_000n // 5 USDT with 6 decimals
const INIT_COMMISSION = 1000n // 10%

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  console.log('Deploying LotturaHub on:', hre.network.name)

  console.log('Deployer address:', deployerAddress)

  const chainId = await publicClient.getChainId()

  console.log('Chain ID:', chainId)

  console.log('Current chain data:', LAYERZERO_ENDPOINTSDATA[chainId])

  const LotturaHubFactory = await ethers.getContractFactory('LotturaHub')

  const lotturaHubProxy = await upgrades.deployProxy(
    LotturaHubFactory,
    [
      LAYERZERO_ENDPOINTSDATA[chainId].usdt0Address,
      INIT_TICKET_PRICE,
      INIT_COMMISSION,
      chainId == 137 || chainId == 80002, // isOnPolygonChain
    ],
    {
      initializer: 'initialize',
      kind: 'uups',
      constructorArgs: [LAYERZERO_ENDPOINTSDATA[chainId].endpointV2],
      unsafeAllow: [
        'constructor',
        'state-variable-immutable',
        'missing-initializer-call',
      ],
    },
  )

  await lotturaHubProxy.waitForDeployment()

  console.log(`LotturaHub deployed at: ${await lotturaHubProxy.getAddress()}`)
}

main()
  .then()
  .catch((e) => console.error(e))
