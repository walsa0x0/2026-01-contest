import hre, { ethers, upgrades } from 'hardhat'
import { zeroAddress } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  const chainId = await publicClient.getChainId()

  const chainData = LAYERZERO_ENDPOINTSDATA[chainId]

  if (!chainData) {
    throw new Error(`Unsupported chainId ${chainId}`)
  }

  if (chainData.lotturaCoreAddress === zeroAddress) {
    throw new Error(`Missing lotturaCore for chainId ${chainId}`)
  }

  console.log('Upgrading LotturaCore')
  console.log('Network: ', hre.network.name)
  console.log('Chain ID: ', chainId)
  console.log('Deployer Address: ', deployerAddress)
  console.log('Chain data:', chainData)

  const lotturaCoreFactory = await ethers.getContractFactory('LotturaCore')

  const upgraded = await upgrades.upgradeProxy(
    chainData.lotturaCoreAddress!,
    lotturaCoreFactory,
    {
      constructorArgs: [LAYERZERO_ENDPOINTSDATA[chainId].endpointV2],
      unsafeAllow: [
        'constructor',
        'state-variable-immutable',
        'missing-initializer-call',
      ],
    },
  )

  await upgraded.waitForDeployment()

  console.log('✅ LotturaCore upgraded successfully')
}

main()
  .then()
  .catch((e) => console.error(e))
