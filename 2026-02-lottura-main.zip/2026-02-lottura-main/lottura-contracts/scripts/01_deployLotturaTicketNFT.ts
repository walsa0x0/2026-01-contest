import hre from 'hardhat'
import { privateKeyToAccount } from 'viem/accounts'
import { LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  console.log('Deploying LotturaTicketNFT on:', hre.network.name)

  console.log('Deployer address:', deployerAddress)

  const chainId = await publicClient.getChainId()

  console.log('Chain ID:', chainId)

  const lotturaTicketNFT = await hre.viem.deployContract('LotturaTicketNFT', [
    'LotturaTicketNFT',
    'OTNFT',
    LAYERZERO_ENDPOINTSDATA[chainId].endpointV2,
    deployerAddress,
  ])

  console.log(`LotturaTicketNFT deployed at: ${lotturaTicketNFT.address}`)
}

main()
  .then()
  .catch((e) => console.error(e))
