import hre from 'hardhat'
import {
  createWalletClient,
  getContract,
  http,
  pad,
  parseEther,
  zeroAddress,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { chainByName, LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  const walletClient = createWalletClient({
    account: deployer,
    chain: chainByName[hre.network.name],
    transport: http(),
  })

  const chainId = await publicClient.getChainId()

  const chainData = LAYERZERO_ENDPOINTSDATA[chainId]

  if (!chainData) {
    throw new Error(`Unsupported chainId ${chainId}`)
  }

  if (chainData.lotturaHubAddress === zeroAddress) {
    throw new Error(`Missing lotturaHub for chainId ${chainId}`)
  }

  let nonce = await publicClient.getTransactionCount({
    address: deployerAddress,
  })

  console.log('Testing cross-chain purchase')
  console.log('Network: ', hre.network.name)
  console.log('Chain ID: ', chainId)
  console.log('Deployer Address: ', deployerAddress)
  console.log('Chain data:', chainData)

  const mockUSDT0Artifact = await hre.artifacts.readArtifact('MockUSDT0')

  const usdt0 = getContract({
    address: chainData.usdt0Address,
    abi: mockUSDT0Artifact.abi,
    client: walletClient,
  })

  const mintingTxHash = await usdt0.write.mint([deployerAddress, 10_000_000n], {
    nonce,
  })

  await publicClient.waitForTransactionReceipt({
    hash: mintingTxHash,
  })

  nonce++

  const approveTxHash = await usdt0.write.approve(
    [chainData.lotturaHubAddress, 10_000_000n],
    { nonce },
  )

  await publicClient.waitForTransactionReceipt({
    hash: approveTxHash,
  })

  nonce++

  const lotturaHubArtifact = await hre.artifacts.readArtifact('LotturaHub')

  const lotturaHub = getContract({
    address: chainData.lotturaHubAddress,
    abi: lotturaHubArtifact.abi,
    client: walletClient,
  })

  const fundGasTxHash = await lotturaHub.write.fundGas({
    value: parseEther('0.01'),
    nonce,
  })

  await publicClient.waitForTransactionReceipt({
    hash: fundGasTxHash,
  })

  nonce++

  const purchaseTicketTxHash = await lotturaHub.write.purchaseTicket(
    [
      [1, 2, 3, 4, 5, 6], // ticket numbers
      1n, // draw ID
      pad('0x0000000000000000000000000000000000000001', { size: 32 }), // randomness
    ],
    { nonce },
  )

  console.log('Purchasing ticket... ', purchaseTicketTxHash)

  await publicClient.waitForTransactionReceipt({
    hash: purchaseTicketTxHash,
  })

  console.log('✅ Ticket purchased successfully')
}

main()
  .then()
  .catch((e) => console.error(e))
