import hre from 'hardhat'
import { createWalletClient, getContract, http, zeroAddress } from 'viem'
import { Address, privateKeyToAccount } from 'viem/accounts'
import { chainByName, LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

const NEW_OWNER_ADDRESS: Address = '0x00000000000000000000000000000000000000000'

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  const walletClient = createWalletClient({
    account: deployer,
    chain: chainByName[hre.network.name],
    transport: http(),
  })

  const chainId = await publicClient.getChainId()

  const chainData = LAYERZERO_ENDPOINTSDATA[chainId]

  if (!chainData) {
    throw new Error(`Unsupported chainId ${chainId}`)
  }

  if (chainData.lotturaTicketNftAddress === zeroAddress) {
    throw new Error(`Missing lotturaTicketNftAddress for chainId ${chainId}`)
  }

  console.log('Transferring LotturaTicketNFT ownership')
  console.log('Network: ', hre.network.name)
  console.log('Chain ID: ', chainId)
  console.log('Deployer Address: ', deployerAddress)

  const lotturaTicketNFTArtifact =
    await hre.artifacts.readArtifact('LotturaTicketNFT')

  const lotturaTicketNFT = getContract({
    address: chainData.lotturaTicketNftAddress,
    abi: lotturaTicketNFTArtifact.abi,
    client: walletClient,
  })

  const transferOwnershipTxHash =
    await lotturaTicketNFT.write.transferOwnership([NEW_OWNER_ADDRESS])

  await publicClient.waitForTransactionReceipt({
    hash: transferOwnershipTxHash,
  })

  console.log('✅ Ownership transferred successfully')
}

main()
  .then()
  .catch((e) => console.error(e))
