import hre from 'hardhat'
import { privateKeyToAccount } from 'viem/accounts'
import { LAYERZERO_ENDPOINTSDATA } from './chain-helpers'

async function main() {
  const publicClient = await hre.viem.getPublicClient()

  const deployer = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`)

  const deployerAddress = deployer.address

  console.log('Deploying MockUSDT0 on:', hre.network.name)

  console.log('Deployer address:', deployerAddress)

  const chainId = await publicClient.getChainId()

  console.log('Chain ID:', chainId)

  const mockUSDT0 = await hre.viem.deployContract('MockUSDT0', [
    'MockUSDT0',
    'MUSDT0',
    LAYERZERO_ENDPOINTSDATA[chainId].endpointV2,
    deployerAddress,
  ])

  console.log(`MockUSDT0 deployed at: ${mockUSDT0.address}`)
}

main()
  .then()
  .catch((e) => console.error(e))
