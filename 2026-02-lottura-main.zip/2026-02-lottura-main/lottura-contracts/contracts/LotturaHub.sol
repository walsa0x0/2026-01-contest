// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

import {
    UUPSUpgradeable
} from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import {
    PausableUpgradeable
} from "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {
    SafeERC20
} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {
    OAppUpgradeable,
    MessagingFee,
    Origin
} from "@layerzerolabs/oapp-evm-upgradeable/contracts/oapp/OAppUpgradeable.sol";
import {
    IOFT,
    SendParam
} from "@layerzerolabs/oft-evm/contracts/interfaces/IOFT.sol";
import {
    OptionsBuilder
} from "@layerzerolabs/oapp-evm/contracts/oapp/libs/OptionsBuilder.sol";
import {
    OAppOptionsType3Upgradeable
} from "@layerzerolabs/oapp-evm-upgradeable/contracts/oapp/libs/OAppOptionsType3Upgradeable.sol";
import {TicketReceipt} from "./libraries/Common.sol";
import {LotturaTicketNFT} from "./LotturaTicketNFT.sol";
import {LotturaCore} from "./LotturaCore.sol";

/**
 * @title LotturaHub
 * @notice LotturaHub is the main contract for managing lottery ticket purchases and claims across chains.
 * It interacts with LotturaCore for core lottery functionalities and LotturaTicketNFT for ticket NFT management.
 * @dev This contract is upgradeable using UUPS pattern and includes pausability features.
 */
contract LotturaHub is
    UUPSUpgradeable,
    OAppUpgradeable,
    PausableUpgradeable,
    OAppOptionsType3Upgradeable
{
    using SafeERC20 for IERC20;
    using OptionsBuilder for bytes;

    ///////////////////////////////////////////////////////////////
    //                        CONSTANTS
    ///////////////////////////////////////////////////////////////

    uint8 private constant MIN_NUMBER = 1; // Ticket numbers range from 1 to 50

    uint8 private constant MAX_NUMBER = 50; // Ticket numbers range from 1 to 50

    uint8 private constant NUMBERS_PER_TICKET = 6; // Each ticket has 6 numbers

    uint8 private constant MSG_TYPE_PURCHASE = 1; // Message type for ticket purchase for cross-chain

    uint8 private constant MSG_TYPE_CLAIM = 2; // Message type for ticket claim for cross-chain

    /*//////////////////////////////////////////////////////////////
    /                      STRUCTS AND ENUMS                       /
    //////////////////////////////////////////////////////////////*/

    /**
     * @dev Enumeration of invalid parameter types for error handling.
     */
    enum InvalidParams {
        ZeroAmount,
        DrawIdZero,
        TicketNumbersOutOfRange,
        TicketNumbersDuplicate,
        ZeroAddressLotturaCore,
        ZeroLotturaCoreEid,
        ZeroAddressPaymentToken,
        ZeroTicketPrice,
        ZeroAddressImplementation,
        ZeroAddressTicketNFT,
        ZeroHashedRandomness,
        InvalidGasAmount,
        NotEnoughBalance,
        NoTickets,
        ArrayLengthMismatch,
        InvalidCommission
    }

    ///////////////////////////////////////////////////////////////
    //                          EVENTS
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Emitted when the ticket price is updated.
     * @param price The new ticket price.
     */
    event TicketPriceUpdated(uint256 indexed price);

    /**
     * @notice Emitted when the LotturaCore contract address and EID is updated.
     * @param lotturaCore The new LotturaCore contract address.
     * @param lotturaCoreEid The new LotturaCore EID.
     */
    event LotturaCoreUpdated(
        address indexed lotturaCore,
        uint32 indexed lotturaCoreEid
    );

    /**
     * @notice Emitted when the payment token address is updated.
     * @param paymentToken The new payment token address.
     */
    event PaymentTokenUpdated(address indexed paymentToken);

    /**
     * @notice Emitted when a ticket token is purchased.
     * @param tokenId The ID of the purchased ticket token.
     * @param owner The address of the ticket owner.
     * @param drawId The draw ID for which the ticket was purchased.
     * @param numbers The selected numbers on the ticket.
     * @param hashedRandomness The hashed randomness associated with the ticket purchase.
     */
    event TokenPurchased(
        uint256 indexed tokenId,
        address indexed owner,
        uint256 indexed drawId,
        uint8[6] numbers,
        bytes32 hashedRandomness
    );

    /**
     * @notice Emitted when a ticket token is claimed.
     * @param tokenId The ID of the claimed ticket token.
     * @param owner The address of the ticket owner who claimed the ticket.
     */
    event TokenClaimed(uint256 indexed tokenId, address indexed owner);

    /**
     * @notice Emitted when the commission rate is updated.
     * @param oldCommission The previous commission rate.
     * @param newCommission The new commission rate.
     */
    event CommissionUpdated(
        uint16 indexed oldCommission,
        uint16 indexed newCommission
    );

    /**
     * @notice Emitted when the LotturaTicketNFT contract address is updated.
     * @param ticketNFT The new LotturaTicketNFT contract address.
     */
    event TicketNFTUpdated(address indexed ticketNFT);

    /**
     * @notice Emitted when native tokens are funded to the contract for gas.
     * @param sender The address of the sender who funded the native tokens.
     * @param amount The amount of native tokens funded.
     */
    event NativeTokenFunded(address indexed sender, uint256 indexed amount);

    /**
     * @notice Emitted when tokens are withdrawn in case of emergency.
     * @param owner The address of the owner who performed the withdrawal.
     * @param tokenAmount The amount of tokens withdrawn.
     */
    event TokensEmergencyWithdraw(
        address indexed owner,
        uint256 indexed tokenAmount
    );

    /**
     * @notice Emitted when native tokens are withdrawn in case of emergency.
     * @param owner The address of the owner who performed the withdrawal.
     * @param nativeAmount The amount of native tokens withdrawn.
     */
    event NativeEmergencyWithdraw(
        address indexed owner,
        uint256 indexed nativeAmount
    );

    /*//////////////////////////////////////////////////////////////
    /                        STATE VARIABLES                       /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Address of the LotturaCore contract.
     */
    LotturaCore public lotturaCore;

    /**
     * @notice EID of the LotturaCore contract.
     */
    uint32 public lotturaCoreEid;

    /**
     * @notice Address of the payment token (OFT).
     */
    address public paymentToken;

    /**
     * @notice Price of a lottery ticket.
     */
    uint256 public ticketPrice;

    /**
     * @notice Commission rate in basis points.
     */
    uint16 public commission;

    /**
     * @notice Address of the LotturaTicketNFT contract.
     */
    LotturaTicketNFT public ticketNFT;

    /**
     * @notice Flag indicating if the contract is deployed on Polygon chain.
     */
    bool public isOnPolygonChain;

    uint256 private _chainId; // Chain ID of the current chain

    /*//////////////////////////////////////////////////////////////
    /                            ERRORS                            /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Thrown when a function is called with an invalid parameter.
     * @param param The invalid parameter.
     */
    error InvalidParam(InvalidParams param);

    /**
     * @notice Thrown when there are insufficient LayerZero fees for cross-chain operations.
     */
    error InsufficientLayerZeroFee();

    /**
     * @notice Thrown when a caller is not the owner of a specified token.
     */
    error NotTokenOwner();

    /**
     * @notice Thrown when an emergency withdrawal fails.
     */
    error EmergencyWithdrawFailed();

    ///////////////////////////////////////////////////////////////
    //                       CONSTRUCTOR
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Constructor for LotturaHub contract.
     * @param _endpoint The LayerZero endpoint address.
     * @dev Disables initializers to prevent misuse.
     */
    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor(address _endpoint) OAppUpgradeable(_endpoint) {
        _disableInitializers();
    }

    /*//////////////////////////////////////////////////////////////
    /                       EXTERNAL METHODS                       /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Initializes the LotturaHub contract.
     * @param _paymentToken The address of the payment token (OFT).
     * @param _initTicketPrice The initial price of a lottery ticket.
     * @param _initCommission The initial commission rate in basis points.
     * @param _isOnPolygonChain Flag indicating if the contract is deployed on Polygon chain.
     * @dev This function must be called only once during deployment.
     * @custom:emits `PaymentTokenUpdated` Emitted when the payment token is set.
     * @custom:emits `TicketPriceUpdated` Emitted when the ticket price is set.
     * @custom:emits `CommissionUpdated` Emitted when the commission rate is set
     */
    function initialize(
        address _paymentToken,
        uint256 _initTicketPrice,
        uint16 _initCommission,
        bool _isOnPolygonChain
    ) external initializer {
        __UUPSUpgradeable_init();
        __Ownable_init(_msgSender());
        __OApp_init(_msgSender());
        __Pausable_init();

        _chainId = block.chainid;

        _updatePaymentToken(_paymentToken);

        _updateTicketPrice(_initTicketPrice);

        _updateCommission(_initCommission);

        isOnPolygonChain = _isOnPolygonChain;

        // MUST CALL updateLotturaCore AFTER initialization to set lotturaCore and lotturaCoreEid

        // MUST CALL updateTicketNFT AFTER initialization to set ticketNFT
    }

    /**
     * @notice Updates the LotturaCore contract address and EID.
     * @param newLotturaCore The new LotturaCore contract address.
     * @param newLotturaCoreEid The new LotturaCore EID.
     * @dev Only the contract owner can call this function.
     * @custom:emits `LotturaCoreUpdated` Emitted when the LotturaCore contract is updated.
     * @custom:error `InvalidParam` Thrown if the newLotturaCore address is zero or newLotturaCoreEid is zero.
     */
    function updateLotturaCore(
        address newLotturaCore,
        uint32 newLotturaCoreEid
    ) external onlyOwner {
        _updateLotturaCore(newLotturaCore, newLotturaCoreEid);
    }

    /**
     * @notice Updates the payment token address.
     * @param newPaymentToken The new payment token address.
     * @dev Only the contract owner can call this function.
     * @custom:emits `PaymentTokenUpdated` Emitted when the payment token is updated.
     * @custom:error `InvalidParam` Thrown if the newPaymentToken address is zero.
     */
    function updatePaymentToken(address newPaymentToken) external onlyOwner {
        _updatePaymentToken(newPaymentToken);
    }

    /**
     * @notice Updates the ticket price.
     * @param newTicketPrice The new ticket price.
     * @dev Only the contract owner can call this function.
     * @custom:emits `TicketPriceUpdated` Emitted when the ticket price is updated.
     * @custom:error `InvalidParam` Thrown if the newTicketPrice is zero.
     */
    function updateTicketPrice(uint256 newTicketPrice) external onlyOwner {
        _updateTicketPrice(newTicketPrice);
    }

    /**
     * @notice Updates the commission rate.
     * @param newCommission The new commission rate in basis points.
     * @dev Only the contract owner can call this function.
     * @custom:emits `CommissionUpdated` Emitted when the commission rate is updated.
     */
    function updateCommission(uint16 newCommission) external onlyOwner {
        _updateCommission(newCommission);
    }

    /**
     * @notice Updates the LotturaTicketNFT contract address.
     * @param newTicketNFT The new LotturaTicketNFT contract address.
     * @dev Only the contract owner can call this function.
     * @custom:emits `TicketNFTUpdated` Emitted when the LotturaTicketNFT contract is updated.
     * @custom:error `InvalidParam` Thrown if the newTicketNFT address is zero.
     */
    function updateTicketNFT(address newTicketNFT) external onlyOwner {
        _updateTicketNFT(newTicketNFT);
    }

    /**
     * @notice Allows the contract owner to withdraw tokens in case of emergency.
     * @param amount The amount of tokens to withdraw.
     * @dev Only the contract owner can call this function.
     * @custom:error `InvalidParam` Thrown if the amount is zero.
     */
    function tokensEmergencyWithdraw(uint256 amount) external onlyOwner {
        if (amount == 0) revert InvalidParam(InvalidParams.ZeroAmount);

        IERC20(paymentToken).safeTransfer(_msgSender(), amount);

        emit TokensEmergencyWithdraw(_msgSender(), amount);
    }

    /**
     * @notice Allows the contract owner to withdraw native in case of emergency.
     * @param amount The amount of native to withdraw.
     * @dev Only the contract owner can call this function.
     * @custom:error `InvalidParam` Thrown if the amount is zero or if there is not enough balance.
     */
    function nativeEmergencyWithdraw(uint256 amount) external onlyOwner {
        if (amount == 0) revert InvalidParam(InvalidParams.ZeroAmount);

        if (address(this).balance < amount)
            revert InvalidParam(InvalidParams.NotEnoughBalance);

        (bool success, ) = _msgSender().call{value: amount}("");

        if (!success) revert EmergencyWithdrawFailed();

        emit NativeEmergencyWithdraw(_msgSender(), amount);
    }

    /**
     * @notice Pauses the contract, disabling ticket purchases and claims.
     * @dev Only the contract owner can call this function.
     */
    function pause() external onlyOwner {
        _pause();
    }

    /**
     * @notice Unpauses the contract, enabling ticket purchases and claims.
     * @dev Only the contract owner can call this function.
     */
    function unpause() external onlyOwner {
        _unpause();
    }

    /**
     * @notice Funds the contract with native tokens for LayerZero gas fees.
     * @dev Emits a `NativeTokenFunded` event upon successful funding.
     * @custom:error `InvalidParam` Thrown if the sent value is zero.
     */
    function fundGas() external payable {
        if (msg.value == 0) revert InvalidParam(InvalidParams.InvalidGasAmount);

        emit NativeTokenFunded(_msgSender(), msg.value);
    }

    /**
     * @notice Purchases lottery tickets with specified numbers for a given draw.
     * @param numbersList An array of arrays, each containing 6 unique numbers selected for the tickets.
     * @param drawId The ID of the lottery draw for which the tickets are purchased.
     * @param hashedRandomnessList An array of bytes32 values representing user committed randomness for each ticket.
     * @return tokenIds An array of token IDs representing the purchased tickets.
     * @dev Reverts with `InvalidParam` error if drawId is zero, no tickets are provided,
     * or if the lengths of numbersList and hashedRandomnessList do not match.
     * @custom:emits `TokenPurchased` Emitted when a ticket token is purchased.
     * @custom:error `InvalidParam` Thrown if drawId is zero, no tickets are provided,
     * or if the lengths of numbersList and hashedRandomnessList do not match.
     */
    function purchaseTickets(
        uint8[6][] calldata numbersList,
        uint256 drawId,
        bytes32[] calldata hashedRandomnessList
    ) external whenNotPaused returns (uint256[] memory tokenIds) {
        uint256 ticketsCount = numbersList.length;

        if (drawId == 0) revert InvalidParam(InvalidParams.DrawIdZero);

        if (ticketsCount == 0) revert InvalidParam(InvalidParams.NoTickets);

        if (ticketsCount != hashedRandomnessList.length)
            revert InvalidParam(InvalidParams.ArrayLengthMismatch);

        tokenIds = new uint256[](ticketsCount);

        uint256 totalPrice = ticketPrice * ticketsCount;

        if (isOnPolygonChain) {
            IERC20(paymentToken).safeTransferFrom(
                _msgSender(),
                address(lotturaCore),
                totalPrice
            );
        } else {
            IERC20(paymentToken).safeTransferFrom(
                _msgSender(),
                address(this),
                totalPrice
            );
        }

        for (uint256 i = 0; i < ticketsCount; i++) {
            bytes32 hashedRandomness = hashedRandomnessList[i];

            if (hashedRandomness == bytes32(0))
                revert InvalidParam(InvalidParams.ZeroHashedRandomness);

            uint8[6] calldata numbers = numbersList[i];

            _validateTicketNumbers(numbers);

            TicketReceipt memory ticketReceipt = TicketReceipt({
                numbers: numbers,
                drawId: drawId,
                timestamp: uint40(block.timestamp)
            });

            uint256 tokenId = ticketNFT.mint(_msgSender(), ticketReceipt);

            tokenIds[i] = tokenId;

            if (isOnPolygonChain) {
                lotturaCore.purchaseTicket(
                    tokenId,
                    _msgSender(),
                    numbers,
                    drawId,
                    hashedRandomness,
                    ticketPrice,
                    commission
                );
            } else {
                _sendCrossChainPurchase(
                    tokenId,
                    _msgSender(),
                    numbers,
                    drawId,
                    hashedRandomness
                );
            }

            emit TokenPurchased(
                tokenId,
                _msgSender(),
                drawId,
                numbers,
                hashedRandomness
            );
        }
    }

    /**
     * @notice Claims the lottery ticket with the specified token ID.
     * @param tokenId The ID of the ticket token to be claimed.
     * @dev It verifies the caller is the owner of the ticket and interacts with LotturaCore for cross-chain claims if necessary.
     * @custom:emits `TokenClaimed` Emitted when a ticket token is claimed.
     * @custom:error `NotTokenOwner` Thrown if the caller is not the owner of the specified token ID.
     */
    function claimTicket(uint256 tokenId) external whenNotPaused {
        if (ticketNFT.ownerOf(tokenId) != _msgSender()) revert NotTokenOwner();

        if (isOnPolygonChain) {
            lotturaCore.claimTicket(tokenId, _msgSender());
        } else {
            _sendCrossChainClaim(tokenId, _msgSender());
        }

        emit TokenClaimed(tokenId, _msgSender());
    }

    /*//////////////////////////////////////////////////////////////
    /                       INTERNAL METHODS                       /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Authorizes the upgrade of the contract implementation.
     * @param newImplementation The address of the new implementation contract.
     * @dev Only the contract owner can authorize an upgrade.
     * @custom:error `InvalidParam` Thrown if the newImplementation address is zero.
     */
    function _authorizeUpgrade(
        address newImplementation
    ) internal override onlyOwner {
        // Validation for new implementation
        if (newImplementation == address(0))
            revert InvalidParam(InvalidParams.ZeroAddressImplementation);
    }

    /**
     * @notice Handles incoming LayerZero messages.
     * @dev This function is intentionally left empty as LotturaHub does not process incoming messages.
     */
    function _lzReceive(
        Origin calldata /*_origin*/,
        bytes32 /*_guid*/,
        bytes calldata /*_message*/,
        address /*_executor*/,
        bytes calldata /*_extraData*/
    ) internal override {}

    /*//////////////////////////////////////////////////////////////
    /                       PRIVATE METHODS                        /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Validates the ticket numbers to ensure they are within the valid range and contain no duplicates.
     * @param numbers An array of 6 numbers selected for the ticket.
     * @dev Reverts with `InvalidParam` error if any number is out of range or if there are duplicate numbers.
     */
    function _validateTicketNumbers(uint8[6] memory numbers) private pure {
        for (uint8 i = 0; i < NUMBERS_PER_TICKET; i++) {
            if (numbers[i] < MIN_NUMBER || numbers[i] > MAX_NUMBER) {
                revert InvalidParam(InvalidParams.TicketNumbersOutOfRange);
            }

            // Check duplicates
            for (uint8 j = i + 1; j < NUMBERS_PER_TICKET; j++) {
                if (numbers[i] == numbers[j])
                    revert InvalidParam(InvalidParams.TicketNumbersDuplicate);
            }
        }
    }

    /**
     * @notice Updates the LotturaCore contract address and EID.
     * @param newLotturaCore The new LotturaCore contract address.
     * @param newLotturaCoreEid The new LotturaCore EID.
     * @dev Reverts with `InvalidParam` error if the newLotturaCore address is zero or newLotturaCoreEid is zero.
     * @custom:emits `LotturaCoreUpdated` Emitted when the LotturaCore contract is updated.
     */
    function _updateLotturaCore(
        address newLotturaCore,
        uint32 newLotturaCoreEid
    ) private {
        if (newLotturaCore == address(0))
            revert InvalidParam(InvalidParams.ZeroAddressLotturaCore);
        if (newLotturaCoreEid == 0)
            revert InvalidParam(InvalidParams.ZeroLotturaCoreEid);

        lotturaCore = LotturaCore(newLotturaCore);

        lotturaCoreEid = newLotturaCoreEid;

        emit LotturaCoreUpdated(address(lotturaCore), lotturaCoreEid);
    }

    /**
     * @notice Updates the payment token address.
     * @param newPaymentToken The new payment token address.
     * @dev Reverts with `InvalidParam` error if the newPaymentToken address is zero.
     * @custom:emits `PaymentTokenUpdated` Emitted when the payment token is updated.
     */
    function _updatePaymentToken(address newPaymentToken) private {
        if (newPaymentToken == address(0))
            revert InvalidParam(InvalidParams.ZeroAddressPaymentToken);

        paymentToken = newPaymentToken;

        emit PaymentTokenUpdated(paymentToken);
    }

    /**
     * @notice Updates the ticket price.
     * @param newPrice The new ticket price.
     * @dev Reverts with `InvalidParam` error if the newPrice is zero.
     * @custom:emits `TicketPriceUpdated` Emitted when the ticket price is updated.
     */
    function _updateTicketPrice(uint256 newPrice) private {
        if (newPrice == 0) revert InvalidParam(InvalidParams.ZeroTicketPrice);

        ticketPrice = newPrice;

        emit TicketPriceUpdated(ticketPrice);
    }

    /**
     * @notice Updates the commission rate.
     * @param newCommission The new commission rate in basis points.
     * @custom:emits `CommissionUpdated` Emitted when the commission rate is updated.
     * @custom:error `InvalidParam` Thrown if the newCommission is greater than 10000 (100%).
     */
    function _updateCommission(uint16 newCommission) private {
        if (newCommission > 10000)
            revert InvalidParam(InvalidParams.InvalidCommission);

        uint16 oldCommission = commission;

        commission = newCommission;

        emit CommissionUpdated(oldCommission, newCommission);
    }

    /**
     * @notice Updates the LotturaTicketNFT contract address.
     * @param newTicketNFT The new LotturaTicketNFT contract address.
     * @dev Reverts with `InvalidParam` error if the newTicketNFT address is zero.
     * @custom:emits `TicketNFTUpdated` Emitted when the LotturaTicketNFT contract is updated.
     */
    function _updateTicketNFT(address newTicketNFT) private {
        if (newTicketNFT == address(0))
            revert InvalidParam(InvalidParams.ZeroAddressTicketNFT);

        ticketNFT = LotturaTicketNFT(newTicketNFT);

        emit TicketNFTUpdated(newTicketNFT);
    }

    /**
     * @notice Builds the LayerZero message options with compose option for cross-chain purchase.
     * @return The encoded options for the LayerZero message.
     */
    function _buildOptionsWithCompose() private pure returns (bytes memory) {
        return
            OptionsBuilder
                .newOptions()
                .addExecutorLzReceiveOption(200000, 0)
                .addExecutorLzComposeOption(0, 700000, 0);
    }

    /**
     * @notice Builds the LayerZero message options without compose option for cross-chain claim.
     * @return The encoded options for the LayerZero message.
     */
    function _buildOptionsWithoutCompose() private pure returns (bytes memory) {
        return
            OptionsBuilder.newOptions().addExecutorLzReceiveOption(500000, 0);
    }

    /**
     * @notice Sends a cross-chain purchase message to the LotturaCore contract.
     * @param tokenId The ID of the purchased ticket token.
     * @param buyer The address of the ticket buyer.
     * @param numbers An array of 6 unique numbers selected for the ticket.
     * @param drawId The ID of the lottery draw for which the ticket is purchased.
     * @param hashedRandomness A bytes32 value representing the user committed randomness for the draw.
     */
    function _sendCrossChainPurchase(
        uint256 tokenId,
        address buyer,
        uint8[6] memory numbers,
        uint256 drawId,
        bytes32 hashedRandomness
    ) private {
        bytes memory composeMsg = abi.encode(
            MSG_TYPE_PURCHASE,
            _chainId,
            tokenId,
            buyer,
            numbers,
            drawId,
            hashedRandomness,
            ticketPrice,
            commission
        );

        bytes memory options = _buildOptionsWithCompose();

        SendParam memory sendParam = SendParam({
            dstEid: lotturaCoreEid,
            to: _addressToBytes32(address(lotturaCore)),
            amountLD: ticketPrice,
            minAmountLD: ticketPrice,
            extraOptions: options,
            composeMsg: composeMsg,
            oftCmd: ""
        });

        MessagingFee memory fee = IOFT(paymentToken).quoteSend(
            sendParam,
            false
        );

        if (address(this).balance < fee.nativeFee)
            revert InsufficientLayerZeroFee();

        IOFT(paymentToken).send{value: fee.nativeFee}(
            sendParam,
            fee,
            address(this)
        );
    }

    /**
     * @notice Sends a cross-chain claim message to the LotturaCore contract.
     * @param tokenId The ID of the ticket token to be claimed.
     * @param claimer The address of the ticket claimer.
     */
    function _sendCrossChainClaim(uint256 tokenId, address claimer) private {
        bytes memory message = abi.encode(
            MSG_TYPE_CLAIM,
            _chainId,
            tokenId,
            claimer
        );

        MessagingFee memory fee = _quote(
            lotturaCoreEid,
            message,
            this.combineOptions(
                lotturaCoreEid,
                1,
                _buildOptionsWithoutCompose()
            ),
            false
        );

        _lzSend(
            lotturaCoreEid,
            message,
            this.combineOptions(
                lotturaCoreEid,
                1,
                _buildOptionsWithoutCompose()
            ),
            fee,
            address(this)
        );
    }

    /**
     * @notice Pays the required native fee for LayerZero cross-chain operations.
     * @param _nativeFee The required native fee amount.
     * @return nativeFee The amount of native fee paid.
     * @dev Reverts with `NotEnoughNative` error if the contract does not have enough native balance.
     */
    function _payNative(
        uint256 _nativeFee
    ) internal virtual override returns (uint256 nativeFee) {
        if (address(this).balance < _nativeFee)
            revert NotEnoughNative(address(this).balance);

        return _nativeFee;
    }

    /**
     * @notice Converts an address to a bytes32 representation.
     * @param _addr The address to convert.
     * @return The bytes32 representation of the address.
     */
    function _addressToBytes32(address _addr) private pure returns (bytes32) {
        return bytes32(uint256(uint160(_addr)));
    }
}
