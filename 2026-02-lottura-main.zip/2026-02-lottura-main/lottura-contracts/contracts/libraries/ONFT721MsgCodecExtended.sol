// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

import {TicketReceipt, ExtendedSendParam} from "./Common.sol";

/**
 * @title ONFT721MsgCodec
 * @notice Library for encoding and decoding ONFT721 LayerZero messages.
 */
library ONFT721MsgCodecExtended {
    uint8 private constant SEND_TO_OFFSET = 32;
    uint8 private constant TOKEN_ID_OFFSET = 64;
    uint8 private constant COMPOSE_FLAG_OFFSET = 64;
    uint8 private constant TICKET_OFFSET = 65;

    /**
     * @dev Encodes an ONFT721 LayerZero message payload.
     * @param _sendTo The recipient address.
     * @param _tokenId The ID of the token to transfer.
     * @param _composeMsg The composed payload.
     * @return payload The encoded message payload.
     * @return hasCompose A boolean indicating whether the message payload contains a composed payload.
     */
    function encode(
        bytes32 _sendTo,
        uint256 _tokenId,
        TicketReceipt memory _ticket,
        bytes memory _composeMsg
    ) internal view returns (bytes memory payload, bool hasCompose) {
        bytes memory ticketData = abi.encode(_ticket);

        hasCompose = _composeMsg.length > 0;

        payload = hasCompose
            ? abi.encodePacked(
                _sendTo,
                _tokenId,
                uint8(hasCompose ? 1 : 0),
                ticketData,
                addressToBytes32(msg.sender),
                _composeMsg
            )
            : abi.encodePacked(
                _sendTo,
                _tokenId,
                uint8(hasCompose ? 1 : 0),
                ticketData
            );
    }

    /**
     * @dev Decodes sendTo from the ONFT LayerZero message.
     * @param _msg The message.
     * @return The recipient address in bytes32 format.
     */
    function sendTo(bytes calldata _msg) internal pure returns (bytes32) {
        return bytes32(_msg[:SEND_TO_OFFSET]);
    }

    /**
     * @dev Decodes tokenId from the ONFT LayerZero message.
     * @param _msg The message.
     * @return The ID of the tokens to transfer.
     */
    function tokenId(bytes calldata _msg) internal pure returns (uint256) {
        return uint256(bytes32(_msg[SEND_TO_OFFSET:TOKEN_ID_OFFSET]));
    }

    function ticketReceipt(
        bytes calldata _msg
    ) internal pure returns (TicketReceipt memory) {
        bytes calldata data = _msg[TICKET_OFFSET:];

        return abi.decode(data, (TicketReceipt));
    }

    /**
     * @dev Decodes whether there is a composed payload.
     * @param _msg The message.
     * @return A boolean indicating whether the message has a composed payload.
     */
    function isComposed(bytes calldata _msg) internal pure returns (bool) {
        return uint8(_msg[COMPOSE_FLAG_OFFSET]) == 1;
    }

    /**
     * @dev Decodes the composed message.
     * @param _msg The message.
     * @return The composed message.
     */
    function composeMsg(
        bytes calldata _msg
    ) internal pure returns (bytes memory) {
        if (!isComposed(_msg)) {
            return "";
        }

        (, , bytes memory compose) = abi.decode(
            _msg[TICKET_OFFSET:],
            (TicketReceipt, bytes32, bytes)
        );

        return compose;
    }

    /**
     * @dev Converts an address to bytes32.
     * @param _addr The address to convert.
     * @return The bytes32 representation of the address.
     */
    function addressToBytes32(address _addr) internal pure returns (bytes32) {
        return bytes32(uint256(uint160(_addr)));
    }

    /**
     * @dev Converts bytes32 to an address.
     * @param _b The bytes32 value to convert.
     * @return The address representation of bytes32.
     */
    function bytes32ToAddress(bytes32 _b) internal pure returns (address) {
        return address(uint160(uint256(_b)));
    }
}
