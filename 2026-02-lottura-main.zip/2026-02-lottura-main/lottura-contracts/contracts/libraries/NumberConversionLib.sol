// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

/**
 * @title NumberConversionLib
 * @notice Library for converting between uint8[6] arrays and packed uint48 format
 *         for lottery ticket number representation.
 * @dev Each ticket has 6 numbers in the range 1-50, stored as 2-digit pairs
 *      in a single uint48 (e.g., [5,12,23,34,41,48] → 051223344148).
 */
library NumberConversionLib {
    ///////////////////////////////////////////////////////////////
    //                        CONSTANTS
    ///////////////////////////////////////////////////////////////
    /**
     * @notice Minimum number allowed (1)
     */
    uint8 public constant MIN_NUMBER = 1;

    /**
     * @notice Maximum number allowed (50)
     */
    uint8 public constant MAX_NUMBER = 50;

    /**
     * @notice Number of numbers per ticket
     */
    uint8 public constant NUMBERS_PER_TICKET = 6;

    /*//////////////////////////////////////////////////////////////
    /                            ERRORS                            /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Error for invalid number range
     * @param number The invalid number
     */
    error InvalidNumberRange(uint8 number);

    /**
     * @notice Error for duplicate numbers
     * @param number The duplicate number
     */
    error DuplicateNumber(uint8 number);

    /*//////////////////////////////////////////////////////////////
    /                       INTERNAL METHODS                       /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Converts an array of 6 uint8 numbers into a packed uint48 format
     * @param numbers Array of 6 numbers (each 1-50)
     * @return packed Packed uint48 representation
     */
    function numbersToUint48(
        uint8[6] memory numbers
    ) internal pure returns (uint48 packed) {
        packed = 0;

        for (uint8 i = 0; i < NUMBERS_PER_TICKET; i++) {
            // Validate range (1-50)
            if (numbers[i] < MIN_NUMBER || numbers[i] > MAX_NUMBER) {
                revert InvalidNumberRange(numbers[i]);
            }

            // Check for duplicates
            for (uint8 j = i + 1; j < NUMBERS_PER_TICKET; j++) {
                if (numbers[i] == numbers[j]) {
                    revert DuplicateNumber(numbers[i]);
                }
            }

            // Pack number as 2-digit pair
            // Multiply by 100 to shift left, then add current number
            packed = packed * 100 + uint48(numbers[i]);
        }

        return packed;
    }

    /**
     * @notice Converts a packed uint48 format back into an array of 6 uint8 numbers
     * @param packed Packed uint48 representation
     * @return numbers Array of 6 numbers (each 1-50)
     */
    function uint48ToNumbers(
        uint48 packed
    ) internal pure returns (uint8[6] memory numbers) {
        // Extract numbers from right to left
        for (uint8 i = 0; i < NUMBERS_PER_TICKET; i++) {
            // Get rightmost 2 digits
            numbers[NUMBERS_PER_TICKET - 1 - i] = uint8(packed % 100);

            // Shift right by dividing by 100
            packed = packed / 100;
        }

        return numbers;
    }

    /**
     * @notice Counts how many numbers match between a ticket and winning numbers
     * @param ticketNumbers Packed uint48 ticket numbers
     * @param winningNumbers Packed uint48 winning numbers
     * @return matches Number of matching numbers
     */
    function countMatches(
        uint48 ticketNumbers,
        uint48 winningNumbers
    ) internal pure returns (uint8 matches) {
        uint8[6] memory ticket = uint48ToNumbers(ticketNumbers);
        uint8[6] memory winning = uint48ToNumbers(winningNumbers);

        matches = 0;

        for (uint8 i = 0; i < NUMBERS_PER_TICKET; ++i) {
            for (uint8 j = 0; j < NUMBERS_PER_TICKET; ++j) {
                if (ticket[i] == winning[j]) {
                    matches++;

                    break;
                }
            }
        }

        return matches;
    }

    /**
     * @notice Generates 6 unique random numbers in the range 1-50
     *         using a given seed.
     * @param seed Seed for randomness
     * @return numbers Array of 6 unique random numbers
     */
    function generateRandomNumbers(
        uint256 seed
    ) internal pure returns (uint8[6] memory numbers) {
        uint8[50] memory pool;

        // Fill pool with 1..50
        for (uint8 i = 0; i < 50; i++) {
            pool[i] = i + 1;
        }

        uint256 randomness = seed;

        // Partial Fisher-Yates shuffle (only first 6)
        for (uint8 i = 0; i < 6; i++) {
            uint256 j = i + (randomness % (50 - i));
            randomness = uint256(keccak256(abi.encodePacked(randomness, i)));

            // swap pool[i] and pool[j]
            uint8 temp = pool[i];
            pool[i] = pool[j];
            pool[j] = temp;

            numbers[i] = pool[i];
        }
    }
}
