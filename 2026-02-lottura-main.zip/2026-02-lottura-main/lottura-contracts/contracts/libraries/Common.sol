// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

struct TicketReceipt {
    uint8[6] numbers;
    uint256 drawId;
    uint40 timestamp;
}

struct ExtendedSendParam {
    uint32 dstEid;
    bytes32 to;
    uint256 tokenId;
    TicketReceipt ticket;
    bytes extraOptions;
    bytes composeMsg;
    bytes onftCmd;
}
