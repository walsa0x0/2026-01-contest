// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

import {
    ONFT721Enumerable
} from "@layerzerolabs/onft-evm/contracts/onft721/ONFT721Enumerable.sol";
import {Origin} from "@layerzerolabs/oapp-evm/contracts/oapp/OApp.sol";
import {
    ONFTComposeMsgCodec
} from "@layerzerolabs/onft-evm/contracts/libs/ONFTComposeMsgCodec.sol";
import {
    SendParam
} from "@layerzerolabs/onft-evm/contracts/onft721/interfaces/IONFT721.sol";
import {
    MessagingFee,
    MessagingReceipt
} from "@layerzerolabs/oapp-evm/contracts/oapp/OAppSender.sol";
import {
    IOAppMsgInspector
} from "@layerzerolabs/oapp-evm/contracts/oapp/interfaces/IOAppMsgInspector.sol";
import {ONFT721MsgCodecExtended} from "./libraries/ONFT721MsgCodecExtended.sol";
import {TicketReceipt, ExtendedSendParam} from "./libraries/Common.sol";

/**
 * @title LotturaTicketNFT
 * @notice Lottura Ticket NFT contract enabling cross-chain NFT transfers with ticket receipt data.
 * @dev Inherits from ONFT721Enumerable for cross-chain NFT functionality.
 */
contract LotturaTicketNFT is ONFT721Enumerable {
    using ONFT721MsgCodecExtended for bytes;
    using ONFT721MsgCodecExtended for bytes32;

    /*//////////////////////////////////////////////////////////////
    /                      STRUCTS AND ENUMS                       /
    //////////////////////////////////////////////////////////////*/

    /**
     * @dev Enumeration of invalid parameter types for error handling.
     */
    enum InvalidParams {
        ZeroAddressMinter
    }

    ///////////////////////////////////////////////////////////////
    //                          EVENTS
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Emitted when the minter address is updated.
     * @param newMinter The new minter address.
     */
    event MinterUpdated(address indexed newMinter);

    /**
     * @notice Emitted when a new ticket NFT is minted.
     * @param tokenId The ID of the minted ticket NFT.
     * @param owner The address of the ticket NFT owner.
     * @param numbers The lottery numbers associated with the ticket.
     * @param drawId The draw ID for which the ticket was minted.
     */
    event TicketMinted(
        uint256 indexed tokenId,
        address indexed owner,
        uint8[6] numbers,
        uint256 drawId
    );

    /*//////////////////////////////////////////////////////////////
    /                        STATE VARIABLES                       /
    //////////////////////////////////////////////////////////////*/

    mapping(uint256 => TicketReceipt) private _ticketReceipts; // tokenId => TicketReceipt

    uint256 private _localTokenCounter; // Local counter for token ID generation

    uint256 private _chainId; // Chain ID of the current blockchain

    address private _minter; // Address authorized to mint tickets

    /*//////////////////////////////////////////////////////////////
    /                            ERRORS                            /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Thrown when a function is called with an invalid parameter.
     * @param param The invalid parameter.
     */
    error InvalidParam(InvalidParams param);

    /**
     * @notice Thrown when the caller is not the minter.
     */
    error NotAMinter();

    /*//////////////////////////////////////////////////////////////
    /                           MODIFIERS                          /
    //////////////////////////////////////////////////////////////*/

    /**
     * @dev Modifier to restrict function access to the minter only.
     * @custom:error `NotAMinter` Thrown if the caller is not the minter.
     */
    modifier onlyMinter() {
        if (_msgSender() != _minter) revert NotAMinter();

        _;
    }

    /*//////////////////////////////////////////////////////////////
    /                          CONSTRUCTOR                         /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Constructor to initialize the LotturaTicketNFT contract.
     * @param _name The name of the NFT collection.
     * @param _symbol The symbol of the NFT collection.
     * @param _lzEndpoint The LayerZero endpoint address for cross-chain messaging.
     * @param _delegate The delegate address for ONFT operations.
     */
    constructor(
        string memory _name,
        string memory _symbol,
        address _lzEndpoint,
        address _delegate
    ) ONFT721Enumerable(_name, _symbol, _lzEndpoint, _delegate) {
        _chainId = block.chainid;

        // MUST CALL setMinter AFTER deployment to set the minter
    }

    /*//////////////////////////////////////////////////////////////
    /                       EXTERNAL METHODS                       /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Sets the minter address authorized to mint tickets.
     * @param newMinter The new minter address.
     * @dev Can only be called by the contract owner.
     * @custom:error `InvalidParam` Thrown if the new minter address is invalid.
     * @custom:emits `MinterUpdated` Emitted when the minter address is updated.
     */
    function setMinter(address newMinter) external onlyOwner {
        _setMinter(newMinter);
    }

    /**
     * @notice Mints a new ticket NFT to the specified address with the provided ticket receipt.
     * @param to The address to mint the ticket NFT to.
     * @param ticketReceipt The ticket receipt data associated with the minted ticket.
     * @return tokenId The ID of the minted ticket NFT.
     * @dev Can only be called by the authorized minter.
     * @custom:error `NotAMinter` Thrown if the caller is not the minter.
     * @custom:emits `TicketMinted` Emitted when a new ticket NFT is minted.
     */
    function mint(
        address to,
        TicketReceipt calldata ticketReceipt
    ) external onlyMinter returns (uint256 tokenId) {
        tokenId = _generateTokenId();

        _mint(to, tokenId);

        _ticketReceipts[tokenId] = ticketReceipt;

        _localTokenCounter++;

        emit TicketMinted(
            tokenId,
            to,
            ticketReceipt.numbers,
            ticketReceipt.drawId
        );
    }

    /**
     * @notice Retrieves the ticket receipt associated with a given token ID.
     * @param tokenId The ID of the ticket NFT.
     * @return TicketReceipt struct containing the ticket details.
     * @dev Reverts if the caller is not the owner of the ticket NFT.
     */
    function getTicketReceipt(
        uint256 tokenId
    ) external view returns (TicketReceipt memory) {
        _requireOwned(tokenId);

        return _ticketReceipts[tokenId];
    }

    /**
     * @notice Quotes the messaging fee for sending a ticket NFT cross-chain.
     * @param _sendParam The parameters for sending the ticket NFT.
     * @param _payInLzToken Boolean indicating if the fee should be paid in LayerZero token.
     * @return msgFee The quoted messaging fee.
     */
    function quoteSend(
        SendParam calldata _sendParam,
        bool _payInLzToken
    ) external view override returns (MessagingFee memory msgFee) {
        ExtendedSendParam memory extendedParam = ExtendedSendParam({
            dstEid: _sendParam.dstEid,
            to: _sendParam.to,
            tokenId: _sendParam.tokenId,
            ticket: _ticketReceipts[_sendParam.tokenId],
            extraOptions: _sendParam.extraOptions,
            composeMsg: _sendParam.composeMsg,
            onftCmd: _sendParam.onftCmd
        });

        (
            bytes memory message,
            bytes memory options
        ) = _buildMsgAndOptionsExtended(extendedParam);

        return _quote(extendedParam.dstEid, message, options, _payInLzToken);
    }

    /**
     * @notice Sends a ticket NFT cross-chain to the specified destination.
     * @param _sendParam The parameters for sending the ticket NFT.
     * @param _fee The messaging fee details.
     * @param _refundAddress The address to refund any excess fee.
     * @return msgReceipt The messaging receipt containing details of the send operation.
     * @custom:emits `ONFTSent` Emitted when a ticket NFT is sent cross-chain.
     */
    function send(
        SendParam calldata _sendParam,
        MessagingFee calldata _fee,
        address _refundAddress
    ) external payable override returns (MessagingReceipt memory msgReceipt) {
        _debit(_msgSender(), _sendParam.tokenId, _sendParam.dstEid);

        ExtendedSendParam memory extendedParam = ExtendedSendParam({
            dstEid: _sendParam.dstEid,
            to: _sendParam.to,
            tokenId: _sendParam.tokenId,
            ticket: _ticketReceipts[_sendParam.tokenId],
            extraOptions: _sendParam.extraOptions,
            composeMsg: _sendParam.composeMsg,
            onftCmd: _sendParam.onftCmd
        });

        delete _ticketReceipts[_sendParam.tokenId];

        (
            bytes memory message,
            bytes memory options
        ) = _buildMsgAndOptionsExtended(extendedParam);

        msgReceipt = _lzSend(
            extendedParam.dstEid,
            message,
            options,
            _fee,
            _refundAddress
        );

        emit ONFTSent(
            msgReceipt.guid,
            extendedParam.dstEid,
            _msgSender(),
            extendedParam.tokenId
        );
    }

    /*//////////////////////////////////////////////////////////////
    /                       INTERNAL METHODS                       /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Internal function to handle the receipt of a ticket NFT from another chain.
     * @param _origin The origin information of the message.
     * @param _guid The unique identifier for the message.
     * @param _message The message payload containing ticket NFT details.
     * @dev Overrides the _lzReceive function from the ONFT721Enumerable contract.
     * @custom:emits `ONFTReceived` Emitted when a ticket NFT is received cross-chain.
     */
    function _lzReceive(
        Origin calldata _origin,
        bytes32 _guid,
        bytes calldata _message,
        address,
        bytes calldata
    ) internal virtual override {
        address toAddress = _message.sendTo().bytes32ToAddress();

        uint256 tokenId = _message.tokenId();

        _credit(toAddress, tokenId, _origin.srcEid);

        TicketReceipt memory ticket = _message.ticketReceipt();

        _ticketReceipts[tokenId] = ticket;

        if (_message.isComposed()) {
            bytes memory composeMsg = ONFTComposeMsgCodec.encode(
                _origin.nonce,
                _origin.srcEid,
                _message.composeMsg()
            );

            endpoint.sendCompose(toAddress, _guid, 0, composeMsg);
        }

        emit ONFTReceived(_guid, _origin.srcEid, toAddress, tokenId);
    }

    /**
     * @notice Internal function to build the message and options for sending a ticket NFT.
     * @param _sendParam The extended parameters for sending the ticket NFT.
     * @return message The encoded message payload.
     * @return options The combined options for the message.
     * @custom:error `InvalidReceiver` Thrown if the receiver address is invalid.
     */
    function _buildMsgAndOptionsExtended(
        ExtendedSendParam memory _sendParam
    ) internal view returns (bytes memory message, bytes memory options) {
        if (_sendParam.to == bytes32(0)) revert InvalidReceiver();

        bool hasCompose;

        (message, hasCompose) = ONFT721MsgCodecExtended.encode(
            _sendParam.to,
            _sendParam.tokenId,
            _sendParam.ticket,
            _sendParam.composeMsg
        );

        uint16 msgType = hasCompose ? SEND_AND_COMPOSE : SEND;

        options = this.combineOptions(
            _sendParam.dstEid,
            msgType,
            _sendParam.extraOptions
        );

        address inspector = msgInspector;

        if (inspector != address(0))
            IOAppMsgInspector(inspector).inspect(message, options);
    }

    /*//////////////////////////////////////////////////////////////
    /                       PRIVATE METHODS                        /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Generates a unique token ID for a new ticket NFT.
     * @return A unique uint256 token ID.
     */
    function _generateTokenId() private view returns (uint256) {
        return
            uint256(
                keccak256(
                    abi.encodePacked(
                        _chainId,
                        block.timestamp,
                        _msgSender(),
                        _localTokenCounter
                    )
                )
            );
    }

    /**
     * @notice Internal function to set the minter address.
     * @param newMinter The new minter address.
     * @custom:error `InvalidParam` Thrown if the new minter address is invalid.
     * @custom:emits `MinterUpdated` Emitted when the minter address is updated.
     */
    function _setMinter(address newMinter) private {
        if (newMinter == address(0))
            revert InvalidParam(InvalidParams.ZeroAddressMinter);

        _minter = newMinter;

        emit MinterUpdated(newMinter);
    }
}
