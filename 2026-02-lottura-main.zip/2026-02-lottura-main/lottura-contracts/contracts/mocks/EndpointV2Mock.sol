// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

import "@layerzerolabs/test-devtools-evm-hardhat/contracts/mocks/EndpointV2Mock.sol";
