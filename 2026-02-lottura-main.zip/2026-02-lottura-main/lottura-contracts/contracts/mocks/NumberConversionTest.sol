// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

import {NumberConversionLib} from "../libraries/NumberConversionLib.sol";

/**
 * @title NumberConversionTest
 * @notice Test contract that exposes NumberConversionLib functions for testing
 * @dev This contract is only used for testing purposes
 */
contract NumberConversionTest {
    using NumberConversionLib for uint8[6];
    using NumberConversionLib for uint48;

    function numbersToUint48(
        uint8[6] memory numbers
    ) public pure returns (uint48) {
        return numbers.numbersToUint48();
    }

    function uint48ToNumbers(
        uint48 packed
    ) public pure returns (uint8[6] memory) {
        return packed.uint48ToNumbers();
    }

    function countMatches(
        uint48 ticket,
        uint48 winning
    ) public pure returns (uint8) {
        return ticket.countMatches(winning);
    }

    function generateRandomNumbers(
        uint256 seed
    ) public pure returns (uint8[6] memory) {
        return NumberConversionLib.generateRandomNumbers(seed);
    }
}
