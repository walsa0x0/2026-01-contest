// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

interface IVRFV2PlusWrapper {
    function lastRequestId() external view returns (uint256);

    function calculateRequestPriceNative(
        uint32 callbackGasLimit,
        uint32 numWords
    ) external pure returns (uint256);

    function requestRandomWordsInNative(
        uint32 callbackGasLimit,
        uint16 requestConfirmations,
        uint32 numWords,
        bytes calldata extraArgs
    ) external payable returns (uint256);
}

/**
 * @title MockVRFV2PlusWrapper
 * @notice Mock implementation of Chainlink VRF V2 Plus Wrapper for testing
 * @dev This mock simulates the async behavior of real VRF by storing requests
 *      and allowing manual fulfillment in a separate transaction
 */
contract MockVRFV2PlusWrapper is IVRFV2PlusWrapper {
    uint256 public override lastRequestId;

    // Store request details for later fulfillment
    struct Request {
        address consumer;
        uint32 numWords;
        bool fulfilled;
    }

    mapping(uint256 => Request) public requests;

    event RandomWordsRequested(
        uint256 indexed requestId,
        address indexed consumer,
        uint32 numWords
    );

    event RandomWordsFulfilled(
        uint256 indexed requestId,
        address indexed consumer
    );

    event DebugRequestCreated(
        uint256 requestId,
        uint256 lastRequestIdAfter,
        address consumer
    );

    constructor() {}

    /**
     * @notice Calculate the price for requesting random words in native token
     * @param numWords Number of random words requested
     * @return Price in native token (wei)
     */
    function calculateRequestPriceNative(
        uint32,
        uint32 numWords
    ) external pure override returns (uint256) {
        // Simple pricing: 0.001 ETH per word
        return numWords * 0.001 ether;
    }

    /**
     * @notice Request random words (stores request for later fulfillment)
     * @dev Does NOT fulfill immediately - call fulfillRandomWords separately
     * @return requestId The ID of the request
     */
    function requestRandomWordsInNative(
        uint32,
        uint16,
        uint32 numWords,
        bytes calldata
    ) external payable override returns (uint256 requestId) {
        lastRequestId++;
        requestId = lastRequestId;

        // Store the request for later fulfillment
        requests[requestId] = Request({
            consumer: msg.sender,
            numWords: numWords,
            fulfilled: false
        });

        emit RandomWordsRequested(requestId, msg.sender, numWords);
        emit DebugRequestCreated(requestId, lastRequestId, msg.sender);

        return requestId;
    }

    /**
     * @notice Manually fulfill a random words request (for testing)
     * @param requestId The request ID to fulfill
     * @param consumer The consumer contract address
     * @dev This simulates the async callback from real Chainlink VRF
     * @dev Returns FIXED winning numbers for predictable testing: [1, 2, 3, 4, 5, 6]
     */
    function fulfillRandomWords(
        uint256 requestId,
        address consumer
    ) external {
        Request storage request = requests[requestId];
        require(request.consumer != address(0), "Request not found");
        require(!request.fulfilled, "Already fulfilled");
        require(request.consumer == consumer, "Wrong consumer");

        // Generate FIXED deterministic seed for testing
        // This seed, when combined with user randomness and processed by NumberConversionLib,
        // will generate predictable winning numbers for reliable testing
        // Using a simple fixed value ensures consistency across all test runs
        uint256[] memory words = new uint256[](request.numWords);
        for (uint256 i = 0; i < request.numWords; i++) {
            // Return a fixed seed value
            // This will be XORed with user committed randomness in LotturaCore
            // The resulting seed will generate consistent winning numbers
            words[i] = 12345678901234567890123456789012345678901234567890;
        }

        // Mark as fulfilled before callback to prevent reentrancy
        request.fulfilled = true;

        // Call the consumer's callback function
        (bool success, bytes memory returnData) = consumer.call(
            abi.encodeWithSignature(
                "rawFulfillRandomWords(uint256,uint256[])",
                requestId,
                words
            )
        );

        if (!success) {
            // Revert with the original error message if available
            if (returnData.length > 0) {
                assembly {
                    let returnDataSize := mload(returnData)
                    revert(add(32, returnData), returnDataSize)
                }
            } else {
                revert("VRF fulfillment failed");
            }
        }

        emit RandomWordsFulfilled(requestId, consumer);
    }

    /**
     * @notice Get request details
     * @param requestId The request ID
     * @return consumer The consumer address
     * @return numWords Number of words requested
     * @return fulfilled Whether the request has been fulfilled
     */
    function getRequest(
        uint256 requestId
    ) external view returns (address consumer, uint32 numWords, bool fulfilled) {
        Request memory request = requests[requestId];
        return (request.consumer, request.numWords, request.fulfilled);
    }
}
