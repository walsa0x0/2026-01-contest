// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

import {
    UUPSUpgradeable
} from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import {
    AccessControlUpgradeable
} from "@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol";
import {
    SafeERC20
} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {
    OAppUpgradeable,
    Origin
} from "@layerzerolabs/oapp-evm-upgradeable/contracts/oapp/OAppUpgradeable.sol";
import {
    IOAppComposer
} from "@layerzerolabs/oapp-evm/contracts/oapp/interfaces/IOAppComposer.sol";
import {
    OptionsBuilder
} from "@layerzerolabs/oapp-evm/contracts/oapp/libs/OptionsBuilder.sol";
import {
    MessagingFee
} from "@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/ILayerZeroEndpointV2.sol";
import {NumberConversionLib} from "./libraries/NumberConversionLib.sol";
import {
    IOFT,
    SendParam
} from "@layerzerolabs/oft-evm/contracts/interfaces/IOFT.sol";
import {
    OFTComposeMsgCodec
} from "@layerzerolabs/oft-evm/contracts/libs/OFTComposeMsgCodec.sol";
import {
    OAppOptionsType3Upgradeable
} from "@layerzerolabs/oapp-evm-upgradeable/contracts/oapp/libs/OAppOptionsType3Upgradeable.sol";
import {
    IVRFV2PlusWrapper
} from "@chainlink/contracts/src/v0.8/vrf/dev/interfaces/IVRFV2PlusWrapper.sol";
import {
    VRFV2PlusClient
} from "@chainlink/contracts/src/v0.8/vrf/dev/libraries/VRFV2PlusClient.sol";
import {LotturaHub} from "./LotturaHub.sol";

/**
 * @title LotturaCore
 * @notice Core contract for the Lottura decentralized lottery system.
 */
contract LotturaCore is
    UUPSUpgradeable,
    AccessControlUpgradeable,
    OAppUpgradeable,
    OAppOptionsType3Upgradeable,
    IOAppComposer
{
    using SafeERC20 for IERC20;
    using SafeERC20 for IOFT;
    using NumberConversionLib for uint8[6];
    using NumberConversionLib for uint48;
    using OptionsBuilder for bytes;

    ///////////////////////////////////////////////////////////////
    //                        CONSTANTS
    ///////////////////////////////////////////////////////////////
    /**
     * @notice Admin role identifier.
     */
    bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");

    /**
     * @notice Operator role identifier.
     */
    bytes32 public constant OPERATOR_ROLE = keccak256("OPERATOR_ROLE");

    /**
     * @notice Upgrader role identifier.
     */
    bytes32 public constant UPGRADER_ROLE = keccak256("UPGRADER_ROLE");

    uint256 private constant BASIS_POINTS = 10000; // 100%

    uint8 private constant MSG_TYPE_PURCHASE = 1; // Message type for ticket purchase for cross-chain

    uint8 private constant MSG_TYPE_CLAIM = 2; // Message type for ticket claim for cross-chain

    ///////////////////////////////////////////////////////////////
    //                    STRUCTS AND ENUMS
    ///////////////////////////////////////////////////////////////

    /**
     * @dev Enumeration of invalid parameter types for error handling.
     */
    enum InvalidParams {
        ZeroAddressImplementation,
        InvalidCrossChainMessageType,
        ZeroAddressPaymentToken,
        ZeroAddressVRFV2PlusWrapper,
        InvalidReserveAmount,
        InvalidGasAmount,
        ZeroDrawInterval,
        SameDrawInterval,
        ZeroChainId,
        ZeroChainEid,
        InvalidWinningTicketsCountsArrayLength,
        ZeroAmount,
        NotEnoughBalance,
        ZeroHubAddress
    }

    /**
     * @notice Configuration parameters for the lottery.
     */
    struct LotteryConfig {
        uint32 drawInterval; // Seconds between draws
        uint8 minNumber; // 1
        uint8 maxNumber; // 50
        uint8 numbersPerTicket; // 6
    }

    /**
     * @notice Represents a lottery draw.
     */
    struct Draw {
        uint256 id; // Draw ID
        uint40 startTime; // Draw start time
        uint40 endTime; // Draw end time
        uint48 winningNumbers; // Packed uint48 format
        uint256 prizePool; // Prize pool amount
        uint32 ticketsSold; // Number of tickets sold
        uint256[3] rolloverAmount; // Rollover per tier (4, 5, 6 matches)
        DrawStatus status; // Current status of the draw
        uint256 vrfRequestId; // Chainlink VRF request ID
        uint256 combinedCommittedRandomness; // User committed combined randomness from ticket purchases
        uint256[3] winningTicketsCounts; // Number of winning tickets per tier
        uint256[3] prizesPerWinner; // Prize amount per winner per tier
        uint256 vrfSeed; // VRF seed for randomness
    }

    /**
     * @notice Enumeration of draw statuses.
     */
    enum DrawStatus {
        OPEN,
        DRAWING,
        PROCESSING_WINNERS,
        COMPLETED
    }

    /**
     * @notice Represents a lottery ticket.
     */
    struct Ticket {
        uint256 id; // Ticket ID
        address owner; // Ticket owner
        uint256 drawId; // Associated draw ID
        uint48 numbers; // Selected numbers
        uint40 purchaseTime; // Purchase timestamp
        TicketStatus status; // Current ticket status
        uint8 matchedCount; // Count of matched numbers
        uint256 prizeAmount; // Prize amount won
        uint256 sourceChain; // Source chain ID (0 = native Polygon)
    }

    /**
     * @notice Enumeration of ticket statuses.
     */
    enum TicketStatus {
        ACTIVE,
        PAID
    }

    ///////////////////////////////////////////////////////////////
    //                          EVENTS
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Emitted when a ticket is purchased.
     * @param buyer Address of the ticket buyer.
     * @param ticketId ID of the purchased ticket.
     * @param drawId ID of the associated draw.
     * @param numbers Packed selected numbers on the ticket.
     * @param sourceChain Source chain ID (0 = native Polygon).
     */
    event TicketPurchased(
        address indexed buyer,
        uint256 indexed ticketId,
        uint256 indexed drawId,
        uint48 numbers,
        uint256 sourceChain
    );

    /**
     * @notice Emitted when a new draw is created.
     * @param drawId ID of the created draw.
     * @param startTime Start time of the draw.
     * @param endTime End time of the draw.
     */
    event DrawCreated(
        uint256 indexed drawId,
        uint256 indexed startTime,
        uint256 indexed endTime
    );

    /**
     * @notice Emitted when draw execution starts.
     * @param drawId ID of the draw being executed.
     * @param vrfRequestId Chainlink VRF request ID.
     */
    event DrawExecutionStarted(
        uint256 indexed drawId,
        uint256 indexed vrfRequestId
    );

    /**
     * @notice Emitted when winners are being processed for a draw.
     * @param drawId ID of the draw being processed.
     * @param winningNumbers Packed winning numbers for the draw.
     */
    event DrawProcessingWinners(
        uint256 indexed drawId,
        uint48 indexed winningNumbers
    );

    /**
     * @notice Emitted when a draw is completed.
     * @param drawId ID of the completed draw.
     */
    event DrawCompleted(uint256 indexed drawId);

    /**
     * @notice Emitted when a user commits randomness during ticket purchase.
     * @param drawId ID of the draw.
     * @param user Address of the user committing randomness.
     * @param tokenId ID of the ticket token.
     * @param hashedRandomness Hashed randomness committed by the user.
     */
    event RandomnessCommitted(
        uint256 indexed drawId,
        address indexed user,
        uint256 indexed tokenId,
        bytes32 hashedRandomness
    );

    /**
     * @notice Emitted when a prize is paid to a winner.
     * @param ticketId ID of the winning ticket.
     * @param winner Address of the winner.
     * @param tier Winning tier (4-6).
     * @param amount Prize amount paid.
     * @param destinationChainEid Destination chain EID for cross-chain payments.
     */
    event PrizePaid(
        uint256 indexed ticketId,
        address indexed winner,
        uint8 indexed tier,
        uint256 amount,
        uint32 destinationChainEid
    );

    /**
     * @notice Emitted when rollover amount is added to the next draw.
     * @param drawId ID of the draw receiving rollover.
     * @param tier Tier number (4-6).
     * @param amount Rollover amount added.
     */
    event RolloverAdded(
        uint256 indexed drawId,
        uint8 indexed tier,
        uint256 indexed amount
    );

    /**
     * @notice Emitted when the draw interval is updated.
     * @param oldInterval Previous draw interval in seconds.
     * @param newInterval New draw interval in seconds.
     */
    event DrawIntervalUpdated(
        uint256 indexed oldInterval,
        uint256 indexed newInterval
    );

    /**
     * @notice Emitted when the prize distribution percentages are updated.
     * @param newDistribution New prize distribution percentages for tiers 4, 5, and 6.
     */
    event PrizeDistributionUpdated(uint16[3] newDistribution);

    /**
     * @notice Emitted when reserve funds are allocated to the current draw.
     * @param drawId ID of the draw receiving reserve allocation.
     * @param amount Amount of reserve funds allocated.
     */
    event ReserveAllocated(uint256 indexed drawId, uint256 indexed amount);

    /**
     * @notice Emitted when commission is withdrawn to the multi-sig wallet.
     * @param recipient Address of the multi-sig wallet receiving the commission.
     * @param amount Amount of commission withdrawn.
     */
    event CommissionWithdrawn(
        address indexed recipient,
        uint256 indexed amount
    );

    /**
     * @notice Emitted when the hub address for a chain ID is updated.
     * @param chainId Chain ID for which the hub address is updated.
     * @param oldHub Previous hub address.
     * @param newHub New hub address.
     */
    event HubAddressUpdated(
        uint256 indexed chainId,
        address indexed oldHub,
        address indexed newHub
    );

    /**
     * @notice Emitted when native tokens are funded to the contract for LayerZero and Chainlink fees.
     * @param funder Address of the funder.
     * @param amount Amount of native tokens funded.
     */
    event NativeTokenFunded(address indexed funder, uint256 indexed amount);

    /**
     * @notice Emitted when tokens are withdrawn in case of emergency.
     * @param owner The address of the owner who performed the withdrawal.
     * @param tokenAmount The amount of tokens withdrawn.
     */
    event TokensEmergencyWithdraw(
        address indexed owner,
        uint256 indexed tokenAmount
    );

    /**
     * @notice Emitted when native tokens are withdrawn in case of emergency.
     * @param owner The address of the owner who performed the withdrawal.
     * @param nativeAmount The amount of native tokens withdrawn.
     */
    event NativeEmergencyWithdraw(
        address indexed owner,
        uint256 indexed nativeAmount
    );

    ///////////////////////////////////////////////////////////////
    //                      STATE VARIABLES
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Payment token (OFT) address.
     */
    IOFT public paymentToken;

    /**
     * @notice Current draw ID.
     */
    uint256 public currentDrawId;

    /**
     * @notice Mapping of draw ID to array of ticket IDs.
     */
    mapping(uint256 => uint256[]) public drawTickets;

    /**
     * @notice Accumulated commission amount.
     */
    uint256 public accumulatedCommission;

    /**
     * @notice Mapping of chain ID to LotturaHub address.
     */
    mapping(uint256 => LotturaHub) public hubs;

    /**
     * @notice Chainlink VRF V2 Plus Wrapper address.
     */
    IVRFV2PlusWrapper public vrfV2PlusWrapper;

    /**
     * @notice Mapping of VRF request ID to draw ID.
     */
    mapping(uint256 => uint256) public vrfRequestToDraw;

    uint16[3] private _prizeDistributionPercentages; // 4, 5, 6 match tiers

    uint256 private _chainId; // Current chain ID

    mapping(uint256 => uint32) private _chainIdToChainEid; // Chain ID to LayerZero chain EID

    LotteryConfig private _config; // Lottery configuration

    mapping(uint256 => Ticket) private _tickets; // Ticket ID to Ticket struct

    mapping(uint256 => mapping(uint8 => uint256[])) private _winnersByTier; // Draw ID => Tier => Array of Winner Ticket IDs

    mapping(uint256 => Draw) private _draws; // Draw ID to Draw struct

    ///////////////////////////////////////////////////////////////
    //                          ERRORS
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Thrown when a function is called with an invalid parameter.
     * @param param The invalid parameter.
     */
    error InvalidParam(InvalidParams param);

    /**
     * @notice Thrown when a non-endpoint contract attempts to execute lzCompose.
     */
    error OnlyEndpointExecutesLZCompose();

    /**
     * @notice Thrown when the prize distribution is invalid.
     */
    error InvalidPrizeDistribution();

    /**
     * @notice Thrown when a draw is in an invalid status for the requested operation.
     */
    error InvalidDrawStatus();

    /**
     * @notice Thrown when attempting to operate on a draw that is not open.
     */
    error DrawNotOpen();

    /**
     * @notice Thrown when attempting to operate on a draw that has not yet ended.
     */
    error DrawNotEnded();

    /**
     * @notice Thrown when attempting to operate on a draw that has already ended.
     */
    error DrawAlreadyEnded();

    /**
     * @notice Thrown when a non-VRF Coordinator contract attempts to fulfill randomness.
     */
    error OnlyVRFCoordinator();

    /**
     * @notice Thrown when there is no commission available for withdrawal.
     */
    error NoCommissionAvailable();

    /**
     * @notice Thrown when the caller is not the LotturaHub for the current chain.
     */
    error CallerNotLotturaHub();

    /**
     * @notice Thrown when there is insufficient native token balance for cross-chain prize distribution.
     */
    error InsufficientGasForCrossChainPrize();

    /**
     * @notice Thrown when there is insufficient native token balance for Chainlink VRF requests.
     */
    error InsufficientGasForChainlinkVRF();

    /**
     * @notice Thrown when the caller is not the owner of the ticket.
     */
    error NotTicketOwner();

    /**
     * @notice Thrown when a ticket is in an invalid status for the requested operation.
     */
    error InvalidTicketStatus();

    /**
     * @notice Thrown when attempting to claim a ticket that did not win.
     */
    error TicketNotWon();

    /**
     * @notice Thrown when an emergency withdrawal fails.
     */
    error EmergencyWithdrawFailed();

    /*//////////////////////////////////////////////////////////////
    /                           MODIFIERS                          /
    //////////////////////////////////////////////////////////////*/

    /**
     * @notice Modifier to restrict function access to only the LotturaHub of the current chain.
     */
    modifier onlyHub() {
        if (_msgSender() != address(hubs[_chainId]))
            revert CallerNotLotturaHub();

        _;
    }

    ///////////////////////////////////////////////////////////////
    //                       CONSTRUCTOR
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Constructor to set the LayerZero endpoint address.
     * @param _endpoint LayerZero endpoint address.
     * @dev Disables initializers to prevent misuse.
     */
    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor(address _endpoint) OAppUpgradeable(_endpoint) {
        _disableInitializers();
    }

    ///////////////////////////////////////////////////////////////
    //                     EXTERNAL METHODS
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Initializer function to set up the contract.
     * @param _paymentToken Address of the payment token (OFT).
     * @param _vrfV2PlusWrapper Address of the Chainlink VRF V2 Plus Wrapper.
     * @dev This function must be called only once during deployment.
     * @custom:error InvalidParam Thrown when a parameter is invalid.
     */
    function initialize(
        address _paymentToken,
        address _vrfV2PlusWrapper
    ) external initializer {
        if (_paymentToken == address(0))
            revert InvalidParam(InvalidParams.ZeroAddressPaymentToken);
        if (_vrfV2PlusWrapper == address(0))
            revert InvalidParam(InvalidParams.ZeroAddressVRFV2PlusWrapper);

        _chainId = block.chainid;

        __UUPSUpgradeable_init();
        __Ownable_init(_msgSender());
        __AccessControl_init();
        __OApp_init(_msgSender());

        // Set payment token
        paymentToken = IOFT(_paymentToken);

        vrfV2PlusWrapper = IVRFV2PlusWrapper(_vrfV2PlusWrapper);

        // Grant roles to Multi-Sig
        _grantRole(DEFAULT_ADMIN_ROLE, _msgSender());
        _grantRole(ADMIN_ROLE, _msgSender());
        _grantRole(UPGRADER_ROLE, _msgSender());
        _grantRole(OPERATOR_ROLE, _msgSender());

        // Initialize config
        _config = LotteryConfig({
            drawInterval: 1 hours, // Weekly draws
            minNumber: 1,
            maxNumber: 50,
            numbersPerTicket: 6
        });

        // Initialize prize distribution (4, 5, 6 match tiers)
        // 15%, 25%, 60%
        _prizeDistributionPercentages = [1500, 2500, 6000];

        // Create first draw
        _createDraw();

        // MUST CALL setHubAddress AFTER initialization to set at least a lotturaHub

        // MUST CALL setChainEidForChainId AFTER initialization to set at least a chainEid
    }

    /**
     * @notice Purchase a lottery ticket.
     * @param tokenId ID of the ticket token.
     * @param buyer Address of the ticket buyer.
     * @param numbers Selected numbers for the ticket.
     * @param drawId ID of the draw for which the ticket is purchased.
     * @param hashedRandomness Hashed randomness committed by the user.
     * @param ticketPrice Price of the ticket.
     * @param commission Commission percentage in basis points.
     * @dev This function can only be called by the LotturaHub of the current chain.
     * @custom:emits TicketPurchased Emitted when a ticket is purchased.
     * @custom:emits RandomnessCommitted Emitted when user randomness is committed.
     * @custom:error CallerNotLotturaHub Thrown when the caller is not the LotturaHub.
     * @custom:error DrawNotOpen Thrown when the draw is not open for ticket purchases.
     * @custom:error DrawAlreadyEnded Thrown when the draw has already ended.
     */
    function purchaseTicket(
        uint256 tokenId,
        address buyer,
        uint8[6] calldata numbers,
        uint256 drawId,
        bytes32 hashedRandomness,
        uint256 ticketPrice,
        uint16 commission
    ) external onlyHub {
        _purchaseTicket(
            tokenId,
            buyer,
            numbers,
            drawId,
            hashedRandomness,
            0,
            ticketPrice,
            commission
        );
    }

    /**
     * @notice Claim a winning ticket.
     * @param tokenId ID of the ticket token.
     * @param claimer Address of the ticket claimer.
     * @dev This function can only be called by the LotturaHub of the current chain.
     * @custom:error CallerNotLotturaHub Thrown when the caller is not the LotturaHub.
     * @custom:error NotTicketOwner Thrown when the caller is not the owner of the ticket.
     * @custom:error InvalidTicketStatus Thrown when the ticket is not active.
     * @custom:error TicketNotWon Thrown when the ticket did not win any prize.
     * @custom:error  InsufficientGasForCrossChainPrize Thrown when there is insufficient native token balance for cross-chain prize distribution.
     * @custom:emits PrizePaid Emitted when the prize is paid to the winner.
     */
    function claimTicket(uint256 tokenId, address claimer) external onlyHub {
        _claimTicket(tokenId, claimer, 0);
    }

    /**
     * @notice Execute the draw to select winning numbers.
     * @param drawId ID of the draw to execute.
     * @dev This function can only be called by an operator.
     * @custom:error InvalidDrawStatus Thrown when the draw is not in OPEN status.
     * @custom:error DrawNotEnded Thrown when the draw has not yet ended.
     * @custom:emits DrawExecutionStarted Emitted when draw execution starts.
     */
    function executeDraw(uint256 drawId) external onlyRole(OPERATOR_ROLE) {
        Draw storage draw = _draws[drawId];

        if (draw.status != DrawStatus.OPEN || draw.endTime == 0)
            revert InvalidDrawStatus();

        if (block.timestamp < draw.endTime) revert DrawNotEnded();

        draw.status = DrawStatus.DRAWING;

        // Request randomness from Chainlink VRF
        uint256 requestId = _requestRandomWords();

        draw.vrfRequestId = requestId;

        vrfRequestToDraw[requestId] = drawId;

        emit DrawExecutionStarted(drawId, requestId);
    }

    /**
     * @notice Set winning tickets counts and calculate prizes per winner.
     * @param drawId ID of the draw to complete.
     * @param winningTicketsCounts Array of winning ticket counts for tiers 4, 5, and 6.
     * @dev This function can only be called by an operator.
     * @custom:error InvalidDrawStatus Thrown when the draw is not in PROCESSING_WINNERS status.
     * @custom:error InvalidParam Thrown when the winning tickets counts array length is not 3.
     * @custom:emits DrawCompleted Emitted when the draw is completed.
     */
    function setWinningTicketsCounts(
        uint256 drawId,
        uint32[3] calldata winningTicketsCounts
    ) external onlyRole(OPERATOR_ROLE) {
        Draw storage draw = _draws[drawId];

        if (draw.status != DrawStatus.PROCESSING_WINNERS)
            revert InvalidDrawStatus();

        if (winningTicketsCounts.length != 3)
            revert InvalidParam(
                InvalidParams.InvalidWinningTicketsCountsArrayLength
            );

        draw.winningTicketsCounts = winningTicketsCounts;

        uint256 totalPrizePool = draw.prizePool;

        for (uint8 i = 0; i < 3; i++) totalPrizePool += draw.rolloverAmount[i];

        if (totalPrizePool > 0)
            for (uint8 tier = 4; tier <= 6; tier++) {
                uint8 tierIndex = tier - 4; // 0, 1, 2

                uint256 tierPercentage = _prizeDistributionPercentages[
                    tierIndex
                ];

                uint256 tierPool = (totalPrizePool * tierPercentage) /
                    BASIS_POINTS;

                if (winningTicketsCounts[tierIndex] == 0) continue;

                uint256 prizePerWinner = tierPool /
                    winningTicketsCounts[tierIndex];

                draw.prizesPerWinner[tierIndex] = prizePerWinner;
            }

        draw.status = DrawStatus.COMPLETED;

        emit DrawCompleted(drawId);

        // Handle rollover for next draw
        _handleRollover(drawId);

        _createDraw();
    }

    /**
     * @notice LayerZero compose function to handle cross-chain messages.
     * @param _oApp Originating OApp address.
     * @param _message Message payload.
     * @dev This function can only be called by the LayerZero endpoint.
     * @custom:error OnlyEndpointExecutesLZCompose Thrown when a non-endpoint contract attempts to execute lzCompose.
     */
    function lzCompose(
        address _oApp,
        bytes32 /*_guid*/,
        bytes calldata _message,
        address /*_executor*/,
        bytes calldata /*_extraData*/
    ) external payable override {
        if (_msgSender() != address(endpoint))
            revert OnlyEndpointExecutesLZCompose();

        _handleCompose(_oApp, _message);
    }

    /**
     * @notice Callback function for Chainlink VRF to fulfill randomness requests.
     * @param requestId ID of the VRF request.
     * @param randomWords Array of random words returned by VRF.
     * @dev This function can only be called by the VRF Coordinator.
     * @custom:error OnlyVRFCoordinator Thrown when a non-VRF Coordinator contract attempts to fulfill randomness.
     */
    function rawFulfillRandomWords(
        uint256 requestId,
        uint256[] calldata randomWords
    ) external {
        if (_msgSender() != address(vrfV2PlusWrapper))
            revert OnlyVRFCoordinator();

        _fulfillRandomWords(requestId, randomWords);
    }

    /**
     * @notice Set the draw interval.
     * @param newInterval New draw interval in seconds.
     * @dev This function can only be called by an admin.
     * @custom:error InvalidParam Thrown when the new interval is invalid.
     * @custom:emits DrawIntervalUpdated Emitted when the draw interval is updated.
     */
    function setDrawInterval(uint32 newInterval) external onlyRole(ADMIN_ROLE) {
        if (newInterval == 0)
            revert InvalidParam(InvalidParams.ZeroDrawInterval);

        if (newInterval == _config.drawInterval)
            revert InvalidParam(InvalidParams.SameDrawInterval);

        uint256 oldInterval = _config.drawInterval;

        _config.drawInterval = newInterval;

        emit DrawIntervalUpdated(oldInterval, newInterval);
    }

    /**
     * @notice Set the prize distribution percentages.
     * @param newDistribution New prize distribution percentages for tiers 4, 5, and 6.
     * @dev This function can only be called by an admin.
     * @custom:error InvalidPrizeDistribution Thrown when the new distribution does not sum to 100%.
     * @custom:emits PrizeDistributionUpdated Emitted when the prize distribution is updated.
     */
    function setPrizeDistribution(
        uint16[3] calldata newDistribution
    ) external onlyRole(ADMIN_ROLE) {
        uint256 total = 0;

        for (uint8 i = 0; i < 3; i++) total += newDistribution[i];

        if (total != BASIS_POINTS) revert InvalidPrizeDistribution();

        _prizeDistributionPercentages = newDistribution;

        emit PrizeDistributionUpdated(newDistribution);
    }

    /**
     * @notice Set the LotturaHub address for a specific chain ID.
     * @param chainId Chain ID for which to set the hub address.
     * @param hubAddress Address of the LotturaHub contract.
     * @dev This function can only be called by an admin.
     * @custom:error InvalidParams.ZeroChainId Thrown when the chain ID is zero.
     * @custom:error InvalidParams.ZeroHubAddress Thrown when the hub address is zero.
     * @custom:emits HubAddressUpdated Emitted when the hub address is updated.
     */
    function setHubAddress(
        uint256 chainId,
        address hubAddress
    ) external onlyRole(ADMIN_ROLE) {
        if (chainId == 0) revert InvalidParam(InvalidParams.ZeroChainId);

        if (hubAddress == address(0))
            revert InvalidParam(InvalidParams.ZeroHubAddress);

        address oldHub = address(hubs[chainId]);

        hubs[chainId] = LotturaHub(hubAddress);

        emit HubAddressUpdated(chainId, oldHub, hubAddress);
    }

    /**
     * @notice Set the LayerZero chain EID for a specific chain ID.
     * @param chainId Chain ID for which to set the chain EID.
     * @param chainEid LayerZero chain EID.
     * @dev This function can only be called by an admin.
     * @custom:error InvalidParam Thrown when the chain ID or chain EID is zero.
     */
    function setChainEidForChainId(
        uint256 chainId,
        uint32 chainEid
    ) external onlyRole(ADMIN_ROLE) {
        if (chainId == 0) revert InvalidParam(InvalidParams.ZeroChainId);

        if (chainEid == 0) revert InvalidParam(InvalidParams.ZeroChainEid);

        _chainIdToChainEid[chainId] = chainEid;
    }

    /**
     * @notice Allocate reserve funds to the current draw.
     * @param amount Amount of reserve funds to allocate.
     * @dev This function can only be called by an admin.
     * @custom:error InvalidParam Thrown when the amount is invalid.
     * @custom:error DrawNotOpen Thrown when the current draw is not open.
     * @custom:emits ReserveAllocated Emitted when reserve funds are allocated.
     */
    function allocateReserve(uint256 amount) external onlyRole(ADMIN_ROLE) {
        if (amount == 0)
            revert InvalidParam(InvalidParams.InvalidReserveAmount);

        Draw storage currentDraw = _draws[currentDrawId];

        if (currentDraw.status != DrawStatus.OPEN) revert DrawNotOpen();

        // Transfer from caller
        IERC20(address(paymentToken)).safeTransferFrom(
            _msgSender(),
            address(this),
            amount
        );

        // Distribute across tiers proportionally
        for (uint8 i = 0; i < 3; i++) {
            uint256 tierAmount = (amount * _prizeDistributionPercentages[i]) /
                BASIS_POINTS;

            currentDraw.rolloverAmount[i] += tierAmount;
        }

        emit ReserveAllocated(currentDrawId, amount);
    }

    /**
     * @notice Withdraw accumulated commission to the multi-sig wallet.
     * @dev This function can only be called by an admin.
     * @custom:error NoCommissionAvailable Thrown when there is no commission available for withdrawal.
     * @custom:emits CommissionWithdrawn Emitted when commission is withdrawn.
     */
    function withdrawCommission() external onlyRole(ADMIN_ROLE) {
        uint256 amount = accumulatedCommission;

        if (amount == 0) revert NoCommissionAvailable();

        accumulatedCommission = 0;

        IERC20(address(paymentToken)).safeTransfer(_msgSender(), amount);

        emit CommissionWithdrawn(_msgSender(), amount);
    }

    /**
     * @notice Fund native tokens to the contract for LayerZero and Chainlink fees.
     * @dev This function allows anyone to fund native tokens.
     * @custom:error InvalidParam Thrown when the funded amount is zero.
     * @custom:emits NativeTokenFunded Emitted when native tokens are funded.
     */
    function fundGas() external payable {
        if (msg.value == 0) revert InvalidParam(InvalidParams.InvalidGasAmount);

        emit NativeTokenFunded(_msgSender(), msg.value);
    }

    /**
     * @notice Allows the contract owner to withdraw tokens in case of emergency.
     * @param amount The amount of tokens to withdraw.
     * @custom:error `InvalidParam` Thrown if the amount is zero.
     */
    function tokensEmergencyWithdraw(
        uint256 amount
    ) external onlyRole(ADMIN_ROLE) {
        if (amount == 0) revert InvalidParam(InvalidParams.ZeroAmount);

        IERC20(address(paymentToken)).safeTransfer(_msgSender(), amount);

        emit TokensEmergencyWithdraw(_msgSender(), amount);
    }

    /**
     * @notice Allows the contract owner to withdraw native in case of emergency.
     * @param amount The amount of native to withdraw.
     * @custom:error `InvalidParam` Thrown if the amount is zero or if there is not enough balance.
     */
    function nativeEmergencyWithdraw(
        uint256 amount
    ) external onlyRole(ADMIN_ROLE) {
        if (amount == 0) revert InvalidParam(InvalidParams.ZeroAmount);

        if (address(this).balance < amount)
            revert InvalidParam(InvalidParams.NotEnoughBalance);

        (bool success, ) = _msgSender().call{value: amount}("");

        if (!success) revert EmergencyWithdrawFailed();

        emit NativeEmergencyWithdraw(_msgSender(), amount);
    }

    ///////////////////////////////////////////////////////////////
    //                      PUBLIC METHODS
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Get the prize distribution percentages.
     * @return Array of prize distribution percentages for tiers 4, 5, and 6.
     */
    function prizeDistribution() external view returns (uint16[3] memory) {
        return _prizeDistributionPercentages;
    }

    /**
     * @notice Get the lottery configuration
     * @return LotteryConfig struct
     */
    function getLotturaConfig() external view returns (LotteryConfig memory) {
        return _config;
    }

    /**
     * @notice Get draw details by draw ID
     * @param drawId Draw ID
     * @return Draw struct
     */
    function getDraw(uint256 drawId) external view returns (Draw memory) {
        return _draws[drawId];
    }

    /**
     * @notice Get ticket details by ticket ID
     * @param ticketId Ticket ID
     * @return Ticket struct
     */
    function getTicket(uint256 ticketId) external view returns (Ticket memory) {
        return _tickets[ticketId];
    }

    /**
     * @notice Get the number of tickets for a draw
     * @param drawId Draw ID
     * @return Number of tickets
     */
    function getDrawTicketsLength(
        uint256 drawId
    ) external view returns (uint256) {
        return drawTickets[drawId].length;
    }

    /**
     * @notice Get a paginated list of ticket IDs for a draw
     * @param drawId Draw ID
     * @param offset Starting index
     * @param limit Number of ticket IDs to retrieve
     * @return page Array of ticket IDs
     */
    function getDrawTicketsPage(
        uint256 drawId,
        uint256 offset,
        uint256 limit
    ) external view returns (uint256[] memory page) {
        uint256 len = drawTickets[drawId].length;

        if (offset >= len) return new uint256[](0);

        uint256 end = offset + limit;

        if (end > len) end = len;

        page = new uint256[](end - offset);

        for (uint256 i = offset; i < end; i++)
            page[i - offset] = drawTickets[drawId][i];
    }

    /**
     * @notice Get the number of winners for a draw and tier
     * @param drawId Draw ID
     * @param tier Winning tier (4-6)
     * @return Number of winners
     */
    function getWinnersByTierLength(
        uint256 drawId,
        uint8 tier
    ) external view returns (uint256) {
        return _winnersByTier[drawId][tier].length;
    }

    /**
     * @notice Get a paginated list of winners for a draw and tier
     * @param drawId Draw ID
     * @param tier Winning tier (4-6)
     * @param offset Starting index
     * @param limit Number of winners to retrieve
     * @return page Array of Winner structs
     */
    function getWinnersByTierPage(
        uint256 drawId,
        uint8 tier,
        uint256 offset,
        uint256 limit
    ) external view returns (uint256[] memory page) {
        uint256[] storage arr = _winnersByTier[drawId][tier];

        uint256 len = arr.length;

        if (offset >= len) return new uint256[](0);

        uint256 end = offset + limit;

        if (end > len) end = len;

        page = new uint256[](end - offset);

        for (uint256 i = offset; i < end; i++) page[i - offset] = arr[i];
    }

    ///////////////////////////////////////////////////////////////
    //                     INTERNAL METHODS
    ///////////////////////////////////////////////////////////////

    /**
     * @notice LayerZero receive function to handle incoming cross-chain messages
     * @param _message Message payload
     * @dev Decodes the message and processes ticket claims
     * @custom:emits PrizePaid Emitted when the prize is paid to the winner.
     * @custom:error InvalidParam Thrown when the cross-chain message type is invalid.
     */
    function _lzReceive(
        Origin calldata /*_origin*/,
        bytes32 /*_guid*/,
        bytes calldata _message,
        address /*_executor*/,
        bytes calldata /*_extraData*/
    ) internal override {
        (
            uint8 messageType,
            uint256 chainId,
            uint256 tokenId,
            address claimer
        ) = abi.decode(_message, (uint8, uint256, uint256, address));

        if (messageType == MSG_TYPE_CLAIM) {
            _claimTicket(tokenId, claimer, chainId);
        } else {
            revert InvalidParam(InvalidParams.InvalidCrossChainMessageType);
        }
    }

    /**
     * @notice Authorize contract upgrade
     * @param newImplementation Address of the new implementation contract
     * @dev This function restricts upgrades to only accounts with the UPGRADER_ROLE
     * @custom:error InvalidParam Thrown when the new implementation address is zero.
     */
    function _authorizeUpgrade(
        address newImplementation
    ) internal override onlyRole(UPGRADER_ROLE) {
        if (newImplementation == address(0))
            revert InvalidParam(InvalidParams.ZeroAddressImplementation);
    }

    ///////////////////////////////////////////////////////////////
    //                     PRIVATE METHODS                       //
    ///////////////////////////////////////////////////////////////

    /**
     * @notice Purchase a lottery ticket
     * @param tokenId ID of the ticket token
     * @param buyer Address of the ticket buyer
     * @param numbers Selected numbers for the ticket
     * @param drawId ID of the draw for which the ticket is purchased
     * @param hashedRandomness Hashed randomness committed by the user
     * @param sourceChainId Source chain ID for cross-chain purchases (0 for native)
     * @param ticketPrice Price of the ticket
     * @param commission Commission percentage in basis points
     * @dev Validates draw status and updates draw and ticket data
     * @custom:emits TicketPurchased Emitted when a ticket is purchased.
     * @custom:emits RandomnessCommitted Emitted when user randomness is committed.
     * @custom:error DrawNotOpen Thrown when the draw is not open for ticket purchases.
     * @custom:error DrawAlreadyEnded Thrown when the draw has already ended.
     */
    function _purchaseTicket(
        uint256 tokenId,
        address buyer,
        uint8[6] memory numbers,
        uint256 drawId,
        bytes32 hashedRandomness,
        uint256 sourceChainId,
        uint256 ticketPrice,
        uint16 commission
    ) private {
        // Get current draw
        Draw storage draw = _draws[drawId];

        if (draw.status != DrawStatus.OPEN) revert DrawNotOpen();

        if (block.timestamp >= draw.endTime) revert DrawAlreadyEnded();

        // Calculate commission
        uint256 calculatedCommission = (ticketPrice * commission) /
            BASIS_POINTS;

        uint256 prizePoolContribution = ticketPrice - calculatedCommission;

        // Update commission
        accumulatedCommission += calculatedCommission;

        // Convert and validate numbers
        uint48 packedNumbers = numbers.numbersToUint48();

        _tickets[tokenId] = Ticket({
            id: tokenId,
            owner: buyer,
            drawId: drawId,
            numbers: packedNumbers,
            purchaseTime: uint40(block.timestamp),
            status: TicketStatus.ACTIVE,
            matchedCount: 0,
            prizeAmount: 0,
            sourceChain: sourceChainId
        });

        draw.ticketsSold++;

        draw.prizePool += prizePoolContribution;

        draw.combinedCommittedRandomness =
            draw.combinedCommittedRandomness ^
            uint256(hashedRandomness);

        drawTickets[drawId].push(tokenId);

        emit TicketPurchased(
            buyer,
            tokenId,
            drawId,
            packedNumbers,
            sourceChainId
        );

        emit RandomnessCommitted(drawId, buyer, tokenId, hashedRandomness);
    }

    /**
     * @notice Internal function to handle ticket claims
     * @param tokenId ID of the ticket token
     * @param claimer Address of the ticket claimer
     * @param sourceChainId Source chain ID for cross-chain claims (0 for native)
     * @dev Validates ticket ownership and status, calculates matches, and processes prize payment
     * @custom:emits PrizePaid Emitted when the prize is paid to the winner
     * @custom:error NotTicketOwner Thrown when the caller is not the owner of the ticket
     * @custom:error InvalidTicketStatus Thrown when the ticket is not active
     * @custom:error InvalidDrawStatus Thrown when the draw is not completed
     * @custom:error TicketNotWon Thrown when the ticket did not win any prize
     */
    function _claimTicket(
        uint256 tokenId,
        address claimer,
        uint256 sourceChainId
    ) private {
        Ticket storage ticket = _tickets[tokenId];

        if (ticket.owner != claimer) revert NotTicketOwner();

        if (ticket.status != TicketStatus.ACTIVE) revert InvalidTicketStatus();

        Draw storage draw = _draws[ticket.drawId];

        if (draw.status != DrawStatus.COMPLETED) revert InvalidDrawStatus();

        // Calculate matches
        uint8 matchCount = ticket.numbers.countMatches(draw.winningNumbers);

        if (matchCount < 4) revert TicketNotWon();

        uint8 tierIndex = matchCount - 4; // 0, 1, 2

        ticket.status = TicketStatus.PAID;

        ticket.matchedCount = matchCount;

        ticket.prizeAmount = draw.prizesPerWinner[tierIndex];

        _winnersByTier[ticket.drawId][matchCount].push(tokenId);

        // Check if cross-chain or native
        if (sourceChainId == 0) {
            // Native Polygon: transfer directly
            IERC20(address(paymentToken)).safeTransfer(
                claimer,
                draw.prizesPerWinner[tierIndex]
            );

            emit PrizePaid(
                tokenId,
                claimer,
                tierIndex,
                draw.prizesPerWinner[tierIndex],
                0
            );
        } else {
            // Cross-chain: send via OFT
            _sendCrossChainPrize(
                _chainIdToChainEid[sourceChainId],
                tokenId,
                claimer,
                draw.prizesPerWinner[tierIndex],
                tierIndex
            );
        }
    }

    /**
     * @notice Convert address to bytes32
     * @param _addr Address to convert
     * @return bytes32 representation of the address
     */
    function _addressToBytes32(address _addr) private pure returns (bytes32) {
        return bytes32(uint256(uint160(_addr)));
    }

    /**
     * @notice Convert bytes32 to address
     * @param _b bytes32 to convert
     * @return Address representation of the bytes32
     */
    function _bytes32ToAddress(bytes32 _b) private pure returns (address) {
        return address(uint160(uint256(_b)));
    }

    /**
     * @notice Handle LayerZero compose messages
     * @param _message Message payload
     * @dev Decodes the message and processes ticket purchases
     * @custom:emits TicketPurchased Emitted when a ticket is purchased.
     * @custom:emits RandomnessCommitted Emitted when user randomness is committed.
     * @custom:error CallerNotLotturaHub Thrown when the caller is not the LotturaHub.
     * @custom:error InvalidParam Thrown when the cross-chain message type is invalid
     */
    function _handleCompose(
        address /*_oApp*/,
        bytes calldata _message
    ) private {
        address sourceLotturaHub = _bytes32ToAddress(
            OFTComposeMsgCodec.composeFrom(_message)
        );

        bytes memory composeMsg = OFTComposeMsgCodec.composeMsg(_message);

        (
            uint8 messageType,
            uint256 chainId,
            uint256 tokenId,
            address buyer,
            uint8[6] memory numbers,
            uint256 drawId,
            bytes32 hashedRandomness,
            uint256 ticketPrice,
            uint16 commission
        ) = abi.decode(
                composeMsg,
                (
                    uint8,
                    uint256,
                    uint256,
                    address,
                    uint8[6],
                    uint256,
                    bytes32,
                    uint256,
                    uint16
                )
            );

        if (address(hubs[chainId]) != sourceLotturaHub) {
            revert CallerNotLotturaHub();
        }

        if (messageType == MSG_TYPE_PURCHASE) {
            _purchaseTicket(
                tokenId,
                buyer,
                numbers,
                drawId,
                hashedRandomness,
                chainId,
                ticketPrice,
                commission
            );
        } else {
            revert InvalidParam(InvalidParams.InvalidCrossChainMessageType);
        }
    }

    /**
     * @notice Request randomness from Chainlink VRF V2 Plus Wrapper, paying in native tokens
     * @param _callbackGasLimit Gas limit for the callback
     * @param _requestConfirmations Number of confirmations to wait
     * @param _numWords Number of random words to request
     * @return requestId VRF request ID
     * @return requestPrice Price paid for the VRF request
     * @custom:error InsufficientGasForChainlinkVRF Thrown when there is insufficient native token balance to pay for the VRF request.
     */
    function _requestRandomnessPayInNative(
        uint32 _callbackGasLimit,
        uint16 _requestConfirmations,
        uint32 _numWords
    ) private returns (uint256 requestId, uint256 requestPrice) {
        requestPrice = vrfV2PlusWrapper.calculateRequestPriceNative(
            _callbackGasLimit,
            _numWords
        );

        if (address(this).balance < requestPrice)
            revert InsufficientGasForChainlinkVRF();

        bytes memory extraArgs = VRFV2PlusClient._argsToBytes(
            VRFV2PlusClient.ExtraArgsV1({nativePayment: true})
        );

        return (
            vrfV2PlusWrapper.requestRandomWordsInNative{value: requestPrice}(
                _callbackGasLimit,
                _requestConfirmations,
                _numWords,
                extraArgs
            ),
            requestPrice
        );
    }

    /**
     * @notice Create a new lottery draw
     * @dev Increments the current draw ID and initializes a new Draw struct
     * @custom:emits DrawCreated Emitted when a new draw is created.
     */
    function _createDraw() private {
        currentDrawId++;

        Draw storage newDraw = _draws[currentDrawId];

        newDraw.id = currentDrawId;
        newDraw.startTime = uint40(block.timestamp);
        newDraw.endTime = uint40(block.timestamp + _config.drawInterval);
        newDraw.status = DrawStatus.OPEN;

        emit DrawCreated(currentDrawId, newDraw.startTime, newDraw.endTime);
    }

    /**
     * @notice Request random words from Chainlink VRF
     * @return requestId VRF request ID
     */
    function _requestRandomWords() private returns (uint256 requestId) {
        (requestId, ) = _requestRandomnessPayInNative(100_000, 3, 1);

        return requestId;
    }

    /**
     * @notice Fulfill random words from Chainlink VRF
     * @param requestId VRF request ID
     * @param randomWords Array of random words returned by VRF
     * @dev Combines VRF randomness with user committed randomness to generate winning numbers
     * @custom:emits DrawProcessingWinners Emitted when winners are being processed for a draw.
     * @custom:error InvalidDrawStatus Thrown when the draw is not in DRAWING status.
     */
    function _fulfillRandomWords(
        uint256 requestId,
        uint256[] memory randomWords
    ) private {
        uint256 drawId = vrfRequestToDraw[requestId];

        Draw storage draw = _draws[drawId];

        if (draw.status != DrawStatus.DRAWING) revert InvalidDrawStatus();

        draw.vrfSeed = randomWords[0];

        // Combine VRF randomness with user randomness
        uint256 combinedSeed = randomWords[0] ^
            draw.combinedCommittedRandomness;

        // Generate winning numbers from combined randomness
        uint8[6] memory winningNumbersArray = NumberConversionLib
            .generateRandomNumbers(combinedSeed);

        uint48 winningNumbers = winningNumbersArray.numbersToUint48();

        // Store winning numbers
        draw.winningNumbers = winningNumbers;

        // Complete draw
        draw.status = DrawStatus.PROCESSING_WINNERS;

        emit DrawProcessingWinners(drawId, winningNumbers);
    }

    /**
     * @notice Send cross-chain prize to winner
     * @param chainEid Destination chain EID
     * @param ticketId Ticket ID
     * @param winner Winner address
     * @param prizeAmount Prize amount
     * @param tier Winning tier
     * @dev Uses LayerZero OFT to send prize cross-chain
     * @custom:emits PrizePaid Emitted when the prize is paid to the winner.
     * @custom:error InsufficientGasForCrossChainPrize Thrown when there is insufficient native token balance for cross-chain prize distribution.
     */
    function _sendCrossChainPrize(
        uint32 chainEid,
        uint256 ticketId,
        address winner,
        uint256 prizeAmount,
        uint8 tier
    ) private {
        bytes memory options = OptionsBuilder
            .newOptions()
            .addExecutorLzReceiveOption(200000, 0);

        SendParam memory sendParam = SendParam({
            dstEid: chainEid,
            to: _addressToBytes32(winner),
            amountLD: prizeAmount,
            minAmountLD: prizeAmount,
            extraOptions: options,
            composeMsg: "",
            oftCmd: ""
        });

        MessagingFee memory fee = paymentToken.quoteSend(sendParam, false);

        if (address(this).balance < fee.nativeFee)
            revert InsufficientGasForCrossChainPrize();

        paymentToken.send{value: fee.nativeFee}(sendParam, fee, address(this));

        emit PrizePaid(ticketId, winner, tier, prizeAmount, chainEid);
    }

    /**
     * @notice Handle rollover of unclaimed prizes to the next draw
     * @param drawId ID of the completed draw
     * @dev Calculates rollover amounts and updates the next draw's rollover amounts
     * @custom:emits RolloverAdded Emitted when rollover amount is added to the next draw.
     */
    function _handleRollover(uint256 drawId) private {
        Draw storage draw = _draws[drawId];

        uint256 totalPrizePool = draw.prizePool;

        for (uint8 i = 0; i < 3; i++) totalPrizePool += draw.rolloverAmount[i];

        uint256 totalPaid = 0;

        for (uint8 tier = 4; tier <= 6; tier++) {
            uint8 tierIndex = tier - 4; // 0, 1, 2

            totalPaid +=
                draw.winningTicketsCounts[tierIndex] *
                draw.prizesPerWinner[tierIndex];
        }

        uint256 rollover = totalPrizePool - totalPaid;

        if (rollover > 0) {
            uint256 nextDrawId = drawId + 1;

            Draw storage nextDraw = _draws[nextDrawId];

            // Distribute rollover across tiers proportionally
            for (uint8 i = 0; i < 3; i++) {
                uint256 tierRollover = (rollover *
                    _prizeDistributionPercentages[i]) / BASIS_POINTS;

                nextDraw.rolloverAmount[i] = tierRollover;

                emit RolloverAdded(nextDrawId, i + 4, tierRollover);
            }
        }
    }
}
