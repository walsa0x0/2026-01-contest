# Solidity API

## LotturaTicketNFT

Lottura Ticket NFT contract enabling cross-chain NFT transfers with ticket receipt data.

_Inherits from ONFT721Enumerable for cross-chain NFT functionality._

### InvalidParams

_Enumeration of invalid parameter types for error handling._

```solidity
enum InvalidParams {
  ZeroAddressMinter
}
```

### MinterUpdated

```solidity
event MinterUpdated(address newMinter)
```

Emitted when the minter address is updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newMinter | address | The new minter address. |

### TicketMinted

```solidity
event TicketMinted(uint256 tokenId, address owner, uint8[6] numbers, uint256 drawId)
```

Emitted when a new ticket NFT is minted.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenId | uint256 | The ID of the minted ticket NFT. |
| owner | address | The address of the ticket NFT owner. |
| numbers | uint8[6] | The lottery numbers associated with the ticket. |
| drawId | uint256 | The draw ID for which the ticket was minted. |

### InvalidParam

```solidity
error InvalidParam(enum LotturaTicketNFT.InvalidParams param)
```

Thrown when a function is called with an invalid parameter.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| param | enum LotturaTicketNFT.InvalidParams | The invalid parameter. |

### NotAMinter

```solidity
error NotAMinter()
```

Thrown when the caller is not the minter.

### onlyMinter

```solidity
modifier onlyMinter()
```

_Modifier to restrict function access to the minter only._

### constructor

```solidity
constructor(string _name, string _symbol, address _lzEndpoint, address _delegate) public
```

Constructor to initialize the LotturaTicketNFT contract.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _name | string | The name of the NFT collection. |
| _symbol | string | The symbol of the NFT collection. |
| _lzEndpoint | address | The LayerZero endpoint address for cross-chain messaging. |
| _delegate | address | The delegate address for ONFT operations. |

### setMinter

```solidity
function setMinter(address newMinter) external
```

Sets the minter address authorized to mint tickets.

_Can only be called by the contract owner._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newMinter | address | The new minter address. |

### mint

```solidity
function mint(address to, struct TicketReceipt ticketReceipt) external returns (uint256 tokenId)
```

Mints a new ticket NFT to the specified address with the provided ticket receipt.

_Can only be called by the authorized minter._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| to | address | The address to mint the ticket NFT to. |
| ticketReceipt | struct TicketReceipt | The ticket receipt data associated with the minted ticket. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenId | uint256 | The ID of the minted ticket NFT. |

### getTicketReceipt

```solidity
function getTicketReceipt(uint256 tokenId) external view returns (struct TicketReceipt)
```

Retrieves the ticket receipt associated with a given token ID.

_Reverts if the caller is not the owner of the ticket NFT._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenId | uint256 | The ID of the ticket NFT. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | struct TicketReceipt | TicketReceipt struct containing the ticket details. |

### quoteSend

```solidity
function quoteSend(struct SendParam _sendParam, bool _payInLzToken) external view returns (struct MessagingFee msgFee)
```

Quotes the messaging fee for sending a ticket NFT cross-chain.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _sendParam | struct SendParam | The parameters for sending the ticket NFT. |
| _payInLzToken | bool | Boolean indicating if the fee should be paid in LayerZero token. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| msgFee | struct MessagingFee | The quoted messaging fee. |

### send

```solidity
function send(struct SendParam _sendParam, struct MessagingFee _fee, address _refundAddress) external payable returns (struct MessagingReceipt msgReceipt)
```

Sends a ticket NFT cross-chain to the specified destination.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _sendParam | struct SendParam | The parameters for sending the ticket NFT. |
| _fee | struct MessagingFee | The messaging fee details. |
| _refundAddress | address | The address to refund any excess fee. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| msgReceipt | struct MessagingReceipt | The messaging receipt containing details of the send operation. |

### _lzReceive

```solidity
function _lzReceive(struct Origin _origin, bytes32 _guid, bytes _message, address, bytes) internal virtual
```

Internal function to handle the receipt of a ticket NFT from another chain.

_Overrides the _lzReceive function from the ONFT721Enumerable contract._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _origin | struct Origin | The origin information of the message. |
| _guid | bytes32 | The unique identifier for the message. |
| _message | bytes | The message payload containing ticket NFT details. |
|  | address |  |
|  | bytes |  |

### _buildMsgAndOptionsExtended

```solidity
function _buildMsgAndOptionsExtended(struct ExtendedSendParam _sendParam) internal view returns (bytes message, bytes options)
```

Internal function to build the message and options for sending a ticket NFT.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _sendParam | struct ExtendedSendParam | The extended parameters for sending the ticket NFT. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| message | bytes | The encoded message payload. |
| options | bytes | The combined options for the message. |

