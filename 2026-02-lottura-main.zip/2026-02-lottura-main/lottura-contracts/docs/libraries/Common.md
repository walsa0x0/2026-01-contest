# Solidity API

## TicketReceipt

```solidity
struct TicketReceipt {
  uint8[6] numbers;
  uint256 drawId;
  uint40 timestamp;
}
```

## ExtendedSendParam

```solidity
struct ExtendedSendParam {
  uint32 dstEid;
  bytes32 to;
  uint256 tokenId;
  struct TicketReceipt ticket;
  bytes extraOptions;
  bytes composeMsg;
  bytes onftCmd;
}
```

