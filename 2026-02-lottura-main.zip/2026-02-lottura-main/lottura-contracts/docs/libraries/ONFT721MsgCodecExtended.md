# Solidity API

## ONFT721MsgCodecExtended

Library for encoding and decoding ONFT721 LayerZero messages.

### encode

```solidity
function encode(bytes32 _sendTo, uint256 _tokenId, struct TicketReceipt _ticket, bytes _composeMsg) internal view returns (bytes payload, bool hasCompose)
```

_Encodes an ONFT721 LayerZero message payload._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _sendTo | bytes32 | The recipient address. |
| _tokenId | uint256 | The ID of the token to transfer. |
| _ticket | struct TicketReceipt |  |
| _composeMsg | bytes | The composed payload. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| payload | bytes | The encoded message payload. |
| hasCompose | bool | A boolean indicating whether the message payload contains a composed payload. |

### sendTo

```solidity
function sendTo(bytes _msg) internal pure returns (bytes32)
```

_Decodes sendTo from the ONFT LayerZero message._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _msg | bytes | The message. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | bytes32 | The recipient address in bytes32 format. |

### tokenId

```solidity
function tokenId(bytes _msg) internal pure returns (uint256)
```

_Decodes tokenId from the ONFT LayerZero message._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _msg | bytes | The message. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | uint256 | The ID of the tokens to transfer. |

### ticketReceipt

```solidity
function ticketReceipt(bytes _msg) internal pure returns (struct TicketReceipt)
```

### isComposed

```solidity
function isComposed(bytes _msg) internal pure returns (bool)
```

_Decodes whether there is a composed payload._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _msg | bytes | The message. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | bool | A boolean indicating whether the message has a composed payload. |

### composeMsg

```solidity
function composeMsg(bytes _msg) internal pure returns (bytes)
```

_Decodes the composed message._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _msg | bytes | The message. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | bytes | The composed message. |

### addressToBytes32

```solidity
function addressToBytes32(address _addr) internal pure returns (bytes32)
```

_Converts an address to bytes32._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _addr | address | The address to convert. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | bytes32 | The bytes32 representation of the address. |

### bytes32ToAddress

```solidity
function bytes32ToAddress(bytes32 _b) internal pure returns (address)
```

_Converts bytes32 to an address._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _b | bytes32 | The bytes32 value to convert. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | address | The address representation of bytes32. |

