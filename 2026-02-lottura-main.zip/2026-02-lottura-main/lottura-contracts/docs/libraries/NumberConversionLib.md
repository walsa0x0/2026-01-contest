# Solidity API

## NumberConversionLib

Library for converting between uint8[6] arrays and packed uint48 format
        for lottery ticket number representation.

_Each ticket has 6 numbers in the range 1-50, stored as 2-digit pairs
     in a single uint48 (e.g., [5,12,23,34,41,48] → 051223344148)._

### MIN_NUMBER

```solidity
uint8 MIN_NUMBER
```

Minimum number allowed (1)

### MAX_NUMBER

```solidity
uint8 MAX_NUMBER
```

Maximum number allowed (50)

### NUMBERS_PER_TICKET

```solidity
uint8 NUMBERS_PER_TICKET
```

Number of numbers per ticket

### InvalidNumberRange

```solidity
error InvalidNumberRange(uint8 number)
```

Error for invalid number range

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| number | uint8 | The invalid number |

### DuplicateNumber

```solidity
error DuplicateNumber(uint8 number)
```

Error for duplicate numbers

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| number | uint8 | The duplicate number |

### numbersToUint48

```solidity
function numbersToUint48(uint8[6] numbers) internal pure returns (uint48 packed)
```

Converts an array of 6 uint8 numbers into a packed uint48 format

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| numbers | uint8[6] | Array of 6 numbers (each 1-50) |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| packed | uint48 | Packed uint48 representation |

### uint48ToNumbers

```solidity
function uint48ToNumbers(uint48 packed) internal pure returns (uint8[6] numbers)
```

Converts a packed uint48 format back into an array of 6 uint8 numbers

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| packed | uint48 | Packed uint48 representation |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| numbers | uint8[6] | Array of 6 numbers (each 1-50) |

### countMatches

```solidity
function countMatches(uint48 ticketNumbers, uint48 winningNumbers) internal pure returns (uint8 matches)
```

Counts how many numbers match between a ticket and winning numbers

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| ticketNumbers | uint48 | Packed uint48 ticket numbers |
| winningNumbers | uint48 | Packed uint48 winning numbers |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| matches | uint8 | Number of matching numbers |

### generateRandomNumbers

```solidity
function generateRandomNumbers(uint256 seed) internal pure returns (uint8[6] numbers)
```

Generates 6 unique random numbers in the range 1-50
        using a given seed.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| seed | uint256 | Seed for randomness |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| numbers | uint8[6] | Array of 6 unique random numbers |

