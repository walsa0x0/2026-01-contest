# Solidity API

## LotturaHub

LotturaHub is the main contract for managing lottery ticket purchases and claims across chains.
It interacts with LotturaCore for core lottery functionalities and LotturaTicketNFT for ticket NFT management.

_This contract is upgradeable using UUPS pattern and includes pausability features._

### InvalidParams

_Enumeration of invalid parameter types for error handling._

```solidity
enum InvalidParams {
  ZeroAmount,
  DrawIdZero,
  TicketNumbersOutOfRange,
  TicketNumbersDuplicate,
  ZeroAddressLotturaCore,
  ZeroLotturaCoreEid,
  ZeroAddressPaymentToken,
  ZeroTicketPrice,
  ZeroAddressImplementation,
  ZeroAddressTicketNFT,
  ZeroHashedRandomness,
  InvalidGasAmount,
  NotEnoughBalance,
  NoTickets,
  ArrayLengthMismatch,
  InvalidCommission
}
```

### TicketPriceUpdated

```solidity
event TicketPriceUpdated(uint256 price)
```

Emitted when the ticket price is updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| price | uint256 | The new ticket price. |

### LotturaCoreUpdated

```solidity
event LotturaCoreUpdated(address lotturaCore, uint32 lotturaCoreEid)
```

Emitted when the LotturaCore contract address and EID is updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| lotturaCore | address | The new LotturaCore contract address. |
| lotturaCoreEid | uint32 | The new LotturaCore EID. |

### PaymentTokenUpdated

```solidity
event PaymentTokenUpdated(address paymentToken)
```

Emitted when the payment token address is updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| paymentToken | address | The new payment token address. |

### TokenPurchased

```solidity
event TokenPurchased(uint256 tokenId, address owner, uint256 drawId, uint8[6] numbers, bytes32 hashedRandomness)
```

Emitted when a ticket token is purchased.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenId | uint256 | The ID of the purchased ticket token. |
| owner | address | The address of the ticket owner. |
| drawId | uint256 | The draw ID for which the ticket was purchased. |
| numbers | uint8[6] | The selected numbers on the ticket. |
| hashedRandomness | bytes32 | The hashed randomness associated with the ticket purchase. |

### TokenClaimed

```solidity
event TokenClaimed(uint256 tokenId, address owner)
```

Emitted when a ticket token is claimed.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenId | uint256 | The ID of the claimed ticket token. |
| owner | address | The address of the ticket owner who claimed the ticket. |

### CommissionUpdated

```solidity
event CommissionUpdated(uint16 oldCommission, uint16 newCommission)
```

Emitted when the commission rate is updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| oldCommission | uint16 | The previous commission rate. |
| newCommission | uint16 | The new commission rate. |

### TicketNFTUpdated

```solidity
event TicketNFTUpdated(address ticketNFT)
```

Emitted when the LotturaTicketNFT contract address is updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| ticketNFT | address | The new LotturaTicketNFT contract address. |

### NativeTokenFunded

```solidity
event NativeTokenFunded(address sender, uint256 amount)
```

Emitted when native tokens are funded to the contract for gas.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| sender | address | The address of the sender who funded the native tokens. |
| amount | uint256 | The amount of native tokens funded. |

### TokensEmergencyWithdraw

```solidity
event TokensEmergencyWithdraw(address owner, uint256 tokenAmount)
```

Emitted when tokens are withdrawn in case of emergency.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| owner | address | The address of the owner who performed the withdrawal. |
| tokenAmount | uint256 | The amount of tokens withdrawn. |

### NativeEmergencyWithdraw

```solidity
event NativeEmergencyWithdraw(address owner, uint256 nativeAmount)
```

Emitted when native tokens are withdrawn in case of emergency.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| owner | address | The address of the owner who performed the withdrawal. |
| nativeAmount | uint256 | The amount of native tokens withdrawn. |

### lotturaCore

```solidity
contract LotturaCore lotturaCore
```

Address of the LotturaCore contract.

### lotturaCoreEid

```solidity
uint32 lotturaCoreEid
```

EID of the LotturaCore contract.

### paymentToken

```solidity
address paymentToken
```

Address of the payment token (OFT).

### ticketPrice

```solidity
uint256 ticketPrice
```

Price of a lottery ticket.

### commission

```solidity
uint16 commission
```

Commission rate in basis points.

### ticketNFT

```solidity
contract LotturaTicketNFT ticketNFT
```

Address of the LotturaTicketNFT contract.

### isOnPolygonChain

```solidity
bool isOnPolygonChain
```

Flag indicating if the contract is deployed on Polygon chain.

### InvalidParam

```solidity
error InvalidParam(enum LotturaHub.InvalidParams param)
```

Thrown when a function is called with an invalid parameter.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| param | enum LotturaHub.InvalidParams | The invalid parameter. |

### InsufficientLayerZeroFee

```solidity
error InsufficientLayerZeroFee()
```

Thrown when there are insufficient LayerZero fees for cross-chain operations.

### NotTokenOwner

```solidity
error NotTokenOwner()
```

Thrown when a caller is not the owner of a specified token.

### EmergencyWithdrawFailed

```solidity
error EmergencyWithdrawFailed()
```

Thrown when an emergency withdrawal fails.

### constructor

```solidity
constructor(address _endpoint) public
```

### initialize

```solidity
function initialize(address _paymentToken, uint256 _initTicketPrice, uint16 _initCommission, bool _isOnPolygonChain) external
```

Initializes the LotturaHub contract.

_This function must be called only once during deployment._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _paymentToken | address | The address of the payment token (OFT). |
| _initTicketPrice | uint256 | The initial price of a lottery ticket. |
| _initCommission | uint16 | The initial commission rate in basis points. |
| _isOnPolygonChain | bool | Flag indicating if the contract is deployed on Polygon chain. |

### updateLotturaCore

```solidity
function updateLotturaCore(address newLotturaCore, uint32 newLotturaCoreEid) external
```

Updates the LotturaCore contract address and EID.

_Only the contract owner can call this function._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newLotturaCore | address | The new LotturaCore contract address. |
| newLotturaCoreEid | uint32 | The new LotturaCore EID. |

### updatePaymentToken

```solidity
function updatePaymentToken(address newPaymentToken) external
```

Updates the payment token address.

_Only the contract owner can call this function._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newPaymentToken | address | The new payment token address. |

### updateTicketPrice

```solidity
function updateTicketPrice(uint256 newTicketPrice) external
```

Updates the ticket price.

_Only the contract owner can call this function._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newTicketPrice | uint256 | The new ticket price. |

### updateCommission

```solidity
function updateCommission(uint16 newCommission) external
```

Updates the commission rate.

_Only the contract owner can call this function._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newCommission | uint16 | The new commission rate in basis points. |

### updateTicketNFT

```solidity
function updateTicketNFT(address newTicketNFT) external
```

Updates the LotturaTicketNFT contract address.

_Only the contract owner can call this function._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newTicketNFT | address | The new LotturaTicketNFT contract address. |

### tokensEmergencyWithdraw

```solidity
function tokensEmergencyWithdraw(uint256 amount) external
```

Allows the contract owner to withdraw tokens in case of emergency.

_Only the contract owner can call this function._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| amount | uint256 | The amount of tokens to withdraw. |

### nativeEmergencyWithdraw

```solidity
function nativeEmergencyWithdraw(uint256 amount) external
```

Allows the contract owner to withdraw native in case of emergency.

_Only the contract owner can call this function._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| amount | uint256 | The amount of native to withdraw. |

### pause

```solidity
function pause() external
```

Pauses the contract, disabling ticket purchases and claims.

_Only the contract owner can call this function._

### unpause

```solidity
function unpause() external
```

Unpauses the contract, enabling ticket purchases and claims.

_Only the contract owner can call this function._

### fundGas

```solidity
function fundGas() external payable
```

Funds the contract with native tokens for LayerZero gas fees.

_Emits a `NativeTokenFunded` event upon successful funding._

### purchaseTickets

```solidity
function purchaseTickets(uint8[6][] numbersList, uint256 drawId, bytes32[] hashedRandomnessList) external returns (uint256[] tokenIds)
```

Purchases lottery tickets with specified numbers for a given draw.

_Reverts with `InvalidParam` error if drawId is zero, no tickets are provided,
or if the lengths of numbersList and hashedRandomnessList do not match._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| numbersList | uint8[6][] | An array of arrays, each containing 6 unique numbers selected for the tickets. |
| drawId | uint256 | The ID of the lottery draw for which the tickets are purchased. |
| hashedRandomnessList | bytes32[] | An array of bytes32 values representing user committed randomness for each ticket. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenIds | uint256[] | An array of token IDs representing the purchased tickets. |

### claimTicket

```solidity
function claimTicket(uint256 tokenId) external
```

Claims the lottery ticket with the specified token ID.

_It verifies the caller is the owner of the ticket and interacts with LotturaCore for cross-chain claims if necessary._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenId | uint256 | The ID of the ticket token to be claimed. |

### _authorizeUpgrade

```solidity
function _authorizeUpgrade(address newImplementation) internal
```

Authorizes the upgrade of the contract implementation.

_Only the contract owner can authorize an upgrade._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newImplementation | address | The address of the new implementation contract. |

### _lzReceive

```solidity
function _lzReceive(struct Origin, bytes32, bytes, address, bytes) internal
```

Handles incoming LayerZero messages.

_This function is intentionally left empty as LotturaHub does not process incoming messages._

### _payNative

```solidity
function _payNative(uint256 _nativeFee) internal virtual returns (uint256 nativeFee)
```

Pays the required native fee for LayerZero cross-chain operations.

_Reverts with `NotEnoughNative` error if the contract does not have enough native balance._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _nativeFee | uint256 | The required native fee amount. |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| nativeFee | uint256 | The amount of native fee paid. |

