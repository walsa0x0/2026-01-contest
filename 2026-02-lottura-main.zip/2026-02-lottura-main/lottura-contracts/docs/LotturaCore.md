# Solidity API

## LotturaCore

Core contract for the Lottura decentralized lottery system.

### ADMIN_ROLE

```solidity
bytes32 ADMIN_ROLE
```

Admin role identifier.

### OPERATOR_ROLE

```solidity
bytes32 OPERATOR_ROLE
```

Operator role identifier.

### UPGRADER_ROLE

```solidity
bytes32 UPGRADER_ROLE
```

Upgrader role identifier.

### InvalidParams

_Enumeration of invalid parameter types for error handling._

```solidity
enum InvalidParams {
  ZeroAddressImplementation,
  InvalidCrossChainMessageType,
  ZeroAddressPaymentToken,
  ZeroAddressVRFV2PlusWrapper,
  InvalidReserveAmount,
  InvalidGasAmount,
  ZeroDrawInterval,
  SameDrawInterval,
  ZeroChainId,
  ZeroChainEid,
  InvalidWinningTicketsCountsArrayLength,
  ZeroAmount,
  NotEnoughBalance,
  ZeroHubAddress
}
```

### LotteryConfig

Configuration parameters for the lottery.

```solidity
struct LotteryConfig {
  uint32 drawInterval;
  uint8 minNumber;
  uint8 maxNumber;
  uint8 numbersPerTicket;
}
```

### Draw

Represents a lottery draw.

```solidity
struct Draw {
  uint256 id;
  uint40 startTime;
  uint40 endTime;
  uint48 winningNumbers;
  uint256 prizePool;
  uint32 ticketsSold;
  uint256[3] rolloverAmount;
  enum LotturaCore.DrawStatus status;
  uint256 vrfRequestId;
  uint256 combinedCommittedRandomness;
  uint256[3] winningTicketsCounts;
  uint256[3] prizesPerWinner;
  uint256 vrfSeed;
}
```

### DrawStatus

Enumeration of draw statuses.

```solidity
enum DrawStatus {
  OPEN,
  DRAWING,
  PROCESSING_WINNERS,
  COMPLETED
}
```

### Ticket

Represents a lottery ticket.

```solidity
struct Ticket {
  uint256 id;
  address owner;
  uint256 drawId;
  uint48 numbers;
  uint40 purchaseTime;
  enum LotturaCore.TicketStatus status;
  uint8 matchedCount;
  uint256 prizeAmount;
  uint256 sourceChain;
}
```

### TicketStatus

Enumeration of ticket statuses.

```solidity
enum TicketStatus {
  ACTIVE,
  PAID
}
```

### TicketPurchased

```solidity
event TicketPurchased(address buyer, uint256 ticketId, uint256 drawId, uint48 numbers, uint256 sourceChain)
```

Emitted when a ticket is purchased.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| buyer | address | Address of the ticket buyer. |
| ticketId | uint256 | ID of the purchased ticket. |
| drawId | uint256 | ID of the associated draw. |
| numbers | uint48 | Packed selected numbers on the ticket. |
| sourceChain | uint256 | Source chain ID (0 = native Polygon). |

### DrawCreated

```solidity
event DrawCreated(uint256 drawId, uint256 startTime, uint256 endTime)
```

Emitted when a new draw is created.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the created draw. |
| startTime | uint256 | Start time of the draw. |
| endTime | uint256 | End time of the draw. |

### DrawExecutionStarted

```solidity
event DrawExecutionStarted(uint256 drawId, uint256 vrfRequestId)
```

Emitted when draw execution starts.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the draw being executed. |
| vrfRequestId | uint256 | Chainlink VRF request ID. |

### DrawProcessingWinners

```solidity
event DrawProcessingWinners(uint256 drawId, uint48 winningNumbers)
```

Emitted when winners are being processed for a draw.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the draw being processed. |
| winningNumbers | uint48 | Packed winning numbers for the draw. |

### DrawCompleted

```solidity
event DrawCompleted(uint256 drawId)
```

Emitted when a draw is completed.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the completed draw. |

### RandomnessCommitted

```solidity
event RandomnessCommitted(uint256 drawId, address user, uint256 tokenId, bytes32 hashedRandomness)
```

Emitted when a user commits randomness during ticket purchase.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the draw. |
| user | address | Address of the user committing randomness. |
| tokenId | uint256 | ID of the ticket token. |
| hashedRandomness | bytes32 | Hashed randomness committed by the user. |

### PrizePaid

```solidity
event PrizePaid(uint256 ticketId, address winner, uint8 tier, uint256 amount, uint32 destinationChainEid)
```

Emitted when a prize is paid to a winner.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| ticketId | uint256 | ID of the winning ticket. |
| winner | address | Address of the winner. |
| tier | uint8 | Winning tier (4-6). |
| amount | uint256 | Prize amount paid. |
| destinationChainEid | uint32 | Destination chain EID for cross-chain payments. |

### RolloverAdded

```solidity
event RolloverAdded(uint256 drawId, uint8 tier, uint256 amount)
```

Emitted when rollover amount is added to the next draw.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the draw receiving rollover. |
| tier | uint8 | Tier number (4-6). |
| amount | uint256 | Rollover amount added. |

### DrawIntervalUpdated

```solidity
event DrawIntervalUpdated(uint256 oldInterval, uint256 newInterval)
```

Emitted when the draw interval is updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| oldInterval | uint256 | Previous draw interval in seconds. |
| newInterval | uint256 | New draw interval in seconds. |

### PrizeDistributionUpdated

```solidity
event PrizeDistributionUpdated(uint16[3] newDistribution)
```

Emitted when the prize distribution percentages are updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newDistribution | uint16[3] | New prize distribution percentages for tiers 4, 5, and 6. |

### ReserveAllocated

```solidity
event ReserveAllocated(uint256 drawId, uint256 amount)
```

Emitted when reserve funds are allocated to the current draw.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the draw receiving reserve allocation. |
| amount | uint256 | Amount of reserve funds allocated. |

### CommissionWithdrawn

```solidity
event CommissionWithdrawn(address recipient, uint256 amount)
```

Emitted when commission is withdrawn to the multi-sig wallet.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| recipient | address | Address of the multi-sig wallet receiving the commission. |
| amount | uint256 | Amount of commission withdrawn. |

### HubAddressUpdated

```solidity
event HubAddressUpdated(uint256 chainId, address oldHub, address newHub)
```

Emitted when the hub address for a chain ID is updated.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| chainId | uint256 | Chain ID for which the hub address is updated. |
| oldHub | address | Previous hub address. |
| newHub | address | New hub address. |

### NativeTokenFunded

```solidity
event NativeTokenFunded(address funder, uint256 amount)
```

Emitted when native tokens are funded to the contract for LayerZero and Chainlink fees.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| funder | address | Address of the funder. |
| amount | uint256 | Amount of native tokens funded. |

### TokensEmergencyWithdraw

```solidity
event TokensEmergencyWithdraw(address owner, uint256 tokenAmount)
```

Emitted when tokens are withdrawn in case of emergency.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| owner | address | The address of the owner who performed the withdrawal. |
| tokenAmount | uint256 | The amount of tokens withdrawn. |

### NativeEmergencyWithdraw

```solidity
event NativeEmergencyWithdraw(address owner, uint256 nativeAmount)
```

Emitted when native tokens are withdrawn in case of emergency.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| owner | address | The address of the owner who performed the withdrawal. |
| nativeAmount | uint256 | The amount of native tokens withdrawn. |

### paymentToken

```solidity
contract IOFT paymentToken
```

Payment token (OFT) address.

### currentDrawId

```solidity
uint256 currentDrawId
```

Current draw ID.

### drawTickets

```solidity
mapping(uint256 => uint256[]) drawTickets
```

Mapping of draw ID to array of ticket IDs.

### accumulatedCommission

```solidity
uint256 accumulatedCommission
```

Accumulated commission amount.

### hubs

```solidity
mapping(uint256 => contract LotturaHub) hubs
```

Mapping of chain ID to LotturaHub address.

### vrfV2PlusWrapper

```solidity
contract IVRFV2PlusWrapper vrfV2PlusWrapper
```

Chainlink VRF V2 Plus Wrapper address.

### vrfRequestToDraw

```solidity
mapping(uint256 => uint256) vrfRequestToDraw
```

Mapping of VRF request ID to draw ID.

### InvalidParam

```solidity
error InvalidParam(enum LotturaCore.InvalidParams param)
```

Thrown when a function is called with an invalid parameter.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| param | enum LotturaCore.InvalidParams | The invalid parameter. |

### OnlyEndpointExecutesLZCompose

```solidity
error OnlyEndpointExecutesLZCompose()
```

Thrown when a non-endpoint contract attempts to execute lzCompose.

### InvalidPrizeDistribution

```solidity
error InvalidPrizeDistribution()
```

Thrown when the prize distribution is invalid.

### InvalidDrawStatus

```solidity
error InvalidDrawStatus()
```

Thrown when a draw is in an invalid status for the requested operation.

### DrawNotOpen

```solidity
error DrawNotOpen()
```

Thrown when attempting to operate on a draw that is not open.

### DrawNotEnded

```solidity
error DrawNotEnded()
```

Thrown when attempting to operate on a draw that has not yet ended.

### DrawAlreadyEnded

```solidity
error DrawAlreadyEnded()
```

Thrown when attempting to operate on a draw that has already ended.

### OnlyVRFCoordinator

```solidity
error OnlyVRFCoordinator()
```

Thrown when a non-VRF Coordinator contract attempts to fulfill randomness.

### NoCommissionAvailable

```solidity
error NoCommissionAvailable()
```

Thrown when there is no commission available for withdrawal.

### CallerNotLotturaHub

```solidity
error CallerNotLotturaHub()
```

Thrown when the caller is not the LotturaHub for the current chain.

### InsufficientGasForCrossChainPrize

```solidity
error InsufficientGasForCrossChainPrize()
```

Thrown when there is insufficient native token balance for cross-chain prize distribution.

### InsufficientGasForChainlinkVRF

```solidity
error InsufficientGasForChainlinkVRF()
```

Thrown when there is insufficient native token balance for Chainlink VRF requests.

### NotTicketOwner

```solidity
error NotTicketOwner()
```

Thrown when the caller is not the owner of the ticket.

### InvalidTicketStatus

```solidity
error InvalidTicketStatus()
```

Thrown when a ticket is in an invalid status for the requested operation.

### TicketNotWon

```solidity
error TicketNotWon()
```

Thrown when attempting to claim a ticket that did not win.

### EmergencyWithdrawFailed

```solidity
error EmergencyWithdrawFailed()
```

Thrown when an emergency withdrawal fails.

### onlyHub

```solidity
modifier onlyHub()
```

Modifier to restrict function access to only the LotturaHub of the current chain.

### constructor

```solidity
constructor(address _endpoint) public
```

### initialize

```solidity
function initialize(address _paymentToken, address _vrfV2PlusWrapper) external
```

Initializer function to set up the contract.

_This function must be called only once during deployment._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _paymentToken | address | Address of the payment token (OFT). |
| _vrfV2PlusWrapper | address | Address of the Chainlink VRF V2 Plus Wrapper. |

### purchaseTicket

```solidity
function purchaseTicket(uint256 tokenId, address buyer, uint8[6] numbers, uint256 drawId, bytes32 hashedRandomness, uint256 ticketPrice, uint16 commission) external
```

Purchase a lottery ticket.

_This function can only be called by the LotturaHub of the current chain._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenId | uint256 | ID of the ticket token. |
| buyer | address | Address of the ticket buyer. |
| numbers | uint8[6] | Selected numbers for the ticket. |
| drawId | uint256 | ID of the draw for which the ticket is purchased. |
| hashedRandomness | bytes32 | Hashed randomness committed by the user. |
| ticketPrice | uint256 | Price of the ticket. |
| commission | uint16 | Commission percentage in basis points. |

### claimTicket

```solidity
function claimTicket(uint256 tokenId, address claimer) external
```

Claim a winning ticket.

_This function can only be called by the LotturaHub of the current chain._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| tokenId | uint256 | ID of the ticket token. |
| claimer | address | Address of the ticket claimer. |

### executeDraw

```solidity
function executeDraw(uint256 drawId) external
```

Execute the draw to select winning numbers.

_This function can only be called by an operator._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the draw to execute. |

### setWinningTicketsCounts

```solidity
function setWinningTicketsCounts(uint256 drawId, uint32[3] winningTicketsCounts) external
```

Set winning tickets counts and calculate prizes per winner.

_This function can only be called by an operator._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | ID of the draw to complete. |
| winningTicketsCounts | uint32[3] | Array of winning ticket counts for tiers 4, 5, and 6. |

### lzCompose

```solidity
function lzCompose(address _oApp, bytes32, bytes _message, address, bytes) external payable
```

LayerZero compose function to handle cross-chain messages.

_This function can only be called by the LayerZero endpoint._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| _oApp | address | Originating OApp address. |
|  | bytes32 |  |
| _message | bytes | Message payload. |
|  | address |  |
|  | bytes |  |

### rawFulfillRandomWords

```solidity
function rawFulfillRandomWords(uint256 requestId, uint256[] randomWords) external
```

Callback function for Chainlink VRF to fulfill randomness requests.

_This function can only be called by the VRF Coordinator._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| requestId | uint256 | ID of the VRF request. |
| randomWords | uint256[] | Array of random words returned by VRF. |

### setDrawInterval

```solidity
function setDrawInterval(uint32 newInterval) external
```

Set the draw interval.

_This function can only be called by an admin._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newInterval | uint32 | New draw interval in seconds. |

### setPrizeDistribution

```solidity
function setPrizeDistribution(uint16[3] newDistribution) external
```

Set the prize distribution percentages.

_This function can only be called by an admin._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newDistribution | uint16[3] | New prize distribution percentages for tiers 4, 5, and 6. |

### setHubAddress

```solidity
function setHubAddress(uint256 chainId, address hubAddress) external
```

Set the LotturaHub address for a specific chain ID.

_This function can only be called by an admin._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| chainId | uint256 | Chain ID for which to set the hub address. |
| hubAddress | address | Address of the LotturaHub contract. |

### setChainEidForChainId

```solidity
function setChainEidForChainId(uint256 chainId, uint32 chainEid) external
```

Set the LayerZero chain EID for a specific chain ID.

_This function can only be called by an admin._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| chainId | uint256 | Chain ID for which to set the chain EID. |
| chainEid | uint32 | LayerZero chain EID. |

### allocateReserve

```solidity
function allocateReserve(uint256 amount) external
```

Allocate reserve funds to the current draw.

_This function can only be called by an admin._

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| amount | uint256 | Amount of reserve funds to allocate. |

### withdrawCommission

```solidity
function withdrawCommission() external
```

Withdraw accumulated commission to the multi-sig wallet.

_This function can only be called by an admin._

### fundGas

```solidity
function fundGas() external payable
```

Fund native tokens to the contract for LayerZero and Chainlink fees.

_This function allows anyone to fund native tokens._

### tokensEmergencyWithdraw

```solidity
function tokensEmergencyWithdraw(uint256 amount) external
```

Allows the contract owner to withdraw tokens in case of emergency.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| amount | uint256 | The amount of tokens to withdraw. |

### nativeEmergencyWithdraw

```solidity
function nativeEmergencyWithdraw(uint256 amount) external
```

Allows the contract owner to withdraw native in case of emergency.

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| amount | uint256 | The amount of native to withdraw. |

### prizeDistribution

```solidity
function prizeDistribution() external view returns (uint16[3])
```

Get the prize distribution percentages.

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | uint16[3] | Array of prize distribution percentages for tiers 4, 5, and 6. |

### getLotturaConfig

```solidity
function getLotturaConfig() external view returns (struct LotturaCore.LotteryConfig)
```

Get the lottery configuration

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | struct LotturaCore.LotteryConfig | LotteryConfig struct |

### getDraw

```solidity
function getDraw(uint256 drawId) external view returns (struct LotturaCore.Draw)
```

Get draw details by draw ID

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | Draw ID |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | struct LotturaCore.Draw | Draw struct |

### getTicket

```solidity
function getTicket(uint256 ticketId) external view returns (struct LotturaCore.Ticket)
```

Get ticket details by ticket ID

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| ticketId | uint256 | Ticket ID |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | struct LotturaCore.Ticket | Ticket struct |

### getDrawTicketsLength

```solidity
function getDrawTicketsLength(uint256 drawId) external view returns (uint256)
```

Get the number of tickets for a draw

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | Draw ID |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | uint256 | Number of tickets |

### getDrawTicketsPage

```solidity
function getDrawTicketsPage(uint256 drawId, uint256 offset, uint256 limit) external view returns (uint256[] page)
```

Get a paginated list of ticket IDs for a draw

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | Draw ID |
| offset | uint256 | Starting index |
| limit | uint256 | Number of ticket IDs to retrieve |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| page | uint256[] | Array of ticket IDs |

### getWinnersByTierLength

```solidity
function getWinnersByTierLength(uint256 drawId, uint8 tier) external view returns (uint256)
```

Get the number of winners for a draw and tier

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | Draw ID |
| tier | uint8 | Winning tier (4-6) |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| [0] | uint256 | Number of winners |

### getWinnersByTierPage

```solidity
function getWinnersByTierPage(uint256 drawId, uint8 tier, uint256 offset, uint256 limit) external view returns (uint256[] page)
```

Get a paginated list of winners for a draw and tier

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| drawId | uint256 | Draw ID |
| tier | uint8 | Winning tier (4-6) |
| offset | uint256 | Starting index |
| limit | uint256 | Number of winners to retrieve |

#### Return Values

| Name | Type | Description |
| ---- | ---- | ----------- |
| page | uint256[] | Array of Winner structs |

### _lzReceive

```solidity
function _lzReceive(struct Origin, bytes32, bytes _message, address, bytes) internal
```

LayerZero receive function to handle incoming cross-chain messages

_Decodes the message and processes ticket claims_

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
|  | struct Origin |  |
|  | bytes32 |  |
| _message | bytes | Message payload |
|  | address |  |
|  | bytes |  |

### _authorizeUpgrade

```solidity
function _authorizeUpgrade(address newImplementation) internal
```

Authorize contract upgrade

_This function restricts upgrades to only accounts with the UPGRADER_ROLE_

#### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| newImplementation | address | Address of the new implementation contract |

