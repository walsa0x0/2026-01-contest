# Lottura Smart Contracts

A decentralized cross-chain lottery system with NFT tickets, automatic prize distribution, and verifiable randomness.

**Core Network**: Polygon (Mainnet)  
**Supported Chains**: Ethereum, Arbitrum, Polygon  
**Testnets**: Sepolia, Arbitrum Sepolia, Polygon Amoy

## 🎯 Features

- **50-6 Lottery Format**: Pick 6 unique numbers from 1-50
- **Cross-Chain Architecture**: Buy tickets on any supported chain via LayerZero
- **NFT Tickets**: Each ticket is an ERC-721 token (ONFT721) transferable across chains
- **Chainlink VRF V2 Plus**: Verifiable random function for fair draw execution
- **USDT0 Payments**: Cross-chain USDT via LayerZero OFT standard
- **Claimable Prizes**: Winners claim their prizes via LotturaHub after draw completion
- **UUPS Upgradeable**: All core contracts are upgradeable

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Multi-Chain Architecture                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐          │
│  │   Ethereum   │    │   Arbitrum   │    │   Polygon    │          │
│  │   Sepolia    │    │   Sepolia    │    │    Amoy      │          │
│  ├──────────────┤    ├──────────────┤    ├──────────────┤          │
│  │ LotturaHub   │    │ LotturaHub   │    │ LotturaHub   │          │
│  │ TicketNFT    │    │ TicketNFT    │    │ TicketNFT    │          │
│  │ MockUSDT0    │    │ MockUSDT0    │    │ MockUSDT0    │          │
│  └──────┬───────┘    └──────┬───────┘    │ LotturaCore  │          │
│         │                   │            └──────┬───────┘          │
│         │                   │                   │                  │
│         └───────────────────┴───────────────────┘                  │
│                             │                                       │
│                    LayerZero V2 Protocol                           │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

## 📁 Project Structure

```
lottura-contracts/
├── contracts/
│   ├── LotturaCore.sol           # Core lottery logic (Polygon only)
│   ├── LotturaHub.sol            # Ticket purchase & claim hub (all chains)
│   ├── LotturaTicketNFT.sol      # Cross-chain NFT tickets (ONFT721)
│   ├── libraries/
│   │   ├── Common.sol            # Shared structs
│   │   ├── NumberConversionLib.sol    # Number packing utilities
│   │   └── ONFT721MsgCodecExtended.sol # Extended LayerZero codec
│   └── mocks/
│       ├── EndpointV2Mock.sol    # LayerZero endpoint mock
│       ├── MockUSDT0.sol         # Mock USDT0 token
│       ├── MockVRFV2PlusWrapper.sol # Chainlink VRF mock
│       └── NumberConversionTest.sol  # Test helper
├── scripts/
│   ├── 01_deployLotturaTicketNFT.ts
│   ├── 02_configureLotturaTicketNFTCommunication.ts
│   ├── 03_testCrossChainTransferLotturaTicketNFT.ts
│   ├── 04_deployLotturaHub.ts
│   ├── 05_deployLotturaCore.ts
│   ├── 06_wireLotturaTicketNFTAndLotturaHub.ts
│   ├── 07_wireLotturaCore.ts
│   ├── 08_transferLotturaTicketNFTOwnership.ts
│   ├── 09_transferLotturaHubOwnership.ts
│   ├── 10_transferLotturaCoreOwnership.ts
│   ├── 11_deployMockUSDT0.ts
│   ├── 12_testPurchase.ts
│   ├── 13_configureMockUSDT0Communication.ts
│   ├── 14_upgradeLotturaCore.ts
│   ├── 15_upgradeLotturaHub.ts
│   └── chain-helpers.ts
├── test/
│   ├── LotturaGeneric/           # Core functionality tests
│   └── LotturaTicketNFT/         # NFT specific tests
├── docs/                          # Generated documentation
├── hardhat.config.ts
└── package.json
```

## 📜 Smart Contracts

### LotturaCore (Polygon Only)

The central lottery engine handling:

- Draw creation and management
- Chainlink VRF V2 Plus randomness requests
- Winning number generation
- Prize pool management and distribution
- Cross-chain ticket registration via LayerZero
- Cross-chain prize claims processing via LotturaHub

### LotturaHub (All Chains)

Entry point for users on each chain:

- Ticket purchase with USDT0
- Cross-chain messaging to LotturaCore
- Ticket claim functionality
- Commission management

### LotturaTicketNFT (All Chains)

ERC-721 ticket representation:

- ONFT721 standard for cross-chain transfers
- Stores ticket receipt data (numbers, drawId, timestamp)
- Enumerable for easy querying

## 🚀 Quick Start

### Prerequisites

- pnpm

### Install Dependencies

```bash
pnpm install
```

### Compile Contracts

```bash
pnpm compile
```

### Run Tests

```bash
pnpm test
```

### Run Tests with Gas Report

```bash
pnpm test:gas
```

### Run Coverage

```bash
pnpm coverage
```

### Generate Documentation

```bash
pnpm generate-docs
```

## 🔧 Configuration

Create a `.env` file:

```bash
# Deployment
PRIVATE_KEY=your_private_key_here

# Network RPCs
MAINNET_RPC_URL=https://mainnet.infura.io/v3/YOUR_KEY
SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/YOUR_KEY
POLYGON_RPC_URL=https://polygon-rpc.com
POLYGON_AMOY_RPC_URL=https://rpc-amoy.polygon.technology
ARBITRUM_RPC_URL=https://arb1.arbitrum.io/rpc
ARBITRUM_SEPOLIA_RPC_URL=https://arbitrum-sepolia.gateway.tenderly.co

# Hardhat Settings
HARDHAT_UPGRADES_SILENCE_WARNINGS=true
REPORT_GAS=true

# Verification & Gas Reporting
COINMARKETCAP_API_KEY=your_key
ETHERSCAN_API_KEY=your_key
ARBISCAN_API_KEY=your_key
POLYGONSCAN_API_KEY=your_key
```

## 🚢 Deployment

### Deployment Order

Deploy contracts in the following order:

```bash
# 1. Deploy MockUSDT0 (testnet only)
pnpm deploy:mockusdt0:sepolia
pnpm deploy:mockusdt0:arbitrum:sepolia
pnpm deploy:mockusdt0:polygon:amoy

# 2. Configure MockUSDT0 cross-chain communication
pnpm configure:mockusdt0:sepolia
pnpm configure:mockusdt0:arbitrum:sepolia
pnpm configure:mockusdt0:polygon:amoy

# 3. Deploy LotturaTicketNFT on all chains
pnpm deploy:ticketnft:sepolia
pnpm deploy:ticketnft:arbitrum:sepolia
pnpm deploy:ticketnft:polygon:amoy

# 4. Configure TicketNFT cross-chain communication
pnpm configure:ticketnft:sepolia
pnpm configure:ticketnft:arbitrum:sepolia
pnpm configure:ticketnft:polygon:amoy

# 5. Deploy LotturaHub on all chains
pnpm deploy:lotturahub:sepolia
pnpm deploy:lotturahub:arbitrum:sepolia
pnpm deploy:lotturahub:polygon:amoy

# 6. Deploy LotturaCore (Polygon only)
pnpm deploy:lotturacore:polygon:amoy

# 7. Wire contracts together
pnpm wire:lotturaticketnft-lotturahub:sepolia
pnpm wire:lotturaticketnft-lotturahub:arbitrum:sepolia
pnpm wire:lotturaticketnft-lotturahub:polygon:amoy
pnpm wire:lotturacore:polygon:amoy
```

### Upgrade Contracts

```bash
# Upgrade LotturaCore
pnpm upgrade:lotturacore:polygon:amoy

# Upgrade LotturaHub
pnpm upgrade:lotturahub:sepolia
pnpm upgrade:lotturahub:arbitrum:sepolia
pnpm upgrade:lotturahub:polygon:amoy
```

## 📊 Gas Optimization

### Packed Number Storage

**Before (Array)**:

```solidity
uint8[6] numbers;  // 6 separate values
```

**After (Packed uint48)**:

```solidity
uint48 numbers;    // Single packed value
```

**Example**: `[5, 12, 23, 34, 41, 48]` → `51223344148`

**Savings**: ~40% gas reduction on storage operations

### Conversion Library

```solidity
// Array to packed uint48
uint48 packed = NumberConversionLib.numbersToUint48(numbers);

// Packed uint48 to array
uint8[6] memory unpacked = NumberConversionLib.uint48ToNumbers(packed);

// Count matches between tickets
uint8 matches = NumberConversionLib.countMatches(ticket, winning);

// Generate random numbers from VRF seed XORed with committedCombinedRandomness
uint8[6] memory random = NumberConversionLib.generateRandomNumbers(seed);
```

## 🔐 Security

### Access Control Roles

| Role            | Description                                                     |
| --------------- | --------------------------------------------------------------- |
| `ADMIN_ROLE`    | Configuration changes (ticket price, commission, draw interval) |
| `OPERATOR_ROLE` | Draw execution and winner processing                            |
| `UPGRADER_ROLE` | Contract upgrade authorization                                  |

### Key Security Features

- **UUPS Upgradeable**: Controlled upgrade mechanism
- **Pausable**: Emergency pause functionality on LotturaHub
- **Chainlink VRF V2 Plus**: Cryptographically verifiable randomness
- **LayerZero V2**: Secure cross-chain messaging
- **SafeERC20**: Safe token transfers
- **Emergency Withdrawals**: Native and token emergency withdraw functions for fund recovery

## 🏆 Prize Tiers

| Matches   | Prize Pool %           |
| --------- | ---------------------- |
| 4 numbers | Tier 1 share           |
| 5 numbers | Tier 2 share           |
| 6 numbers | Tier 3 share (Jackpot) |

_Prize distribution percentages are configurable via `setPrizeDistribution()`_

### Rollover Mechanism

Unclaimed prizes from tiers with no winners roll over to the next draw automatically.

## 🎲 Number Format

### User Input (Frontend)

```typescript
const numbers: number[] = [5, 12, 23, 34, 41, 48]
```

### Contract Storage (Packed)

```solidity
uint48 packed = 51223344148
```

### Validation Rules

- Each number must be between 1-50
- All 6 numbers must be unique
- Order does not matter for matching

## 📡 Cross-Chain Flow

### Ticket Purchase Flow

1. User calls `purchaseTickets()` on LotturaHub (any chain)
2. LotturaHub mints NFT ticket locally
3. If not on Polygon: sends cross-chain message via LayerZero
4. LotturaCore registers ticket for current draw

### Prize Claim Flow

1. User calls `claimTicket()` on LotturaHub
2. LotturaHub sends claim message to LotturaCore
3. LotturaCore validates win and sends prize via OFT
4. User receives USDT0 on their chain

## 🧪 Testing

### Test Structure

```
test/
├── LotturaGeneric/
│   ├── fixture.ts              # Test setup
│   ├── LotturaGeneric.test.ts  # Integration tests
│   ├── NumberConversionLib.test.ts # Library unit tests
│   └── test-enums.ts           # Test utilities
└── LotturaTicketNFT/
    ├── fixtures.ts             # NFT test setup
    └── LotturaTicketNFT.test.ts # NFT specific tests
```

### Run Specific Tests

```bash
# All tests
pnpm test

# With gas reporting
pnpm test:gas

# Coverage report
pnpm coverage
```

## 📚 Documentation

Generated documentation is available in the `docs/` folder:

- [LotturaCore.md](docs/LotturaCore.md)
- [LotturaHub.md](docs/LotturaHub.md)
- [LotturaTicketNFT.md](docs/LotturaTicketNFT.md)
- [Common.md](docs/libraries/Common.md)
- [NumberConversionLib.md](docs/libraries/NumberConversionLib.md)
- [ONFT721MsgCodecExtended.md](docs/libraries/ONFT721MsgCodecExtended.md)

Regenerate docs:

```bash
pnpm generate-docs
```

## 🛠️ Development

### Lint Solidity

```bash
pnpm lint:sol
```

### Clean Build

```bash
pnpm clean
pnpm compile
```

### Contract Sizes

Contract sizes are automatically reported on compile via `hardhat-contract-sizer`.

## 📄 License

MIT License - See LICENSE file for details

---

**Version**: 1.0.0  
**Solidity**: 0.8.22  
**License**: MIT
