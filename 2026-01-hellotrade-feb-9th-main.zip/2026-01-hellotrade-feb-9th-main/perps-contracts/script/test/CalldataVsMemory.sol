// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

contract CalldataVsMemory {
    string public memoryStoredString;
    string public calldataStoredString;

    function writeFromCalldata(string calldata input) external {
        calldataStoredString = input;
    }

    function writeFromMemory(string memory input) external {
        memoryStoredString = input;
    }
}

