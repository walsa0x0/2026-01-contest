// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {CalldataVsMemory} from "./CalldataVsMemory.sol";

contract SetString is Script {
    function setUp() public {}

    function runCalldata(address target, string calldata value) public {
        console.log("Calling writeFromCalldata...");
        console.log("Target:", target);
        console.log("Value:", value);

        vm.startBroadcast();
        CalldataVsMemory(target).writeFromCalldata(value);
        vm.stopBroadcast();

        console.log("String stored via calldata!");
    }

    function runMemory(address target, string calldata value) public {
        console.log("Calling writeFromMemory...");
        console.log("Target:", target);
        console.log("Value:", value);

        vm.startBroadcast();
        CalldataVsMemory(target).writeFromMemory(value);
        vm.stopBroadcast();

        console.log("String stored via memory!");
    }

    function run(address target, string calldata value, bool useCalldata) public {
        if (useCalldata) {
            runCalldata(target, value);
        } else {
            runMemory(target, value);
        }
    }
}

