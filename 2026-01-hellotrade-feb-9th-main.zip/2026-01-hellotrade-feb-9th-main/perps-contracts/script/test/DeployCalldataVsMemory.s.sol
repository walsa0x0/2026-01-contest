// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {CalldataVsMemory} from "./CalldataVsMemory.sol";

contract DeployCalldataVsMemory is Script {
    function setUp() public {}

    function run() public {
        console.log("Deploying CalldataVsMemory...");
        vm.startBroadcast();

        CalldataVsMemory deployed = new CalldataVsMemory();

        console.log("CalldataVsMemory deployed to:", address(deployed));
        vm.stopBroadcast();
    }
}

