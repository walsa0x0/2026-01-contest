// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {IHelloVaultV1_6} from "src/interfaces/IHelloVaultV1_6.sol";

contract SetFeeRecipient is Script {
    function setUp() public {}

    function run(address vault, address feeRecipient) public {
        vm.startBroadcast();
        IHelloVaultV1_6(vault).setFeeRecipient(feeRecipient);
        console.log("Fee recipient set to", feeRecipient);
        vm.stopBroadcast();
    }
}
