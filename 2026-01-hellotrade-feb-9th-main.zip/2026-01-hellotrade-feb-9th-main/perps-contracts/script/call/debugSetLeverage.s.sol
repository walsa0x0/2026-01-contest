// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script} from "forge-std/Script.sol";

interface IDebugVault {
    function debugSetPositionLeverage(address user, uint256 mktId, uint128 leverage) external;
}

contract SetMargin is Script {
    function setUp() public {}

    function run(address vault, address user, uint256 market, uint128 leverage) public {
        vm.startBroadcast();
        IDebugVault(vault).debugSetPositionLeverage(user, market, leverage);
        vm.stopBroadcast();
    }
}
