// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";

interface IERC20Mint {
    function mint(address to, uint256 value) external;
}

contract MintMockUsdc is Script {
    function setUp() public {}

    function run(address token, address to, uint256 amount) public {
        vm.startBroadcast();
        IERC20Mint(token).mint(to, amount);
        console.log("Minted", amount, "tokens to", to);
        vm.stopBroadcast();
    }
}
