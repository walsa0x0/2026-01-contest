// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {IHelloVaultV1_6} from "src/interfaces/IHelloVaultV1_6.sol";

contract SetToken is Script {
    function setUp() public {}

    function run(address vault, address token) public {
        vm.startBroadcast();
        IHelloVaultV1_6(vault).setToken(token);
        console.log("Token set to", IHelloVaultV1_6(vault).quoteToken());
        vm.stopBroadcast();
    }
}
