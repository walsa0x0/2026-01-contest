// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {IHelloVaultV1_6} from "src/interfaces/IHelloVaultV1_6.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {console} from "forge-std/console.sol";

contract SetMarketConfig is Script {
    function setUp() public {}

    function run(
        address vault,
        uint32 market,
        uint32 maxLeverage,
        uint16 defaultLeverage,
        uint8 pricePrecision,
        uint8 basePrecision,
        uint8 quotePrecision,
        int32 fundingMax,
        int32 fundingMin,
        uint32 minFundingInterval
    ) public {
        vm.startBroadcast();

        console.log("Default leverage:", defaultLeverage);

        MarketConfig memory config = MarketConfig({
            maxLeverage: maxLeverage,
            defaultLeverage: defaultLeverage,
            minFundingInterval: minFundingInterval,
            fundingMax: fundingMax,
            fundingMin: fundingMin,
            pricePrecision: pricePrecision,
            basePrecision: basePrecision,
            quotePrecision: quotePrecision
        });

        IHelloVaultV1_6(vault).setMarketConfig(market, config);
        vm.stopBroadcast();
    }
}
