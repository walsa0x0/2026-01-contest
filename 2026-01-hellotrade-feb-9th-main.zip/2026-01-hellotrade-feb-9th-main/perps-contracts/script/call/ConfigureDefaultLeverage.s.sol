// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script} from "forge-std/Script.sol";
import {IHelloVaultV1_6} from "src/interfaces/IHelloVaultV1_6.sol";

contract ConfigureDefaultLeverage is Script {
    function setUp() public {}

    function run(address vault, uint32 market, uint16 defaultLeverage) public {
        vm.startBroadcast();
        IHelloVaultV1_6(vault).setDefaultLeverage(market, defaultLeverage);
        vm.stopBroadcast();
    }
}
