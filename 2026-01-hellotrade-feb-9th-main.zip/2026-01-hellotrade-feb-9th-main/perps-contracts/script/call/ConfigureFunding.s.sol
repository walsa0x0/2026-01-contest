// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script} from "forge-std/Script.sol";
import {IHelloVaultV1_6} from "src/interfaces/IHelloVaultV1_6.sol";

contract ConfigureFunding is Script {
    function setUp() public {}

    function run(address vault, uint32 market, int32 fundingMax, int32 fundingMin, uint32 maxFundingInterval) public {
        vm.startBroadcast();
        IHelloVaultV1_6(vault).setFundingConfig(market, fundingMax, fundingMin, maxFundingInterval);
        vm.stopBroadcast();
    }
}
