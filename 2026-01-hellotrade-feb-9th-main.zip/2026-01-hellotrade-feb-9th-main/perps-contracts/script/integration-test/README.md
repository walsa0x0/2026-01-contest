# Integration Test Scripts

A chain of scripts for end-to-end integration testing of the HelloVault perpetuals trading system.

## Overview

These scripts create a complete test environment with:
- 16 markets configured
- 2 users (Alice and Bob) with margin deposited
- 16 positions created (15 incrementally, then 1 final with 16 price updates)

## Script Chain

| Script | Just Command | Description |
|--------|--------------|-------------|
| `01_Deploy.s.sol` | `just int-deploy` | Deploy USDC, Stork mock, and HelloVault contracts |
| `02_Configure.s.sol` | `just int-configure` | Configure 16 markets with permissive timestamp tolerances |
| `03_PrepareUsers.s.sol` | `just int-prepare-users` | Mint USDC and deposit margin for Alice and Bob |
| `04_Positions_1_4.s.sol` | `just int-positions-1-4` | Create positions 1-4 in markets 1-4 |
| `05_Positions_5_8.s.sol` | `just int-positions-5-8` | Create positions 5-8 in markets 5-8 |
| `06_Positions_9_12.s.sol` | `just int-positions-9-12` | Create positions 9-12 in markets 9-12 |
| `07_Positions_13_15.s.sol` | `just int-positions-13-15` | Create positions 13-15 in markets 13-15 |
| `08_Position16_WithPrices.s.sol` | `just int-position-16` | Create position 16 with full 16 price updates |

## Usage

### Step-by-Step Execution

```bash
# Start anvil in a separate terminal
anvil

# Step 1: Deploy contracts
just int-deploy

# Copy addresses from output, then:
# Step 2: Configure markets
just int-configure <VAULT_ADDRESS> <STORK_ADDRESS>

# Step 3: Prepare users
just int-prepare-users <USDC_ADDRESS> <VAULT_ADDRESS>

# Steps 4a-4d: Create positions 1-15
just int-positions-1-4 <VAULT_ADDRESS>
just int-positions-5-8 <VAULT_ADDRESS>
just int-positions-9-12 <VAULT_ADDRESS>
just int-positions-13-15 <VAULT_ADDRESS>

# Step 5: Create position 16 with price updates
just int-position-16 <VAULT_ADDRESS>
```

### Run All After Deploy

After deploying with `just int-deploy`, you can run all remaining steps:

```bash
just int-all <USDC_ADDRESS> <STORK_ADDRESS> <VAULT_ADDRESS>
```

### Custom RPC URL

Override the default RPC URL (http://127.0.0.1:8545):

```bash
INT_RPC_URL=http://your-rpc-url:8545 just int-deploy
```

## Key Design Decisions

### Unique Namespace for Keys
All private keys are derived deterministically using a unique namespace (`INTTEST_`) to avoid conflicts with normal test fixtures:
- `INTTEST_ADMIN`
- `INTTEST_RELAYER`
- `INTTEST_ALICE`
- `INTTEST_BOB`
- `INTTEST_STORK_SIGNER`
- `INTTEST_FEE_RECIPIENT`

### Permissive Timestamp Tolerances
Stork mock is configured with a 30-day valid time period to ensure price updates don't become stale during testing.

### Market Configuration
All 16 markets are configured identically with:
- Max leverage: 100x (10000)
- Default leverage: 1x (100)
- Price precision: 18 decimals
- Initial price: 1e18 (1 USDC equivalent)

### Position Structure
- Alice takes long positions (+1000 size)
- Bob takes short positions (-1000 size)
- Each position is in a different market
- Scripts 4a-4c create 4 positions each
- Script 4d creates 3 positions (total of 15)
- Script 5 creates the 16th position with full price updates

## Output

After running all scripts successfully:
- Alice has 16 long positions in markets 1-16
- Bob has 16 short positions in markets 1-16
- All markets have funding initialized
- The final fill includes 16 Stork price updates

## List All Integration Commands

```bash
just --list --unsorted | grep int-
```
