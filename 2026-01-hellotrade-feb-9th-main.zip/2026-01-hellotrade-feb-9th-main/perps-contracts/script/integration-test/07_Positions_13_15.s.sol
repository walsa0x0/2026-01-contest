// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {console} from "forge-std/Script.sol";

import {HelloVaultV1_6} from "src/HelloVaultV1_6.sol";
import {Order} from "src/lib/Order.sol";

import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

import {IntegrationTestBase} from "./IntegrationTestBase.sol";

/// @title CreatePositions13to15
/// @notice Script 4d: Create positions 13-15 in markets 13-15 for Alice (long) and Bob (short)
/// @dev Run with: just int-positions-13-15 <vault>
contract CreatePositions13to15 is IntegrationTestBase {
    function run(address vaultAddr, address alice_, address bob_, bytes32 aliceKey_, bytes32 bobKey_, bytes32 storkKey_)
        public
    {
        // Cast bytes32 keys to uint256 internally
        uint256 aliceKey = uint256(aliceKey_);
        uint256 bobKey = uint256(bobKey_);
        uint256 storkKey = uint256(storkKey_);

        console.log("=== Integration Test: Create Positions 13-15 ===");
        console.log("Vault:", vaultAddr);

        HelloVaultV1_6 vault = HelloVaultV1_6(vaultAddr);

        vm.startBroadcast();

        // Create positions in markets 13-15 (only 3 positions in this script)
        for (uint32 marketIndex = 12; marketIndex < 15; marketIndex++) {
            uint32 marketId = getMarketId(marketIndex);
            uint256 nonce = marketIndex + 1; // Nonces 13-15

            _openPosition(vault, vaultAddr, marketId, nonce, alice_, bob_, aliceKey, bobKey, storkKey);

            console.log("Opened position", marketIndex + 1, "in market", marketId);
        }

        vm.stopBroadcast();

        console.log("");
        console.log("=== Positions 13-15 Created ===");
        console.log("Alice has 15 long positions in markets 1-15");
        console.log("Bob has 15 short positions in markets 1-15");
        console.log("");
        console.log("Ready for final 16th position script!");
    }

    function _openPosition(
        HelloVaultV1_6 vault,
        address vaultAddr,
        uint32 marketId,
        uint256 nonce,
        address alice_,
        address bob_,
        uint256 aliceKey_,
        uint256 bobKey_,
        uint256 storkKey_
    ) internal {
        // Alice goes long, Bob goes short
        Order memory aliceOrder =
            Order({account: alice_, market: marketId, size: POSITION_SIZE, limitPrice: PRICE_WAD, nonce: nonce});

        Order memory bobOrder = Order({
            account: bob_,
            market: marketId,
            size: -POSITION_SIZE,
            limitPrice: 0, // Market order
            nonce: nonce
        });

        bytes memory aliceSig = signOrder(aliceKey_, aliceOrder, vaultAddr);
        bytes memory bobSig = signOrder(bobKey_, bobOrder, vaultAddr);

        // Create fresh price update for this market
        bytes32 storkId = getStorkInstrumentId(marketId);
        uint64 timestampNs = uint64(block.timestamp) * 1e9;
        int192 price = int192(int256(PRICE_WAD));

        StorkStructs.TemporalNumericValueInput[] memory priceUpdates = new StorkStructs.TemporalNumericValueInput[](1);
        priceUpdates[0] = createSignedPriceUpdate(storkKey_, storkId, price, timestampNs);

        uint256 trackingHead = vault.trackingHead() + 1;
        uint256 fillSize = uint256(POSITION_SIZE);

        vault.handleMatchedFill(priceUpdates, aliceOrder, aliceSig, bobOrder, bobSig, fillSize, trackingHead);
    }
}
