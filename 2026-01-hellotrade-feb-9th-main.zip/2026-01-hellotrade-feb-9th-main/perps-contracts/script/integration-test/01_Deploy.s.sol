// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {console} from "forge-std/Script.sol";

import {HelloVaultV1_6} from "src/HelloVaultV1_6.sol";
import {UsdcMockPermissionless} from "src/mocks/UsdcMockPermissionless.sol";
import {StorkMock} from "src/mocks/StorkMock.sol";

import {IntegrationTestBase} from "./IntegrationTestBase.sol";

/// @title DeployIntegrationTest
/// @notice Script 1: Deploy USDC, Stork mock, and HelloVault contracts
/// @dev Run with: just int-deploy
/// @dev Owner is also the relayer and fee recipient for these integration tests
contract DeployIntegrationTest is IntegrationTestBase {
    UsdcMockPermissionless public usdc;
    StorkMock public stork;
    HelloVaultV1_6 public vault;

    function run(address owner, bytes32 storkSignerKey_) public {
        // Cast bytes32 key to uint256 internally
        uint256 storkSignerKey = uint256(storkSignerKey_);

        console.log("=== Integration Test: Deploy Contracts ===");
        console.log("Owner (also relayer & fee recipient):", owner);

        address storkPublicKey = vm.addr(storkSignerKey);
        console.log("Stork public key:", storkPublicKey);

        vm.startBroadcast();

        // 1. Deploy USDC Mock
        usdc = new UsdcMockPermissionless();
        console.log("Deployed UsdcMockPermissionless at:", address(usdc));

        // 2. Deploy Stork Mock with permissive time tolerance
        stork = new StorkMock();
        // Initialize with permissive settings: 30 days tolerance, 0 fee
        stork.initialize(storkPublicKey, PERMISSIVE_VALID_TIME_PERIOD, 0);
        console.log("Deployed StorkMock at:", address(stork));
        console.log("  - Valid time period:", PERMISSIVE_VALID_TIME_PERIOD, "seconds");

        // 3. Deploy HelloVault (owner is also relayer)
        vault = new HelloVaultV1_6();
        vault.initialize(owner, owner, address(usdc), address(stork));
        console.log("Deployed HelloVaultV1_6 at:", address(vault));

        // 4. Set fee recipient (owner is also fee recipient)
        vault.setFeeRecipient(owner);
        console.log("Fee recipient set to:", owner);

        vm.stopBroadcast();

        // Output deployment summary for next script
        console.log("");
        console.log("=== Deployment Complete ===");
        console.log("  USDC_ADDRESS=%s", vm.toString(address(usdc)));
        console.log("  STORK_ADDRESS=%s", vm.toString(address(stork)));
        console.log("  VAULT_ADDRESS=%s", vm.toString(address(vault)));
    }
}
