// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {Test} from "forge-std/Test.sol";

import {Order} from "src/lib/Order.sol";

import {UsdcMockPermissionless} from "src/mocks/UsdcMockPermissionless.sol";

import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";
import {MessageHashUtils} from "@openzeppelin-contracts/utils/cryptography/MessageHashUtils.sol";

/// @title IntegrationTestBase
/// @notice Shared constants, utilities and signing helpers for integration test scripts
/// @dev Uses a unique namespace (INTTEST) for keys to avoid conflicts with normal tests
abstract contract IntegrationTestBase is Script, Test {
    // =============================================================
    //                           CONSTANTS
    // =============================================================

    uint256 constant NUM_MARKETS = 16;
    uint256 constant USDC_DECIMALS = 6;
    uint256 constant PRICE_WAD = 1e18;

    // Market configuration defaults
    uint16 constant MAX_LEVERAGE = 10000; // 100x
    uint16 constant DEFAULT_LEVERAGE = 100; // 1x
    uint8 constant PRICE_PRECISION = 18;
    uint8 constant BASE_PRECISION = 2;
    uint8 constant QUOTE_PRECISION = 6;
    int32 constant FUNDING_MAX = 100_000_000;
    int32 constant FUNDING_MIN = -100_000_000;
    uint32 constant MIN_FUNDING_INTERVAL = 1;

    // Permissive timestamp tolerance (30 days in seconds)
    uint256 constant PERMISSIVE_VALID_TIME_PERIOD = 30 days;

    // Funding rate index initial value
    int256 constant FUNDING_RATE_IDX0 = 10_000_000;
    int256 constant FUNDING_PRICE_IDX0 = 1e18;

    // Position size for each trade
    int256 constant POSITION_SIZE = 1_000;

    // Margin amount per user (1M USDC)
    uint256 constant MARGIN_AMOUNT = 1_000_000 * 10 ** USDC_DECIMALS;

    // =============================================================
    //                        KEY DERIVATION
    // =============================================================

    /// @notice Derive deterministic private keys using unique namespace
    /// @dev Using INTTEST_ prefix to avoid conflicts with normal test keys
    function _deriveKey(string memory name) internal pure returns (uint256) {
        return uint256(keccak256(abi.encodePacked("INTTEST_", name)));
    }

    function adminKey() internal pure returns (uint256) {
        return _deriveKey("ADMIN");
    }

    function relayerKey() internal pure returns (uint256) {
        return _deriveKey("RELAYER");
    }

    function aliceKey() internal pure returns (uint256) {
        return _deriveKey("ALICE");
    }

    function bobKey() internal pure returns (uint256) {
        return _deriveKey("BOB");
    }

    function storkSignerKey() internal pure returns (uint256) {
        return _deriveKey("STORK_SIGNER");
    }

    function feeRecipientKey() internal pure returns (uint256) {
        return _deriveKey("FEE_RECIPIENT");
    }

    // =============================================================
    //                      ADDRESS HELPERS
    // =============================================================

    function admin() internal view returns (address) {
        return vm.addr(adminKey());
    }

    function relayer() internal view returns (address) {
        return vm.addr(relayerKey());
    }

    function alice() internal view returns (address) {
        return vm.addr(aliceKey());
    }

    function bob() internal view returns (address) {
        return vm.addr(bobKey());
    }

    function storkSigner() internal view returns (address) {
        return vm.addr(storkSignerKey());
    }

    function feeRecipient() internal view returns (address) {
        return vm.addr(feeRecipientKey());
    }

    // =============================================================
    //                     MARKET ID HELPERS
    // =============================================================

    /// @notice Get market ID (1-indexed)
    function getMarketId(uint256 index) internal pure returns (uint32) {
        require(index < NUM_MARKETS, "Market index out of bounds");
        return uint32(index + 1);
    }

    /// @notice Get stork instrument ID for a market
    /// @dev Creates mostly-full bytes32 values by subtracting from uint256 max
    function getStorkInstrumentId(uint32 marketId) internal pure returns (bytes32) {
        return bytes32(type(uint256).max - (marketId - 1));
    }

    // =============================================================
    //                     SIGNING UTILITIES
    // =============================================================

    bytes32 private constant EIP712_DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");

    bytes32 private constant PERMIT_TYPEHASH =
        keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)");

    /// @notice Build domain separator for HelloVault
    function _buildDomainSeparator(address vaultAddr) internal view returns (bytes32) {
        return keccak256(
            abi.encode(
                EIP712_DOMAIN_TYPEHASH, keccak256(bytes("HelloVault")), keccak256(bytes("1")), block.chainid, vaultAddr
            )
        );
    }

    /// @notice Build domain separator for USDC mock (for permit)
    /// @dev Uses UsdcMockPermissionless which has EIP712 name "UsdcMockPermissionless"
    function _buildUsdcDomainSeparator(address usdcAddr) internal view returns (bytes32) {
        return keccak256(
            abi.encode(
                EIP712_DOMAIN_TYPEHASH,
                keccak256(bytes("UsdcMockPermissionless")),
                keccak256(bytes("1")),
                block.chainid,
                usdcAddr
            )
        );
    }

    /// @notice Sign an order for HelloVault
    function signOrder(uint256 privateKey, Order memory order, address vaultAddr)
        internal
        view
        returns (bytes memory signature)
    {
        bytes32 structHash = _buildOrderHash(order.account, order.market, order.size, order.limitPrice, order.nonce);
        bytes32 domainSeparator = _buildDomainSeparator(vaultAddr);
        bytes32 digest = MessageHashUtils.toTypedDataHash(domainSeparator, structHash);

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(privateKey, digest);
        signature = abi.encodePacked(r, s, v);
    }

    /// @notice Build order struct hash
    function _buildOrderHash(address account, uint32 market, int256 size, uint256 limitPrice, uint256 nonce)
        internal
        pure
        returns (bytes32)
    {
        bytes32 ORDER_TYPEHASH =
            keccak256("Order(address account,uint32 market,int256 size,uint256 limitPrice,uint256 nonce)");
        return keccak256(abi.encode(ORDER_TYPEHASH, account, market, size, limitPrice, nonce));
    }

    /// @notice Sign USDC permit
    function signPermit(uint256 privateKey, address usdcAddr, address spender, uint256 value, uint256 deadline)
        internal
        view
        returns (bytes memory)
    {
        address owner = vm.addr(privateKey);
        uint256 nonce = UsdcMockPermissionless(usdcAddr).nonces(owner);

        bytes32 structHash = keccak256(abi.encode(PERMIT_TYPEHASH, owner, spender, value, nonce, deadline));
        bytes32 domainSeparator = _buildUsdcDomainSeparator(usdcAddr);
        bytes32 digest = MessageHashUtils.toTypedDataHash(domainSeparator, structHash);

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(privateKey, digest);
        return abi.encodePacked(r, s, v);
    }

    // =============================================================
    //                      STORK UTILITIES
    // =============================================================

    /// @notice Sign a Stork price update payload
    function signStorkPayload(
        uint256 privateKey,
        bytes32 id,
        uint256 recvTime,
        int256 quantizedValue,
        bytes32 publisherMerkleRoot,
        bytes32 valueComputeAlgHash
    ) internal view returns (bytes32 r, bytes32 s, uint8 v) {
        address storkPubKey = vm.addr(privateKey);

        bytes32 msgHash = keccak256(
            abi.encodePacked(storkPubKey, id, recvTime, quantizedValue, publisherMerkleRoot, valueComputeAlgHash)
        );
        bytes32 signedMessageHash = MessageHashUtils.toEthSignedMessageHash(msgHash);

        (v, r, s) = vm.sign(privateKey, signedMessageHash);
    }

    /// @notice Create a signed temporal numeric value input
    function createSignedPriceUpdate(uint256 privateKey, bytes32 id, int192 price, uint64 timestampNs)
        internal
        view
        returns (StorkStructs.TemporalNumericValueInput memory)
    {
        bytes32 publisherMerkleRoot = bytes32(uint256(1));
        bytes32 valueComputeAlgHash = bytes32(uint256(1));

        (bytes32 r, bytes32 s, uint8 v) =
            signStorkPayload(privateKey, id, timestampNs, int256(price), publisherMerkleRoot, valueComputeAlgHash);

        return StorkStructs.TemporalNumericValueInput({
            temporalNumericValue: StorkStructs.TemporalNumericValue({timestampNs: timestampNs, quantizedValue: price}),
            id: id,
            publisherMerkleRoot: publisherMerkleRoot,
            valueComputeAlgHash: valueComputeAlgHash,
            r: r,
            s: s,
            v: v
        });
    }

    /// @notice Create price updates for all 16 markets
    function createAllPriceUpdates(uint256 privateKey)
        internal
        view
        returns (StorkStructs.TemporalNumericValueInput[] memory)
    {
        StorkStructs.TemporalNumericValueInput[] memory prices =
            new StorkStructs.TemporalNumericValueInput[](NUM_MARKETS);

        uint64 timestampNs = uint64(block.timestamp) * 1e9;
        int192 basePrice = int192(int256(PRICE_WAD));

        for (uint256 i = 0; i < NUM_MARKETS; i++) {
            bytes32 storkId = getStorkInstrumentId(getMarketId(i));
            // Each price is slightly different to ensure uniqueness
            int192 price = basePrice + int192(int256(i));
            prices[i] = createSignedPriceUpdate(privateKey, storkId, price, timestampNs);
        }

        return prices;
    }

    // =============================================================
    //                      LOGGING UTILITIES
    // =============================================================

    function logAddresses(address usdc, address stork, address vault) internal pure {
        console.log("=== Deployed Addresses ===");
        console.log("USDC:", usdc);
        console.log("Stork:", stork);
        console.log("Vault:", vault);
        console.log("=== Derived Addresses ===");
    }

    function logDerivedAddresses() internal view {
        console.log("Admin:", admin());
        console.log("Relayer:", relayer());
        console.log("Alice:", alice());
        console.log("Bob:", bob());
        console.log("Fee Recipient:", feeRecipient());
        console.log("Stork Signer:", storkSigner());
    }
}

