// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {console} from "forge-std/Script.sol";

import {HelloVaultV1_6} from "src/HelloVaultV1_6.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {StorkMock} from "src/mocks/StorkMock.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

import {IntegrationTestBase} from "./IntegrationTestBase.sol";

/// @title ConfigureIntegrationTest
/// @notice Script 2: Configure 16 markets in HelloVault and Stork
/// @dev Run with: just int-configure <vault> <stork> <stork_signer_key>
contract ConfigureIntegrationTest is IntegrationTestBase {
    int192 constant STORK_PRICE = 111_111_111_111_111_111_111_111_110;

    function run(address vaultAddr, address storkAddr, bytes32 storkSignerKey_) public {
        // Cast bytes32 key to uint256 internally
        uint256 storkSignerKey = uint256(storkSignerKey_);

        console.log("=== Integration Test: Configure Contracts ===");
        console.log("Vault:", vaultAddr);
        console.log("Stork:", storkAddr);

        HelloVaultV1_6 vault = HelloVaultV1_6(vaultAddr);
        StorkMock stork = StorkMock(storkAddr);

        vm.startBroadcast();

        // Set permissive validity period for local price checks (30 days in nanoseconds)
        vault.setValidTimePeriodNs(PERMISSIVE_VALID_TIME_PERIOD * 1e9);
        console.log("Set validTimePeriodNs:", PERMISSIVE_VALID_TIME_PERIOD * 1e9);

        for (uint32 i = 1; i <= NUM_MARKETS; i++) {
            bytes32 storkId = getStorkInstrumentId(i);

            // Set market configuration
            vault.setMarketConfig(
                i,
                MarketConfig({
                    maxLeverage: MAX_LEVERAGE,
                    defaultLeverage: DEFAULT_LEVERAGE,
                    pricePrecision: PRICE_PRECISION,
                    basePrecision: BASE_PRECISION,
                    quotePrecision: QUOTE_PRECISION,
                    fundingMax: FUNDING_MAX,
                    fundingMin: FUNDING_MIN,
                    minFundingInterval: MIN_FUNDING_INTERVAL
                })
            );

            // Link market to Stork instrument ID
            vault.setMarketStorkId(i, storkId);
            vault.setMarketHelloStorkId(i, storkId);

            // Set initial price in Stork mock using signed update
            _setStorkPrice(stork, storkSignerKey, storkId, STORK_PRICE);

            console.log("Configured market", i, "with storkId:", vm.toString(storkId));
        }

        // Initialize funding for all markets
        for (uint32 i = 1; i <= NUM_MARKETS; i++) {
            vault.updateFundingInstant(i, FUNDING_RATE_IDX0, FUNDING_PRICE_IDX0, 0);
        }

        vm.stopBroadcast();

        console.log("");
        console.log("=== Configuration Complete ===");
        console.log("Configured", NUM_MARKETS, "markets with:");
        console.log("  - Max leverage:", MAX_LEVERAGE);
        console.log("  - Default leverage:", DEFAULT_LEVERAGE);
        console.log("  - Price precision:", PRICE_PRECISION);
        console.log("  - Initial price: 1e18 (1 USDC)");
    }

    /// @notice Set a price in StorkMock using a signed update
    function _setStorkPrice(StorkMock stork, uint256 signerKey, bytes32 id, int192 price) internal {
        uint64 timestampNs = uint64(block.timestamp) * 1e9;

        StorkStructs.TemporalNumericValueInput memory input = createSignedPriceUpdate(signerKey, id, price, timestampNs);

        StorkStructs.TemporalNumericValueInput[] memory inputs = new StorkStructs.TemporalNumericValueInput[](1);
        inputs[0] = input;

        stork.updateTemporalNumericValuesV1(inputs);
    }
}
