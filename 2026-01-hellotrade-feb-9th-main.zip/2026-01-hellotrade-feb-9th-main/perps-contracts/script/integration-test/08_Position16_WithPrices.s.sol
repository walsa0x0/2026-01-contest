// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {console} from "forge-std/Script.sol";

import {HelloVaultV1_6} from "src/HelloVaultV1_6.sol";
import {Order} from "src/lib/Order.sol";

import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

import {IntegrationTestBase} from "./IntegrationTestBase.sol";

/// @title CreatePosition16WithPriceUpdates
/// @notice Script 5: Create the 16th position in market 16 with a full complement of 16 price updates
/// @dev Run with: just int-position-16 <vault>
contract CreatePosition16WithPriceUpdates is IntegrationTestBase {
    function run(address vaultAddr, address alice_, address bob_, bytes32 aliceKey_, bytes32 bobKey_, bytes32 storkKey_)
        public
    {
        // Cast bytes32 keys to uint256 internally
        uint256 aliceKey = uint256(aliceKey_);
        uint256 bobKey = uint256(bobKey_);
        uint256 storkKey = uint256(storkKey_);

        console.log("=== Integration Test: Create Position 16 with 16 Price Updates ===");
        console.log("Vault:", vaultAddr);

        HelloVaultV1_6 vault = HelloVaultV1_6(vaultAddr);

        vm.startBroadcast();

        // Market 16 (index 15)
        uint32 marketId = getMarketId(15); // Market ID 16
        uint256 nonce = 16;

        // Create price updates for all 16 markets
        StorkStructs.TemporalNumericValueInput[] memory priceUpdates = _createAllPriceUpdates(storkKey);

        console.log("Created", priceUpdates.length, "price updates");

        // Alice goes long, Bob goes short in market 16
        Order memory aliceOrder = Order({
            account: alice_,
            market: marketId,
            size: POSITION_SIZE,
            limitPrice: PRICE_WAD + 100, // Slightly above to ensure fill
            nonce: nonce
        });

        Order memory bobOrder = Order({
            account: bob_,
            market: marketId,
            size: -POSITION_SIZE,
            limitPrice: 0, // Market order
            nonce: nonce
        });

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder, vaultAddr);
        bytes memory bobSig = signOrder(bobKey, bobOrder, vaultAddr);

        uint256 trackingHead = vault.trackingHead() + 1;
        uint256 fillSize = uint256(POSITION_SIZE);

        // Execute the fill with all 16 price updates
        vault.handleMatchedFill(priceUpdates, aliceOrder, aliceSig, bobOrder, bobSig, fillSize, trackingHead);

        console.log("Opened position 16 in market", marketId, "with 16 price updates");

        vm.stopBroadcast();

        console.log("");
        console.log("=== Position 16 Created ===");
        console.log("Alice has 16 long positions in markets 1-16");
        console.log("Bob has 16 short positions in markets 1-16");
        console.log("");
        console.log("=== Integration Test Complete! ===");
        console.log("Total positions created: 16 for each user");
        console.log("Total markets used: 16");
        console.log("Final fill included 16 price updates");
    }

    /// @notice Create price updates for all 16 markets using the provided Stork signer key
    function _createAllPriceUpdates(uint256 storkKey_)
        internal
        view
        returns (StorkStructs.TemporalNumericValueInput[] memory)
    {
        StorkStructs.TemporalNumericValueInput[] memory prices =
            new StorkStructs.TemporalNumericValueInput[](NUM_MARKETS);

        uint64 timestampNs = uint64(block.timestamp) * 1e9;
        int192 basePrice = int192(int256(PRICE_WAD));

        for (uint256 i = 0; i < NUM_MARKETS; i++) {
            bytes32 storkId = getStorkInstrumentId(getMarketId(i));
            // Each price is slightly different
            int192 price = basePrice + int192(int256(i + 1));

            prices[i] = _createSignedPriceUpdate(storkKey_, storkId, price, timestampNs);
        }

        return prices;
    }

    /// @notice Create a signed temporal numeric value input for Stork
    function _createSignedPriceUpdate(uint256 storkKey_, bytes32 id, int192 price, uint64 timestampNs)
        internal
        view
        returns (StorkStructs.TemporalNumericValueInput memory)
    {
        bytes32 publisherMerkleRoot = bytes32(uint256(1));
        bytes32 valueComputeAlgHash = bytes32(uint256(1));

        (bytes32 r, bytes32 s, uint8 v) =
            _signStorkPayload(storkKey_, id, timestampNs, int256(price), publisherMerkleRoot, valueComputeAlgHash);

        return StorkStructs.TemporalNumericValueInput({
            temporalNumericValue: StorkStructs.TemporalNumericValue({timestampNs: timestampNs, quantizedValue: price}),
            id: id,
            publisherMerkleRoot: publisherMerkleRoot,
            valueComputeAlgHash: valueComputeAlgHash,
            r: r,
            s: s,
            v: v
        });
    }

    /// @notice Sign a Stork price update payload
    function _signStorkPayload(
        uint256 privateKey,
        bytes32 id,
        uint256 recvTime,
        int256 quantizedValue,
        bytes32 publisherMerkleRoot,
        bytes32 valueComputeAlgHash
    ) internal view returns (bytes32 r, bytes32 s, uint8 v) {
        address storkPubKey = vm.addr(privateKey);

        bytes32 msgHash = keccak256(
            abi.encodePacked(storkPubKey, id, recvTime, quantizedValue, publisherMerkleRoot, valueComputeAlgHash)
        );

        bytes32 signedMessageHash = keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", msgHash));

        (v, r, s) = vm.sign(privateKey, signedMessageHash);
    }
}
