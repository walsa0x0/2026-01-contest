// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";

interface IMarketConfig {
    function marketConfig(uint256 marketId) external view returns (MarketConfig memory);
}

contract GetMarketConfig is Script {
    function setUp() public {}

    function run(address vault, uint32 market) public {
        vm.startBroadcast();
        IMarketConfig helloVault = IMarketConfig(vault);
        MarketConfig memory config = helloVault.marketConfig(market);
        console.log("maxLeverage:", config.maxLeverage);
        console.log("defaultLeverage:", config.defaultLeverage);
        console.log("pricePrecision:", config.pricePrecision);
        console.log("basePrecision:", config.basePrecision);
        console.log("quotePrecision:", config.quotePrecision);
        console.log("fundingMax:", config.fundingMax);
        console.log("fundingMin:", config.fundingMin);
        console.log("minFundingInterval:", config.minFundingInterval);
        vm.stopBroadcast();
    }
}
