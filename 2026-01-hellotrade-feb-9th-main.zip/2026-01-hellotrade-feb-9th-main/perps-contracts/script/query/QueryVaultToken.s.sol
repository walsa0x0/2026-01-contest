// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {IHelloVaultV1_6} from "src/interfaces/IHelloVaultV1_6.sol";

contract QueryVaultToken is Script {
    function setUp() public {}

    function run(address vault) public {
        vm.startBroadcast();
        IHelloVaultV1_6 helloVault = IHelloVaultV1_6(vault);
        console.log("Vault token:", helloVault.quoteToken());
        vm.stopBroadcast();
    }
}
