// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script} from "forge-std/Script.sol";
import {Options, Upgrades} from "openzeppelin-foundry-upgrades/Upgrades.sol";

contract UpgradeVaultToV1_6 is Script {
    function run(address vault) public {
        vm.startBroadcast();
        Options memory opts;
        opts.referenceContract = "HelloVaultEmpty.sol";
        Upgrades.validateUpgrade("HelloVaultV1_6.sol", opts);
        Upgrades.upgradeProxy(vault, "HelloVaultV1_6.sol", "");
        vm.stopBroadcast();
    }
}
