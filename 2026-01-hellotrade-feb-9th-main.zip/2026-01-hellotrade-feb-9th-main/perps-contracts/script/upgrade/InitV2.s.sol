// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script} from "forge-std/Script.sol";

interface Reinit {
    function intializeV2(address stork) external;
}

contract InitVaultV2 is Script {
    function run(address vault, address stork) public {
        vm.startBroadcast();
        Reinit(vault).intializeV2(stork);
        vm.stopBroadcast();
    }
}
