// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {Options, Upgrades} from "openzeppelin-foundry-upgrades/Upgrades.sol";

interface IReinit {
    function initializeV1_2() external;
}

contract UpgradeUsdcMock is Script {
    function run(address usdc) public {
        vm.startBroadcast();
        Options memory opts;
        opts.referenceContract = "UsdcMockUpgradeableV1_1.sol";
        Upgrades.validateUpgrade("UsdcMockUpgradeableV1_2.sol", opts);
        Upgrades.upgradeProxy(usdc, "UsdcMockUpgradeableV1_2.sol", "");
        IReinit(usdc).initializeV1_2();
        vm.stopBroadcast();
        console.log("USDC Upgrade complete!");
    }
}
