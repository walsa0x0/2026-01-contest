// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {IHelloVaultV1_6} from "src/interfaces/IHelloVaultV1_6.sol";
import {DeployUUPSProtocolBase} from "./bases/DeployUUPSProtocolBase.sol";

contract DeployUUPSHelloVault is DeployUUPSProtocolBase, Script {
    function setUp() public {}

    function run(address owner, address relayer, address token, address stork) public {
        console.log("Deploying HelloVault...");
        vm.startBroadcast();
        deploy(owner, relayer, token, stork);
        console.log("Proxy deployed to:", proxy);
        address token_ = IHelloVaultV1_6(proxy).quoteToken();
        console.log("Token check", token_);
        vm.stopBroadcast();
    }
}
