// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {SimpleStorage} from "../../src/mocks/SimpleStorage.sol";

contract DeploySimpleStorage is Script {
    function setUp() public {}

    function run() public {
        console.log("Deploying SimpleStorage...");
        vm.startBroadcast();
        SimpleStorage simpleStorage = new SimpleStorage();
        vm.stopBroadcast();
    }
}
