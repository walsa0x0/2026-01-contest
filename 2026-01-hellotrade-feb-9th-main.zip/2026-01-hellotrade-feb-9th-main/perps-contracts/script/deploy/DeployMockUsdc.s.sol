// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {UsdcMock} from "../../src/mocks/UsdcMock.sol";

contract DeployMockUsdc is Script {
    uint256 constant ONE_MILLION = 1_000_000 * 10 ** 6; // 1 million USDC in 6 decimals

    function setUp() public {}

    function run() public {
        console.log("Deploying HelloVault...");
        vm.startBroadcast();
        UsdcMock usdcMock = new UsdcMock();
        usdcMock.mint(msg.sender, ONE_MILLION);
        vm.stopBroadcast();
    }
}
