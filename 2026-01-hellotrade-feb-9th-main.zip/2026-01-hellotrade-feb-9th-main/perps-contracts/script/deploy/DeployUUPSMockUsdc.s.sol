// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Script, console} from "forge-std/Script.sol";
import {UsdcMockUpgradeable} from "src/mocks/UsdcMockUpgradeable.sol";
import {Upgrades} from "openzeppelin-foundry-upgrades/Upgrades.sol";

import {IERC20Metadata} from "@openzeppelin-contracts/token/ERC20/extensions/IERC20Metadata.sol";

contract DeployUsdcMockUpgradeable is Script {
    address public proxy_;

    function setUp() public {}

    function run(address owner) public {
        console.log("Deploying USDC proxy...");
        vm.startBroadcast();
        deploy(owner);
        console.log("Proxy deployed to:", proxy_);
        uint8 decimals = IERC20Metadata(proxy_).decimals();
        console.log("Decimals check", decimals);
        vm.stopBroadcast();
    }

    function deploy(address owner) public {
        proxy_ = Upgrades.deployUUPSProxy(
            "UsdcMockUpgradeable.sol", abi.encodeCall(UsdcMockUpgradeable.initialize, (owner))
        );
    }
}
