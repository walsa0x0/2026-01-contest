// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {HelloVaultV1_6} from "src/HelloVaultV1_6.sol";
import {Upgrades} from "openzeppelin-foundry-upgrades/Upgrades.sol";

contract DeployUUPSProtocolBase {
    address public proxy;

    function deploy(address owner, address relayer, address token, address stork) public {
        proxy = Upgrades.deployUUPSProxy(
            "HelloVaultV1_6.sol", abi.encodeCall(HelloVaultV1_6.initialize, (owner, relayer, token, stork))
        );
    }
}
