## Documentation

Core solidity contracts for Hello using Foundry + Soldeer.

## Installation

Install rustup if not already and the latest stable version of Rust:
```sh
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

Update rust and install justfile & foundry:
```sh
rustup update stable
cargo install just
curl -L https://foundry.paradigm.xyz | bash
```

Restart your terminal or source your profile.

Then run foundryup:
```sh
foundryup
```

Enter the project directory and install dependencies:
```sh
forge soldeer install
```

## Usage

### Build

```sh
forge build
```

### Test

```sh
forge test
```

### Format

```sh
forge fmt
```

### Gas Snapshots

```sh
forge snapshot
```

### Anvil

```sh
anvil
```

### Deploy

Copy .env.example to .env and fill in the required values for various RPC URLs.

```sh
cp .env.example .env
```

### Local Deploymnet

Start an anvil instance:
```sh
anvil
```

Deploy contracts in a separate terminal using the default anvil key:
```sh
forge script script/deploy/Vault.Deploy.s.sol --broadcast --rpc-url anvil --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --sig "run(address)" ${TOKEN_ADDRESS} 
```


### Testnet Deployment

The contained justfile expects a foundry keystore to be present for testnet deployments.

```sh
cast wallet import --private-key <your_private_key> testnet-deployer 
```

The above will create a keystore file with the name `testnet-deployer` in the `~/.foundry/keystores` directory. The preconfigured justfile deployment script expects this file to be present when deploying to testnets.

To deploy:
```sh
forge script script/deploy/Vault.Deploy.s.sol --slow --broadcast --rpc-url megaeth_testnet --account testnet-deployer --sig "run(address)" ${TOKEN_ADDRESS}
```

Or its justfile equivalent to pull the RPC URL from the environment:
```sh
just deploy-testnet ${TOKEN_ADDRESS}
```
