// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

interface IUsdcMock {
    function decimals() external pure returns (uint8);
    function mint(address to, uint256 value) external;
    function permitTypehash() external pure returns (bytes32);
    function hashTypedDataV4(bytes32 structHash) external view returns (bytes32);
    function nonces(address owner) external view returns (uint256);
}
