// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {ERC20} from "@openzeppelin-contracts/token/ERC20/ERC20.sol";

error NotOwner();

contract WethMock is ERC20 {
    address owner;

    constructor() ERC20("WethMock", "WETHM") {
        owner = msg.sender;
    }

    function mint(address to, uint256 value) public {
        if (owner != msg.sender) {
            revert NotOwner();
        }
        _mint(to, value);
    }
}
