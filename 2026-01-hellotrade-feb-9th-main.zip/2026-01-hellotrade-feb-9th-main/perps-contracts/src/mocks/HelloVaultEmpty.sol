// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

// Intentionally left empty for upgrade overrides while iterating smart contract integration with relayer.
contract HelloVaultEmpty {}
