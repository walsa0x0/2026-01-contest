// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

event StorageSet(uint256 value);

contract SimpleStorage {
    uint256 public slot;
    uint256 public slot2;

    constructor() {
        slot = 101;
    }

    function setStorage(uint256 v) external {
        slot = v;
        emit StorageSet(v);
    }

    function setStorage2(uint256 v) external {
        slot2 = v;
        emit StorageSet(v);
    }

    function setAndClearStorage(uint256 v) external {
        slot = v;
        slot2 = 0;
        emit StorageSet(v);
    }
}
