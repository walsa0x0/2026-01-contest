// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {ERC20} from "@openzeppelin-contracts/token/ERC20/ERC20.sol";
import {ERC20Permit} from "@openzeppelin-contracts/token/ERC20/extensions/ERC20Permit.sol";

import {IUsdcMock} from "src/mocks/interface/IUsdcMock.sol";

error NotOwner();

contract UsdcMock is ERC20, ERC20Permit, IUsdcMock {
    address public owner;

    constructor() ERC20("UsdcMock", "USDC") ERC20Permit("UsdcMock") {
        owner = msg.sender;
    }

    function decimals() public pure override(ERC20, IUsdcMock) returns (uint8) {
        return 6;
    }

    function mint(address to, uint256 value) public {
        if (owner != msg.sender) {
            revert NotOwner();
        }
        _mint(to, value);
    }

    function permitTypehash() public pure returns (bytes32) {
        return keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)");
    }

    function hashTypedDataV4(bytes32 structHash) public view returns (bytes32) {
        return _hashTypedDataV4(structHash);
    }

    function nonces(address owner_) public view override(ERC20Permit, IUsdcMock) returns (uint256) {
        return super.nonces(owner_);
    }
}
