// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {IStork} from "@storknetwork/stork-evm-sdk/IStork.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";
import {StorkErrors} from "@storknetwork/stork-evm-sdk/StorkErrors.sol";
import {StorkGetters} from "@storknetwork/stork-evm/stork/contracts/StorkGetters.sol";
import {StorkSetters} from "@storknetwork/stork-evm/stork/contracts/StorkSetters.sol";
import {StorkVerify} from "@storknetwork/stork-evm/stork/contracts/StorkVerify.sol";

import {ECDSA} from "@openzeppelin-contracts/utils/cryptography/ECDSA.sol";
import {MessageHashUtils} from "@openzeppelin-contracts/utils/cryptography/MessageHashUtils.sol";

/// @title StorkMock
/// @notice Deployable Stork mock contract for integration testing
/// @dev Does NOT inherit from forge-std Test, so it can be deployed to real chains
contract StorkMock is StorkGetters, StorkSetters, StorkVerify {
    using ECDSA for bytes32;
    using MessageHashUtils for bytes32;

    function initialize(address storkPublicKey, uint256 validTimePeriodSeconds_, uint256 singleUpdateFeeInWei_) public {
        StorkSetters.setValidTimePeriodSeconds(validTimePeriodSeconds_);
        StorkSetters.setSingleUpdateFeeInWei(singleUpdateFeeInWei_);
        StorkSetters.setStorkPublicKey(storkPublicKey);
    }

    function updateTemporalNumericValuesV1(StorkStructs.TemporalNumericValueInput[] calldata updateData)
        public
        payable
    {
        uint16 numUpdates = 0;
        for (uint256 i = 0; i < updateData.length; i++) {
            bool verified = verifyStorkSignatureV1(
                storkPublicKey(),
                updateData[i].id,
                updateData[i].temporalNumericValue.timestampNs,
                updateData[i].temporalNumericValue.quantizedValue,
                updateData[i].publisherMerkleRoot,
                updateData[i].valueComputeAlgHash,
                updateData[i].r,
                updateData[i].s,
                updateData[i].v
            );
            if (!verified) revert StorkErrors.InvalidSignature();
            bool updated = updateLatestValueIfNecessary(updateData[i]);
            if (updated) {
                numUpdates++;
            }
        }
        if (numUpdates == 0) revert StorkErrors.NoFreshUpdate();

        uint256 requiredFee = _getTotalFee(numUpdates);
        if (msg.value < requiredFee) revert StorkErrors.InsufficientFee();
    }

    function getUpdateFeeV1(StorkStructs.TemporalNumericValueInput[] calldata updateData)
        public
        view
        returns (uint256 feeAmount)
    {
        return _getTotalFee(updateData.length);
    }

    function getTemporalNumericValueV1(bytes32 id)
        public
        view
        returns (StorkStructs.TemporalNumericValue memory value)
    {
        StorkStructs.TemporalNumericValue memory numericValue = latestCanonicalTemporalNumericValue(id);
        if (numericValue.timestampNs == 0) {
            revert StorkErrors.NotFound();
        }

        if (block.timestamp - (numericValue.timestampNs / 1000000000) > validTimePeriodSeconds()) {
            revert StorkErrors.StaleValue();
        }
        return numericValue;
    }

    function getTemporalNumericValueUnsafeV1(bytes32 id)
        public
        view
        returns (StorkStructs.TemporalNumericValue memory value)
    {
        StorkStructs.TemporalNumericValue memory numericValue = latestCanonicalTemporalNumericValue(id);
        if (numericValue.timestampNs == 0) {
            revert StorkErrors.NotFound();
        }

        return numericValue;
    }

    function getTemporalNumericValuesUnsafeV1(bytes32[] calldata ids)
        public
        view
        returns (StorkStructs.TemporalNumericValue[] memory values)
    {
        values = new StorkStructs.TemporalNumericValue[](ids.length);
        for (uint256 i = 0; i < ids.length; i++) {
            values[i] = latestCanonicalTemporalNumericValue(ids[i]);
            if (values[i].timestampNs == 0) {
                revert StorkErrors.NotFound();
            }
        }
        return values;
    }

    function verifyPublisherSignaturesV1(StorkStructs.PublisherSignature[] calldata signatures, bytes32 merkleRoot)
        public
        pure
        returns (bool)
    {
        bytes32[] memory hashes = new bytes32[](signatures.length);

        for (uint256 i = 0; i < signatures.length; i++) {
            if (!verifyPublisherSignatureV1(
                    signatures[i].pubKey,
                    signatures[i].assetPairId,
                    signatures[i].timestamp,
                    signatures[i].quantizedValue,
                    signatures[i].r,
                    signatures[i].s,
                    signatures[i].v
                )) return false;
            bytes32 computed = getPublisherMessageHash(
                signatures[i].pubKey, signatures[i].assetPairId, signatures[i].timestamp, signatures[i].quantizedValue
            );
            hashes[i] = computed;
        }
        return verifyMerkleRoot(hashes, merkleRoot);
    }

    function version() public pure returns (string memory) {
        return "1.0.4";
    }

    function _getTotalFee(uint256 totalNumUpdates) private view returns (uint256 requiredFee) {
        return totalNumUpdates * singleUpdateFeeInWei();
    }

    function updateValidTimePeriodSeconds(uint256 validTimePeriodSeconds_) public {
        setValidTimePeriodSeconds(validTimePeriodSeconds_);
    }

    function updateSingleUpdateFeeInWei(uint256 singleUpdateFeeInWei_) public {
        setSingleUpdateFeeInWei(singleUpdateFeeInWei_);
    }

    function updateStorkPublicKey(address storkPublicKey_) public {
        setStorkPublicKey(storkPublicKey_);
    }
}

