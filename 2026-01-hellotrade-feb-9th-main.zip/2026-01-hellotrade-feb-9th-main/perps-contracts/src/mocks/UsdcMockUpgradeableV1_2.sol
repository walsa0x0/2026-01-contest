// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Initializable} from "@openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";
import {ERC20Upgradeable} from "@openzeppelin-contracts-upgradeable/token/ERC20/ERC20Upgradeable.sol";
import {
    ERC20PermitUpgradeable
} from "@openzeppelin-contracts-upgradeable/token/ERC20/extensions/ERC20PermitUpgradeable.sol";

import {UUPSUpgradeable} from "@openzeppelin-contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";

error NotOwner();

/// @custom:oz-upgrades-from UsdcMockUpgradeableV1_1
contract UsdcMockUpgradeableV1_2 is Initializable, ERC20Upgradeable, ERC20PermitUpgradeable, UUPSUpgradeable {
    address public owner;

    function initialize(address owner_) external initializer {
        owner = owner_;
        __ERC20_init("UsdcMock", "USDC");
        __ERC20Permit_init("UsdcMockUpgradeablesdcMock");
    }

    /// @custom:oz-upgrades-validate-as-initializer
    function initializeV1_2() public reinitializer(2) {
        __ERC20_init("UsdcMock", "USDC");
        __ERC20Permit_init("UsdcMock");
    }

    function decimals() public pure override returns (uint8) {
        return 6;
    }

    function mint(address to, uint256 value) public {
        if (owner != msg.sender) {
            revert NotOwner();
        }
        _mint(to, value);
    }

    function _authorizeUpgrade(address) internal view override {
        if (msg.sender != owner) {
            revert NotOwner();
        }
    }
}
