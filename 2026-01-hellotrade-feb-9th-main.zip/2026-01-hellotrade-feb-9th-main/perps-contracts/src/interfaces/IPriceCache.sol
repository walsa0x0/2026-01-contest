// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {IUnifiedStork} from "./IUnifiedStork.sol";

interface IPriceCache {
    function stork() external view returns (IUnifiedStork);

    function marketToHelloStorkId(uint32 marketId) external view returns (bytes32);

    function helloStorkIdToMarket(bytes32 helloStorkId) external view returns (uint32);

    function marketToStorkId(uint32 marketId) external view returns (bytes32);

    function validTimePeriodNs() external view returns (uint256);
}

