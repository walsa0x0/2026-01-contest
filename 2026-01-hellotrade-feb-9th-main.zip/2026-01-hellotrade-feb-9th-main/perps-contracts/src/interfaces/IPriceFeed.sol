// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

interface IPriceFeed {
    function setFeed(address feed) external;

    function getPrice(address asset) external view returns (uint256);
}
