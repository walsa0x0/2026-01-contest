// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/// @title IHelloVaultEvents
/// @notice Events emitted by the HelloVault contract
interface IHelloVaultEvents {
    event Deposited(address indexed account, uint256 amount, uint256 nonce);

    event Delevered(
        address indexed closer, address indexed liquidatee, uint256 indexed market, uint256 size, uint256 execPrice
    );

    event WithdrawProcessed(address indexed account, uint256 amount, uint256 nonce);

    event OrderCancelled(address indexed account, uint256 nonce);

    event LeverageSet(address indexed account, uint256 market, uint256 leverage);

    // V2 events for isolated margin support
    event DepositedV2(address indexed account, uint256 amount, uint32 indexed market, uint256 nonce, bool isIsolated);
    event WithdrawProcessedV2(
        address indexed account, uint256 amount, uint32 indexed market, uint256 nonce, bool isIsolated
    );
    event LeverageSetV2(address indexed account, uint256 market, uint256 leverage, bool isIsolated);
    event MarginTransferred(address indexed account, uint256 amount, uint32 indexed market, bool toIsolated);
    event LiquidatedV2(
        address indexed account,
        uint32 indexed market,
        uint256 execPrice,
        int256 fillSize,
        int256 marginDelta,
        uint256 fee,
        bool isIsolated,
        uint256 trackingHead
    );

    event TrackingHeadSet(uint256 trackingHead);

    event EmergencyWithdraw(address indexed account, uint256 amount);

    event Paused();

    event OrderFilled(
        address account,
        uint256 nonce,
        uint256 market,
        uint256 execPrice,
        uint256 entryPrice,
        int256 orderSize,
        int256 fillSize,
        int256 marginDelta,
        uint256 fee,
        uint256 trackingHead,
        bool isMaker
    );

    event OrderFilledV2(
        address indexed account,
        uint256 nonce,
        uint32 indexed market,
        uint256 execPrice,
        uint256 entryPrice,
        int256 orderSize,
        int256 fillSize,
        int256 marginDelta,
        uint256 fee,
        uint256 trackingHead,
        bool isMaker,
        bool isIsolated
    );

    event Liquidated(
        address account,
        uint256 market,
        uint256 execPrice,
        int256 fillSize,
        int256 marginDelta,
        uint256 fee,
        uint256 trackingHead
    );

    event DeleveredV2(
        address indexed closer,
        address indexed liquidatee,
        uint256 indexed market,
        uint256 size,
        uint256 execPrice,
        bool closerIsIsolated,
        bool liquidateeIsIsolated
    );
}

