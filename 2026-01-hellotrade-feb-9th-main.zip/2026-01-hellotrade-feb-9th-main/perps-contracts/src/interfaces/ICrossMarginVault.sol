// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Position} from "../lib/Position.sol";

/// @title ICrossMarginVault
/// @notice Interface for cross-margin vault view functions
interface ICrossMarginVault {
    /// @notice Get raw margin balance for an account
    function getMargin(address account) external view returns (int256);

    /// @notice Get free margin (equity - assigned margin)
    function getFreeMargin(address account) external view returns (int256);

    /// @notice Get position PnL at mark price
    function getPositionPnl(address account, uint256 market) external view returns (int256 pnl);

    /// @notice Get full account summary
    function getAccountSummary(address account)
        external
        view
        returns (int256 marginAcct, int256 crossPnl, uint256 crossAssMarg, uint256 crossMaintMarg);

    /// @notice Get all positions for a user
    function getAllPositions(address user) external view returns (uint256[] memory, Position[] memory);

    /// @notice Get all active markets for an account
    function getActiveMarkets(address account) external view returns (uint256[] memory);

    /// @notice Check if account is in liquidation
    function accountInLiquidation(address account) external view returns (bool);
}

