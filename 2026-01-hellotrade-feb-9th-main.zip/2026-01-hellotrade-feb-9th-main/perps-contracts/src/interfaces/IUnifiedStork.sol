// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {IStork} from "@storknetwork/stork-evm-sdk/IStork.sol";
import {IStorkGetters} from "@storknetwork/stork-evm-sdk/IStorkGetters.sol";

interface IUnifiedStork is IStork, IStorkGetters {}
