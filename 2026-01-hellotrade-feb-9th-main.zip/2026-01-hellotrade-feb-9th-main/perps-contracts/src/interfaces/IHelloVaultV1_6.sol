// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {MarketConfig} from "../price-feeds/HelloMarketData.sol";
import {ICrossMarginVault} from "./ICrossMarginVault.sol";

/// @title IHelloVaultV1_6
/// @notice Interface for HelloVault perpetuals trading contract
interface IHelloVaultV1_6 is ICrossMarginVault {
    struct Signature {
        bytes32 r;
        bytes32 s;
        uint8 v;
    }

    function initialize(address _owner, address _relayer, address _token, address _stork) external;

    function quoteToken() external view returns (address);

    function nonceUsed(address user, uint256 nonce) external view returns (bool);

    function setToken(address token) external;

    function setMarketConfig(uint32 market, MarketConfig memory config) external;

    function setFundingConfig(uint32 market, int32 fundingMax, int32 fundingMin, uint32 minFundingInterval) external;

    function setDefaultLeverage(uint32 market, uint32 leverage) external;

    function setMarketHelloStorkId(uint32 market, bytes32 helloStorkId) external;

    function setMarketStorkId(uint32 market, bytes32 storkId) external;

    function setValidTimePeriodNs(uint256 validTimePeriodNs_) external;

    function setFeeRecipient(address feeRecipient) external;
}
