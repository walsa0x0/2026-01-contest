// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/// @title IHelloVaultErrors
/// @notice Errors used by the HelloVault contract
interface IHelloVaultErrors {
    // Basic input validation errors
    error AmountZero();
    error AddressZero();

    // Order integrity errors
    error NonceUsed();
    error LevOverMax();
    error NoOrderCross(uint256 buyPrice, uint256 sellPrice);

    // Trade errors
    error DeleverOverSize();
    error OrderSignMismatch(int256 makerSize, int256 takerSize);
    error MarketMismatch(uint256 makerMarket, uint256 takerMarket);
    error FillOverSize();
    error FillSignMismatch();
    error WithdrawUnderfunded();
    error InvalidSigner(address signer, address expected);

    // Margin errors
    error InvalidAccountLiquidation();
    error InvalidAccountDelever(address account);
    error FillOverPosition();
    error InvalidSlTp(int256 orderSide, int256 fillSize);
    error LeverageOverMax(uint32 leverage, uint32 maxLeverage);
    error LeverageZero();

    // System state errors
    error ContractPaused();
    error BreakGlass();
    error HeartbeatNotExpired();
    error DeadlineExpired();
}

