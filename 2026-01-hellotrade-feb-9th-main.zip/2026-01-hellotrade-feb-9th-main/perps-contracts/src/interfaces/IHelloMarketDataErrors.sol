// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/// @title IHelloMarketDataErrors
/// @notice Errors used by the HelloMarketData contract
interface IHelloMarketDataErrors {
    // Configuration errors
    error UintZero();
    error MarketNotInitialized(uint256 market);
    error DefaultLeverageOverMarket(uint256 provided, uint256 maximum);
    error DefaultLeverageNotSet(uint256 market);
    error PrecisionTooHigh(uint256 precision);

    // Funding errors
    error FundingMaxOverGlobal();
    error FundingMinOverMax();
    error FundingMinUnderGlobal();
    error BadGlobalFundingInterval();
    error FundingOverMax(int256 rate, int256 max);
    error FundingUnderMin(int256 rate, int256 min);
    error BadFundingInterval();
}

