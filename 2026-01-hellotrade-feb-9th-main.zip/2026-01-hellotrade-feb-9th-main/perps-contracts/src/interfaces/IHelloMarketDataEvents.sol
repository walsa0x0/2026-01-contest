// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {MarketConfig} from "src/price-feeds/HelloMarketDataStructs.sol";

/// @title IHelloMarketDataEvents
/// @notice Events emitted by the HelloMarketData contract
interface IHelloMarketDataEvents {
    event FundingUpdated(
        uint32 indexed timestamp,
        uint256 indexed market,
        int256 fundingIdxLast,
        int256 newFundingRate,
        int256 newPriceMark
    );

    event MarketConfigSet(uint256 indexed market, MarketConfig config);
}

