// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {IERC20} from "@openzeppelin-contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin-contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "src/lib/Math.sol";

event FeesSet(uint64 makerFee, uint64 takerFee, uint64 liquidationFee, uint64 baseFee);

event FeeRecipientSet(address feeRecipient);

event FeeSent(address indexed account, address quoteToken, address feeRecipient, uint256 fee);

error AddressZero();
error FeeOverMax(uint256 fee);

struct Fees {
    uint64 makerFee;
    uint64 takerFee;
    uint64 liquidationFee;
    uint64 baseFee;
}

/// @notice Protocol fee structure with ERC-7201 namespaced storage.
contract HelloFees {
    using SafeERC20 for IERC20;

    uint256 constant MAKER_FEE_MAX = 500;
    uint256 constant TAKER_FEE_MAX = 500;
    uint256 constant LIQUIDATION_FEE_MAX = 500;
    uint256 constant BASE_FEE_MAX = 1e5; // 1e5 = 10 cents
    uint256 constant FEE_DENOMINATOR = 10_000;

    /// @custom:storage-location erc7201:hellotrade.storage.HelloFees
    struct HelloFeesStorage {
        address feeRecipient;
        Fees fees;
    }

    // keccak256(abi.encode(uint256(keccak256("hellotrade.storage.Fees")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant HELLO_FEES_STORAGE_LOCATION =
        0x98592fea62ca582710d5c216b231a8b45946f127efd7319ca9284fa696f9b800;

    function _getHelloFeesStorage() internal pure returns (HelloFeesStorage storage $) {
        assembly {
            $.slot := HELLO_FEES_STORAGE_LOCATION
        }
    }

    function _setFees(uint64 makerFee, uint64 takerFee, uint64 liquidationFee, uint64 baseFee) internal virtual {
        if (makerFee > MAKER_FEE_MAX) revert FeeOverMax(makerFee);
        if (takerFee > TAKER_FEE_MAX) revert FeeOverMax(takerFee);
        if (liquidationFee > LIQUIDATION_FEE_MAX) revert FeeOverMax(liquidationFee);
        if (baseFee > BASE_FEE_MAX) revert FeeOverMax(baseFee);

        HelloFeesStorage storage $ = _getHelloFeesStorage();
        $.fees = Fees({makerFee: makerFee, takerFee: takerFee, liquidationFee: liquidationFee, baseFee: baseFee});
        emit FeesSet(makerFee, takerFee, liquidationFee, baseFee);
    }

    /// @notice Calculate fill fee in quote token units.
    /// @param amount Notional amount in price-scaled units (fillSize * execPrice)
    /// @param baseDecimals The base asset decimal multiplier (10^basePrecision)
    /// @param isMaker Whether this is a maker order
    /// @return fee Fee in quote token units (includes baseFee)
    function _calcFillFee(uint256 amount, uint256 baseDecimals, bool isMaker)
        internal
        view
        virtual
        returns (uint256 fee)
    {
        HelloFeesStorage storage $ = _getHelloFeesStorage();
        uint256 divisor = Math.notionalDivisor(baseDecimals);
        return (amount * (isMaker ? $.fees.makerFee : $.fees.takerFee) / FEE_DENOMINATOR) / divisor + $.fees.baseFee;
    }

    /// @notice Calculate the liquidation fee for a given amount and remaining margin.
    /// @dev Takes the liquidation fee as a percentage of the amount, adds baseFee, clamped to the remaining margin.
    /// @param amount Notional amount in price-scaled units (fillSize * execPrice)
    /// @param baseDecimals The base asset decimal multiplier (10^basePrecision)
    /// @param available Amount available for fee coverage, typically margin net PNL
    /// @return Fee in quote token units, capped to available
    function _calcLiquidationFee(uint256 amount, uint256 baseDecimals, uint256 available)
        internal
        view
        virtual
        returns (uint256)
    {
        HelloFeesStorage storage $ = _getHelloFeesStorage();
        uint256 divisor = Math.notionalDivisor(baseDecimals);
        uint256 fee = (amount * $.fees.liquidationFee / FEE_DENOMINATOR) / divisor + $.fees.baseFee;
        return fee > available ? available : fee;
    }

    function _setFeeRecipient(address newFeeRecipient) internal virtual {
        HelloFeesStorage storage $ = _getHelloFeesStorage();
        $.feeRecipient = newFeeRecipient;
        emit FeeRecipientSet(newFeeRecipient);
    }

    function _sendFee(address account, address quoteToken, uint256 fee) internal virtual {
        HelloFeesStorage storage $ = _getHelloFeesStorage();
        address feeRecipient = $.feeRecipient;

        if (feeRecipient == address(0)) revert AddressZero();
        IERC20(quoteToken).safeTransfer(feeRecipient, fee);
        emit FeeSent(account, quoteToken, feeRecipient, fee);
    }
}
