// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

event DelegatorSet(address indexed account, address indexed delegator, uint256 until);

/// @title SignerDelegator
/// @notice Manages delegation of signing rights from one account to another.
/// @dev Allows for one user to perform signed actions on behalf of another
/// until a predetermined timestamp.
abstract contract SignerDelegator {
    /// @notice Maps account => delegator => expiration timestamp
    mapping(address => mapping(address => uint256)) internal delegators;

    /// @notice Check if a delegator is authorized to sign on behalf of an account
    /// @param account The account that granted delegation
    /// @param delegator The address checking delegation rights
    /// @return bool True if the delegator is authorized and has not expired
    function _isDelegated(address account, address delegator) internal view virtual returns (bool) {
        return delegators[account][delegator] > block.timestamp;
    }

    /// @notice Set a delegator for an account
    /// @param account The account granting delegation
    /// @param delegator The address being granted signing rights
    /// @param until The timestamp until which the delegation is valid
    function _setDelegator(address account, address delegator, uint256 until) internal virtual {
        delegators[account][delegator] = until;
        emit DelegatorSet(account, delegator, until);
    }

    /// @notice Get the expiration timestamp for a delegation
    /// @param account The account that granted delegation
    /// @param delegator The delegated address
    /// @return The timestamp until which the delegation is valid
    function getDelegatorExpiry(address account, address delegator) public view returns (uint256) {
        return delegators[account][delegator];
    }
}

