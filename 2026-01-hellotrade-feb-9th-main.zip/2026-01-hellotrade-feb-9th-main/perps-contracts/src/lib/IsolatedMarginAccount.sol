// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {PositionLib, Position} from "./Position.sol";
import {Math} from "./Math.sol";

struct IsolatedMarginAccount {
    uint256 margin;
    Position position;
}

library IsolatedMarginAccountLib {
    using PositionLib for Position;
    using Math for int256;

    function creditMargin(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market,
        uint256 amount
    ) internal {
        self[user][market].margin += amount;
    }

    function debitMargin(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market,
        uint256 amount
    ) internal {
        self[user][market].margin -= amount;
    }

    function applyMarginDelta(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market,
        int256 delta
    ) internal {
        if (delta > 0) {
            creditMargin(self, user, market, delta.abs());
        } else {
            debitMargin(self, user, market, delta.abs());
        }
    }

    function setMargin(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market,
        uint256 margin
    ) internal {
        self[user][market].margin = margin;
    }

    function getPosition(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market
    ) internal view returns (Position storage) {
        return self[user][market].position;
    }

    function getMargin(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market
    ) internal view returns (uint256) {
        return self[user][market].margin;
    }

    /// @notice Check if an account has an active position in a market
    /// @param self The isolated margin accounts mapping
    /// @param user The user address
    /// @param market The market ID
    /// @return True if position size is non-zero
    function hasPosition(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market
    ) internal view returns (bool) {
        return self[user][market].position.size != 0;
    }

    function updatePosition(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market,
        Position memory newPos
    ) internal {
        self[user][market].position = newPos;
    }

    function setPositionLeverage(
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) storage self,
        address user,
        uint256 market,
        uint128 leverage
    ) internal {
        self[user][market].position.leverage = leverage;
    }
}
