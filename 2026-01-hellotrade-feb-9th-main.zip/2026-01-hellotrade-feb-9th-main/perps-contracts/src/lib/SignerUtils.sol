// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

library SignerUtils {
    bytes32 constant UPDATE_LEVERAGE_TYPEHASH =
        keccak256("UpdateLeverage(address account,uint32 mkt,uint32 leverage,uint256 nonce,uint256 deadline)");

    bytes32 constant WITHDRAW_TYPEHASH =
        keccak256("Withdraw(address account,uint256 amount,uint256 nonce,uint256 deadline)");

    bytes32 constant ORDER_TYPEHASH =
        keccak256("Order(address account,uint32 market,int256 size,uint256 limitPrice,uint256 nonce)");

    bytes32 constant ORDER_V2_TYPEHASH =
        keccak256("OrderV2(address account,uint32 market,int256 size,uint256 limitPrice,uint256 nonce,uint256 flags)");

    bytes32 constant SET_DELEGATOR_TYPEHASH =
        keccak256("SetDelegator(address account,address delegator,uint256 until,uint256 nonce,uint256 deadline)");

    bytes32 constant CANCEL_ORDER_TYPEHASH = keccak256("CancelOrder(address account,uint256 nonce,uint256 deadline)");

    bytes32 constant WITHDRAW_V2_TYPEHASH = keccak256(
        "WithdrawV2(address account,uint256 amount,uint32 market,uint256 flags,uint256 nonce,uint256 deadline)"
    );

    bytes32 constant UPDATE_LEVERAGE_V2_TYPEHASH = keccak256(
        "UpdateLeverageV2(address account,uint32 market,uint32 leverage,uint256 flags,uint256 nonce,uint256 deadline)"
    );

    bytes32 constant TRANSFER_MARGIN_TYPEHASH = keccak256(
        "TransferMargin(address account,uint256 amount,uint32 market,uint256 flags,uint256 nonce,uint256 deadline)"
    );

    function _buildWithdrawHash(address account, uint256 amount, uint256 nonce, uint256 deadline)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(WITHDRAW_TYPEHASH, account, amount, nonce, deadline));
    }

    function _buildLeverageUpdateHash(address account, uint32 market, uint32 leverage, uint256 nonce, uint256 deadline)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(UPDATE_LEVERAGE_TYPEHASH, account, market, leverage, nonce, deadline));
    }

    function _buildOrderHash(address account, uint32 market, int256 size, uint256 limitPrice, uint256 nonce)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(ORDER_TYPEHASH, account, market, size, limitPrice, nonce));
    }

    function _buildOrderV2Hash(
        address account,
        uint32 market,
        int256 size,
        uint256 limitPrice,
        uint256 nonce,
        uint256 flags
    ) internal pure returns (bytes32) {
        return keccak256(abi.encode(ORDER_V2_TYPEHASH, account, market, size, limitPrice, nonce, flags));
    }

    function _buildSetDelegatorHash(address account, address delegator, uint256 until, uint256 nonce, uint256 deadline)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(SET_DELEGATOR_TYPEHASH, account, delegator, until, nonce, deadline));
    }

    function _buildCancelOrderHash(address account, uint256 nonce, uint256 deadline) internal pure returns (bytes32) {
        return keccak256(abi.encode(CANCEL_ORDER_TYPEHASH, account, nonce, deadline));
    }

    function _buildWithdrawV2Hash(
        address account,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 deadline
    ) internal pure returns (bytes32) {
        return keccak256(abi.encode(WITHDRAW_V2_TYPEHASH, account, amount, market, flags, nonce, deadline));
    }

    function _buildLeverageUpdateV2Hash(
        address account,
        uint32 market,
        uint32 leverage,
        uint256 flags,
        uint256 nonce,
        uint256 deadline
    ) internal pure returns (bytes32) {
        return keccak256(abi.encode(UPDATE_LEVERAGE_V2_TYPEHASH, account, market, leverage, flags, nonce, deadline));
    }

    function _buildTransferMarginHash(
        address account,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 deadline
    ) internal pure returns (bytes32) {
        return keccak256(abi.encode(TRANSFER_MARGIN_TYPEHASH, account, amount, market, flags, nonce, deadline));
    }
}
