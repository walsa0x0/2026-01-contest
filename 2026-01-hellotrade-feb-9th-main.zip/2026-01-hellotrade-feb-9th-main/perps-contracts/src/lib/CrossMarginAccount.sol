// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {PositionLib, Position} from "./Position.sol";

import {EnumerableSetLib} from "solady/utils/EnumerableSetLib.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

using CrossMarginAccountLib for CrossMarginAccount global;

/// @title CrossMarginAccount
///
/// @param activeMarkets Enumerable set of all markets where the account has a position (position is non-zero);
/// @param positions Mapping of market address to individual position data for user.
struct CrossMarginAccount {
    int256 margin;
    EnumerableSetLib.Uint256Set activeMarkets;
    mapping(uint256 => Position) positions;
}

library CrossMarginAccountLib {
    using PositionLib for Position;
    using EnumerableSetLib for EnumerableSetLib.Uint256Set;

    function creditMargin(mapping(address => CrossMarginAccount) storage self, address account, uint256 amount)
        internal
    {
        self[account].margin += SafeCastLib.toInt256(amount);
    }

    function debitMargin(mapping(address => CrossMarginAccount) storage self, address account, uint256 amount)
        internal
    {
        self[account].margin -= SafeCastLib.toInt256(amount);
    }

    function applyMarginDelta(mapping(address => CrossMarginAccount) storage self, address account, int256 delta)
        internal
    {
        self[account].margin += delta;
    }

    function updatePosition(
        mapping(address => CrossMarginAccount) storage self,
        address user,
        uint256 market,
        Position memory newPos
    ) internal {
        // If we close position, leave position slots dirty and clear the
        // activeMarkets entry. Otherwise, update position accordingly.

        // zero position, remove user from market
        // early return, position data stays dirty
        if (newPos.size == 0) {
            self[user].activeMarkets.remove(market);
            return;
        }

        // not in market, enter market and update position
        if (!self[user].activeMarkets.contains(market)) {
            self[user].activeMarkets.add(market);
        }

        self[user].positions[market] = Position({
            size: newPos.size,
            entryFundingIdx: newPos.entryFundingIdx,
            leverage: newPos.leverage,
            entryPrice: newPos.entryPrice
        });
    }

    function getPosition(mapping(address => CrossMarginAccount) storage self, address account, uint256 market)
        internal
        view
        returns (Position storage)
    {
        return self[account].positions[market];
    }

    /// @notice Get position with dirty storage normalization for new market entries
    /// @dev Returns clean position if not in market, handling dirty storage from previous closes
    /// @param self The cross margin accounts mapping
    /// @param account The account address
    /// @param market The market ID
    /// @param defaultLeverage The default leverage to use if position leverage is unset
    /// @return pos The position (normalized if not in market)
    /// @return isInMarket_ Whether the account has an active position in this market
    function getPositionOrClean(
        mapping(address => CrossMarginAccount) storage self,
        address account,
        uint256 market,
        uint128 defaultLeverage
    ) internal view returns (Position memory pos, bool isInMarket_) {
        isInMarket_ = self[account].activeMarkets.contains(market);
        pos = self[account].positions[market];

        if (!isInMarket_) {
            // Normalize dirty storage: preserve leverage preference, clear everything else
            pos = Position({
                size: 0,
                entryFundingIdx: pos.entryFundingIdx,
                leverage: PositionLib.getEffectiveLeverage(pos.leverage, defaultLeverage),
                entryPrice: 0
            });
        }
    }

    function getActiveMarkets(CrossMarginAccount storage self) internal view returns (uint256[] memory) {
        return self.activeMarkets.values();
    }

    function getNumActiveMarkets(CrossMarginAccount storage self) internal view returns (uint256) {
        return self.activeMarkets.length();
    }

    function getAllCrossMarginAccount(CrossMarginAccount storage self)
        internal
        view
        returns (uint256[] memory, Position[] memory)
    {
        uint256[] memory inMarkets = getActiveMarkets(self);
        uint256 numMarkets = inMarkets.length;

        Position[] memory positionAcc = new Position[](numMarkets);

        for (uint256 i; i < numMarkets;) {
            positionAcc[i] = self.positions[inMarkets[i]];
            ++i;
        }

        return (inMarkets, positionAcc);
    }

    function isInMarket(mapping(address => CrossMarginAccount) storage self, address account, uint256 market)
        internal
        view
        returns (bool)
    {
        return self[account].activeMarkets.contains(market);
    }
}
