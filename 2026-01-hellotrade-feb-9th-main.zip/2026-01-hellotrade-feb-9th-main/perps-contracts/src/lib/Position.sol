// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {EnumerableSetLib} from "solady/utils/EnumerableSetLib.sol";
import {FixedPointMathLib} from "solady/utils/FixedPointMathLib.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketDataStructs.sol";
import {Math} from "./Math.sol";

using PositionLib for Position global;

/// @title Position
struct Position {
    int256 size;
    int256 entryFundingIdx;
    uint128 leverage;
    uint128 entryPrice;
}

/// @title PositionDeltaResult
/// @notice Result of calculating position deltas from a fill
struct PositionDeltaResult {
    Position newPos;
    int256 pnl;
    bool isSimpleClose;
}

/// @notice Library for tracking all user positions.
/// @dev All PnL calculations round toward negative infinity.
/// @dev All required margin calculations round toward positive infinity.
library PositionLib {
    using Math for int256;
    using FixedPointMathLib for uint256;
    using EnumerableSetLib for EnumerableSetLib.AddressSet;

    uint256 constant LEVERAGE_EXPONENT = 100; // 100 = 1x, 10_000 = 100x

    function calcTotalPnl(Position memory self, uint256 newPrice, int192 fundingIdxLast, uint8 basePrecision)
        internal
        pure
        returns (int256 delta)
    {
        delta = calcNotionalPnl(self.size, uint256(self.entryPrice), newPrice, basePrecision);
        delta += calcFundingPnl(self.size, self.entryFundingIdx, fundingIdxLast, basePrecision);
    }

    /// @notice Calculates the notional PNL between two prices given a position size.
    ///
    /// @param size The size of the position.
    /// @param price0 The initial price.
    /// @param price1 The final price.
    /// @param basePrecision The precision of the base.
    /// @return delta The notional PNL.
    function calcNotionalPnl(int256 size, uint256 price0, uint256 price1, uint8 basePrecision)
        internal
        pure
        returns (int256)
    {
        int256 priceDelta = SafeCastLib.toInt256(price1) - SafeCastLib.toInt256(price0);
        int256 numerator = priceDelta * size;
        int256 denominator = SafeCastLib.toInt256(Math.notionalDivisor(10 ** basePrecision));
        return numerator.divDown(denominator);
    }

    /// @notice Calculates new position and PNL given order fill deltas.
    /// @dev Assumes an initialized position. Guards against uninitialized
    /// positions and bad position values are checked outside of this function.
    function calcNewPosAndPnl(
        Position memory pos,
        MarketConfig memory mktData,
        int256 sizeDelta,
        uint256 execPrice,
        int192 latestFundingIdx
    ) internal pure returns (Position memory newPos, int256 pnl) {
        newPos.size = pos.size + sizeDelta;
        newPos.leverage = pos.leverage;
        newPos.entryFundingIdx = latestFundingIdx;
        bool isIncrease = pos.deltaIsIncrease(sizeDelta);

        if (isIncrease) {
            // Weighted average of prices by size, rounding toward worse execution.
            uint256 numerator = (pos.entryPrice * pos.size.abs()) + (execPrice * sizeDelta.abs());
            uint256 denominator = newPos.size.abs();
            // Shorts round down, longs round up
            uint256 weighAvgPrice = pos.size < 0 ? numerator / denominator : numerator.divUp(denominator);
            newPos.entryPrice = uint128(weighAvgPrice);
        } else {
            bool crossesZero = pos.deltaCrossesZero(sizeDelta);
            uint256 entryPrice = uint256(pos.entryPrice);

            if (crossesZero) {
                // Get PnL for close portion, total size of the previous position.
                pnl = calcNotionalPnl(pos.size, entryPrice, execPrice, mktData.basePrecision);
                // New entry price is equal to new exec price.
                newPos.entryPrice = uint128(execPrice);
            } else {
                // Get PnL for delta amount of the new position
                pnl = calcNotionalPnl(-sizeDelta, entryPrice, execPrice, mktData.basePrecision);
                // New price is unchanged.
                newPos.entryPrice = pos.entryPrice;
            }
        }
        pnl += calcFundingPnl(pos.size, pos.entryFundingIdx, latestFundingIdx, mktData.basePrecision);
    }

    function calcFundingPnl(int256 size, int256 entryFundingIdx, int192 fundingIdxLast, uint8 basePrecision)
        internal
        pure
        returns (int256 fundingPnl)
    {
        // Invert such that positive funding rate means that longs pay shorts. Strictly optional,
        // but cleaves to existing funding rate interpretations.
        int256 fundingDelta = -(fundingIdxLast - entryFundingIdx);
        if (fundingDelta != 0) {
            int256 numerator = fundingDelta * size;
            int256 denominator = SafeCastLib.toInt256(Math.notionalDivisor(10 ** basePrecision));

            fundingPnl = numerator.divDown(denominator);
        }
    }

    /// === assigned margin calculation ===
    function calcAssMargAtPrice(Position memory self, uint256 price, uint8 basePrecision)
        internal
        pure
        returns (uint256 assMarg)
    {
        uint256 numerator = self.size.abs() * price * LEVERAGE_EXPONENT;
        uint256 denominator = self.leverage * Math.notionalDivisor(10 ** basePrecision);
        return numerator.divUp(denominator);
    }

    function calcMaintMargAtPrice(Position memory self, uint256 price, uint8 basePrecision, uint256 maxLeverage)
        internal
        pure
        returns (uint256 maintMarg)
    {
        uint256 numerator = self.size.abs() * price * LEVERAGE_EXPONENT;
        uint256 denominator = maxLeverage * Math.notionalDivisor(10 ** basePrecision);
        maintMarg = numerator.divUp(denominator).divUp(2);
    }

    /// === delta helpers ===

    /// @notice Returns true if delta was an increase in position
    function deltaIsIncrease(Position memory self, int256 other) internal pure returns (bool) {
        return (self.size == 0 || Math.signCmp(self.size, other));
    }

    /// @notice Returns true if delta crosses zero (would result in a new, non-zero position)
    function deltaCrossesZero(Position memory self, int256 other) internal pure returns (bool) {
        // not an increase and other is less than or equal to absolute size
        return (!self.deltaIsIncrease(other)) && (self.size.abs() < other.abs());
    }

    /// @notice delta is a simple close if delta is a decrease, but does not cross zero
    function deltaIsSimpleClose(Position memory self, int256 other) internal pure returns (bool) {
        return (!self.deltaIsIncrease(other)) && (!self.deltaCrossesZero(other));
    }

    /// === leverage helpers ===

    /// @notice Get effective leverage, using default if position leverage is unset
    /// @param posLeverage The position's current leverage (may be 0)
    /// @param defaultLeverage The market's default leverage
    /// @return The effective leverage to use
    function getEffectiveLeverage(uint128 posLeverage, uint128 defaultLeverage) internal pure returns (uint128) {
        return posLeverage == 0 ? defaultLeverage : posLeverage;
    }

    /// === combined position delta calculation ===

    /// @notice Calculate position delta result including newPos, pnl, and isSimpleClose
    /// @param pos The current position
    /// @param mktConfig The market configuration
    /// @param sizeDelta The size change
    /// @param execPrice The execution price
    /// @param latestFundingIdx The latest cumulative funding index
    /// @return result The complete position delta result
    function calcPositionDelta(
        Position memory pos,
        MarketConfig memory mktConfig,
        int256 sizeDelta,
        uint256 execPrice,
        int192 latestFundingIdx
    ) internal pure returns (PositionDeltaResult memory result) {
        (result.newPos, result.pnl) = pos.calcNewPosAndPnl(mktConfig, sizeDelta, execPrice, latestFundingIdx);
        result.isSimpleClose = pos.deltaIsSimpleClose(sizeDelta);
    }
}
