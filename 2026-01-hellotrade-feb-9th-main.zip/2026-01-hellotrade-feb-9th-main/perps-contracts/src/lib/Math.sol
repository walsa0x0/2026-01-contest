// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

error ZeroCmp();
error DivFailed();
error Overflow();

library Math {
    enum Rounding {
        Ceil,
        Floor
    }

    // Price values will always be a 1e18 number
    uint256 constant PRICE_DECIMALS = 1e18;
    // Quote asset is always USDC with 1e6 decimals
    uint256 constant QUOTE_DECIMALS = 1e6;

    /// @notice Calculate the divisor for positional notional value calculations.
    /// @dev Intended for finding the divisor when converting from a base asset with a given
    /// decimal precision into a quote asset amount at a given WAD price.
    /// @param baseDecimals The base asset decimal multiplier (10^basePrecision)
    /// @return divisor The divisor to convert (fillSize * price) to quote units
    function notionalDivisor(uint256 baseDecimals) internal pure returns (uint256) {
        return (baseDecimals * PRICE_DECIMALS) / QUOTE_DECIMALS;
    }

    /// @notice mirrors solady FixedPointMath `abs()`
    function abs(int256 x) internal pure returns (uint256 z) {
        unchecked {
            z = (uint256(x) + uint256(x >> 255)) ^ uint256(x >> 255);
        }
    }

    /// @notice Divides two integers and rounds to negative infinity.
    /// This certainly needs fuzz testing.
    function divDown(int256 x, int256 y) internal pure returns (int256 result) {
        assembly {
            // if (y == 0) revert DivFailed()
            if iszero(y) {
                mstore(0x00, 0x65244e4e) // DivFailed()
                revert(0x1c, 0x04)
            }

            // overflow case: int256.min / -1
            if and(eq(x, shl(255, 1)), eq(y, sub(0, 1))) {
                mstore(0x00, 0x65244e4e) // DivFailed()
                revert(0x1c, 0x04)
            }

            let q := sdiv(x, y)
            let r := sub(x, mul(q, y))

            // floor adjustment if there's a remainder and q < 0
            if and(iszero(iszero(r)), slt(q, 0)) { q := sub(q, 1) }

            result := q
        }
    }

    /// @notice Compares the signs of two integers.
    /// @dev Returns true if both integers have the same sign, false otherwise.
    function signCmp(int256 x, int256 y) internal pure returns (bool) {
        if (x == 0 || y == 0) {
            revert ZeroCmp();
        }
        return (x ^ y) >= 0;
    }
}
