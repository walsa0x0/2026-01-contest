// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

/// @title TransientMapU256
/// @notice A library for stashing and retrieving uint256 values in transient storage.
library TransientMapU256 {
    /// @notice Stash a uint256 value in transient storage.
    /// @param key The key to stash the value at.
    /// @param value The value to stash.
    function stash(uint256 key, uint256 value) internal {
        assembly {
            // Compute keccak256(abi.encodePacked(slot, key)) and store value there
            tstore(key, value)
        }
    }

    /// @notice Get a uint256 value from transient storage.
    /// @param key The key to get the value from.
    /// @return value The value at the key.
    function get(uint256 key) internal view returns (uint256 value) {
        assembly {
            value := tload(key)
        }
    }

    /// @notice Remove a uint256 value from transient storage.
    /// @param key The key to remove the value from.
    function remove(uint256 key) internal {
        assembly {
            tstore(key, 0)
        }
    }
}
