// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Position} from "./Position.sol";
import {MarketConfig} from "../price-feeds/HelloMarketDataStructs.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

/// @notice Reverts when equity is below assigned margin requirement
error InsufficientMargin(int256 equity, uint256 requiredMargin);
/// @notice Reverts when equity is below maintenance margin (liquidatable)
error AccountInLiquidation(int256 equity, uint256 maintenanceMargin);

/// @title PositionMetrics
/// @notice Aggregated margin metrics for one or more positions
struct PositionMetrics {
    int256 unrealizedPnl;
    uint256 assignedMargin;
    uint256 maintenanceMargin;
}

/// @title PositionMetricsLib
/// @notice Library for computing and aggregating position margin metrics
library PositionMetricsLib {
    /// @notice Calculate metrics for a single position at a given price
    /// @param pos The position to calculate metrics for
    /// @param markPrice The current mark price
    /// @param cumulativeFundingIdx The latest cumulative funding index
    /// @param config The market configuration
    /// @return metrics The calculated position metrics
    function calculate(Position memory pos, uint256 markPrice, int192 cumulativeFundingIdx, MarketConfig memory config)
        internal
        pure
        returns (PositionMetrics memory metrics)
    {
        metrics.unrealizedPnl = pos.calcTotalPnl(markPrice, cumulativeFundingIdx, config.basePrecision);
        metrics.assignedMargin = pos.calcAssMargAtPrice(markPrice, config.basePrecision);
        metrics.maintenanceMargin = pos.calcMaintMargAtPrice(markPrice, config.basePrecision, config.maxLeverage);
    }

    /// @notice Accumulate another position's metrics into this one
    /// @dev Mutates self in-place for gas efficiency
    /// @param self The accumulator metrics
    /// @param other The metrics to add
    function add(PositionMetrics memory self, PositionMetrics memory other) internal pure {
        self.unrealizedPnl += other.unrealizedPnl;
        self.assignedMargin += other.assignedMargin;
        self.maintenanceMargin += other.maintenanceMargin;
    }

    /// @notice Calculate total equity (base margin + unrealized PnL)
    /// @param self The position metrics
    /// @param baseEquity The base margin balance for equity calculation
    /// @return totalEquity The total equity
    function calcEquity(PositionMetrics memory self, int256 baseEquity) internal pure returns (int256 totalEquity) {
        return baseEquity + self.unrealizedPnl;
    }

    /// @notice Calculate free margin (equity - assigned margin)
    /// @param self The position metrics
    /// @param baseEquity The base margin balance for equity calculation
    /// @return freeMargin_ The free margin (can be negative)
    function freeMargin(PositionMetrics memory self, int256 baseEquity) internal pure returns (int256 freeMargin_) {
        freeMargin_ = calcEquity(self, baseEquity) - SafeCastLib.toInt256(self.assignedMargin);
    }

    /// @notice Check if account is liquidatable (equity < maintenance margin)
    /// @param self The position metrics
    /// @param baseEquity The base margin balance for equity calculation
    /// @return isLiquidatable_ True if the account can be liquidated
    function isLiquidatable(PositionMetrics memory self, int256 baseEquity)
        internal
        pure
        returns (bool isLiquidatable_)
    {
        isLiquidatable_ =
            calcEquity(self, baseEquity) < SafeCastLib.toInt256(self.maintenanceMargin);
    }

    /// @notice Check if account covers assigned margin (equity >= assigned margin)
    /// @param self The position metrics
    /// @param baseEquity The base margin balance for equity calculation
    /// @return coversAssignedMargin_ True if the account has sufficient margin
    function coversAssignedMargin(PositionMetrics memory self, int256 baseEquity)
        internal
        pure
        returns (bool coversAssignedMargin_)
    {
        coversAssignedMargin_ = calcEquity(self, baseEquity) >= SafeCastLib.toInt256(self.assignedMargin);
    }

    /// @notice Require that margin is sufficient (covers assigned margin and not liquidatable)
    /// @dev Reverts with InsufficientMargin or AccountInLiquidation if checks fail
    /// @param self The position metrics
    /// @param baseEquity The base margin balance for equity calculation
    function requireSufficientMargin(PositionMetrics memory self, int256 baseEquity) internal pure {
        int256 equity = calcEquity(self, baseEquity);
        if (!coversAssignedMargin(self, baseEquity)) {
            revert InsufficientMargin(equity, self.assignedMargin);
        }
        if (isLiquidatable(self, baseEquity)) {
            revert AccountInLiquidation(equity, self.maintenanceMargin);
        }
    }
}

