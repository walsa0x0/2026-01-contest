// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

using NonceBitmap for Bitmap global;

/**
 * @dev Mapping from address to mapping of bitmap index to bitmap value
 * bitmapIndex = nonce / 256
 * bitPosition = nonce % 256
 */
struct Bitmap {
    mapping(uint256 => uint256) bitmap;
}

/**
 * @title NonceBitmap
 * @dev A library for managing nonces using bitmaps.
 *
 * This library allows tracking used nonces per address using bitmaps instead of
 *
 * nonce 1 uses bit 1, etc. For nonces >= 256, we use successive uint256 values
 * in the mapping (nonce 256 uses bit 0 of the second uint256, etc.).
 */
library NonceBitmap {
    error NonceAlreadyUsed(uint256 nonce);

    /**
     * @dev Check if a nonce has been used for a given address
     * @param bitmap The bitmap storage for the address
     * @param nonce The nonce to check
     * @return True if the nonce has been used, false otherwise
     */
    function isUsed(Bitmap storage bitmap, uint256 nonce) internal view returns (bool) {
        (uint256 bitmapIndex, uint256 mask) = _getIdm(nonce);

        return (bitmap.bitmap[bitmapIndex] & mask) != 0;
    }

    /**
     * @dev Mark a nonce as used for a given address
     * @param bitmap The bitmap storage for the address
     * @param nonce The nonce to mark as used
     */
    function burnNonce(Bitmap storage bitmap, uint256 nonce) internal {
        (uint256 bitmapIndex, uint256 mask) = _getIdm(nonce);

        uint256 slot = bitmap.bitmap[bitmapIndex];
        if ((slot & mask) != 0) {
            revert NonceAlreadyUsed(nonce);
        }
        bitmap.bitmap[bitmapIndex] = slot | mask;
    }

    function _getIdm(uint256 nonce) internal pure returns (uint256 bitmapIndex, uint256 mask) {
        assembly {
            bitmapIndex := shr(8, nonce)
            let bitPosition := and(nonce, 0xFF)
            mask := shl(bitPosition, 1)
        }

        return (bitmapIndex, mask);
    }
}
