// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {SignerUtils} from "./SignerUtils.sol";

// Order Types
// 0 - Limit
// 1 - Market

using OrderLib for Order global;
using OrderV2Lib for OrderV2 global;

/// @notice Standard cross-margin order
struct Order {
    address account;
    uint32 market;
    int256 size;
    /// Price in USDC denomination padded to 18 decimals, e.g. 1 USDC = 1e18
    uint256 limitPrice;
    uint256 nonce;
}

/// @notice Order with flags field for margin mode and future extensions
/// @dev flags bit 0: 0 = cross margin, 1 = isolated margin
struct OrderV2 {
    address account;
    uint32 market;
    int256 size;
    /// Price in USDC denomination padded to 18 decimals, e.g. 1 USDC = 1e18
    uint256 limitPrice;
    uint256 nonce;
    /// Bit flags: bit 0 = isolated margin (1) or cross margin (0)
    uint256 flags;
}

struct Liquidation {
    address account;
    uint32 market;
}

/// @dev Flag constants for OrderV2
uint256 constant ORDER_FLAG_ISOLATED = 1;

library OrderLib {
    function digest(Order memory order) internal pure returns (bytes32) {
        return SignerUtils._buildOrderHash(order.account, order.market, order.size, order.limitPrice, order.nonce);
    }
}

library OrderV2Lib {
    function digest(OrderV2 memory order) internal pure returns (bytes32) {
        return SignerUtils._buildOrderV2Hash(
            order.account, order.market, order.size, order.limitPrice, order.nonce, order.flags
        );
    }

    function isIsolated(OrderV2 memory self) internal pure returns (bool) {
        return (self.flags & ORDER_FLAG_ISOLATED) != 0;
    }

    /// @notice Convert OrderV2 to Order (for compatibility with existing handlers)
    function toOrder(OrderV2 memory self) internal pure returns (Order memory) {
        return Order({
            account: self.account, market: self.market, size: self.size, limitPrice: self.limitPrice, nonce: self.nonce
        });
    }
}
