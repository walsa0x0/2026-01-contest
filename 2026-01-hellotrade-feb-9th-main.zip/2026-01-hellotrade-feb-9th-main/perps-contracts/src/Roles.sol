// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

import {AccessControlUpgradeable} from "@openzeppelin-contracts-upgradeable/access/AccessControlUpgradeable.sol";
import {Initializable} from "@openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";

contract HelloRoles is Initializable, AccessControlUpgradeable {
    bytes32 constant ADMIN_ROLE = hex"01";
    bytes32 constant RELAYER_ROLE = hex"02";

    function __HelloRoles_init() internal virtual onlyInitializing {}
}
