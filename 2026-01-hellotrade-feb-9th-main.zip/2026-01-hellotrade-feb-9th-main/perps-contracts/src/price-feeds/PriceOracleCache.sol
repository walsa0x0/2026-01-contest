// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.28;

import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";
import {StorkErrors} from "@storknetwork/stork-evm-sdk/StorkErrors.sol";
import {IStorkEvents} from "@storknetwork/stork-evm-sdk/IStorkEvents.sol";
import {IPriceCache} from "../interfaces/IPriceCache.sol";

import {ECDSA} from "@openzeppelin-contracts/utils/cryptography/ECDSA.sol";
import {MessageHashUtils} from "@openzeppelin-contracts/utils/cryptography/MessageHashUtils.sol";
import {Initializable} from "@openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";

import {Math} from "../lib/Math.sol";

import {IUnifiedStork} from "../interfaces/IUnifiedStork.sol";

error AllOraclesFailed();
error NegativePrice();
error UnknownHelloStorkId(bytes32 helloStorkId);
error MarketInUse(uint32 marketId, bytes32 storkId);
error InvalidMarketMapping(uint32 marketId, bytes32 storkId);
error BytesZero();
error UintZero();

/// @title PriceOracleCache
/// @notice Unified price oracle with 2-tier caching:
///         1. Transient storage (tstore) - current tx only
///         2. Local storage cache - persisted with validity period
///         3. Remote fallback (Stork contract)
/// @dev Prices are keyed by marketId (uint32) directly for gas efficiency
contract PriceOracleCache is Initializable, IPriceCache {
    using ECDSA for bytes32;
    using MessageHashUtils for bytes32;
    using Math for int256;

    // ============ Structs ============

    /// @notice Cached price with timestamp
    struct CachedPrice {
        int192 price;
        uint64 timestampNs;
    }

    // ============ ERC-7201 Namespaced Storage ============

    /// @custom:storage-location erc7201:hellotrade.storage.PriceOracleCache
    struct PriceOracleCacheStorage {
        /// @notice Stork oracle contract
        IUnifiedStork stork;
        /// @notice Local price cache keyed by marketId
        mapping(uint32 => CachedPrice) localPrices;
        /// @notice Mapping from marketId to helloStork feed ID (private feed for local caching)
        mapping(uint32 => bytes32) marketToHelloStorkId;
        /// @notice Reverse mapping from helloStork feed ID to marketId
        mapping(bytes32 => uint32) helloStorkIdToMarket;
        /// @notice Mapping from marketId to public Stork feed ID (for remote fallback)
        mapping(uint32 => bytes32) marketToStorkId;
        /// @notice Validity period for local cached prices in nanoseconds
        uint256 validTimePeriodNs;
    }

    // keccak256(abi.encode(uint256(keccak256("hellotrade.storage.PriceOracleCache")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant PRICE_ORACLE_CACHE_STORAGE_LOCATION =
        0x32a9ac9454c1bd4d04da8f0cfcc7d2c6bd8506fc54889d63d0998574fe99e400;

    function _getPriceOracleCacheStorage() private pure returns (PriceOracleCacheStorage storage $) {
        assembly {
            $.slot := PRICE_ORACLE_CACHE_STORAGE_LOCATION
        }
    }

    // ============ Internal Storage Getters ============

    /// @notice Get stork oracle contract
    function _stork() internal view returns (IUnifiedStork) {
        return _getPriceOracleCacheStorage().stork;
    }

    /// @notice Get local price for a market
    function _localPrices(uint32 marketId) internal view returns (CachedPrice storage) {
        return _getPriceOracleCacheStorage().localPrices[marketId];
    }

    /// @notice Get helloStork feed ID for a market
    function _marketToHelloStorkId(uint32 marketId) internal view returns (bytes32) {
        return _getPriceOracleCacheStorage().marketToHelloStorkId[marketId];
    }

    /// @notice Get market ID for a helloStork feed ID
    function _helloStorkIdToMarket(bytes32 helloStorkId) internal view returns (uint32) {
        return _getPriceOracleCacheStorage().helloStorkIdToMarket[helloStorkId];
    }

    /// @notice Get public Stork feed ID for a market
    function _marketToStorkId(uint32 marketId) internal view returns (bytes32) {
        return _getPriceOracleCacheStorage().marketToStorkId[marketId];
    }

    /// @notice Get validity period for local cached prices
    function _validTimePeriodNs() internal view returns (uint256) {
        return _getPriceOracleCacheStorage().validTimePeriodNs;
    }

    // ============ Constants ============

    /// @notice Slot offset for tstore price cache (avoid collision with other tstore usage)
    uint256 private constant TSTORE_PRICE_SLOT_OFFSET = 0x50524943455F5F5F; // "PRICE___" in hex

    // ============ Initialization ============

    function __PriceOracleCache_init(address stork_) internal onlyInitializing {
        PriceOracleCacheStorage storage $ = _getPriceOracleCacheStorage();
        $.stork = IUnifiedStork(stork_);
        $.validTimePeriodNs = 5e9; // 5 seconds
    }

    // ============ Price Updates ============

    /// @notice Update prices from HelloStork inputs
    /// @dev Verifies signatures, derives marketId from helloStorkIdToMarket mapping,
    ///      writes to both local storage and tstore
    /// @param inputs Array of HelloStork price inputs
    function _updatePrices(StorkStructs.TemporalNumericValueInput[] calldata inputs) internal {
        if (inputs.length == 0) return;

        address storkPubKey = _stork().storkPublicKey();

        for (uint256 i = 0; i < inputs.length; ++i) {
            _updatePrice(inputs[i], storkPubKey);
        }
    }

    function _updatePricesWithCache(StorkStructs.TemporalNumericValueInput[] calldata inputs) internal {
        if (inputs.length == 0) return;

        address storkPubKey = _stork().storkPublicKey();

        for (uint256 i = 0; i < inputs.length; ++i) {
            uint256 price = _updatePrice(inputs[i], storkPubKey);
            _tstorePrice(_helloStorkIdToMarket(inputs[i].id), price);
        }
    }

    function _updatePrice(StorkStructs.TemporalNumericValueInput calldata input, address storkPubKey)
        internal
        returns (uint256 price)
    {
        PriceOracleCacheStorage storage $ = _getPriceOracleCacheStorage();

        // Derive marketId from HelloStork reverse mapping
        uint32 marketId = $.helloStorkIdToMarket[input.id];

        if (marketId == 0) {
            revert UnknownHelloStorkId(input.id);
        }
        if (!_verifyStorkSignature(storkPubKey, input)) {
            revert StorkErrors.InvalidSignature();
        }

        uint64 newTimestamp = input.temporalNumericValue.timestampNs;
        int192 newPrice = input.temporalNumericValue.quantizedValue;
        uint64 oldTimestamp = $.localPrices[marketId].timestampNs;

        // If timestamp is older, revert
        if (newTimestamp < oldTimestamp) {
            revert StorkErrors.StaleValue();
        } else if (newTimestamp == oldTimestamp) {
            return int256($.localPrices[marketId].price).abs();
        }

        $.localPrices[marketId] = CachedPrice({price: newPrice, timestampNs: newTimestamp});

        emit IStorkEvents.ValueUpdate(input.id, newTimestamp, newPrice);

        return int256(newPrice).abs();
    }

    // ============ Price Retrieval ============

    function getPrice(uint32 marketId) external view returns (uint256 price) {
        return _getPrice(marketId);
    }

    /// @notice Get price for a market with 2-tier fallback
    /// @dev 1. Tstore → 2. Local cache → 3. Remote (Stork contract)
    /// @param marketId The market ID
    /// @return price The price (always positive)
    function _getPrice(uint32 marketId) internal view virtual returns (uint256 price) {
        // 1. Check tstore first (current tx cache)
        price = _tloadPrice(marketId);
        if (price != 0) {
            return price;
        }

        PriceOracleCacheStorage storage $ = _getPriceOracleCacheStorage();

        // 2. Check local storage cache
        CachedPrice memory cached = $.localPrices[marketId];
        if (_isPriceValid(cached)) {
            int256 rawPrice = int256(cached.price);
            if (rawPrice < 0) revert NegativePrice();
            return rawPrice.abs();
        }

        // 3. Fallback to remote Stork
        bytes32 storkId = $.marketToStorkId[marketId];
        if (storkId != bytes32(0)) {
            try $.stork.getTemporalNumericValueV1(storkId) returns (StorkStructs.TemporalNumericValue memory value) {
                if (value.timestampNs != 0) {
                    int256 rawPrice = int256(value.quantizedValue);
                    if (rawPrice < 0) revert NegativePrice();
                    return rawPrice.abs();
                }
            } catch {}
        }

        revert AllOraclesFailed();
    }

    /// @notice Get price and cache in tstore for subsequent calls this tx
    /// @param marketId The market ID
    /// @return price The price
    function _getPriceAndCache(uint32 marketId) internal returns (uint256 price) {
        // Check tstore first
        price = _tloadPrice(marketId);
        if (price != 0) {
            return price;
        }

        // Get price via fallback chain
        price = _getPrice(marketId);

        // Cache in tstore for rest of tx
        _tstorePrice(marketId, price);

        return price;
    }

    // ============ Transient Storage Helpers ============

    function _tstorePrice(uint32 marketId, uint256 price) private {
        uint256 slot = TSTORE_PRICE_SLOT_OFFSET + marketId;
        assembly {
            tstore(slot, price)
        }
    }

    function _tloadPrice(uint32 marketId) private view returns (uint256 price) {
        uint256 slot = TSTORE_PRICE_SLOT_OFFSET + marketId;
        assembly {
            price := tload(slot)
        }
    }

    // ============ Validation Helpers ============

    function _isPriceValid(CachedPrice memory cached) private view returns (bool) {
        if (cached.timestampNs == 0) return false;
        return (block.timestamp * 1e9) <= cached.timestampNs + _validTimePeriodNs();
    }

    function _verifyStorkSignature(address storkPubKey, StorkStructs.TemporalNumericValueInput calldata input)
        private
        pure
        returns (bool)
    {
        // Must match Stork's getStorkMessageHashV1 which uses uint256/int256
        bytes32 msgHash = keccak256(
            abi.encodePacked(
                storkPubKey,
                input.id,
                uint256(input.temporalNumericValue.timestampNs),
                int256(input.temporalNumericValue.quantizedValue),
                input.publisherMerkleRoot,
                input.valueComputeAlgHash
            )
        );

        bytes32 signedHash = MessageHashUtils.toEthSignedMessageHash(msgHash);
        bytes memory signature = abi.encodePacked(input.r, input.s, input.v);
        address signer = ECDSA.recover(signedHash, signature);
        return signer == storkPubKey;
    }

    // ============ Admin Setters ============

    /// @notice Set HelloStork feed ID for a market (private feed for local caching)
    /// @dev Maintains both forward and reverse mappings
    function _setMarketHelloStorkId(uint32 marketId, bytes32 helloStorkId) internal {
        PriceOracleCacheStorage storage $ = _getPriceOracleCacheStorage();

        if (marketId == 0) revert UintZero();
        if (helloStorkId == bytes32(0)) revert BytesZero();

        bytes32 oldId = $.marketToHelloStorkId[marketId];
        uint256 oldMkt = $.helloStorkIdToMarket[helloStorkId];
        if (oldId != bytes32(0) || oldMkt != 0) {
            revert MarketInUse(marketId, helloStorkId);
        }
        $.marketToHelloStorkId[marketId] = helloStorkId;
        $.helloStorkIdToMarket[helloStorkId] = marketId;
    }

    function _clearMarketHelloStorkId(uint32 marketId, bytes32 helloStorkId) internal {
        PriceOracleCacheStorage storage $ = _getPriceOracleCacheStorage();

        bytes32 oldId = $.marketToHelloStorkId[marketId];
        uint256 oldMkt = $.helloStorkIdToMarket[helloStorkId];
        if (oldId == bytes32(0) || oldMkt == 0) {
            revert InvalidMarketMapping(marketId, helloStorkId);
        }

        delete $.marketToHelloStorkId[marketId];
        delete $.helloStorkIdToMarket[helloStorkId];
    }

    /// @notice Set public Stork feed ID for a market (for remote fallback)
    function _setMarketStorkId(uint32 marketId, bytes32 storkId) internal {
        _getPriceOracleCacheStorage().marketToStorkId[marketId] = storkId;
    }

    function _setValidTimePeriodNs(uint256 period) internal {
        _getPriceOracleCacheStorage().validTimePeriodNs = period;
    }

    /// @notice Set local price for a market (for testing/initialization)
    function _setLocalPrice(uint32 marketId, CachedPrice memory cached) internal {
        _getPriceOracleCacheStorage().localPrices[marketId] = cached;
    }

    // ============ Public View Getters ============

    /// @notice Get stork oracle contract (public view)
    function stork() public view returns (IUnifiedStork) {
        return _stork();
    }

    /// @notice Get local price for a market (public view)
    /// @dev Returns tuple to match old auto-generated mapping getter signature
    function localPrices(uint32 marketId) public view returns (int192 price, uint64 timestampNs) {
        CachedPrice storage cached = _localPrices(marketId);
        return (cached.price, cached.timestampNs);
    }

    /// @notice Get helloStork feed ID for a market (public view)
    function marketToHelloStorkId(uint32 marketId) public view returns (bytes32) {
        return _marketToHelloStorkId(marketId);
    }

    /// @notice Get market ID for a helloStork feed ID (public view)
    function helloStorkIdToMarket(bytes32 helloStorkId) public view returns (uint32) {
        return _helloStorkIdToMarket(helloStorkId);
    }

    /// @notice Get public Stork feed ID for a market (public view)
    function marketToStorkId(uint32 marketId) public view returns (bytes32) {
        return _marketToStorkId(marketId);
    }

    /// @notice Get validity period for local cached prices (public view)
    function validTimePeriodNs() public view returns (uint256) {
        return _validTimePeriodNs();
    }
}

