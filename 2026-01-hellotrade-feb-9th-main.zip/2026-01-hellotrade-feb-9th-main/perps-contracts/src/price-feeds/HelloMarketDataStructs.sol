// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

struct MarketConfig {
    uint32 maxLeverage; // 4
    uint32 defaultLeverage; // 8
    uint32 minFundingInterval; // 12
    int32 fundingMax; // 16
    int32 fundingMin; // 20
    uint8 pricePrecision; // 21
    uint8 basePrecision; // 22
    uint8 quotePrecision; // 23
}

struct FundingInstant {
    // Cumulative funding index as a 1e18 number
    int192 cumulativeFundingIdx;
    uint32 lastUpdateTimestamp;
    uint32 lastUpdateBlock;
}
