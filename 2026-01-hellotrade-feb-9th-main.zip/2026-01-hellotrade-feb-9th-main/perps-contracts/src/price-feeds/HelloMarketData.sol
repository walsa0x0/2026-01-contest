// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

import {IHelloMarketDataEvents} from "../interfaces/IHelloMarketDataEvents.sol";
import {IHelloMarketDataErrors} from "../interfaces/IHelloMarketDataErrors.sol";
import {MarketConfig, FundingInstant} from "./HelloMarketDataStructs.sol";
import {Position} from "../lib/Position.sol";
import {PositionMetrics, PositionMetricsLib} from "../lib/PositionMetrics.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

import {Initializable} from "@openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";

/// @notice a light store for market data, only storing latest pricing in USDC-unit value + 18 decimals (1.0 USDC = 1e24)
contract HelloMarketData is IHelloMarketDataEvents, IHelloMarketDataErrors, Initializable {
    int256 constant GLOBAL_FUNDING_MAX = 1_000_000_000;
    int256 constant GLOBAL_FUNDING_MIN = -1_000_000_000;
    int256 constant FUNDING_DIVISOR = 10_000_000_000;
    uint8 constant MAX_PRECISION = 18;

    /// @custom:storage-location erc7201:hellotrade.storage.HelloMarketData
    struct HelloMarketDataStorage {
        mapping(uint256 => MarketConfig) marketConfig;
        mapping(uint256 => FundingInstant) lastFundingInstant;
    }

    // keccak256(abi.encode(uint256(keccak256("hellotrade.storage.HelloMarketData")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant HELLO_MARKET_DATA_STORAGE_LOCATION =
        0x6082d6b02064204d8c4e5a3c7f4c9db3c9eacac217dee204f44e3ce97e919900;

    function _getHelloMarketDataStorage() private pure returns (HelloMarketDataStorage storage $) {
        assembly {
            $.slot := HELLO_MARKET_DATA_STORAGE_LOCATION
        }
    }

    /// @notice Get market config for a market
    function _marketConfig(uint256 market) internal view returns (MarketConfig storage) {
        return _getHelloMarketDataStorage().marketConfig[market];
    }

    /// @notice Get last funding instant for a market
    function _lastFundingInstant(uint256 market) internal view returns (FundingInstant storage) {
        return _getHelloMarketDataStorage().lastFundingInstant[market];
    }

    /// @notice Calculate position metrics for a position at a given price
    /// @param pos The position to calculate metrics for
    /// @param market The market ID
    /// @param price The price to use for calculation
    /// @return pm The calculated position metrics
    function _calcPositionMetrics(Position memory pos, uint256 market, uint256 price)
        internal
        view
        returns (PositionMetrics memory pm)
    {
        pm = PositionMetricsLib.calculate(
            pos, price, _lastFundingInstant(market).cumulativeFundingIdx, _marketConfig(market)
        );
    }

    /// @notice Calculate position metrics with pre-loaded market config
    /// @param pos The position to calculate metrics for
    /// @param market The market ID (for funding index lookup)
    /// @param price The price to use for calculation
    /// @param mktConfig The pre-loaded market config
    /// @return pm The calculated position metrics
    function _calcPositionMetricsWithConfig(
        Position memory pos,
        uint256 market,
        uint256 price,
        MarketConfig memory mktConfig
    ) internal view returns (PositionMetrics memory pm) {
        pm = PositionMetricsLib.calculate(pos, price, _lastFundingInstant(market).cumulativeFundingIdx, mktConfig);
    }

    function __HelloMarketData_init() internal onlyInitializing {}

    function _updateFundingInstant(uint32 market, int256 fundingRate, int256 priceMark) internal virtual {
        HelloMarketDataStorage storage $ = _getHelloMarketDataStorage();
        FundingInstant memory lastInstant = $.lastFundingInstant[market];

        _validateFundingInstant(lastInstant.lastUpdateTimestamp, market, fundingRate);

        int192 prevFundingIdx = lastInstant.cumulativeFundingIdx;
        int192 newFundingIdx = SafeCastLib.toInt192(fundingRate * priceMark / FUNDING_DIVISOR);

        $.lastFundingInstant[market] = FundingInstant({
            cumulativeFundingIdx: prevFundingIdx + newFundingIdx,
            lastUpdateTimestamp: uint32(block.timestamp),
            lastUpdateBlock: uint32(block.number)
        });

        emit FundingUpdated(uint32(block.timestamp), market, prevFundingIdx, fundingRate, priceMark);
    }

    function _validateFundingInstant(uint256 lastUpdateTimestamp, uint32 market, int256 fundingRate)
        internal
        view
        virtual
    {
        MarketConfig memory config = _marketConfig(market);
        if (fundingRate > config.fundingMax) {
            revert FundingOverMax(fundingRate, config.fundingMax);
        }
        if (fundingRate < config.fundingMin) {
            revert FundingUnderMin(fundingRate, config.fundingMin);
        }
        if (block.timestamp - lastUpdateTimestamp < config.minFundingInterval) revert BadFundingInterval();
    }

    function _setFundingConfig(uint32 market, int32 fundingMax, int32 fundingMin, uint32 minFundingInterval)
        internal
        virtual
    {
        if (fundingMin > fundingMax) revert FundingMinOverMax();
        if (fundingMax > GLOBAL_FUNDING_MAX) revert FundingMaxOverGlobal();
        if (fundingMin < GLOBAL_FUNDING_MIN) revert FundingMinUnderGlobal();
        if (minFundingInterval == 0) revert BadGlobalFundingInterval();

        HelloMarketDataStorage storage $ = _getHelloMarketDataStorage();
        MarketConfig memory config = $.marketConfig[market];

        config.fundingMax = fundingMax;
        config.fundingMin = fundingMin;
        config.minFundingInterval = minFundingInterval;

        $.marketConfig[market] = config;
    }

    function _setMarketConfig(uint32 market, MarketConfig memory config) internal virtual {
        if (config.maxLeverage == 0) revert UintZero();
        if (config.pricePrecision == 0) revert UintZero();
        if (config.pricePrecision > MAX_PRECISION) revert PrecisionTooHigh(config.pricePrecision);
        if (config.basePrecision == 0) revert UintZero();
        if (config.basePrecision > MAX_PRECISION) revert PrecisionTooHigh(config.basePrecision);
        if (config.quotePrecision == 0) revert UintZero();
        if (config.quotePrecision > MAX_PRECISION) revert PrecisionTooHigh(config.quotePrecision);
        if (config.fundingMin > config.fundingMax) revert FundingMinOverMax();
        if (config.fundingMax > GLOBAL_FUNDING_MAX) revert FundingMaxOverGlobal();
        if (config.fundingMin < GLOBAL_FUNDING_MIN) revert FundingMinUnderGlobal();
        if (config.minFundingInterval == 0) revert BadGlobalFundingInterval();
        _getHelloMarketDataStorage().marketConfig[market] = config;
        emit MarketConfigSet(market, config);
        _getHelloMarketDataStorage().marketConfig[market] = config;
        emit MarketConfigSet(market, config);
    }

    function _setDefaultLeverage(uint32 market, uint32 leverage) internal virtual {
        HelloMarketDataStorage storage $ = _getHelloMarketDataStorage();
        MarketConfig memory data = $.marketConfig[market];
        if (leverage > data.maxLeverage) {
            revert DefaultLeverageOverMarket(leverage, data.maxLeverage);
        }
        $.marketConfig[market].defaultLeverage = leverage;
    }

    /// @notice Set last funding instant for a market (for initialization/testing)
    function _setLastFundingInstant(uint256 market, FundingInstant memory instant) internal {
        _getHelloMarketDataStorage().lastFundingInstant[market] = instant;
    }

    /// @notice Get market config for a market (public view)
    function marketConfig(uint256 market) public view returns (MarketConfig memory) {
        return _marketConfig(market);
    }

    /// @notice Get last funding instant for a market (public view)
    function lastFundingInstant(uint256 market) public view returns (FundingInstant memory) {
        return _lastFundingInstant(market);
    }
}
