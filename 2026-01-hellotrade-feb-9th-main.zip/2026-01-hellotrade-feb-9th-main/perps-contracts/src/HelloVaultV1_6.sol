// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

import {Initializable} from "@openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";
import {EIP712Upgradeable} from "@openzeppelin-contracts-upgradeable/utils/cryptography/EIP712Upgradeable.sol";
import {UUPSUpgradeable} from "@openzeppelin-contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";

import {IERC20} from "@openzeppelin-contracts/token/ERC20/IERC20.sol";
import {IERC20Permit} from "@openzeppelin-contracts/token/ERC20/extensions/IERC20Permit.sol";

import {SafeERC20} from "@openzeppelin-contracts/token/ERC20/utils/SafeERC20.sol";
import {ECDSA} from "@openzeppelin-contracts/utils/cryptography/ECDSA.sol";

import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

import {Order, OrderV2, Liquidation, ORDER_FLAG_ISOLATED} from "./lib/Order.sol";
import {Position} from "./lib/Position.sol";
import {PositionMetrics, PositionMetricsLib} from "./lib/PositionMetrics.sol";

import {Bitmap} from "./lib/NonceBitmap.sol";
import {Math} from "./lib/Math.sol";
import {SignerUtils} from "./lib/SignerUtils.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

import {FundingInstant, MarketConfig} from "./price-feeds/HelloMarketData.sol";
import {HelloFees} from "./Fees.sol";
import {HelloRoles} from "./Roles.sol";
import {SignerDelegator} from "./access/SignerDelegator.sol";
import {CrossMarginVault} from "./vaults/CrossMarginVault.sol";
import {
    LiquidateeResult,
    FillResult,
    LiquidationCrossesZero,
    ADLHealthCheckFailed,
    ADLLastPositionNegativeEquity
} from "./vaults/VaultUtils.sol";
import {InsufficientMargin} from "./lib/PositionMetrics.sol";
import {IsolatedMarginVault} from "./vaults/IsolatedMarginVault.sol";
import {IsolatedMarginAccount} from "./lib/IsolatedMarginAccount.sol";

import {IHelloVaultV1_6} from "./interfaces/IHelloVaultV1_6.sol";
import {IHelloVaultEvents} from "./interfaces/IHelloVaultEvents.sol";
import {IHelloVaultErrors} from "./interfaces/IHelloVaultErrors.sol";

struct GlobalState {
    bool paused;
    bool breakGlass;
    uint64 heartbeat;
    uint128 trackingHead;
}

/// @custom:oz-upgrades-from HelloVaultEmpty
contract HelloVaultV1_6 is
    IHelloVaultV1_6,
    IHelloVaultEvents,
    IHelloVaultErrors,
    Initializable,
    UUPSUpgradeable,
    EIP712Upgradeable,
    CrossMarginVault,
    IsolatedMarginVault,
    HelloRoles,
    SignerDelegator
{
    using ECDSA for bytes32;
    using SafeERC20 for IERC20;
    using Math for int256;
    using PositionMetricsLib for PositionMetrics;

    uint256 constant HEARTBEAT_PERIOD = 7 days;

    /// @custom:storage-location erc7201:hellotrade.storage.HelloVault
    struct HelloVaultStorage {
        /// @notice Order ID keyed fill tracking
        mapping(bytes32 => uint256) orderFills;
        /// @notice Nonce bitmap per account
        mapping(address => Bitmap) nonces;
        /// @notice Global state (pause, breakglass, heartbeat, trackingHead)
        GlobalState globalState;
        /// @notice Quote token address (USDC)
        address quoteToken;
        /// @notice Total balance in the vault
        uint256 totalBalance;
    }

    // keccak256(abi.encode(uint256(keccak256("hellotrade.storage.HelloVault")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant HELLO_VAULT_STORAGE_LOCATION =
        0xb10e2d527612073b26eecdfd717e6a320cf44b4afac2b0732d9fcbe2b7fa0c00;

    function _getHelloVaultStorage() private pure returns (HelloVaultStorage storage $) {
        assembly {
            $.slot := HELLO_VAULT_STORAGE_LOCATION
        }
    }

    /// @notice Get order fill amount by order ID
    function orderFills(bytes32 orderId) public view returns (uint256) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        return $.orderFills[orderId];
    }

    /// @notice Get global state
    function globalState() public view returns (GlobalState memory) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        return $.globalState;
    }

    /// @notice Get quote token address
    function quoteToken() public view returns (address) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        return $.quoteToken;
    }

    /// @notice Get total balance
    function totalBalance() public view returns (uint256) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        return $.totalBalance;
    }

    modifier notPaused() {
        _notPaused();
        _;
    }

    modifier notBreakGlass() {
        _notBreakGlass();
        _;
    }

    // /// @custom:oz-upgrades-unsafe-allow constructor
    // constructor() {
    //     _disableInitializers();
    // }

    function initialize(address _owner, address _relayer, address _token, address _stork) external virtual initializer {
        __EIP712_init("HelloVault", "1");
        __CrossMarginVault_init(_stork);
        __IsolatedMarginVault_init();
        __HelloRoles_init();

        _grantRole(DEFAULT_ADMIN_ROLE, _owner);
        _grantRole(ADMIN_ROLE, _owner);
        _grantRole(RELAYER_ROLE, _relayer);

        HelloVaultStorage storage $ = _getHelloVaultStorage();
        $.quoteToken = _token;
    }

    ///////////////////////
    // Relayer functions //
    ///////////////////////

    function setTrackingHead(uint256 newHead) external onlyRole(RELAYER_ROLE) notBreakGlass {
        _setTrackingHead(newHead);
    }

    function updateFundingInstant(uint32 market, int256 fundingRate, int256 priceMark, uint256 trackingHead_)
        public
        onlyRole(RELAYER_ROLE)
        notPaused
        notBreakGlass
    {
        _updateFundingInstant(market, fundingRate, priceMark);
        _setTrackingHead(trackingHead_);
    }

    /// @notice Handles a matched fill between a maker and taker order (cross-margin only).
    ///
    /// @param prices Stork prices for the market passed inline for local stork
    /// value updates. Backup onchain feeds are used if any prices are stale.
    /// Should not include any markets in which maker and taker do not hold positions.
    /// @param prices Array of Stork price inputs (marketId derived from storkIdToMarket mapping)
    /// @param makerOrder The maker order.
    /// @param makerSig The signature of the maker order.
    /// @param takerOrder The taker order.
    /// @param takerSig The signature of the taker order.
    /// @param fillSize The size of the fill.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    function handleMatchedFill(
        StorkStructs.TemporalNumericValueInput[] calldata prices,
        Order calldata makerOrder,
        bytes calldata makerSig,
        Order calldata takerOrder,
        bytes calldata takerSig,
        uint256 fillSize,
        uint256 trackingHead_
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        _updatePricesWithCache(prices);
        _validateMatchedFill(makerOrder, false, takerOrder);

        uint256 execPrice = makerOrder.limitPrice;

        int256 fillSize_ = SafeCastLib.toInt256(fillSize);
        int256 sizeForDirection =
            makerOrder.size == 0 ? -getPosition(makerOrder.account, makerOrder.market, false).size : makerOrder.size;

        (int256 makerFill, int256 takerFill) = sizeForDirection < 0 ? (-fillSize_, fillSize_) : (fillSize_, -fillSize_);

        _validateFill(makerOrder, makerSig, makerFill);
        _validateFill(takerOrder, takerSig, takerFill);

        // Standard Order always routes to cross-margin
        _handleFill(makerOrder, makerFill, execPrice, true, trackingHead_, false);
        _handleFill(takerOrder, takerFill, execPrice, false, trackingHead_, false);

        _setTrackingHead(trackingHead_);
    }

    /// @notice Handles a matched fill with OrderV2 (supports cross or isolated margin via flags).
    /// @dev flags bit 0: 0 = cross margin, 1 = isolated margin
    ///
    /// @param prices Stork prices for the market.
    /// @param makerOrder The maker order (OrderV2 with flags).
    /// @param makerSig The signature of the maker order.
    /// @param takerOrder The taker order (OrderV2 with flags).
    /// @param takerSig The signature of the taker order.
    /// @param fillSize The size of the fill.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    function handleMatchedFillV2(
        StorkStructs.TemporalNumericValueInput[] calldata prices,
        OrderV2 calldata makerOrder,
        bytes calldata makerSig,
        OrderV2 calldata takerOrder,
        bytes calldata takerSig,
        uint256 fillSize,
        uint256 trackingHead_
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        _validateMatchedFill(makerOrder.toOrder(), makerOrder.isIsolated(), takerOrder.toOrder());

        uint256 execPrice = makerOrder.limitPrice;

        int256 fillSize_ = SafeCastLib.toInt256(fillSize);
        int256 sizeForDirection = makerOrder.size == 0
            ? -getPosition(makerOrder.account, makerOrder.market, makerOrder.isIsolated()).size
            : makerOrder.size;

        (int256 makerFill, int256 takerFill) = sizeForDirection < 0 ? (-fillSize_, fillSize_) : (fillSize_, -fillSize_);

        _validateFillV2(makerOrder, makerSig, makerFill);
        _validateFillV2(takerOrder, takerSig, takerFill);

        // Route based on flags
        Order memory makerOrderStd = makerOrder.toOrder();
        Order memory takerOrderStd = takerOrder.toOrder();

        _handleFill(makerOrderStd, makerFill, execPrice, true, trackingHead_, makerOrder.isIsolated());
        _handleFill(takerOrderStd, takerFill, execPrice, false, trackingHead_, takerOrder.isIsolated());

        _setTrackingHead(trackingHead_);
    }

    /// @notice Liquidates an account with a maker signature. It does not require a signature
    /// for the party undergoing liqudiation. Instead, it validates that the account is under
    /// maintenance margin.
    ///
    /// @param liquidatorOrder The order from the liquidator.
    /// @param liquidatorSig The signature of the liquidator order.
    /// @param liquidated The liquidation object.
    /// @param fillSize The size of the fill.
    /// @param execPrice The execution price.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    function liquidate(
        Order calldata liquidatorOrder,
        bytes calldata liquidatorSig,
        Liquidation calldata liquidated,
        uint256 fillSize,
        uint256 execPrice,
        uint256 trackingHead_
    ) public onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        _liquidate(liquidatorOrder, liquidatorSig, liquidated, fillSize, execPrice, trackingHead_);
    }

    /// @notice Liquidates an account with a maker signature. It does not require a signature
    /// for the party undergoing liqudiation. Instead, it validates that the account is under
    /// maintenance margin.
    ///
    /// @param prices Stork prices for the market passed inline for local stork
    /// value updates. Backup onchain feeds are used if any prices are stale.
    /// Should not include any markets in which maker and taker do not hold positions.
    /// @param liquidatorOrder The order from the liquidator.
    /// @param liquidatorSig The signature of the liquidator order.
    function liquidateWithPrice(
        StorkStructs.TemporalNumericValueInput[] calldata prices,
        Order calldata liquidatorOrder,
        bytes calldata liquidatorSig,
        Liquidation calldata liquidated,
        uint256 fillSize,
        uint256 execPrice,
        uint256 trackingHead_
    ) public payable onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        _updatePrices(prices);
        _liquidate(liquidatorOrder, liquidatorSig, liquidated, fillSize, execPrice, trackingHead_);
    }

    /// @notice Internal function to liquidate an account.
    ///
    /// @param liquidatorOrder The order from the liquidator.
    /// @param liquidatorSig The signature of the liquidator order.
    /// @param liquidated The liquidation object.
    /// @param fillSize The size of the fill.
    /// @param execPrice The execution price.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    function _liquidate(
        Order calldata liquidatorOrder,
        bytes calldata liquidatorSig,
        Liquidation calldata liquidated,
        uint256 fillSize,
        uint256 execPrice,
        uint256 trackingHead_
    ) internal {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        // 1. Execute liquidatee fill in vault (validates, updates position/margin, calculates fee)
        LiquidateeResult memory result =
            _cmExecuteLiquidatee(liquidated.account, liquidated.market, fillSize, execPrice);

        // 2. Liquidator takes opposite side
        int256 liquidatorFill = -result.signedFill;

        // 3. Validate and handle liquidator's fill
        _validateFill(liquidatorOrder, liquidatorSig, liquidatorFill);
        _handleFill(liquidatorOrder, liquidatorFill, execPrice, true, trackingHead_, false);

        // 4. Send fee from liquidatee
        if (result.fee > 0) {
            _sendFee(liquidated.account, $.quoteToken, result.fee);
        }

        // 5. Emit event
        emit LiquidatedV2(
            liquidated.account,
            liquidated.market,
            execPrice,
            result.signedFill,
            result.realizedPnl,
            result.fee,
            false,
            trackingHead_
        );

        _setTrackingHead(trackingHead_);
    }

    /// @notice Internal function to liquidate a position (cross or isolated)
    function _liquidateV2(
        OrderV2 calldata liquidatorOrder,
        bytes calldata liquidatorSig,
        address liquidatedAccount,
        uint32 liquidatedMarket,
        bool liquidatedIsIsolated,
        uint256 fillSize,
        uint256 execPrice,
        uint256 trackingHead_
    ) internal {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        // 1. Execute liquidatee fill in vault (validates, updates position/margin, calculates fee)
        LiquidateeResult memory result = liquidatedIsIsolated
            ? _isoExecuteLiquidatee(liquidatedAccount, liquidatedMarket, fillSize, execPrice)
            : _cmExecuteLiquidatee(liquidatedAccount, liquidatedMarket, fillSize, execPrice);

        // 2. Liquidator takes opposite side
        int256 liquidatorFill = -result.signedFill;

        // 3. Validate and handle liquidator's fill
        _validateFillV2(liquidatorOrder, liquidatorSig, liquidatorFill);

        _handleFill(
            liquidatorOrder.toOrder(), liquidatorFill, execPrice, true, trackingHead_, liquidatorOrder.isIsolated()
        );

        // 4. Send fee from liquidatee
        if (result.fee > 0) {
            _sendFee(liquidatedAccount, $.quoteToken, result.fee);
        }

        // 5. Emit event
        emit LiquidatedV2(
            liquidatedAccount,
            liquidatedMarket,
            execPrice,
            result.signedFill,
            result.realizedPnl,
            result.fee,
            liquidatedIsIsolated,
            trackingHead_
        );

        _setTrackingHead(trackingHead_);
    }

    /// @notice ADL endpoint V2 -- manually close out two positions against each-other and
    /// rebalance the defunct account. Supports both cross and isolated margin.
    /// Requires a signature from neither party.
    ///
    /// @param closer The order from the closer (V2 with flags).
    /// @param liquidated The order from the liquidated (V2 with flags).
    /// @param fillSize The size of the fill.
    /// @param execPrice The execution price.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    function deleverV2(
        OrderV2 calldata closer,
        OrderV2 calldata liquidated,
        uint256 fillSize,
        uint256 execPrice,
        uint256 trackingHead_
    ) public onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        _deleverV2(closer, liquidated, fillSize, execPrice, trackingHead_);
    }

    /// @notice ADL endpoint V2 with prices -- manually close out two positions against each-other and
    /// rebalance the defunct account. Supports both cross and isolated margin.
    /// Requires a signature from neither party.
    ///
    /// @param prices Stork prices for the market passed inline for local stork
    /// value updates. Backup onchain feeds are used if any prices are stale.
    /// @param closer The order from the closer (V2 with flags).
    /// @param liquidated The order from the liquidated (V2 with flags).
    /// @param fillSize The size of the fill.
    /// @param execPrice The execution price.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    function deleverWithPriceV2(
        StorkStructs.TemporalNumericValueInput[] calldata prices,
        OrderV2 calldata closer,
        OrderV2 calldata liquidated,
        uint256 fillSize,
        uint256 execPrice,
        uint256 trackingHead_
    ) public onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        _updatePrices(prices);
        _deleverV2(closer, liquidated, fillSize, execPrice, trackingHead_);
    }

    /// @notice Internal function to delever an account (V2 with isolated margin support).
    ///
    /// @param closer The order from the closer (V2 with flags).
    /// @param liquidated The order from the liquidated (V2 with flags).
    /// @param fillSize The size of the fill.
    /// @param execPrice The execution price.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    function _deleverV2(
        OrderV2 calldata closer,
        OrderV2 calldata liquidated,
        uint256 fillSize,
        uint256 execPrice,
        uint256 trackingHead_
    ) internal {
        if (closer.size == 0 || liquidated.size == 0) revert AmountZero();
        _validateMatchedFill(closer.toOrder(), closer.isIsolated(), liquidated.toOrder());

        int256 closerFill;
        int256 liquidatedFill;
        {
            int256 fillSize_ = SafeCastLib.toInt256(fillSize);
            (closerFill, liquidatedFill) = closer.size < 0 ? (-fillSize_, fillSize_) : (fillSize_, -fillSize_);
        }

        bool liquidatedIsIsolated = liquidated.isIsolated();
        bool closerIsIsolated = closer.isIsolated();

        // Validate 'liquidated' account is underwater based on margin mode
        if (liquidatedIsIsolated) {
            _isoValidateDelever(liquidated.account, liquidated.market);
        } else {
            _cmValidateDelever(liquidated.account);
        }

        // Validate reduce-only for both parties
        _validateADLReduceOnly(closer.account, closer.market, closerIsIsolated, closerFill);
        _validateADLReduceOnly(liquidated.account, liquidated.market, liquidatedIsIsolated, liquidatedFill);

        // Capture liquidated health/equity before fills (at execPrice)
        (int256 equityBefore, uint256 maintMarginBefore) =
            _getAccountHealthMetrics(liquidated.account, liquidated.market, liquidatedIsIsolated, execPrice);

        // Handle fills for both parties
        _handleFill(liquidated.toOrder(), liquidatedFill, execPrice, false, trackingHead_, liquidatedIsIsolated);
        _handleFill(closer.toOrder(), closerFill, execPrice, true, trackingHead_, closerIsIsolated);

        // Validate ADL health/equity constraints for liquidated (at execPrice)
        _validateADLHealthConstraints(
            liquidated.account, liquidated.market, liquidatedIsIsolated, execPrice, equityBefore, maintMarginBefore
        );

        _setTrackingHead(trackingHead_);
        emit DeleveredV2(
            closer.account,
            liquidated.account,
            closer.market,
            fillSize,
            execPrice,
            closerIsIsolated,
            liquidatedIsIsolated
        );
    }

    /// @notice Validate reduce-only for ADL fills
    function _validateADLReduceOnly(address account, uint32 market, bool isIsolated, int256 fillSize) internal view {
        Position memory pos = isIsolated ? getIsoPosition(account, market) : getPosition(account, market, isIsolated);
        _requireReduceOnly(pos, fillSize);
    }

    /// @notice Get health metrics (equity, maintenanceMargin) for an account at a specific price
    /// @dev For cross-margin: uses execPrice for the specified market, mark price for others
    /// @dev For isolated: uses execPrice for the position
    function _getAccountHealthMetrics(address account, uint32 market, bool isIsolated, uint256 execPrice)
        internal
        view
        returns (int256 equity, uint256 maintenanceMargin)
    {
        if (isIsolated) {
            IsolatedMarginAccount memory isoAcct = getIsoAccount(account, market);
            PositionMetrics memory pm = _calcPositionMetrics(isoAcct.position, market, execPrice);
            equity = pm.calcEquity(SafeCastLib.toInt256(isoAcct.margin));
            maintenanceMargin = pm.maintenanceMargin;
        } else {
            // Skip the affected market in aggregation, calculate it at execPrice
            PositionMetrics memory pmOtherMarkets = _cmAggregateWithMarkPrice(account, market);
            Position memory pos = getPosition(account, market, isIsolated);
            PositionMetrics memory pmThisMarket = _calcPositionMetrics(pos, market, execPrice);
            pmOtherMarkets.add(pmThisMarket);
            equity = pmOtherMarkets.calcEquity(getMargin(account));
            maintenanceMargin = pmOtherMarkets.maintenanceMargin;
        }
    }

    /// @notice Validate ADL health constraints after fills
    /// @dev Validates: health0 >= health1 && equity1 <= max(equity0, 0)
    /// @dev Also validates: equity >= 0 on last position close
    function _validateADLHealthConstraints(
        address account,
        uint32 market,
        bool isIsolated,
        uint256 execPrice,
        int256 equityBefore,
        uint256 maintMarginBefore
    ) internal view {
        (int256 equityAfter, uint256 maintMarginAfter) =
            _getAccountHealthMetrics(account, market, isIsolated, execPrice);

        // Health check: health0 >= health1
        // Using cross multiplication to avoid division: equity0 * maint1 >= equity1 * maint0
        // Note: health = equity / maintMargin, higher is better
        // (healthBefore >= healthAfter) => (equityBefore/maintBefore >= equityAfter/maintAfter)
        // => (equityBefore * maintAfter >= equityAfter * maintBefore)
        int256 healthCheckLhs = equityBefore * SafeCastLib.toInt256(maintMarginAfter);
        int256 healthCheckRhs = equityAfter * SafeCastLib.toInt256(maintMarginBefore);

        // Equity check: equity1 <= max(equity0, 0)
        int256 equityUpperBound = equityBefore > 0 ? equityBefore : int256(0);

        if (healthCheckLhs < healthCheckRhs || equityAfter > equityUpperBound) {
            revert ADLHealthCheckFailed(maintMarginBefore, maintMarginAfter, equityBefore, equityAfter);
        }

        // Last position close check: if no more positions, equity must be >= 0
        bool hasNoPositions = isIsolated ? getIsoPosition(account, market).size == 0 : getNumPositions(account) == 0;

        if (hasNoPositions && equityAfter < 0) {
            revert ADLLastPositionNegativeEquity(equityAfter);
        }
    }

    ///////////////////////////////////////
    // User Account Management Functions //
    ///////////////////////////////////////

    /// @notice Deposit quote token into the vault with a signature. Intended to be broadcasted by the relayer.
    ///
    /// @dev Nonce is checked by the ERC20Permit token, and is unrelated to this contract's bitmap nonces.
    ///
    /// @param owner The owner of the quote token.
    /// @param amount The amount of quote token to deposit.
    /// @param deadline The deadline for the permit.
    /// @param v The recovery byte of the signature.
    /// @param r The r value of the signature.
    /// @param s The s value of the signature.
    function depositWithSignature(
        address owner,
        uint256 amount,
        uint256 deadline,
        uint256 trackingHead_,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) public onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        _depositWithSignature(owner, amount, deadline, trackingHead_, r, s, v);
    }

    /// @notice Internal function to deposit with a signature.
    ///
    /// @param owner The owner of the quote token.
    /// @param amount The amount of quote token to deposit.
    /// @param deadline The deadline for the permit.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    /// @param sig The signature as a raw bytes payload.
    function depositWithSignature(
        address owner,
        uint256 amount,
        uint256 deadline,
        uint256 trackingHead_,
        bytes memory sig
    ) public onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly ("memory-safe") {
            r := mload(add(sig, 0x20))
            s := mload(add(sig, 0x40))
            v := byte(0, mload(add(sig, 0x60)))
        }
        _depositWithSignature(owner, amount, deadline, trackingHead_, r, s, v);
    }

    /// @notice Internal function to deposit with a signature.
    ///
    /// @param owner The owner of the quote token.
    /// @param amount The amount of quote token to deposit.
    /// @param deadline The deadline for the permit.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    /// @param r The r value of the signature.
    /// @param s The s value of the signature.
    /// @param v The recovery byte of the signature.
    function _depositWithSignature(
        address owner,
        uint256 amount,
        uint256 deadline,
        uint256 trackingHead_,
        bytes32 r,
        bytes32 s,
        uint8 v
    ) internal {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        // Validate deposit amount
        if (amount == 0) revert AmountZero();

        // Apply state changes
        _cmCreditMargin(owner, amount);

        $.totalBalance += amount;

        _setTrackingHead(trackingHead_);

        // Transfer tokens to vault
        _permitAndTransfer(owner, amount, deadline, v, r, s);

        // Retrieve nonce and emit event
        IERC20Permit token = IERC20Permit($.quoteToken);
        uint256 nonce = token.nonces(owner);
        emit Deposited(owner, amount, nonce);
    }

    /// @notice Withdraw quote token from the vault with a signature. Intended to be broadcasted by the relayer.
    ///
    /// @dev The nonce is managed by the global nonce bitmap.
    ///
    /// @param owner The owner of the quote token.
    /// @param amount The amount of quote token to withdraw.
    /// @param nonce The nonce of the withdrawal request.
    /// @param deadline The deadline for the withdrawal request.
    /// @param sig The signature as a raw bytes payload.
    function withdrawWithSignature(
        address owner,
        uint256 amount,
        uint256 nonce,
        uint256 deadline,
        uint256 trackingHead_,
        bytes calldata sig
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        // Validate deadline
        if (block.timestamp > deadline) revert DeadlineExpired();
        // Validate withdraw
        _validateWithdraw(owner, amount, nonce);

        // Verify signature
        bytes32 digest = _hashTypedDataV4(SignerUtils._buildWithdrawHash(owner, amount, nonce, deadline));
        _verifySignature(sig, digest, owner);

        // Apply state changes
        _cmDebitMargin(owner, amount);
        _setTrackingHead(trackingHead_);

        $.nonces[owner].burnNonce(nonce);
        $.totalBalance -= amount;

        // Transfer tokens to owner
        IERC20($.quoteToken).safeTransfer(owner, amount);

        emit WithdrawProcessed(owner, amount, nonce);
    }

    /// @notice Update the leverage for an account with a signature.
    ///
    /// @param account The account to update the leverage for.
    /// @param mkt The market to update the leverage for.
    /// @param leverage The new leverage.
    /// @param nonce The nonce of the leverage update request.
    /// @param deadline The deadline for the leverage update request.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    /// @param sig The signature as a raw bytes payload.
    function updateLeverageWithSignature(
        address account,
        uint32 mkt,
        uint32 leverage,
        uint256 nonce,
        uint256 deadline,
        uint256 trackingHead_,
        bytes calldata sig
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        if (block.timestamp > deadline) revert DeadlineExpired();
        if (nonceUsed(account, nonce)) revert NonceUsed();

        bytes32 digest = _hashTypedDataV4(SignerUtils._buildLeverageUpdateHash(account, mkt, leverage, nonce, deadline));

        _verifySignature(sig, digest, account);
        _validateLeverageSet(leverage, mkt);

        // Position does not have to be initialized for this call to be valid.
        _cmSetPositionLeverage(account, mkt, uint128(leverage));

        PositionMetrics memory pm = _cmAggAccount(account);
        int256 baseEquity = getMargin(account);

        if (!pm.coversAssignedMargin(baseEquity)) {
            revert InsufficientMargin(pm.calcEquity(baseEquity), pm.assignedMargin);
        }

        $.nonces[account].burnNonce(nonce);
        _setTrackingHead(trackingHead_);

        emit LeverageSet(account, mkt, leverage);
    }

    // ============================================================================
    // V2 ENDPOINTS - ISOLATED MARGIN SUPPORT
    // ============================================================================

    /// @notice Deposit quote token into the vault with a permit signature. V2 supports cross and isolated margin.
    ///
    /// @param owner The owner of the quote token.
    /// @param amount The amount of quote token to deposit.
    /// @param market The market (used only if flags indicates isolated).
    /// @param flags Bit flags: bit 0 = isolated (1) or cross (0).
    /// @param deadline The deadline for the permit.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    /// @param v The recovery byte of the signature.
    /// @param r The r value of the signature.
    /// @param s The s value of the signature.
    function depositWithSignatureV2(
        address owner,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 deadline,
        uint256 trackingHead_,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) public onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        _depositWithSignatureV2(owner, amount, market, flags, deadline, trackingHead_, r, s, v);
    }

    /// @notice Deposit quote token into the vault with a permit signature. V2 supports cross and isolated margin.
    ///
    /// @dev Nonce is checked by the ERC20Permit token, and is unrelated to this contract's bitmap nonces.
    ///
    /// @param owner The owner of the quote token.
    /// @param amount The amount of quote token to deposit.
    /// @param market The market (used only if flags indicates isolated).
    /// @param flags Bit flags: bit 0 = isolated (1) or cross (0).
    /// @param deadline The deadline for the permit.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    /// @param sig The signature as a raw bytes payload.
    function depositWithSignatureV2(
        address owner,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 deadline,
        uint256 trackingHead_,
        bytes memory sig
    ) public onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly ("memory-safe") {
            r := mload(add(sig, 0x20))
            s := mload(add(sig, 0x40))
            v := byte(0, mload(add(sig, 0x60)))
        }
        _depositWithSignatureV2(owner, amount, market, flags, deadline, trackingHead_, r, s, v);
    }

    /// @notice Internal function to deposit with a permit signature. V2 supports cross and isolated margin.
    ///
    /// @param owner The owner of the quote token.
    /// @param amount The amount of quote token to deposit.
    /// @param market The market (used only if flags indicates isolated).
    /// @param flags Bit flags: bit 0 = isolated (1) or cross (0).
    /// @param deadline The deadline for the permit.
    /// @param trackingHead_ The tracking head, used for offchain sync.
    /// @param r The r value of the signature.
    /// @param s The s value of the signature.
    /// @param v The recovery byte of the signature.
    function _depositWithSignatureV2(
        address owner,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 deadline,
        uint256 trackingHead_,
        bytes32 r,
        bytes32 s,
        uint8 v
    ) internal {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        if (amount == 0) revert AmountZero();

        if ((flags & ORDER_FLAG_ISOLATED) != 0) {
            _isoCreditMargin(owner, market, amount);
        } else {
            _cmCreditMargin(owner, amount);
        }

        $.totalBalance += amount;

        _setTrackingHead(trackingHead_);

        _permitAndTransfer(owner, amount, deadline, v, r, s);

        IERC20Permit token = IERC20Permit($.quoteToken);
        uint256 nonce = token.nonces(owner);
        emit DepositedV2(owner, amount, market, nonce, (flags & ORDER_FLAG_ISOLATED) != 0);
    }

    /// @notice Withdraw with flags to route from cross or isolated margin
    /// @param owner The owner of the funds
    /// @param amount The amount to withdraw
    /// @param market The market (used only if flags indicates isolated)
    /// @param flags Bit flags: bit 0 = isolated (1) or cross (0)
    /// @param nonce The nonce for replay protection
    /// @param deadline The deadline for the signature
    /// @param trackingHead_ The tracking head
    /// @param sig The signature (EIP-712 signed WithdrawV2)
    function withdrawWithSignatureV2(
        address owner,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 deadline,
        uint256 trackingHead_,
        bytes calldata sig
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        if (block.timestamp > deadline) revert DeadlineExpired();
        if (amount == 0) revert AmountZero();
        if (nonceUsed(owner, nonce)) revert NonceUsed();

        bytes32 digest =
            _hashTypedDataV4(SignerUtils._buildWithdrawV2Hash(owner, amount, market, flags, nonce, deadline));
        _verifySignature(sig, digest, owner);

        // Route validation and debit based on flags
        if ((flags & ORDER_FLAG_ISOLATED) != 0) {
            _validateIsoWithdraw(owner, market, amount);
            _isoDebitMargin(owner, market, amount);
        } else {
            _validateWithdraw(owner, amount, nonce);
            _cmDebitMargin(owner, amount);
        }

        $.nonces[owner].burnNonce(nonce);
        $.totalBalance -= amount;

        _setTrackingHead(trackingHead_);

        IERC20($.quoteToken).safeTransfer(owner, amount);

        emit WithdrawProcessedV2(owner, amount, market, nonce, (flags & ORDER_FLAG_ISOLATED) != 0);
    }

    /// @notice Update leverage with flags to route to cross or isolated position
    /// @param account The account to update
    /// @param market The market
    /// @param leverage The new leverage
    /// @param flags Bit flags: bit 0 = isolated (1) or cross (0)
    /// @param nonce The nonce for replay protection
    /// @param deadline The deadline for the signature
    /// @param trackingHead_ The tracking head
    /// @param sig The signature (EIP-712 signed UpdateLeverageV2)
    function updateLeverageWithSignatureV2(
        address account,
        uint32 market,
        uint32 leverage,
        uint256 flags,
        uint256 nonce,
        uint256 deadline,
        uint256 trackingHead_,
        bytes calldata sig
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        if (block.timestamp > deadline) revert DeadlineExpired();
        if (nonceUsed(account, nonce)) revert NonceUsed();

        bytes32 digest =
            _hashTypedDataV4(SignerUtils._buildLeverageUpdateV2Hash(account, market, leverage, flags, nonce, deadline));
        _verifySignature(sig, digest, account);
        _validateLeverageSet(leverage, market);

        bool isIsolated = (flags & ORDER_FLAG_ISOLATED) != 0;

        if (isIsolated) {
            // Update isolated position leverage
            _isoSetPositionLeverage(account, market, uint128(leverage));

            // Validate margin requirements after leverage change
            Position memory pos = getIsoPosition(account, market);
            if (pos.size != 0) {
                _isoValidateMargin(account, market, pos, _marketConfig(market));
            }
        } else {
            // Update cross position leverage
            _cmSetPositionLeverage(account, market, uint128(leverage));

            PositionMetrics memory pm = _cmAggAccount(account);
            int256 baseEquity = getMargin(account);

            if (!pm.coversAssignedMargin(baseEquity)) {
                revert InsufficientMargin(pm.calcEquity(baseEquity), pm.assignedMargin);
            }
        }

        $.nonces[account].burnNonce(nonce);
        _setTrackingHead(trackingHead_);

        emit LeverageSetV2(account, market, leverage, isIsolated);
    }

    /// @notice Transfer margin between cross and isolated accounts
    /// @param account The account transferring margin
    /// @param amount The amount to transfer
    /// @param market The isolated market involved
    /// @param flags Bit 0: 0 = cross→isolated, 1 = isolated→cross
    /// @param nonce The nonce for replay protection
    /// @param deadline The deadline for the signature
    /// @param trackingHead_ The tracking head
    /// @param sig The signature (EIP-712 signed TransferMargin)
    function transferMarginWithSignature(
        address account,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 deadline,
        uint256 trackingHead_,
        bytes calldata sig
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        if (block.timestamp > deadline) revert DeadlineExpired();
        if (amount == 0) revert AmountZero();
        if (nonceUsed(account, nonce)) revert NonceUsed();

        bytes32 digest =
            _hashTypedDataV4(SignerUtils._buildTransferMarginHash(account, amount, market, flags, nonce, deadline));
        _verifySignature(sig, digest, account);

        bool fromIsolated = (flags & ORDER_FLAG_ISOLATED) != 0;

        if (fromIsolated) {
            // Transfer from isolated to cross
            _validateIsoWithdraw(account, market, amount);
            _isoDebitMargin(account, market, amount);
            _cmCreditMargin(account, amount);
        } else {
            // Transfer from cross to isolated
            _validateCrossWithdraw(account, amount);
            _cmDebitMargin(account, amount);
            _isoCreditMargin(account, market, amount);
        }

        $.nonces[account].burnNonce(nonce);
        _setTrackingHead(trackingHead_);

        emit MarginTransferred(account, amount, market, !fromIsolated);
    }

    /// @notice Validate cross margin withdrawal (check remaining margin covers positions)
    function _validateCrossWithdraw(address account, uint256 amount) internal view {
        int256 remainingMargin = getMargin(account) - SafeCastLib.toInt256(amount);
        PositionMetrics memory pm = _cmAggAccount(account);

        if (!pm.coversAssignedMargin(remainingMargin)) {
            revert InsufficientMargin(pm.calcEquity(remainingMargin), pm.assignedMargin);
        }
    }

    /// @notice Validate isolated margin withdrawal
    function _validateIsoWithdraw(address account, uint32 market, uint256 amount) internal view {
        uint256 isoMargin = getIsoMargin(account, market);
        if (isoMargin < amount) revert InsufficientMargin(SafeCastLib.toInt256(isoMargin), amount);

        Position memory pos = getIsoPosition(account, market);
        if (pos.size != 0) {
            // Calculate remaining margin after withdrawal
            uint256 remainingMargin = isoMargin - amount;
            uint256 markPrice = _getPrice(market);
            PositionMetrics memory pm = _calcPositionMetrics(pos, market, markPrice);
            pm.requireSufficientMargin(SafeCastLib.toInt256(remainingMargin));
        }
    }

    /// @notice Set a delegator for an account with a signature. The delegator can sign on behalf of the account
    /// until the specified deadline.
    ///
    /// @param account The account granting delegation
    /// @param delegator The address being granted signing rights
    /// @param until The timestamp until which the delegation is valid
    /// @param nonce The nonce of the delegation request
    /// @param deadline The deadline for the signature itself
    /// @param trackingHead_ The tracking head
    /// @param sig The signature
    function setDelegatorWithSignature(
        address account,
        address delegator,
        uint256 until,
        uint256 nonce,
        uint256 deadline,
        uint256 trackingHead_,
        bytes calldata sig
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        if (block.timestamp > deadline) revert DeadlineExpired();
        if (nonceUsed(account, nonce)) revert NonceUsed();

        bytes32 digest =
            _hashTypedDataV4(SignerUtils._buildSetDelegatorHash(account, delegator, until, nonce, deadline));
        address recovered = ECDSA.recover(digest, sig);
        if (account != recovered) revert InvalidSigner(account, recovered);

        $.nonces[account].burnNonce(nonce);

        _setDelegator(account, delegator, until);
        _setTrackingHead(trackingHead_);
    }

    function cancelOrder(address account, uint256 nonce, uint256 trackingHead_)
        external
        onlyRole(RELAYER_ROLE)
        notPaused
        notBreakGlass
    {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        if (nonceUsed(account, nonce)) revert NonceUsed();
        $.nonces[account].burnNonce(nonce);

        bytes32 orderId = keccak256(abi.encode(account, nonce));
        delete $.orderFills[orderId];

        _setTrackingHead(trackingHead_);
        emit OrderCancelled(account, nonce);
    }

    /// @notice Cancel an order by burning its nonce and clearing any partial fill data.
    ///
    /// @dev The nonce is managed by the global nonce bitmap.
    ///
    /// @param account The account that owns the order.
    /// @param nonce The nonce of the order to cancel.
    /// @param deadline The deadline for the cancellation request.
    /// @param trackingHead_ The tracking head.
    /// @param sig The signature as a raw bytes payload.
    function cancelOrderWithSignature(
        address account,
        uint256 nonce,
        uint256 deadline,
        uint256 trackingHead_,
        bytes calldata sig
    ) external onlyRole(RELAYER_ROLE) notPaused notBreakGlass {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        if (block.timestamp > deadline) revert DeadlineExpired();
        if (nonceUsed(account, nonce)) revert NonceUsed();

        bytes32 digest = _hashTypedDataV4(SignerUtils._buildCancelOrderHash(account, nonce, deadline));
        _verifySignature(sig, digest, account);

        $.nonces[account].burnNonce(nonce);

        bytes32 orderId = keccak256(abi.encode(account, nonce));
        delete $.orderFills[orderId];

        _setTrackingHead(trackingHead_);
        emit OrderCancelled(account, nonce);
    }

    /// @notice Validate that the withdrawal is valid.
    ///
    /// @param owner The owner of the quote token.
    /// @param amount The amount of quote token to withdraw.
    /// @param nonce The nonce of the withdrawal request.
    function _validateWithdraw(address owner, uint256 amount, uint256 nonce) internal view {
        if (amount == 0) revert AmountZero();
        if (nonceUsed(owner, nonce)) revert NonceUsed();

        int256 margin = getMargin(owner);
        int256 amount_ = SafeCastLib.toInt256(amount);
        if (margin < amount_) revert InsufficientMargin(margin, 0);

        // Validate assigned margin is still sufficient after withdrawal
        PositionMetrics memory pm = _cmAggAccount(owner);
        if (!pm.coversAssignedMargin(margin - amount_)) {
            revert InsufficientMargin(pm.freeMargin(margin - amount_), pm.assignedMargin);
        }
    }

    /// @notice Validate two fills match each other.
    ///
    /// @param order0 The first order.
    /// @param order1 The second order.
    function _validateMatchedFill(Order memory order0, bool isIsolated0, Order memory order1) internal view {
        // Orders are for different markets
        if (order0.market != order1.market) revert MarketMismatch(order0.market, order1.market);
        // Orders are not opposite sides (skip check if either is SL/TP with size=0)
        if (order0.size != 0 && order1.size != 0) {
            if (Math.signCmp(order0.size, order1.size)) revert OrderSignMismatch(order0.size, order1.size);
        }

        // Order limit prices must cross -- Order size must be loaded from position if zero / SLTP

        int256 sizeForDirection;

        if (order0.size != 0) {
            sizeForDirection = order0.size;
        } else {
            sizeForDirection = isIsolated0
                ? -getIsoPosition(order0.account, order0.market).size
                : -_cmGetPosition(order0.account, order0.market).size;
        }

        (uint256 buyPrice, uint256 sellPrice) =
            sizeForDirection > 0 ? (order0.limitPrice, order1.limitPrice) : (order1.limitPrice, order0.limitPrice);
        if (buyPrice < sellPrice) revert NoOrderCross(buyPrice, sellPrice);
    }

    /// @notice Validate a leverage set request.
    ///
    /// @param leverage The new leverage.
    /// @param market The market to update the leverage for.
    function _validateLeverageSet(uint256 leverage, uint256 market) internal view {
        if (leverage == 0) revert LeverageZero();

        MarketConfig memory mktConfig = _marketConfig(market);

        if (mktConfig.maxLeverage == 0) revert MarketNotInitialized(market);
        if (leverage > mktConfig.maxLeverage) revert LeverageOverMax(uint16(leverage), mktConfig.maxLeverage);
    }

    /// @notice Validate a fill.
    ///
    /// @param order The order to validate.
    /// @param sig The signature of the order.
    /// @param fillSize The size of the fill.
    function _validateFill(Order calldata order, bytes calldata sig, int256 fillSize) internal {
        // Order price is purposely not zero validated; a zero or a max order size indicates a market order
        // Order size == 0: SL/TP, should execute at full position size
        if (order.size == 0) {
            int256 positionSize = _cmGetPosition(order.account, order.market).size;
            if (positionSize != -fillSize) {
                revert InvalidSlTp(order.size, fillSize);
            }
        }
        _validateSignedOrder(order, sig);
        _validateFillSize(order.account, order.nonce, order.size, fillSize);
    }

    /// @notice Validates order signature and prevents replays
    function _validateSignedOrder(Order calldata order, bytes calldata sig) internal view {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        bytes32 digest = _hashTypedDataV4(order.digest());
        _verifySignature(sig, digest, order.account);
        if ($.nonces[order.account].isUsed(order.nonce)) revert NonceUsed();
    }

    function _verifySignature(bytes calldata signature, bytes32 digest, address account) internal view {
        address recovered = ECDSA.recover(digest, signature);
        if (account != recovered && !_isDelegated(account, recovered)) {
            revert InvalidSigner(account, recovered);
        }
    }

    /// @notice Validate an OrderV2 fill.
    function _validateFillV2(OrderV2 calldata order, bytes calldata sig, int256 fillSize) internal {
        if (order.size == 0) {
            int256 positionSize = order.isIsolated()
                ? getIsoPosition(order.account, order.market).size
                : _cmGetPosition(order.account, order.market).size;
            if (positionSize != -fillSize) {
                revert InvalidSlTp(order.size, fillSize);
            }
        }

        _validateSignedOrderV2(order, sig);
        _validateFillSize(order.account, order.nonce, order.size, fillSize);
    }

    /// @notice Validates OrderV2 signature and prevents replays
    function _validateSignedOrderV2(OrderV2 calldata order, bytes calldata sig) internal view {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        bytes32 digest = _hashTypedDataV4(order.digest());
        _verifySignature(sig, digest, order.account);
        if ($.nonces[order.account].isUsed(order.nonce)) revert NonceUsed();
    }

    /// @notice Core fill size validation logic shared by Order and OrderV2
    /// @dev validates the following:
    /// - Order size and fill size are the same direction
    /// - Current fill would not exceed total amount allowed by the signed fill (partial fill case)
    /// @dev Handles nonce burning and updates partial fill accumulator.
    function _validateFillSize(address account, uint256 nonce, int256 orderSize, int256 fillSize) internal {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        // SL/TP orders (size=0) always burn nonce immediately - they're full closes
        if (orderSize == 0) {
            $.nonces[account].burnNonce(nonce);
            return;
        }

        if (!Math.signCmp(orderSize, fillSize)) revert FillSignMismatch();

        // Handle partial fill + nonce burn
        bytes32 orderId = keccak256(abi.encode(account, nonce));
        uint256 netFilled = $.orderFills[orderId] + fillSize.abs();
        uint256 absOrder = orderSize.abs();

        if (netFilled > absOrder) revert FillOverSize();
        if (netFilled == absOrder) {
            delete ($.orderFills[orderId]);
            $.nonces[account].burnNonce(nonce);
        } else {
            $.orderFills[orderId] = netFilled;
        }
    }

    function _setTrackingHead(uint256 newHead) internal {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        if (newHead > $.globalState.trackingHead) $.globalState.trackingHead = uint128(newHead);
        $.globalState.heartbeat = uint64(block.timestamp);
        emit TrackingHeadSet(newHead);
    }

    //
    // Fill handlers
    //

    /// @notice Handle a fill (cross or isolated margin)
    function _handleFill(
        Order memory order,
        int256 fillSize,
        uint256 execPrice,
        bool isMaker,
        uint256 trackingHead_,
        bool isIsolated
    ) internal {
        HelloVaultStorage storage $ = _getHelloVaultStorage();

        // Execute fill in vault (validates, updates position/margin, calculates fee)
        FillResult memory result = isIsolated
            ? _isoExecuteFill(order.account, order.market, fillSize, execPrice, isMaker)
            : _cmExecuteFill(order.account, order.market, fillSize, execPrice, isMaker);

        // Send fee
        _sendFee(order.account, $.quoteToken, result.fee);

        // Emit event
        emit OrderFilledV2(
            order.account,
            order.nonce,
            order.market,
            execPrice,
            result.newEntryPrice,
            order.size,
            fillSize,
            result.realizedPnl,
            result.fee,
            trackingHead_,
            isMaker,
            isIsolated
        );
    }

    function _permitAndTransfer(address owner, uint256 amount, uint256 deadline, uint8 v, bytes32 r, bytes32 s)
        internal
    {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        IERC20Permit($.quoteToken).permit(owner, address(this), amount, deadline, v, r, s);
        IERC20($.quoteToken).safeTransferFrom(owner, address(this), amount);
    }

    /// @notice Validate that the maker and taker sides of an order have opposite signs.
    // function _validateOrderSide(int256 maker, int256 taker) internal pure {
    //     if (Math.signCmp(maker, taker)) revert OrderSignMismatch(maker, taker);
    // }

    function _notPaused() internal view {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        if ($.globalState.paused) revert ContractPaused();
    }

    function _notBreakGlass() internal view {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        if ($.globalState.breakGlass) revert BreakGlass();
    }

    ////////////////////
    // View functions //
    ////////////////////

    function domainSeparatorV4() public view returns (bytes32) {
        return _domainSeparatorV4();
    }

    /// @notice Heartbeat check function. Returns false if more than HEARTBEAT_PERIOD
    /// seconds have passed since the last heartbeat update.
    function heartbeat() public view returns (bool) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        return (block.timestamp - $.globalState.heartbeat) < HEARTBEAT_PERIOD;
    }

    function trackingHead() public view returns (uint256) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        return $.globalState.trackingHead;
    }

    /// @notice Get whether a nonce has been used for a given account.
    function nonceUsed(address account, uint256 nonce) public view returns (bool) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        return $.nonces[account].isUsed(nonce);
    }

    function getPosition(address account, uint256 market, bool isolated)
        public
        view
        returns (Position memory position)
    {
        if (isolated) {
            return getIsoPosition(account, market);
        }
        return getCrossMarginPosition(account, market);
    }

    // getMargin, getFreeMargin, getPosition, getPositionPnl, getAccountSummary,
    // getAllPositions, getActiveMarkets, accountInLiquidation are inherited from CrossMarginVault

    /////////////////////////////
    // Configuration functions //
    /////////////////////////////

    function pause() external onlyRole(ADMIN_ROLE) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        $.globalState.paused = !$.globalState.paused;
        emit Paused();
    }

    function setMarketConfig(uint32 market, MarketConfig memory config) public onlyRole(ADMIN_ROLE) {
        _setMarketConfig(market, config);
    }

    function setFundingConfig(uint32 market, int32 fundingMax, int32 fundingMin, uint32 minFundingInterval)
        public
        onlyRole(ADMIN_ROLE)
    {
        _setFundingConfig(market, fundingMax, fundingMin, minFundingInterval);
    }

    function setDefaultLeverage(uint32 market, uint32 leverage) public onlyRole(ADMIN_ROLE) {
        _setDefaultLeverage(market, leverage);
    }

    /// @notice Set the HelloStork feed ID for a market (private feed for local caching)
    /// @dev This is the feed that price inputs are keyed by
    function setMarketHelloStorkId(uint32 market, bytes32 helloStorkId) public onlyRole(ADMIN_ROLE) {
        _setMarketHelloStorkId(market, helloStorkId);
    }

    function clearMarketHelloStorkId(uint32 market, bytes32 helloStorkId) public onlyRole(ADMIN_ROLE) {
        _clearMarketHelloStorkId(market, helloStorkId);
    }

    /// @notice Set the public Stork feed ID for a market (for remote fallback)
    function setMarketStorkId(uint32 market, bytes32 storkId) public onlyRole(ADMIN_ROLE) {
        _setMarketStorkId(market, storkId);
    }

    function setValidTimePeriodNs(uint256 validTimePeriodNs_) public onlyRole(ADMIN_ROLE) {
        _setValidTimePeriodNs(validTimePeriodNs_);
    }

    function setToken(address token_) public onlyRole(ADMIN_ROLE) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        $.quoteToken = token_;
    }

    function setFees(uint64 makerFee, uint64 takerFee, uint64 liquidationFee, uint64 baseFee)
        public
        onlyRole(ADMIN_ROLE)
    {
        _setFees(makerFee, takerFee, liquidationFee, baseFee);
    }

    function setFeeRecipient(address feeRecipient) public onlyRole(ADMIN_ROLE) {
        _setFeeRecipient(feeRecipient);
    }

    // Emergency functions

    /// @notice Rescues accidental quote token deposits by checking balance in excess of totalBalance.
    function rescueQuote() public onlyRole(ADMIN_ROLE) {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        uint256 amt = IERC20($.quoteToken).balanceOf(address(this)) - $.totalBalance;
        IERC20($.quoteToken).safeTransfer(msg.sender, amt);
    }

    /// @notice Emergency withdraw function. Allows a user to withdraw their margin immediately,
    /// providing the heartbeat timer has been exceeded.
    function emergencyWithdrawCross() public {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        if (heartbeat()) revert HeartbeatNotExpired();
        $.globalState.breakGlass = true;

        int256 margin = getMargin(msg.sender);
        uint256 marginAbs = margin.abs();
        if (margin <= 0) revert InsufficientMargin(margin, 0);

        _cmSetMargin(msg.sender, 0);

        $.totalBalance -= marginAbs;
        IERC20($.quoteToken).safeTransfer(msg.sender, marginAbs);
        emit EmergencyWithdraw(msg.sender, marginAbs);
    }

    function emergencyWithdrawIsolated(uint256 market) public {
        HelloVaultStorage storage $ = _getHelloVaultStorage();
        if (heartbeat()) revert HeartbeatNotExpired();
        $.globalState.breakGlass = true;

        uint256 margin = getIsoMargin(msg.sender, market);
        if (margin <= 0) revert InsufficientMargin(SafeCastLib.toInt256(margin), 0);

        _isoSetMargin(msg.sender, market, 0);

        $.totalBalance -= margin;
        IERC20($.quoteToken).safeTransfer(msg.sender, margin);
        emit EmergencyWithdraw(msg.sender, margin);
    }

    // Upgrade

    function _authorizeUpgrade(address) internal override onlyRole(DEFAULT_ADMIN_ROLE) {}
}
