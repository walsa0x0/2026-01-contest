// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

import {PositionLib, Position, PositionDeltaResult} from "src/lib/Position.sol";
import {PositionMetrics, PositionMetricsLib} from "src/lib/PositionMetrics.sol";
import {Math} from "src/lib/Math.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

import {HelloMarketData, MarketConfig, FundingInstant} from "src/price-feeds/HelloMarketData.sol";
import {PriceOracleCache} from "src/price-feeds/PriceOracleCache.sol";
import {HelloFees} from "src/Fees.sol";

import {IsolatedMarginAccountLib, IsolatedMarginAccount} from "src/lib/IsolatedMarginAccount.sol";

import {
    VaultUtils,
    LiquidateeResult,
    FillResult,
    InvalidAccountLiquidation,
    InvalidAccountDelever,
    LiquidationResultsInNegativeMargin
} from "./VaultUtils.sol";

/// @title IsolatedMarginVault
/// @notice Manages isolated-margin accounts with per-position margin
abstract contract IsolatedMarginVault is HelloMarketData, PriceOracleCache, HelloFees, VaultUtils {
    using PositionLib for Position;
    using PositionMetricsLib for PositionMetrics;
    using Math for int256;
    using SafeCastLib for uint256;

    using IsolatedMarginAccountLib for mapping(address => mapping(uint256 => IsolatedMarginAccount));

    /// @custom:storage-location erc7201:hellotrade.storage.IsolatedMarginVault
    struct IsolatedMarginVaultStorage {
        /// @notice Isolated position mapping: address => marketId => IsolatedMarginAccount
        mapping(address => mapping(uint256 => IsolatedMarginAccount)) isolatedMarginAccounts;
    }

    // keccak256(abi.encode(uint256(keccak256("hellotrade.storage.IsolatedMarginVault")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant ISOLATED_MARGIN_VAULT_STORAGE_LOCATION =
        0x89cb9e8a8e62bdca82353d5f8af3c02782fdb94743bb195a175e8a6635f61e00;

    function _storage() private pure returns (IsolatedMarginVaultStorage storage $) {
        assembly {
            $.slot := ISOLATED_MARGIN_VAULT_STORAGE_LOCATION
        }
    }

    function __IsolatedMarginVault_init() internal onlyInitializing {
        // Price oracle init is handled by CrossMarginVault
    }

    //
    // Isolated-margin position operations (prefixed with _iso)
    //

    /// @notice Calculate position deltas for an isolated margin fill
    function _isoPositionDeltas(
        address account,
        uint256 market,
        int256 fillSize,
        uint256 execPrice,
        MarketConfig memory mktConfig,
        int192 cumulativeFundingIdx
    ) internal view returns (Position memory newPos, int256 posUpdatePnl, bool isSimpleClose) {
        IsolatedMarginVaultStorage storage $ = _storage();
        Position memory pos = $.isolatedMarginAccounts.getPosition(account, market);

        PositionDeltaResult memory result = pos.calcPositionDelta(mktConfig, fillSize, execPrice, cumulativeFundingIdx);
        newPos = result.newPos;
        posUpdatePnl = result.pnl;
        isSimpleClose = result.isSimpleClose;

        // Ensure leverage is set for new positions
        newPos.leverage = PositionLib.getEffectiveLeverage(newPos.leverage, mktConfig.defaultLeverage);
    }

    /// @notice Update an isolated margin position
    function _isoUpdatePosition(address account, uint256 market, Position memory newPos) internal {
        _storage().isolatedMarginAccounts.updatePosition(account, market, newPos);
    }

    /// @notice Set leverage for an isolated position
    function _isoSetPositionLeverage(address account, uint256 market, uint128 leverage) internal {
        _storage().isolatedMarginAccounts.setPositionLeverage(account, market, leverage);
    }

    //
    // Isolated-margin validation (prefixed with _iso)
    //

    /// @notice Validate margin requirements for an isolated position using mark price
    function _isoValidateMargin(address account, uint256 market, Position memory pos, MarketConfig memory mktConfig)
        internal
        view
    {
        uint256 markPrice = _getPrice(uint32(market));
        _isoValidateMarginWithPrice(account, market, pos, markPrice, mktConfig, 0);
    }

    /// @notice Validate margin requirements for an isolated position at a specific price
    function _isoValidateMarginWithPrice(
        address account,
        uint256 market,
        Position memory newPos,
        uint256 execPrice,
        MarketConfig memory mktConfig,
        int256 marginDelta
    ) internal view {
        int256 margin =
            _storage().isolatedMarginAccounts.getMargin(account, market).toInt256() + marginDelta;

        PositionMetrics memory pm = _calcPositionMetricsWithConfig(newPos, market, execPrice, mktConfig);
        pm.requireSufficientMargin(margin);
    }

    /// @notice Check if an isolated position is in liquidation
    function _isoIsPositionInLiquidation(address account, uint256 market) internal view returns (bool) {
        IsolatedMarginVaultStorage storage $ = _storage();
        if (!$.isolatedMarginAccounts.hasPosition(account, market)) return false;

        IsolatedMarginAccount memory isoAcct = $.isolatedMarginAccounts[account][market];
        uint256 markPrice = _getPrice(uint32(market));

        PositionMetrics memory pm = _calcPositionMetrics(isoAcct.position, market, markPrice);
        return pm.isLiquidatable(SafeCastLib.toInt256(isoAcct.margin));
    }

    /// @notice Validate isolated position is below maintenance margin for deleveraging
    function _isoValidateDelever(address account, uint32 market) internal view {
        if (!_isoIsPositionInLiquidation(account, market)) revert InvalidAccountDelever(account);
    }

    //
    // Isolated-margin liquidation execution
    //

    /// @notice Execute liquidation fill for an isolated margin position
    /// @dev Validates liquidatable, calculates position delta, updates position and margin (including fee)
    /// @param account The account being liquidated
    /// @param market The market of the position
    /// @param fillSize The unsigned fill size
    /// @param execPrice The execution price
    /// @return result The liquidation result with fill info and fee to transfer
    function _isoExecuteLiquidatee(address account, uint32 market, uint256 fillSize, uint256 execPrice)
        internal
        returns (LiquidateeResult memory result)
    {
        IsolatedMarginVaultStorage storage $ = _storage();

        // 1. Load position and margin
        Position memory pos = $.isolatedMarginAccounts[account][market].position;
        uint256 margin = $.isolatedMarginAccounts[account][market].margin;

        // 2. Validate position is liquidatable
        if (!_isoIsPositionInLiquidation(account, market)) revert InvalidAccountLiquidation();

        // 3. Get market/funding config
        MarketConfig memory mktConfig = _marketConfig(market);
        FundingInstant memory fundingInst = _lastFundingInstant(market);

        // 4. Determine fill direction based on position
        int256 fillSize_ = SafeCastLib.toInt256(fillSize);
        int256 liquidatedFill = pos.size > 0 ? -fillSize_ : fillSize_;

        // 5. Validate reduce-only
        _requireReduceOnly(pos, liquidatedFill);

        // 6. Calculate position deltas
        (Position memory newPos, int256 posUpdatePnl, bool isSimpleClose) =
            _isoPositionDeltas(account, market, liquidatedFill, execPrice, mktConfig, fundingInst.cumulativeFundingIdx);

        // 7. Calculate fee (isolated uses uint margin, so always >= 0)
        uint256 fee = _calcLiquidationFee(liquidatedFill.abs() * execPrice, 10 ** mktConfig.basePrecision, margin);
        posUpdatePnl -= SafeCastLib.toInt256(fee);

        // 8. Apply state changes (position and margin including fee)
        _isoUpdatePosition(account, market, newPos);
        _isoApplyMarginDelta(account, market, posUpdatePnl);

        // 9. Validate liquidation doesn't result in negative equity (using execPrice)
        {
            uint256 marginAfter = _storage().isolatedMarginAccounts[account][market].margin;
            PositionMetrics memory pmAfter =
                PositionMetricsLib.calculate(newPos, execPrice, fundingInst.cumulativeFundingIdx, mktConfig);
            int256 equityAfter = pmAfter.calcEquity(SafeCastLib.toInt256(marginAfter));
            if (equityAfter < 0) revert LiquidationResultsInNegativeMargin(equityAfter);
        }

        // 10. Return result for fee transfer by caller
        result.signedFill = liquidatedFill;
        result.realizedPnl = posUpdatePnl;
        result.fee = fee;
    }

    //
    // Isolated-margin fill execution
    //

    /// @notice Execute a regular fill for an isolated margin position
    /// @dev Calculates position delta, fee, validates margin, updates position and margin
    /// @param account The account receiving the fill
    /// @param market The market of the position
    /// @param fillSize The signed fill size
    /// @param execPrice The execution price
    /// @param isMaker Whether this is a maker order (affects fee)
    /// @return result The fill result with fee and entry price info
    function _isoExecuteFill(address account, uint32 market, int256 fillSize, uint256 execPrice, bool isMaker)
        internal
        returns (FillResult memory result)
    {
        // 1. Get market/funding config
        MarketConfig memory mktConfig = _marketConfig(market);
        FundingInstant memory fundingInst = _lastFundingInstant(market);

        // 2. Calculate position deltas
        (Position memory newPos, int256 realizedPnl, bool isSimpleClose) =
            _isoPositionDeltas(account, market, fillSize, execPrice, mktConfig, fundingInst.cumulativeFundingIdx);

        // 3. Calculate fee
        uint256 fee = _calcFillFee(fillSize.abs() * execPrice, 10 ** mktConfig.basePrecision, isMaker);
        realizedPnl -= SafeCastLib.toInt256(fee);

        // 4. Validate margin requirements if not a simple close
        if (!isSimpleClose) {
            _isoValidateMarginWithPrice(account, market, newPos, execPrice, mktConfig, realizedPnl);
        }

        // 5. Apply state changes (position and margin including fee)
        _isoUpdatePosition(account, market, newPos);
        _isoApplyMarginDelta(account, market, realizedPnl);

        // 6. Return result for fee transfer by caller
        result.realizedPnl = realizedPnl;
        result.fee = fee;
        result.newEntryPrice = newPos.entryPrice;
    }

    //
    // Isolated-margin account operations
    //

    /// @notice Credit margin to an isolated position
    function _isoCreditMargin(address account, uint256 market, uint256 amount) internal {
        _storage().isolatedMarginAccounts.creditMargin(account, market, amount);
    }

    /// @notice Debit margin from an isolated position
    function _isoDebitMargin(address account, uint256 market, uint256 amount) internal {
        _storage().isolatedMarginAccounts.debitMargin(account, market, amount);
    }

    /// @notice Apply margin delta to an isolated position
    function _isoApplyMarginDelta(address account, uint256 market, int256 delta) internal {
        _storage().isolatedMarginAccounts.applyMarginDelta(account, market, delta);
    }

    /// @notice Set margin for an isolated position
    function _isoSetMargin(address account, uint256 market, uint256 margin) internal {
        _storage().isolatedMarginAccounts.setMargin(account, market, margin);
    }

    //
    // Isolated-margin views
    //

    /// @notice Get margin for an isolated position
    function getIsoMargin(address account, uint256 market) public view returns (uint256) {
        return _storage().isolatedMarginAccounts[account][market].margin;
    }

    /// @notice Get an isolated position
    function getIsoPosition(address account, uint256 market) public view returns (Position memory) {
        return _storage().isolatedMarginAccounts[account][market].position;
    }

    /// @notice Get full isolated account for a market
    function getIsoAccount(address account, uint256 market) public view returns (IsolatedMarginAccount memory) {
        return _storage().isolatedMarginAccounts[account][market];
    }

    /// @notice Check if isolated position is in liquidation
    function isoPositionInLiquidation(address account, uint256 market) public view returns (bool) {
        return _isoIsPositionInLiquidation(account, market);
    }
}
