// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

import {PositionLib, Position, PositionDeltaResult} from "src/lib/Position.sol";
import {CrossMarginAccountLib, CrossMarginAccount} from "src/lib/CrossMarginAccount.sol";
import {PositionMetrics, PositionMetricsLib} from "src/lib/PositionMetrics.sol";
import {Math} from "src/lib/Math.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

import {HelloMarketData, FundingInstant, MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {PriceOracleCache} from "src/price-feeds/PriceOracleCache.sol";
import {HelloFees} from "src/Fees.sol";
import {Initializable} from "@openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";

import {ICrossMarginVault} from "src/interfaces/ICrossMarginVault.sol";
import {
    VaultUtils,
    LiquidateeResult,
    FillResult,
    InvalidAccountLiquidation,
    InvalidAccountDelever,
    MaxPositionsExceeded,
    LiquidationResultsInNegativeMargin
} from "./VaultUtils.sol";

/// @title CrossMarginVault
/// @notice Manages cross-margin accounts with positions across multiple markets
contract CrossMarginVault is
    ICrossMarginVault,
    Initializable,
    HelloMarketData,
    PriceOracleCache,
    HelloFees,
    VaultUtils
{
    using Math for int256;

    using CrossMarginAccountLib for mapping(address => CrossMarginAccount);
    using CrossMarginAccountLib for CrossMarginAccount;
    using PositionLib for mapping(address => Position);
    using PositionLib for Position;
    using PositionMetricsLib for PositionMetrics;

    // Max number of markets a user is allowed to access per account, prevent unbounded iteration
    uint256 constant IN_MARKETS_MAX = 16;

    /// @custom:storage-location erc7201:hellotrade.storage.CrossMarginVault
    struct CrossMarginVaultStorage {
        /// @notice Position data for each account across markets
        mapping(address => CrossMarginAccount) crossMarginAccounts;
    }

    // keccak256(abi.encode(uint256(keccak256("hellotrade.storage.CrossMarginVault")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant CROSS_MARGIN_VAULT_STORAGE_LOCATION =
        0x81af45f347ea3077cc470ce9c3f0c6cedd09e5713c67412f7dfc66b3a53f8100;

    function _crossMarginStorage() internal pure returns (CrossMarginVaultStorage storage $) {
        assembly {
            $.slot := CROSS_MARGIN_VAULT_STORAGE_LOCATION
        }
    }

    function __CrossMarginVault_init(address stork_) internal onlyInitializing {
        __HelloMarketData_init();
        __PriceOracleCache_init(stork_);
    }

    //
    // Cross-margin margin operations (prefixed with _cm)
    //

    /// @notice Credit margin to an account
    function _cmCreditMargin(address account, uint256 amount) internal {
        _crossMarginStorage().crossMarginAccounts.creditMargin(account, amount);
    }

    /// @notice Debit margin from an account
    function _cmDebitMargin(address account, uint256 amount) internal {
        _crossMarginStorage().crossMarginAccounts.debitMargin(account, amount);
    }

    /// @notice Apply margin delta to an account
    function _cmApplyMarginDelta(address account, int256 delta) internal {
        _crossMarginStorage().crossMarginAccounts.applyMarginDelta(account, delta);
    }

    /// @notice Set margin for an account (for emergency withdraw)
    function _cmSetMargin(address account, int256 amount) internal {
        _crossMarginStorage().crossMarginAccounts[account].margin = amount;
    }

    /// @notice Get position from storage (for validation)
    function _cmGetPosition(address account, uint256 market) internal view returns (Position storage) {
        return _crossMarginStorage().crossMarginAccounts.getPosition(account, market);
    }

    //
    // Cross-margin position operations (prefixed with _cm)
    //

    /// @notice Update a position for an account in a market
    function _cmUpdatePosition(address account, uint256 market, Position memory newPos) internal {
        _crossMarginStorage().crossMarginAccounts.updatePosition(account, market, newPos);
    }

    /// @notice Set leverage for a position (does not require position to exist)
    function _cmSetPositionLeverage(address account, uint256 market, uint128 leverage) internal {
        _crossMarginStorage().crossMarginAccounts[account].positions[market].leverage = leverage;
    }

    /// @notice Calculate position deltas for a fill
    function _cmPositionDeltas(
        address account,
        uint256 market,
        int256 fillSize,
        uint256 execPrice,
        MarketConfig memory mktConfig,
        int192 cumulativeFundingIdx
    ) internal view returns (Position memory newPos, int256 posUpdatePnl, bool isSimpleClose) {
        CrossMarginVaultStorage storage $ = _crossMarginStorage();
        uint128 defaultLev = mktConfig.defaultLeverage;
        if (defaultLev == 0) revert MarketNotInitialized(market);

        (Position memory pos, bool isInMarket) = $.crossMarginAccounts.getPositionOrClean(account, market, defaultLev);

        if (!isInMarket) {
            // Entering new market: check limit, clear entryFundingIdx for fresh funding calculation
            if ($.crossMarginAccounts[account].getNumActiveMarkets() >= IN_MARKETS_MAX) revert MaxPositionsExceeded();
            pos.entryFundingIdx = cumulativeFundingIdx;
        }

        PositionDeltaResult memory result = pos.calcPositionDelta(mktConfig, fillSize, execPrice, cumulativeFundingIdx);
        newPos = result.newPos;
        posUpdatePnl = result.pnl;

        // Only calculate isSimpleClose for existing positions (new positions are never "closes")
        isSimpleClose = isInMarket && result.isSimpleClose;
    }

    //
    // Cross-margin account aggregation
    //

    // Sentinel value
    uint256 internal constant NO_SKIP = type(uint256).max;

    /// @notice Aggregate account metrics across all markets using mark price
    function _cmAggAccount(address account) internal view returns (PositionMetrics memory pm) {
        pm = _cmAggregateWithMarkPrice(account, NO_SKIP);
    }

    /// @notice Aggregation using mark prices (view)
    function _cmAggregateWithMarkPrice(address account, uint256 skipMarket)
        internal
        view
        returns (PositionMetrics memory total)
    {
        CrossMarginVaultStorage storage $ = _crossMarginStorage();
        CrossMarginAccount storage ap = $.crossMarginAccounts[account];
        uint256[] memory mkts = ap.getActiveMarkets();

        for (uint256 i = 0; i < mkts.length; ++i) {
            uint256 mkt = mkts[i];
            if (mkt == skipMarket) continue;

            PositionMetrics memory pm = PositionMetricsLib.calculate(
                ap.positions[mkt],
                _getPrice(uint32(mkt)),
                _lastFundingInstant(mkt).cumulativeFundingIdx,
                _marketConfig(mkt)
            );
            total.add(pm);
        }
    }

    /// @notice Aggregation using cached stork prices (non-view, uses transient storage)
    function _cmAggregateWithCachedPrice(address account, uint256 skipMarket)
        internal
        returns (PositionMetrics memory total)
    {
        CrossMarginVaultStorage storage $ = _crossMarginStorage();
        CrossMarginAccount storage ap = $.crossMarginAccounts[account];
        uint256[] memory mkts = ap.getActiveMarkets();

        for (uint256 i = 0; i < mkts.length; ++i) {
            uint256 mkt = mkts[i];
            if (mkt == skipMarket) continue;

            PositionMetrics memory pm = PositionMetricsLib.calculate(
                ap.positions[mkt],
                _getPriceAndCache(uint32(mkt)),
                _lastFundingInstant(mkt).cumulativeFundingIdx,
                _marketConfig(mkt)
            );
            total.add(pm);
        }
    }

    //
    // Cross-margin validation
    //

    /// @notice Check if an account is in liquidation (equity < maintenance margin)
    function _cmIsAccountInLiquidation(address account) internal view returns (bool) {
        CrossMarginVaultStorage storage $ = _crossMarginStorage();
        PositionMetrics memory pm = _cmAggAccount(account);
        return pm.isLiquidatable($.crossMarginAccounts[account].margin);
    }

    /// @notice Validate account is below maintenance margin for deleveraging
    function _cmValidateDelever(address account) internal view {
        if (!_cmIsAccountInLiquidation(account)) revert InvalidAccountDelever(account);
    }

    //
    // Cross-margin liquidation execution
    //

    /// @notice Execute liquidation fill for a cross-margin account
    /// @dev Validates liquidatable, calculates position delta, updates position and margin (including fee)
    /// @param account The account being liquidated
    /// @param market The market of the position
    /// @param fillSize The unsigned fill size
    /// @param execPrice The execution price
    /// @return result The liquidation result with fill info and fee to transfer
    function _cmExecuteLiquidatee(address account, uint32 market, uint256 fillSize, uint256 execPrice)
        internal
        returns (LiquidateeResult memory result)
    {
        CrossMarginVaultStorage storage $ = _crossMarginStorage();

        // 1. Load position and margin
        Position memory pos = $.crossMarginAccounts[account].positions[market];
        int256 margin = $.crossMarginAccounts[account].margin;

        // 2. Get market/funding config
        MarketConfig memory mktConfig = _marketConfig(market);
        FundingInstant memory fundingInst = _lastFundingInstant(market);

        // 3. Validate account is liquidatable
        PositionMetrics memory pm = _cmAggAccount(account);
        if (!pm.isLiquidatable(margin)) revert InvalidAccountLiquidation();

        // 4. Determine fill direction based on position
        int256 fillSize_ = SafeCastLib.toInt256(fillSize);
        int256 liquidatedFill = pos.size > 0 ? -fillSize_ : fillSize_;

        // 5. Validate reduce-only
        _requireReduceOnly(pos, liquidatedFill);

        // 6. Calculate position deltas
        (Position memory newPos, int256 posUpdatePnl, bool isSimpleClose) =
            _cmPositionDeltas(account, market, liquidatedFill, execPrice, mktConfig, fundingInst.cumulativeFundingIdx);

        // 7. Calculate fee if remaining margin is positive
        int256 remainingMargin = margin + posUpdatePnl;
        uint256 fee = 0;
        if (remainingMargin > 0) {
            fee = _calcLiquidationFee(
                liquidatedFill.abs() * execPrice, 10 ** mktConfig.basePrecision, remainingMargin.abs()
            );
            posUpdatePnl -= SafeCastLib.toInt256(fee);
        }

        // 8. Apply state changes (position and margin including fee)
        _cmUpdatePosition(account, market, newPos);
        _cmApplyMarginDelta(account, posUpdatePnl);

        // 9. Validate liquidation doesn't result in negative equity (using execPrice for modified market)
        {
            // Skip liquidated market in aggregation, calculate it at execPrice
            PositionMetrics memory pmOtherMarkets = _cmAggregateWithMarkPrice(account, market);
            PositionMetrics memory pmThisMarket =
                PositionMetricsLib.calculate(newPos, execPrice, fundingInst.cumulativeFundingIdx, mktConfig);
            pmOtherMarkets.add(pmThisMarket);
            int256 equityAfter = pmOtherMarkets.calcEquity($.crossMarginAccounts[account].margin);
            if (equityAfter < 0) revert LiquidationResultsInNegativeMargin(equityAfter);
        }

        // 10. Return result for fee transfer by caller
        result.signedFill = liquidatedFill;
        result.realizedPnl = posUpdatePnl;
        result.fee = fee;
    }

    //
    // Cross-margin fill execution
    //

    /// @notice Execute a regular fill for a cross-margin account
    /// @dev Calculates position delta, fee, validates margin, updates position and margin
    /// @param account The account receiving the fill
    /// @param market The market of the position
    /// @param fillSize The signed fill size
    /// @param execPrice The execution price
    /// @param isMaker Whether this is a maker order (affects fee)
    /// @return result The fill result with fee and entry price info
    function _cmExecuteFill(address account, uint32 market, int256 fillSize, uint256 execPrice, bool isMaker)
        internal
        returns (FillResult memory result)
    {
        // 1. Get market/funding config
        MarketConfig memory mktConfig = _marketConfig(market);
        FundingInstant memory fundingInst = _lastFundingInstant(market);

        // 2. Calculate position deltas
        (Position memory newPos, int256 realizedPnl, bool isSimpleClose) =
            _cmPositionDeltas(account, market, fillSize, execPrice, mktConfig, fundingInst.cumulativeFundingIdx);

        // 3. Calculate fee
        uint256 fee = _calcFillFee(fillSize.abs() * execPrice, 10 ** mktConfig.basePrecision, isMaker);
        realizedPnl -= SafeCastLib.toInt256(fee);

        // 4. Validate margin requirements if not a simple close
        if (!isSimpleClose) {
            _cmValidateMargin(account, market, newPos, execPrice, realizedPnl, mktConfig);
        }

        // 5. Apply state changes (position and margin including fee)
        _cmUpdatePosition(account, market, newPos);
        _cmApplyMarginDelta(account, realizedPnl);

        // 6. Return result for fee transfer by caller
        result.realizedPnl = realizedPnl;
        result.fee = fee;
        result.newEntryPrice = newPos.entryPrice;
    }

    /// @notice Validate margin requirements for a new position
    function _cmValidateMargin(
        address account,
        uint32 market,
        Position memory newPos,
        uint256 execPrice,
        int256 posUpdatePnl,
        MarketConfig memory mktConfig
    ) internal {
        PositionMetrics memory pmNewPos = _calcPositionMetricsWithConfig(newPos, market, execPrice, mktConfig);
        PositionMetrics memory pmAggregated = _cmAggregateWithCachedPrice(account, market);
        pmAggregated.add(pmNewPos);

        // Base equity includes realized PnL from this fill
        int256 baseEquity = _crossMarginStorage().crossMarginAccounts[account].margin;

        pmAggregated.requireSufficientMargin(baseEquity);
    }

    //
    // Views
    //

    /// @notice Get raw margin balance for an account
    function getMargin(address account) public view returns (int256) {
        return _crossMarginStorage().crossMarginAccounts[account].margin;
    }

    /// @notice Get free margin (equity - assigned margin)
    function getFreeMargin(address account) external view returns (int256) {
        PositionMetrics memory pm = _cmAggAccount(account);
        return pm.freeMargin(_crossMarginStorage().crossMarginAccounts[account].margin);
    }

    /// @notice Get position for an account in a market
    /// @dev Returns clean position if user has no active position
    function getCrossMarginPosition(address account, uint256 market) public view returns (Position memory position) {
        uint128 defaultLev = _marketConfig(market).defaultLeverage;
        (position,) = _crossMarginStorage().crossMarginAccounts.getPositionOrClean(account, market, defaultLev);
    }

    /// @notice Get position PnL at mark price
    function getPositionPnl(address account, uint256 market) external view returns (int256 pnl) {
        Position memory pos = _cmGetPosition(account, market);

        uint256 markPrice = _getPrice(uint32(market));
        MarketConfig memory mktConfig = _marketConfig(market);
        FundingInstant memory fundingInst = _lastFundingInstant(market);

        pnl = pos.calcTotalPnl(markPrice, fundingInst.cumulativeFundingIdx, mktConfig.basePrecision);
    }

    /// @notice Get full account summary
    function getAccountSummary(address account)
        external
        view
        returns (int256 marginAcct, int256 crossPnl, uint256 crossAssMarg, uint256 crossMaintMarg)
    {
        PositionMetrics memory pm = _cmAggAccount(account);
        marginAcct = _crossMarginStorage().crossMarginAccounts[account].margin;
        crossPnl = pm.unrealizedPnl;
        crossAssMarg = pm.assignedMargin;
        crossMaintMarg = pm.maintenanceMargin;
    }

    /// @notice Get all positions for a user
    function getAllPositions(address user) public view returns (uint256[] memory, Position[] memory) {
        return _crossMarginStorage().crossMarginAccounts[user].getAllCrossMarginAccount();
    }

    /// @notice Get all active markets for an account
    function getActiveMarkets(address account) public view returns (uint256[] memory) {
        return _crossMarginStorage().crossMarginAccounts[account].getActiveMarkets();
    }

    function getNumPositions(address account) public view returns (uint256) {
        return _crossMarginStorage().crossMarginAccounts[account].getNumActiveMarkets();
    }

    /// @notice Check if account is in liquidation
    function accountInLiquidation(address account) public view returns (bool) {
        return _cmIsAccountInLiquidation(account);
    }
}
