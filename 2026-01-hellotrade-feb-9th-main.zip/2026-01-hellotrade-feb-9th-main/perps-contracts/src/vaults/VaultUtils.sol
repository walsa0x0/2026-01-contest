// SPDX-License-Identifier: UNLICENSED
pragma solidity =0.8.28;

import {Position} from "src/lib/Position.sol";
import {Math} from "src/lib/Math.sol";

error LiquidationCrossesZero();
error MaxPositionsExceeded();
error InvalidAccountLiquidation();
error InvalidAccountDelever(address account);
error ReduceOnlyViolated(int256 oldSize, int256 fillSize);
error LiquidationResultsInNegativeMargin(int256 remainingMargin);
error ADLHealthCheckFailed(
    uint256 maintMarginBefore, uint256 maintMarginAfter, int256 equityBefore, int256 equityAfter
);
error ADLLastPositionNegativeEquity(int256 equity);

/// @notice Result of executing a liquidatee fill in the vault
struct LiquidateeResult {
    int256 signedFill; // Signed fill size (for event and liquidator matching)
    int256 realizedPnl; // PnL applied to margin (after fee deduction)
    uint256 fee; // Fee amount to transfer
}

/// @notice Result of executing a regular fill in the vault
struct FillResult {
    int256 realizedPnl; // PnL applied to margin (after fee deduction)
    uint256 fee; // Fee amount to transfer
    uint128 newEntryPrice; // New position entry price (for event)
}

/// @title VaultUtils
/// @notice Abstract contract with shared utilities for Cross and Isolated margin vaults
abstract contract VaultUtils {
    using Math for int256;
    using Math for uint256;

    /// @notice Validates that a fill reduces position size (doesn't increase or flip)
    /// @param pos The current position
    /// @param fillSize The signed fill size
    function _requireReduceOnly(Position memory pos, int256 fillSize) internal pure {
        // Fill must be opposite direction to position
        if (pos.size == 0) revert ReduceOnlyViolated(pos.size, fillSize);
        // Same sign = increase, not reduce
        if (Math.signCmp(pos.size, fillSize)) revert ReduceOnlyViolated(pos.size, fillSize);
        // Fill larger than position = crosses zero (flip)
        if (fillSize.abs() > pos.size.abs()) revert ReduceOnlyViolated(pos.size, fillSize);
    }
}

