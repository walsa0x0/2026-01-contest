// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

import {IsolatedMarginVault} from "src/vaults/IsolatedMarginVault.sol";
import {IsolatedMarginAccount, IsolatedMarginAccountLib} from "src/lib/IsolatedMarginAccount.sol";
import {Position} from "src/lib/Position.sol";
import {MarketConfig, FundingInstant} from "src/price-feeds/HelloMarketDataStructs.sol";
import {Initializable} from "@openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";

import {StorkMockWithTestHelpers} from "test/mocks/StorkMockTest.sol";

/// @notice Minimal wrapper to expose internal IsolatedMarginVault functions for testing
contract IsolatedMarginVaultHarness is IsolatedMarginVault {
    using IsolatedMarginAccountLib for mapping(address => mapping(uint256 => IsolatedMarginAccount));

    StorkMockWithTestHelpers public storkMock;

    function initialize(uint32 market, MarketConfig memory config, uint256 storkKey) external initializer {
        storkMock = new StorkMockWithTestHelpers();
        storkMock.initializeWithKey(30, 0, storkKey);

        __HelloMarketData_init();
        __PriceOracleCache_init(address(storkMock));
        __IsolatedMarginVault_init();

        _setMarketConfig(market, config);
        // Initialize a valid funding instant
        _setLastFundingInstant(
            market,
            FundingInstant({
                cumulativeFundingIdx: 0,
                lastUpdateTimestamp: uint32(block.timestamp),
                lastUpdateBlock: uint32(block.number)
            })
        );
        // Set up price oracle mapping
        _setMarketHelloStorkId(market, bytes32(uint256(market)));
        _setMarketStorkId(market, bytes32(uint256(market)));
        storkMock.setStorkPrice(bytes32(uint256(market)), int192(int256(1e18)));
    }

    /// @notice Expose _isoPositionDeltas for testing
    function positionDeltas(
        address account,
        uint256 market,
        int256 fillSize,
        uint256 execPrice,
        MarketConfig memory mktConfig,
        int192 cumulativeFundingIdx
    ) external view returns (Position memory newPos, int256 posUpdatePnl, bool isSimpleClose) {
        return _isoPositionDeltas(account, market, fillSize, execPrice, mktConfig, cumulativeFundingIdx);
    }

    /// @notice Expose _isoUpdatePosition for testing
    function updatePosition(address account, uint256 market, Position memory newPos) external {
        _isoUpdatePosition(account, market, newPos);
    }

    /// @notice Expose _isoCreditMargin for testing
    function creditMargin(address account, uint256 market, uint256 amount) external {
        _isoCreditMargin(account, market, amount);
    }

    /// @notice Expose _isoDebitMargin for testing
    function debitMargin(address account, uint256 market, uint256 amount) external {
        _isoDebitMargin(account, market, amount);
    }

    /// @notice Expose _isoApplyMarginDelta for testing
    function applyMarginDelta(address account, uint256 market, int256 delta) external {
        _isoApplyMarginDelta(account, market, delta);
    }

    /// @notice Check if isolated position is in liquidation
    function isPositionInLiquidation(address account, uint256 market) external view returns (bool) {
        return _isoIsPositionInLiquidation(account, market);
    }

    /// @notice Get raw position from storage
    function getRawPosition(address account, uint256 market) external view returns (Position memory) {
        return getIsoPosition(account, market);
    }

    /// @notice Get raw margin from storage
    function getRawMargin(address account, uint256 market) external view returns (uint256) {
        return getIsoMargin(account, market);
    }

    /// @notice Check if position has any size
    function hasPosition(address account, uint256 market) external view returns (bool) {
        return getIsoPosition(account, market).size != 0;
    }
}

contract IsolatedMarginVaultTest is Test {
    IsolatedMarginVaultHarness vault;

    address alice = makeAddr("alice");
    address bob = makeAddr("bob");

    uint256 storkKey;

    uint32 constant MARKET_ID = 1;
    uint256 constant ENTRY_PRICE = 100e18; // $100
    uint256 constant EXIT_PRICE = 110e18; // $110 (10% gain for longs)

    MarketConfig defaultConfig;

    function setUp() public {
        (, storkKey) = makeAddrAndKey("STORK");
        vault = new IsolatedMarginVaultHarness();

        defaultConfig = MarketConfig({
            maxLeverage: 10000, // 100x
            defaultLeverage: 100, // 1x
            pricePrecision: 18,
            basePrecision: 2, // 1e2 = 1 unit
            quotePrecision: 6,
            fundingMax: 100_000_000,
            fundingMin: -100_000_000,
            minFundingInterval: 1
        });

        vault.initialize(MARKET_ID, defaultConfig, storkKey);
    }

    // ============ 1. New Position Open ============

    /// @notice First position in a market - user never traded before
    function test_NewPositionOpen() public {
        assertFalse(vault.hasPosition(bob, MARKET_ID), "Precondition: bob has no position");

        int256 fillSize = 100e2; // 100 units long

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(bob, MARKET_ID, fillSize, ENTRY_PRICE, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, fillSize, "size: should match fill");
        assertEq(newPos.entryPrice, uint128(ENTRY_PRICE), "entryPrice: should be exec price");
        assertEq(newPos.leverage, defaultConfig.defaultLeverage, "leverage: should use default");
        assertEq(newPos.entryFundingIdx, 0, "entryFundingIdx: should be current funding idx");

        // PnL
        assertEq(pnl, 0, "pnl: should be 0 for new position");

        // Simple close - for isolated, first position is not a close
        assertFalse(isSimpleClose, "isSimpleClose: new position is never a close");
    }

    // ============ 2. Existing Position Increase Size ============

    /// @notice Increase existing long position
    function test_ExistingPositionIncreaseSize() public {
        // Setup: Alice has a long position with margin
        Position memory initialPos = Position({
            size: 100e2, // 100 units
            entryFundingIdx: 0,
            leverage: 200, // 2x
            entryPrice: uint128(ENTRY_PRICE) // $100
        });
        vault.updatePosition(alice, MARKET_ID, initialPos);
        vault.creditMargin(alice, MARKET_ID, 5000e6); // $5000 margin

        assertTrue(vault.hasPosition(alice, MARKET_ID), "Precondition: alice has position");

        // Increase by 50 units at higher price
        int256 fillSize = 50e2;
        uint256 execPrice = 120e18; // $120

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, execPrice, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, 150e2, "size: 100 + 50 = 150");
        assertEq(newPos.leverage, 200, "leverage: unchanged");
        // Weighted avg: (100*100e18 + 50*120e18) / 150 = 16000e18 / 150 = 106.67e18
        // For longs, rounds up
        uint256 expectedAvgPrice = (100 * ENTRY_PRICE + 50 * execPrice + 149) / 150;
        assertEq(newPos.entryPrice, uint128(expectedAvgPrice), "entryPrice: weighted average (rounded up for long)");

        // PnL - only funding (which is 0), no realized PnL on increase
        assertEq(pnl, 0, "pnl: no realized PnL on increase");

        // Simple close
        assertFalse(isSimpleClose, "isSimpleClose: increase is not a close");
    }

    // ============ 3. Existing Position Decrease Size (Partial Close) ============

    /// @notice Partial close of existing long position
    function test_ExistingPositionDecreaseSize() public {
        // Setup: Alice has a long position at $100
        Position memory initialPos =
            Position({size: 100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);
        vault.creditMargin(alice, MARKET_ID, 5000e6);

        // Close 30 units at $110 (profit)
        int256 fillSize = -30e2;
        uint256 execPrice = EXIT_PRICE; // $110

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, execPrice, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, 70e2, "size: 100 - 30 = 70");
        assertEq(newPos.leverage, 200, "leverage: unchanged");
        assertEq(newPos.entryPrice, uint128(ENTRY_PRICE), "entryPrice: unchanged on partial close");

        // PnL: 30 units * ($110 - $100) = 30 * $10 = $300
        int256 expectedPnl = 300e6;
        assertEq(pnl, expectedPnl, "pnl: realized profit on partial close");

        // Simple close
        assertTrue(isSimpleClose, "isSimpleClose: partial close IS a simple close");
    }

    // ============ 4. Existing Position Crosses Zero ============

    /// @notice Position flips from long to short (crosses zero)
    function test_ExistingPositionCrossesZero() public {
        // Setup: Alice has a long position at $100
        Position memory initialPos =
            Position({size: 100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);
        vault.creditMargin(alice, MARKET_ID, 5000e6);

        // Sell 150 units at $110 (close 100 long, open 50 short)
        int256 fillSize = -150e2;
        uint256 execPrice = EXIT_PRICE;

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, execPrice, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, -50e2, "size: flipped to -50 short");
        assertEq(newPos.leverage, 200, "leverage: unchanged");
        assertEq(newPos.entryPrice, uint128(execPrice), "entryPrice: reset to exec price after flip");

        // PnL: Close entire 100 unit long at profit
        // 100 units * ($110 - $100) = $1000
        int256 expectedPnl = 1000e6;
        assertEq(pnl, expectedPnl, "pnl: realized profit from closing entire long");

        // Simple close
        assertFalse(isSimpleClose, "isSimpleClose: crossing zero is NOT a simple close");
    }

    // ============ 5. Full Close ============

    /// @notice Full close (size goes to exactly zero)
    function test_FullClose() public {
        Position memory initialPos =
            Position({size: 100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);
        vault.creditMargin(alice, MARKET_ID, 5000e6);

        int256 fillSize = -100e2; // Exact close

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, EXIT_PRICE, defaultConfig, 0);

        assertEq(newPos.size, 0, "size: fully closed");
        assertTrue(isSimpleClose, "isSimpleClose: full close IS a simple close");

        int256 expectedPnl = 1000e6; // 100 * $10
        assertEq(pnl, expectedPnl, "pnl: full realized profit");
    }

    // ============ Isolated-specific: Margin Operations ============

    /// @notice Test isolated margin credit/debit
    function test_MarginOperations() public {
        // Credit margin
        vault.creditMargin(alice, MARKET_ID, 1000e6);
        assertEq(vault.getIsoMargin(alice, MARKET_ID), 1000e6, "margin: should be credited");

        // Credit more
        vault.creditMargin(alice, MARKET_ID, 500e6);
        assertEq(vault.getIsoMargin(alice, MARKET_ID), 1500e6, "margin: should accumulate");

        // Debit
        vault.debitMargin(alice, MARKET_ID, 300e6);
        assertEq(vault.getIsoMargin(alice, MARKET_ID), 1200e6, "margin: should be debited");
    }

    /// @notice Test margin delta application
    function test_ApplyMarginDelta() public {
        vault.creditMargin(alice, MARKET_ID, 1000e6);

        // Positive delta (profit)
        vault.applyMarginDelta(alice, MARKET_ID, 200e6);
        assertEq(vault.getIsoMargin(alice, MARKET_ID), 1200e6, "margin: increased by profit");

        // Negative delta (loss)
        vault.applyMarginDelta(alice, MARKET_ID, -300e6);
        assertEq(vault.getIsoMargin(alice, MARKET_ID), 900e6, "margin: decreased by loss");
    }

    // ============ Isolated-specific: Per-market isolation ============

    /// @notice Test that positions in different markets are isolated
    function test_MarketsAreIsolated() public {
        uint32 market2 = 2;

        // Setup market 2
        vault.storkMock().setStorkPrice(bytes32(uint256(market2)), int192(int256(50e18)));

        // Alice has position in market 1
        Position memory pos1 =
            Position({size: 100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, pos1);
        vault.creditMargin(alice, MARKET_ID, 5000e6);

        // Alice has different position in market 2
        Position memory pos2 = Position({
            size: -50e2, // Short
            entryFundingIdx: 0,
            leverage: 100,
            entryPrice: uint128(50e18)
        });
        vault.updatePosition(alice, market2, pos2);
        vault.creditMargin(alice, market2, 2500e6);

        // Verify isolation
        assertEq(vault.getIsoPosition(alice, MARKET_ID).size, 100e2, "market1: position intact");
        assertEq(vault.getIsoMargin(alice, MARKET_ID), 5000e6, "market1: margin intact");

        assertEq(vault.getIsoPosition(alice, market2).size, -50e2, "market2: different position");
        assertEq(vault.getIsoMargin(alice, market2), 2500e6, "market2: different margin");

        // Operations on one market don't affect the other
        vault.applyMarginDelta(alice, MARKET_ID, -1000e6);
        assertEq(vault.getIsoMargin(alice, MARKET_ID), 4000e6, "market1: margin updated");
        assertEq(vault.getIsoMargin(alice, market2), 2500e6, "market2: margin unchanged");
    }

    // ============ Short Position Tests ============

    /// @notice Short position partial close
    function test_ShortPositionDecreaseSize() public {
        // Setup: Alice has a short position at $100
        Position memory initialPos =
            Position({size: -100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);
        vault.creditMargin(alice, MARKET_ID, 5000e6);

        // Buy back 30 units at $90 (profit for short)
        int256 fillSize = 30e2;
        uint256 execPrice = 90e18;

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, execPrice, defaultConfig, 0);

        assertEq(newPos.size, -70e2, "size: -100 + 30 = -70");
        assertTrue(isSimpleClose, "isSimpleClose: reducing short IS a simple close");

        // PnL: 30 units * ($100 - $90) = $300 profit
        int256 expectedPnl = 300e6;
        assertEq(pnl, expectedPnl, "pnl: profit from covering short at lower price");
    }
}

