// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Bitmap} from "src/lib/NonceBitmap.sol";

contract NonceBitmapWrapper {
    Bitmap private bitmap;

    function isUsed(uint256 nonce) external view returns (bool) {
        return bitmap.isUsed(nonce);
    }

    function burnNonce(uint256 nonce) external {
        bitmap.burnNonce(nonce);
    }
}
