// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

import {CrossMarginVault} from "src/vaults/CrossMarginVault.sol";
import {CrossMarginAccount, CrossMarginAccountLib} from "src/lib/CrossMarginAccount.sol";
import {Position} from "src/lib/Position.sol";
import {MarketConfig, FundingInstant} from "src/price-feeds/HelloMarketDataStructs.sol";

import {StorkMockWithTestHelpers} from "test/mocks/StorkMockTest.sol";

/// @notice Minimal wrapper to expose internal CrossMarginVault functions for testing
contract CrossMarginVaultHarness is CrossMarginVault {
    using CrossMarginAccountLib for mapping(address => CrossMarginAccount);

    StorkMockWithTestHelpers public storkMock;

    function initialize(uint32 market, MarketConfig memory config, uint256 storkKey) external initializer {
        storkMock = new StorkMockWithTestHelpers();
        storkMock.initializeWithKey(30, 0, storkKey);

        __CrossMarginVault_init(address(storkMock));
        _setMarketConfig(market, config);
        // Initialize a valid funding instant
        _setLastFundingInstant(
            market,
            FundingInstant({
                cumulativeFundingIdx: 0,
                lastUpdateTimestamp: uint32(block.timestamp),
                lastUpdateBlock: uint32(block.number)
            })
        );
        // Set up price oracle mapping
        _setMarketHelloStorkId(market, bytes32(uint256(market)));
        _setMarketStorkId(market, bytes32(uint256(market)));
        storkMock.setStorkPrice(bytes32(uint256(market)), int192(int256(1e18)));
    }

    /// @notice Expose _cmPositionDeltas for testing
    function positionDeltas(
        address account,
        uint256 market,
        int256 fillSize,
        uint256 execPrice,
        MarketConfig memory mktConfig,
        int192 cumulativeFundingIdx
    ) external view returns (Position memory newPos, int256 posUpdatePnl, bool isSimpleClose) {
        return _cmPositionDeltas(account, market, fillSize, execPrice, mktConfig, cumulativeFundingIdx);
    }

    /// @notice Expose _cmUpdatePosition for testing
    function updatePosition(address account, uint256 market, Position memory newPos) external {
        _cmUpdatePosition(account, market, newPos);
    }

    /// @notice Direct access to set margin for testing
    function setMargin(address account, int256 amount) external {
        _cmSetMargin(account, amount);
    }

    /// @notice Check if account is in market
    function isInMarket(address account, uint256 market) external view returns (bool) {
        CrossMarginVaultStorage storage $ = _crossMarginStorage();
        return $.crossMarginAccounts.isInMarket(account, market);
    }

    /// @notice Get raw position from storage (includes dirty data)
    function getRawPosition(address account, uint256 market) external view returns (Position memory) {
        CrossMarginVaultStorage storage $ = _crossMarginStorage();
        return $.crossMarginAccounts[account].positions[market];
    }
}

contract CrossMarginVaultTest is Test {
    CrossMarginVaultHarness vault;

    address alice = makeAddr("alice");
    address bob = makeAddr("bob");

    uint256 storkKey;

    uint32 constant MARKET_ID = 1;
    uint256 constant ENTRY_PRICE = 100e18; // $100
    uint256 constant EXIT_PRICE = 110e18; // $110 (10% gain for longs)

    MarketConfig defaultConfig;

    function setUp() public {
        (, storkKey) = makeAddrAndKey("STORK");
        vault = new CrossMarginVaultHarness();

        defaultConfig = MarketConfig({
            maxLeverage: 10000, // 100x
            defaultLeverage: 100, // 1x
            pricePrecision: 18,
            basePrecision: 2, // 1e2 = 1 unit
            quotePrecision: 6,
            fundingMax: 100_000_000,
            fundingMin: -100_000_000,
            minFundingInterval: 1
        });

        vault.initialize(MARKET_ID, defaultConfig, storkKey);
    }

    // ============ 1. New Position Open ============

    /// @notice First position in a market - user never traded before
    function test_NewPositionOpen() public {
        assertFalse(vault.isInMarket(bob, MARKET_ID), "Precondition: bob not in market");

        int256 fillSize = 100e2; // 100 units long

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(bob, MARKET_ID, fillSize, ENTRY_PRICE, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, fillSize, "size: should match fill");
        assertEq(newPos.entryPrice, uint128(ENTRY_PRICE), "entryPrice: should be exec price");
        assertEq(newPos.leverage, defaultConfig.defaultLeverage, "leverage: should use default");
        assertEq(newPos.entryFundingIdx, 0, "entryFundingIdx: should be current funding idx");

        // PnL
        assertEq(pnl, 0, "pnl: should be 0 for new position");

        // Simple close
        assertFalse(isSimpleClose, "isSimpleClose: new position is never a close");
    }

    // ============ 2. Dirty Position Open (Reopen After Close) ============

    /// @notice Reopen position after closing - dirty storage should not affect result
    function test_DirtyPositionOpen() public {
        uint128 customLeverage = 500; // 5x

        // Setup: Open and close a position, leaving dirty storage
        Position memory initialPos =
            Position({size: 100e2, entryFundingIdx: 0, leverage: customLeverage, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);
        vault.updatePosition(
            alice, MARKET_ID, Position({size: 0, entryFundingIdx: 0, leverage: customLeverage, entryPrice: 0})
        );

        // Verify dirty state
        assertFalse(vault.isInMarket(alice, MARKET_ID), "Precondition: alice not in market");
        Position memory dirtyPos = vault.getRawPosition(alice, MARKET_ID);
        assertEq(dirtyPos.size, 100e2, "Precondition: dirty storage has old size");

        // Reopen in opposite direction
        int256 fillSize = -50e2; // 50 units short

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, EXIT_PRICE, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, fillSize, "size: should match fill (not affected by dirty data)");
        assertEq(newPos.entryPrice, uint128(EXIT_PRICE), "entryPrice: should be exec price");
        assertEq(newPos.leverage, customLeverage, "leverage: should preserve user preference from dirty storage");
        assertEq(newPos.entryFundingIdx, 0, "entryFundingIdx: should be current funding idx");

        // PnL
        assertEq(pnl, 0, "pnl: should be 0 (dirty position PnL ignored)");

        // Simple close
        assertFalse(isSimpleClose, "isSimpleClose: reopening is never a close");
    }

    // ============ 3. Existing Position Increase Size ============

    /// @notice Increase existing long position
    function test_ExistingPositionIncreaseSize() public {
        // Setup: Alice has a long position
        Position memory initialPos = Position({
            size: 100e2, // 100 units
            entryFundingIdx: 0,
            leverage: 200, // 2x
            entryPrice: uint128(ENTRY_PRICE) // $100
        });
        vault.updatePosition(alice, MARKET_ID, initialPos);
        assertTrue(vault.isInMarket(alice, MARKET_ID), "Precondition: alice in market");

        // Increase by 50 units at higher price
        int256 fillSize = 50e2;
        uint256 execPrice = 120e18; // $120

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, execPrice, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, 150e2, "size: 100 + 50 = 150");
        assertEq(newPos.leverage, 200, "leverage: unchanged");
        // Weighted avg: (100*100e18 + 50*120e18) / 150 = 16000e18 / 150 = 106.67e18
        // For longs, rounds up
        uint256 expectedAvgPrice = (100 * ENTRY_PRICE + 50 * execPrice + 149) / 150;
        assertEq(newPos.entryPrice, uint128(expectedAvgPrice), "entryPrice: weighted average (rounded up for long)");

        // PnL - only funding (which is 0), no realized PnL on increase
        assertEq(pnl, 0, "pnl: no realized PnL on increase");

        // Simple close
        assertFalse(isSimpleClose, "isSimpleClose: increase is not a close");
    }

    // ============ 4. Existing Position Decrease Size (Partial Close) ============

    /// @notice Partial close of existing long position
    function test_ExistingPositionDecreaseSize() public {
        // Setup: Alice has a long position at $100
        Position memory initialPos =
            Position({size: 100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);

        // Close 30 units at $110 (profit)
        int256 fillSize = -30e2;
        uint256 execPrice = EXIT_PRICE; // $110

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, execPrice, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, 70e2, "size: 100 - 30 = 70");
        assertEq(newPos.leverage, 200, "leverage: unchanged");
        assertEq(newPos.entryPrice, uint128(ENTRY_PRICE), "entryPrice: unchanged on partial close");

        // PnL: 30 units * ($110 - $100) = 30 * $10 = $300
        // With basePrecision=2: 30e2 * (110e18 - 100e18) / (1e2 * 1e18 / 1e6) = 30e2 * 10e18 / 1e14 = 300e6
        int256 expectedPnl = 300e6;
        assertEq(pnl, expectedPnl, "pnl: realized profit on partial close");

        // Simple close
        assertTrue(isSimpleClose, "isSimpleClose: partial close IS a simple close");
    }

    // ============ 5. Existing Position Crosses Zero ============

    /// @notice Position flips from long to short (crosses zero)
    function test_ExistingPositionCrossesZero() public {
        // Setup: Alice has a long position at $100
        Position memory initialPos =
            Position({size: 100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);

        // Sell 150 units at $110 (close 100 long, open 50 short)
        int256 fillSize = -150e2;
        uint256 execPrice = EXIT_PRICE;

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, execPrice, defaultConfig, 0);

        // Position state
        assertEq(newPos.size, -50e2, "size: flipped to -50 short");
        assertEq(newPos.leverage, 200, "leverage: unchanged");
        assertEq(newPos.entryPrice, uint128(execPrice), "entryPrice: reset to exec price after flip");

        // PnL: Close entire 100 unit long at profit
        // 100 units * ($110 - $100) = $1000
        int256 expectedPnl = 1000e6;
        assertEq(pnl, expectedPnl, "pnl: realized profit from closing entire long");

        // Simple close
        assertFalse(isSimpleClose, "isSimpleClose: crossing zero is NOT a simple close");
    }

    // ============ Additional Edge Cases ============

    /// @notice Full close (size goes to exactly zero)
    function test_FullClose() public {
        Position memory initialPos =
            Position({size: 100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);

        int256 fillSize = -100e2; // Exact close

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, EXIT_PRICE, defaultConfig, 0);

        assertEq(newPos.size, 0, "size: fully closed");
        assertTrue(isSimpleClose, "isSimpleClose: full close IS a simple close");

        int256 expectedPnl = 1000e6; // 100 * $10
        assertEq(pnl, expectedPnl, "pnl: full realized profit");
    }

    /// @notice Short position partial close
    function test_ShortPositionDecreaseSize() public {
        // Setup: Alice has a short position at $100
        Position memory initialPos =
            Position({size: -100e2, entryFundingIdx: 0, leverage: 200, entryPrice: uint128(ENTRY_PRICE)});
        vault.updatePosition(alice, MARKET_ID, initialPos);

        // Buy back 30 units at $90 (profit for short)
        int256 fillSize = 30e2;
        uint256 execPrice = 90e18;

        (Position memory newPos, int256 pnl, bool isSimpleClose) =
            vault.positionDeltas(alice, MARKET_ID, fillSize, execPrice, defaultConfig, 0);

        assertEq(newPos.size, -70e2, "size: -100 + 30 = -70");
        assertTrue(isSimpleClose, "isSimpleClose: reducing short IS a simple close");

        // PnL: 30 units * ($100 - $90) = $300 profit
        int256 expectedPnl = 300e6;
        assertEq(pnl, expectedPnl, "pnl: profit from covering short at lower price");
    }
}
