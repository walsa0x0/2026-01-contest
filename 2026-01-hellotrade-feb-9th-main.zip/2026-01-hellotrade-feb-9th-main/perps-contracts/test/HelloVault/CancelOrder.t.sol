// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {MessageHashUtils} from "@openzeppelin-contracts/utils/cryptography/MessageHashUtils.sol";
import {Order, OrderLib} from "src/lib/Order.sol";
import {SignerUtils} from "src/lib/SignerUtils.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {IHelloVaultEvents} from "src/interfaces/IHelloVaultEvents.sol";

contract CancelOrderTest is Test, VaultTestHelpers, IHelloVaultErrors, IHelloVaultEvents {
    bytes32 vaultDomainSep;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();
    }

    // BASIC CANCELLATION TESTS

    function test_UserCanCancelUnusedNonce() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 nonce = 42;

        // Verify nonce is not used initially
        assertFalse(helloVault.nonceUsed(alice, nonce));

        // Sign and execute cancellation
        bytes memory sig = signCancelOrder(aliceKey, nonce, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);

        vm.expectEmit(true, false, false, true);
        emit OrderCancelled(alice, nonce);

        helloVault.cancelOrderWithSignature(alice, nonce, vm.getBlockTimestamp() + 1 hours, trackingHead, sig);

        // Verify nonce is now used
        assertTrue(helloVault.nonceUsed(alice, nonce));
    }

    function test_CannotCancelAlreadyUsedNonce() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 nonce = 42;

        // First cancel should succeed
        bytes memory sig = signCancelOrder(aliceKey, nonce, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
        helloVault.cancelOrderWithSignature(alice, nonce, vm.getBlockTimestamp() + 1 hours, trackingHead, sig);

        // Second cancel should revert
        bytes memory sig2 = signCancelOrder(aliceKey, nonce, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
        vm.expectRevert(abi.encodeWithSelector(NonceUsed.selector));
        helloVault.cancelOrderWithSignature(alice, nonce, vm.getBlockTimestamp() + 1 hours, trackingHead + 1, sig2);
    }

    function test_CannotCancelWithInvalidSignature() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 nonce = 42;

        bytes memory sig = signCancelOrder(bobKey, nonce, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);

        vm.expectRevert(
            abi.encodeWithSelector(InvalidSigner.selector, alice, 0x8cadc8C208AB0f2012BDFFF05FeF559665c7b8A9)
        );
        helloVault.cancelOrderWithSignature(alice, nonce, vm.getBlockTimestamp() + 1 hours, trackingHead, sig);
    }

    // PARTIAL FILL CANCELLATION TESTS

    function test_CancelClearsPartialFillData() public {
        uint256 trackingHead = _useTrackingHead();

        // Deposit for both users
        _depositFor(aliceKey, 100e6, trackingHead);
        _depositFor(bobKey, 100e6, trackingHead + 1);

        // Create orders - Alice long 10, Bob short 10
        uint256 aliceNonce = 1;
        Order memory aliceLong =
            Order({account: alice, market: mktId1, size: 10e2, limitPrice: 1e18, nonce: aliceNonce});
        bytes memory aliceLongSig = signOrder(aliceKey, aliceLong);

        Order memory bobShort = Order({account: bob, market: mktId1, size: -10e2, limitPrice: 0, nonce: 1});
        bytes memory bobShortSig = signOrder(bobKey, bobShort);

        // Partial fill: only 5 units
        StorkStructs.TemporalNumericValueInput[] memory emptyPrices = new StorkStructs.TemporalNumericValueInput[](0);
        helloVault.handleMatchedFill(emptyPrices, aliceLong, aliceLongSig, bobShort, bobShortSig, 5e2, trackingHead + 2);

        // Verify partial fill is tracked
        bytes32 orderId = keccak256(abi.encode(alice, aliceNonce));
        assertEq(helloVault.orderFills(orderId), 5e2);
        assertFalse(helloVault.nonceUsed(alice, aliceNonce)); // Nonce not burnt yet

        // Cancel the remaining order
        bytes memory cancelSig = signCancelOrder(aliceKey, aliceNonce, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);

        vm.expectEmit(true, false, false, true);
        emit OrderCancelled(alice, aliceNonce);

        helloVault.cancelOrderWithSignature(
            alice, aliceNonce, vm.getBlockTimestamp() + 1 hours, trackingHead + 3, cancelSig
        );

        // Verify nonce is burnt and partial fill data is cleared
        assertTrue(helloVault.nonceUsed(alice, aliceNonce));
        assertEq(helloVault.orderFills(orderId), 0);
    }

    function test_CannotFillAfterCancel() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 100e6, trackingHead);
        _depositFor(bobKey, 100e6, trackingHead + 1);

        uint256 aliceNonce = 1;
        Order memory aliceLong =
            Order({account: alice, market: mktId1, size: 10e2, limitPrice: 1e18, nonce: aliceNonce});
        bytes memory aliceLongSig = signOrder(aliceKey, aliceLong);

        // Cancel before any fill
        bytes memory cancelSig = signCancelOrder(aliceKey, aliceNonce, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
        helloVault.cancelOrderWithSignature(
            alice, aliceNonce, vm.getBlockTimestamp() + 1 hours, trackingHead + 2, cancelSig
        );

        // Try to fill the cancelled order
        Order memory bobShort = Order({account: bob, market: mktId1, size: -10e2, limitPrice: 0, nonce: 1});
        bytes memory bobShortSig = signOrder(bobKey, bobShort);

        StorkStructs.TemporalNumericValueInput[] memory emptyPrices = new StorkStructs.TemporalNumericValueInput[](0);
        vm.expectRevert(abi.encodeWithSelector(NonceUsed.selector));
        helloVault.handleMatchedFill(emptyPrices, aliceLong, aliceLongSig, bobShort, bobShortSig, 5e2, trackingHead + 3);
    }

    // DELEGATED SIGNER TESTS

    function signSetDelegator(
        uint256 signerKey,
        address account,
        address delegator,
        uint256 until,
        uint256 nonce,
        uint256 deadline
    ) internal view returns (bytes memory) {
        bytes32 structHash = SignerUtils._buildSetDelegatorHash(account, delegator, until, nonce, deadline);
        bytes32 digest = MessageHashUtils.toTypedDataHash(vaultDomainSep, structHash);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }

    function signCancelOrderFor(uint256 signerKey, address account, uint256 nonce, uint256 deadline)
        internal
        view
        returns (bytes memory)
    {
        bytes32 structHash = SignerUtils._buildCancelOrderHash(account, nonce, deadline);
        bytes32 digest = MessageHashUtils.toTypedDataHash(vaultDomainSep, structHash);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }

    function test_DelegatedSignerCanCancelOrder() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 until = vm.getBlockTimestamp() + 1 days;

        // Alice delegates to Charlie
        bytes memory delegateSig =
            signSetDelegator(aliceKey, alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours);

        helloVault.setDelegatorWithSignature(
            alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours, trackingHead, delegateSig
        );

        // Charlie signs a cancel order for Alice
        uint256 nonceToCancel = 42;
        bytes memory cancelSig = signCancelOrderFor(charlieKey, alice, nonceToCancel, vm.getBlockTimestamp() + 1 hours);

        vm.expectEmit(true, false, false, true);
        emit OrderCancelled(alice, nonceToCancel);

        helloVault.cancelOrderWithSignature(
            alice, nonceToCancel, vm.getBlockTimestamp() + 1 hours, trackingHead + 1, cancelSig
        );

        // Verify nonce is burnt
        assertTrue(helloVault.nonceUsed(alice, nonceToCancel));
    }
}

