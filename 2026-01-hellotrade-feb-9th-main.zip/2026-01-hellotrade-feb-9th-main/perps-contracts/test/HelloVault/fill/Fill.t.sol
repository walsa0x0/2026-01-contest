// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

// libraries
import {Math} from "src/lib/Math.sol";
import {Order} from "src/lib/Order.sol";
import {Position} from "src/lib/Position.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {FundingInstant} from "src/price-feeds/HelloMarketDataStructs.sol";

import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {IHelloMarketDataErrors} from "src/interfaces/IHelloMarketDataErrors.sol";
import {MaxPositionsExceeded} from "src/vaults/CrossMarginVault.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";

contract VaultFillTest is Test, VaultTestHelpers, IHelloVaultErrors, IHelloMarketDataErrors {
    uint256 constant WAD = 1e18;
    using Math for int256;

    Order aliceLongN1;
    bytes aliceLongN1Sig;
    Order bobShortN1;
    bytes bobShortN1Sig;

    Order aliceShortN2;
    bytes aliceShortN2Sig;
    Order bobLongN2;
    bytes bobLongN2Sig;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        _depositFor(aliceKey, 100_000 * 1e6, _useTrackingHead());
        _depositFor(bobKey, 100_000 * 1e6, _useTrackingHead());

        // Nonce 1 orders: Alice long, Bob short
        aliceLongN1 = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 1});
        aliceLongN1Sig = signOrder(aliceKey, aliceLongN1);
        bobShortN1 = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 1});
        bobShortN1Sig = signOrder(bobKey, bobShortN1);

        // Nonce 2 orders: Alice short (close), Bob long
        aliceShortN2 = Order({account: alice, market: mktId1, size: -5_000, limitPrice: 1e18, nonce: 2});
        aliceShortN2Sig = signOrder(aliceKey, aliceShortN2);
        bobLongN2 = Order({account: bob, market: mktId1, size: 5_000, limitPrice: type(uint256).max, nonce: 2});
        bobLongN2Sig = signOrder(bobKey, bobLongN2);

        prices = toArray(_createPriceInputWithPrice(mktId1, 1e18));
    }

    function test_netFillLongThenShort() public {
        // Alice opens long
        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, _useTrackingHead());

        // Alice closes half (short)
        _fillMatchedOrder(aliceShortN2, aliceShortN2Sig, bobLongN2, bobLongN2Sig, 5_000, _useTrackingHead());

        // Nonces burned
        assert(helloVault.nonceUsed(alice, 1));
        assert(helloVault.nonceUsed(alice, 2));

        int256 orderNet = 10_000 - 5_000;

        Position memory position = helloVault.getPosition(alice, mktId1, false);
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;

        assertEq(position.size, orderNet);
        assertEq(position.leverage, defaultLeverage);
        assertEq(position.entryPrice, 1e18);
        assertEq(position.entryFundingIdx, fundingIdxLast);
    }

    // ============================================================================
    // VALIDATION SAD PATH TESTS
    // ============================================================================

    // Order for alice signed by bob
    function test_ValidateOrderSigner() public {
        uint256 trackingHead = _useTrackingHead();

        Order memory makerOrder = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 1});

        // Alice's order signed by bob (invalid)
        bytes memory makerSig = signOrder(bobKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        vm.expectPartialRevert(InvalidSigner.selector);
        _fillMatchedOrder(prices, makerOrder, makerSig, takerOrder, takerSig, 10_000, trackingHead);
    }

    function test_ValidateOrderMarket() public {
        uint32 invalidMarket = uint32(42069);
        uint256 trackingHead = _useTrackingHead();

        Order memory makerOrder =
            Order({account: alice, market: invalidMarket, size: 10_000, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({account: bob, market: invalidMarket, size: -10_000, limitPrice: 0, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        vm.expectRevert(abi.encodeWithSelector(MarketNotInitialized.selector, invalidMarket));
        _fillMatchedOrder(prices, makerOrder, makerSig, takerOrder, takerSig, 10_000, trackingHead);
    }

    /// @notice Test that SL/TP orders (size=0) with no position revert
    /// @dev When order.size == 0, it's an SL/TP order that must close the full position.
    ///      If there's no position, it reverts with InvalidSlTp.
    function test_ValidateOrderSize() public {
        uint256 trackingHead = _useTrackingHead();

        Order memory makerOrder = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({account: bob, market: mktId1, size: 0, limitPrice: 1e18, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // SL/TP (size=0) with no position reverts with InvalidSlTp
        // Alice has no position, so positionSize=0, fillSize=1000, check: 0 != -1000 → revert
        vm.expectRevert(abi.encodeWithSelector(InvalidSlTp.selector, int256(0), int256(1000)));
        _fillMatchedOrder(prices, makerOrder, makerSig, takerOrder, takerSig, 1000, trackingHead);
    }

    function test_ValidateOrderNonce() public {
        // First fill succeeds
        _fillMatchedOrder(prices, aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, _useTrackingHead());

        // Second fill with same nonce should fail
        uint256 trackingHead = _useTrackingHead();
        Order memory makerOrder = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 2});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        vm.expectRevert(NonceUsed.selector);
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, 10_000, trackingHead);
    }

    function test_FillLongSizeMismatch() public {
        uint256 trackingHead = _useTrackingHead();

        // Both orders are long (same sign) - should fail
        Order memory makerOrder = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({
            account: bob,
            market: mktId1,
            size: 10_000, // Same sign as maker - invalid
            limitPrice: 1e18,
            nonce: 1
        });

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        vm.expectRevert(abi.encodeWithSelector(OrderSignMismatch.selector, 10_000, 10_000));
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, 10_000, trackingHead);
    }

    // ============================================================================
    // FUNDING PROCESSING ON FILL TESTS
    // ============================================================================

    function test_FundingOnFillLong() public {}

    function test_FundingOnFillNegativeMargin() public {
        // TODO: Test funding is processed when post-funding margin is negative
    }

    function test_FundingOnFillMultipleMarkets() public {
        // TODO: Test funding processing across multiple markets
        // - User with positions in multiple markets
        // - Each market processes funding independently
        // - Aggregate funding PnL calculation
    }

    function test_FundingPnlZero() public {}

    // ============================================================================
    // MAX POSITIONS TESTS
    // ============================================================================

    function test_MaxPositionsExceeded() public {
        uint256 IN_MARKETS_MAX = 16;

        // Set up markets 2-17
        vm.startPrank(admin);
        for (uint32 i = 2; i <= IN_MARKETS_MAX + 1; i++) {
            helloVault.setMarketConfig(
                i,
                MarketConfig({
                    maxLeverage: maxLeverage,
                    defaultLeverage: defaultLeverage,
                    pricePrecision: pricePrecision,
                    basePrecision: basePrecision,
                    quotePrecision: quotePrecision,
                    fundingMax: 100_000_000,
                    fundingMin: -100_000_000,
                    minFundingInterval: 1
                })
            );
            helloVault.setMarketStorkId(i, bytes32(uint256(i)));
            helloVault.setMarketHelloStorkId(i, bytes32(uint256(i)));
            storkMock.setStorkPrice(bytes32(uint256(i)), int192(1e18));
        }
        vm.stopPrank();

        // Initialize funding for all new markets
        vm.startPrank(relayer);
        for (uint32 i = 2; i <= IN_MARKETS_MAX + 1; i++) {
            helloVault.updateFundingInstant(i, FUNDING_RATE_IDX0, FUNDING_PRICE_IDX0, 0);
        }

        // Open positions in all 16 markets
        for (uint32 i = 1; i <= IN_MARKETS_MAX; i++) {
            Order memory aliceOrder = Order({account: alice, market: i, size: 100, limitPrice: 1e18, nonce: i});
            Order memory bobOrder = Order({account: bob, market: i, size: -100, limitPrice: 0, nonce: i});

            bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
            bytes memory bobSig = signOrder(bobKey, bobOrder);

            _fillMatchedOrder(aliceOrder, aliceSig, bobOrder, bobSig, 100, _useTrackingHead());
        }

        // Verify Alice has exactly 16 positions
        uint256[] memory aliceMarkets = helloVault.getActiveMarkets(alice);
        assertEq(aliceMarkets.length, IN_MARKETS_MAX);

        // Try to open a 17th position - should revert
        uint32 market17 = uint32(IN_MARKETS_MAX + 1);
        Order memory aliceOrder17 =
            Order({account: alice, market: market17, size: 100, limitPrice: 1e18, nonce: IN_MARKETS_MAX + 1});
        Order memory bobOrder17 =
            Order({account: bob, market: market17, size: -100, limitPrice: 0, nonce: IN_MARKETS_MAX + 1});

        bytes memory aliceSig17 = signOrder(aliceKey, aliceOrder17);
        bytes memory bobSig17 = signOrder(bobKey, bobOrder17);

        uint256 trackingHead = _useTrackingHead();

        vm.expectRevert(MaxPositionsExceeded.selector);
        _fillMatchedOrder(aliceOrder17, aliceSig17, bobOrder17, bobSig17, 100, trackingHead);
    }

    function test_CanStillFillExistingPositionAtMaxMarkets() public {
        uint256 IN_MARKETS_MAX = 16;

        // Set up markets 2-16
        vm.startPrank(admin);
        for (uint32 i = 2; i <= IN_MARKETS_MAX; i++) {
            helloVault.setMarketConfig(
                i,
                MarketConfig({
                    maxLeverage: maxLeverage,
                    defaultLeverage: defaultLeverage,
                    pricePrecision: pricePrecision,
                    basePrecision: basePrecision,
                    quotePrecision: quotePrecision,
                    fundingMax: 100_000_000,
                    fundingMin: -100_000_000,
                    minFundingInterval: 1
                })
            );
            helloVault.setMarketStorkId(i, bytes32(uint256(i)));
            helloVault.setMarketHelloStorkId(i, bytes32(uint256(i)));
            storkMock.setStorkPrice(bytes32(uint256(i)), int192(1e18));
        }
        vm.stopPrank();

        // Initialize funding for all new markets
        vm.startPrank(relayer);
        for (uint32 i = 2; i <= IN_MARKETS_MAX; i++) {
            helloVault.updateFundingInstant(i, FUNDING_RATE_IDX0, FUNDING_PRICE_IDX0, 0);
        }

        // Open positions in all 16 markets
        for (uint32 i = 1; i <= IN_MARKETS_MAX; i++) {
            Order memory aliceOrder = Order({account: alice, market: i, size: 100, limitPrice: 1e18, nonce: i});
            Order memory bobOrder = Order({account: bob, market: i, size: -100, limitPrice: 0, nonce: i});

            bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
            bytes memory bobSig = signOrder(bobKey, bobOrder);

            _fillMatchedOrder(aliceOrder, aliceSig, bobOrder, bobSig, 100, _useTrackingHead());
        }

        // Can still increase an existing position at max markets
        Order memory aliceOrder = Order({account: alice, market: mktId1, size: 100, limitPrice: 1e18, nonce: 17});
        Order memory bobOrder = Order({account: bob, market: mktId1, size: -100, limitPrice: 0, nonce: 17});

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
        bytes memory bobSig = signOrder(bobKey, bobOrder);

        // Should NOT revert - just increasing existing position
        _fillMatchedOrder(aliceOrder, aliceSig, bobOrder, bobSig, 100, _useTrackingHead());

        Position memory pos = helloVault.getPosition(alice, mktId1, false);
        assertEq(pos.size, 200); // 100 + 100
    }
}
