// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {Test} from "forge-std/Test.sol";

// libraries
import {Math} from "src/lib/Math.sol";
import {Order} from "src/lib/Order.sol";

import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";

contract FillIncreaseFromZeroTest is Test, VaultTestHelpers, IHelloVaultErrors {
    uint256 constant WAD = 1e18;
    using Math for int256;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        // Alice deposits 100,000 USDC
        bytes memory aliceSig =
            signPermit(aliceKey, address(usdcMock), address(helloVault), 100_000 * 1e6, block.timestamp + 1 hours);
        helloVault.depositWithSignature(alice, 100_000 * 1e6, block.timestamp + 1 hours, _useTrackingHead(), aliceSig);
        // So does bob
        bytes memory bobSig =
            signPermit(bobKey, address(usdcMock), address(helloVault), 100_000 * 1e6, block.timestamp + 1 hours);
        helloVault.depositWithSignature(bob, 100_000 * 1e6, block.timestamp + 1 hours, _useTrackingHead(), bobSig);
    }

    function test_FillLongMakerShortTaker() public {
        uint256 longLimit = 1e18;
        uint256 shortLimit = 0.9e18;
        int256 size = 10_000;
        uint256 trackingHead = _useTrackingHead();

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: longLimit, nonce: 1});

        Order memory takerOrder = Order({account: bob, market: mktId1, size: -size, limitPrice: shortLimit, nonce: 2});
        bytes memory sig = signOrder(aliceKey, makerOrder);
        bytes memory sig2 = signOrder(bobKey, takerOrder);
        _fillMatchedOrder(makerOrder, sig, takerOrder, sig2, size.abs(), trackingHead);
    }

    function test_FillShortMakerLongTaker() public {
        uint256 longLimit = 1e18;
        uint256 shortLimit = 0.9e18;
        int256 size = 10_000;
        uint256 trackingHead = _useTrackingHead();

        Order memory makerOrder = Order({account: alice, market: mktId1, size: -size, limitPrice: shortLimit, nonce: 1});

        Order memory takerOrder = Order({account: bob, market: mktId1, size: size, limitPrice: longLimit, nonce: 2});
        bytes memory sig = signOrder(aliceKey, makerOrder);
        bytes memory sig2 = signOrder(bobKey, takerOrder);
        _fillMatchedOrder(makerOrder, sig, takerOrder, sig2, size.abs(), trackingHead);
    }

    function test_FillLongPriceLtShortPriceCannotCross() public {
        uint256 longLimit = 1e18;
        uint256 shortLimit = 1.1e18;
        int256 size = 10_000;
        uint256 trackingHead = _useTrackingHead();

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: longLimit, nonce: 1});

        Order memory takerOrder = Order({account: bob, market: mktId1, size: -size, limitPrice: shortLimit, nonce: 2});
        bytes memory sig1 = signOrder(aliceKey, makerOrder);
        bytes memory sig2 = signOrder(bobKey, takerOrder);
        vm.expectRevert(abi.encodeWithSelector(NoOrderCross.selector, longLimit, shortLimit));
        _fillMatchedOrder(makerOrder, sig1, takerOrder, sig2, size.abs(), trackingHead);
    }
}
