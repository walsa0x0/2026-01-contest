// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {Test} from "forge-std/Test.sol";

// libraries
import {Math} from "src/lib/Math.sol";
import {Position} from "src/lib/Position.sol";
import {Order} from "src/lib/Order.sol";
import {FundingInstant} from "src/price-feeds/HelloMarketDataStructs.sol";

import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

import {console} from "forge-std/console.sol";

contract VaultFillFundingTest is Test, VaultTestHelpers {
    uint256 constant DEPOSIT_AMOUNT = 100_000 * 1e6;
    int256 constant FUNDING_DIVISOR = 10_000_000_000;

    using Math for int256;

    // Set funding config to pass intervals automatically

    function setUp() public virtual override {
        super.setUp();

        vm.startPrank(admin);
        helloVault.setFundingConfig(mktId1, 10_000_000, -10_000_000, 1);
        vm.startPrank(relayer);

        _depositFor(aliceKey, DEPOSIT_AMOUNT, 1);
        _depositFor(bobKey, DEPOSIT_AMOUNT, _useTrackingHead());
    }

    //
    // FUNDING PROCESSING ON FILL TESTS
    //

    // Internal helper to setup a matched order
    function _setupMatch(int256 size) internal {
        uint256 longLimit = 1e18;
        uint256 shortLimit = 1e18;
        (uint256 makerLimit, uint256 takerLimit) = (size > 0) ? (longLimit, shortLimit) : (shortLimit, longLimit);
        Order memory makerOrder =
            Order({account: alice, market: mktId1, size: size, limitPrice: makerLimit, nonce: _useNonce(alice)});

        Order memory takerOrder =
            Order({account: bob, market: mktId1, size: -size, limitPrice: takerLimit, nonce: _useNonce(bob)});

        bytes memory sig = signOrder(aliceKey, makerOrder);
        bytes memory sig2 = signOrder(bobKey, takerOrder);

        _fillMatchedOrder(prices, makerOrder, sig, takerOrder, sig2, size.abs(), _useTrackingHead());
    }

    function test_OrderInitializesAtLatestFundingInst() public {
        _setupMatch(10_000);
        int192 expectedFundingIdx = int192(FUNDING_RATE_IDX0 * FUNDING_PRICE_IDX0 / FUNDING_DIVISOR);

        Position memory alicePos = helloVault.getPosition(alice, mktId1, false);
        assertEq(alicePos.entryFundingIdx, expectedFundingIdx);
        Position memory bobPos = helloVault.getPosition(alice, mktId1, false);
        assertEq(bobPos.entryFundingIdx, expectedFundingIdx);
    }

    function test_FundingRoundsTo1e18() public {
        vm.startPrank(admin);
        helloVault.setFundingConfig(mktId1, 1_000_000_000, -1_000_000_000, 1);
        vm.startPrank(relayer);

        skip(60);

        uint256 trackingHead = _useTrackingHead();
        int256 fundingRate = 111_111_111; //1.11% repeating to e10
        int256 price = 111_111_111_111_111_111_111; // 111.1 repeating to e18
        helloVault.updateFundingInstant(1, fundingRate, price, trackingHead);

        // int192(fundingRate * price / 1e10);
        int192 expectedCumFundIdx1 = 1234567899999999999;
        FundingInstant memory f1 = helloVault.lastFundingInstant(1);
        assertEq(f1.cumulativeFundingIdx, expectedCumFundIdx1);

        // do it again
        skip(60);

        helloVault.updateFundingInstant(1, fundingRate, price, trackingHead);

        // int192(fundingRate * price / 1e10) + f1.cumulativeFundingIdx;
        int192 expectedCumFundIdx2 = 2469135799999999999;
        FundingInstant memory f2 = helloVault.lastFundingInstant(1);

        assertEq(f2.cumulativeFundingIdx + 1, expectedCumFundIdx2);
    }

    function test_LongPosNegativeFunding() public {
        _setupMatch(10_000);
    }

    function test_ShortPosNegativeFunding() public {
        _setupMatch(10_000);
    }

    function test_LongPosPositiveFunding() public {
        _setupMatch(10_000);
    }

    function test_ShortPosPositiveFunding() public {
        _setupMatch(10_000);
    }

    function test_OrderExecBetweenIntervalsNoFundingPnl() public {
        _setupMatch(10_000);
        int256 aliceMargin = helloVault.getMargin(alice);
        int256 bobMargin = helloVault.getMargin(bob);
        /// Immediately close out, zero net PNL
        _setupMatch(10_000);
        int256 newAliceMargin = helloVault.getMargin(alice);
        int256 newBobMargin = helloVault.getMargin(bob);
        assertEq(aliceMargin, newAliceMargin);
        assertEq(bobMargin, newBobMargin);
    }

    function test_OrderExecOneFundingPeriodIncrease() public {
        _setupMatch(10_000);

        vm.warp(3600);
        // Refresh prices after warp to avoid StaleValue (also updates stork mock)
        _setPricesForMarketWithPrice(mktId1, 1e18);
        helloVault.updateFundingInstant(mktId1, 10_000_000, 1e18, 0);

        _setupMatch(10_000);

        int256 newAliceMargin = helloVault.getMargin(alice);
        int256 newBobMargin = helloVault.getMargin(bob);

        assertEq(newAliceMargin, 99_999.9 * 1e6);
        assertEq(newBobMargin, 100_000.1 * 1e6);
    }

    function test_OrderExecOneFundingPeriodDecrease() public {
        _setupMatch(10_000);

        vm.warp(3600);
        // Refresh prices after warp to avoid StaleValue (also updates stork mock)
        _setPricesForMarketWithPrice(mktId1, 1e18);
        helloVault.updateFundingInstant(mktId1, 10_000_000, 1e18, 0);

        _setupMatch(-10_000);

        int256 newAliceMargin = helloVault.getMargin(alice);
        int256 newBobMargin = helloVault.getMargin(bob);

        assertEq(newAliceMargin, 99_999.9 * 1e6);
        assertEq(newBobMargin, 100_000.1 * 1e6);
    }

    function test_TwoOrderExecOneFundingPeriod() public {
        _setupMatch(10_000);

        vm.warp(3600);
        // Refresh prices after warp to avoid StaleValue (also updates stork mock)
        _setPricesForMarketWithPrice(mktId1, 1e18);
        helloVault.updateFundingInstant(mktId1, 10_000_000, 1e18, 0);

        _setupMatch(10_000);
        _setupMatch(10_000);

        int256 newAliceMargin = helloVault.getMargin(alice);
        int256 newBobMargin = helloVault.getMargin(bob);

        assertEq(newAliceMargin, 99_999.9 * 1e6);
        assertEq(newBobMargin, 100_000.1 * 1e6);
    }
}
