// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {Test} from "forge-std/Test.sol";
import {FundingInstant} from "src/price-feeds/HelloMarketDataStructs.sol";

// libraries
import {Math} from "src/lib/Math.sol";
import {Order} from "src/lib/Order.sol";

contract FillIncreaseFromZeroTest is Test, VaultTestHelpers {
    uint256 constant WAD = 1e18;
    using Math for int256;

    // Nonce 1 orders
    Order aliceLongN1;
    bytes aliceLongN1Sig;
    Order aliceShortN1;
    bytes aliceShortN1Sig;

    Order bobShortN1;
    bytes bobShortN1Sig;
    Order bobLongN1;
    bytes bobLongN1Sig;

    // Nonce 2 orders
    Order aliceLongN2;
    bytes aliceLongN2Sig;
    Order bobShortN2;
    bytes bobShortN2Sig;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        _depositFor(aliceKey, 100_000 * 1e6, _useTrackingHead());
        _depositFor(bobKey, 100_000 * 1e6, _useTrackingHead());

        // Nonce 1: Alice long, Bob short
        aliceLongN1 = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 1});
        aliceLongN1Sig = signOrder(aliceKey, aliceLongN1);
        bobShortN1 = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 1});
        bobShortN1Sig = signOrder(bobKey, bobShortN1);

        // Nonce 1: Alice short, Bob long
        aliceShortN1 = Order({account: alice, market: mktId1, size: -10_000, limitPrice: 1e18, nonce: 1});
        aliceShortN1Sig = signOrder(aliceKey, aliceShortN1);
        bobLongN1 = Order({account: bob, market: mktId1, size: 10_000, limitPrice: type(uint256).max, nonce: 1});
        bobLongN1Sig = signOrder(bobKey, bobLongN1);

        // Nonce 2: Alice long, Bob short
        aliceLongN2 = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18 + 1e17, nonce: 2});
        aliceLongN2Sig = signOrder(aliceKey, aliceLongN2);
        bobShortN2 = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 2});
        bobShortN2Sig = signOrder(bobKey, bobShortN2);
    }

    // From zero position to full position tests
    function test_FillLongFullFromZero() public {
        int256 size = 10_000;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, trackingHead);

        // Nonce burned and accumulator is empty
        _assertOrderState(alice, 1, true, 0);

        // Position equals order amounts
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size, 1e18, defaultLeverage, fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_FillLongPartialFromZero() public {
        int256 size = 10_000;
        int256 fillSize = size / 2;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({account: bob, market: mktId1, size: -size, limitPrice: 0, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // Partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead);

        // Nonce not burned (partial fill)
        _assertOrderState(alice, 1, false, fillSize.abs());

        // Position equals fill amount
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, fillSize, 1e18, defaultLeverage, fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_FillShortFullFromZero() public {
        int256 size = -10_000;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        _fillMatchedOrder(aliceShortN1, aliceShortN1Sig, bobLongN1, bobLongN1Sig, 10_000, trackingHead);

        // Nonce burned
        _assertOrderState(alice, 1, true, 0);

        // Position equals order amount
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size, 1e18, defaultLeverage, fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_FillShortPartialFromZero() public {
        int256 size = -10_000;
        int256 fillSize = size / 2;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder =
            Order({account: bob, market: mktId1, size: -size, limitPrice: type(uint256).max, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // Partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead);

        // Nonce not burned (partial fill)
        _assertOrderState(alice, 1, false, fillSize.abs());

        // Position equals fill amount
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, fillSize, 1e18, defaultLeverage, fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_EnterPositionPopulatesInMarkets() public {
        uint256 trackingHead = _useTrackingHead();

        uint256[] memory activeMarkets = helloVault.getActiveMarkets(alice);
        assertEq(activeMarkets.length, 0);

        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, trackingHead);

        activeMarkets = helloVault.getActiveMarkets(alice);
        assertEq(activeMarkets.length, 1);
        assertEq(activeMarkets[0], mktId1);
    }

    function test_FillTwoLongsWithPriceDelta() public {
        int256 size = 10_000;
        int256 size2 = 10_000;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, trackingHead);
        _fillMatchedOrder(aliceLongN2, aliceLongN2Sig, bobShortN2, bobShortN2Sig, 10_000, trackingHead + 1);

        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size + size2, 105e16, defaultLeverage, fundingIdxLast);
        _assertMarginChange(alice, margin, 0);
    }

    // TODO: Game this with lowest feasibly priced asset and bankers' rounding vs
    // worse-state rounding
    function test_FillTwoLongsWithPriceDeltaRoundsDown() public {
        uint256 limitPrice = 1e18;
        uint256 limitPrice2 = 1e18 + 2;
        int256 size = 10_000;
        int256 size2 = 10_000;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, trackingHead);

        // Use inline orders for the second fill with tiny price delta
        Order memory aliceLong2 =
            Order({account: alice, market: mktId1, size: size2, limitPrice: limitPrice2, nonce: 2});
        Order memory bobShort2 = Order({account: bob, market: mktId1, size: -size2, limitPrice: 0, nonce: 2});
        _fillMatchedOrder(
            aliceLong2,
            signOrder(aliceKey, aliceLong2),
            bobShort2,
            signOrder(bobKey, bobShort2),
            10_000,
            trackingHead + 1
        );

        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size + size2, 1e18 + 1, defaultLeverage, fundingIdxLast);
        _assertMarginChange(alice, margin, 0);
    }
}
