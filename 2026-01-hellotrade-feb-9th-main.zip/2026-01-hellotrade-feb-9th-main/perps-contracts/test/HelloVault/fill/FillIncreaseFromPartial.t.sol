// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {console} from "forge-std/console.sol";

// libraries
import {Math} from "src/lib/Math.sol";
import {OrderLib, Order} from "src/lib/Order.sol";
import {Position} from "src/lib/Position.sol";
import {FundingInstant} from "src/price-feeds/HelloMarketDataStructs.sol";

import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";

contract FillIncreaseFromPartialTest is Test, VaultTestHelpers, IHelloVaultErrors {
    uint256 constant WAD = 1e18;
    using Math for int256;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        _depositFor(aliceKey, 100_000 * 1e6, _useTrackingHead());
        _depositFor(bobKey, 100_000 * 1e6, _useTrackingHead());
    }

    function test_FillLongTwoPartial() public {
        int256 size = 10_000;
        int256 fillSize = size / 10;
        int256 netFillSize = fillSize * 2;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({account: bob, market: mktId1, size: -size, limitPrice: 0, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // First partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead);
        _assertOrderState(alice, 1, false, fillSize.abs());

        // Second partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead + 1);
        _assertOrderState(alice, 1, false, netFillSize.abs());

        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        // Position equals net fill amounts
        _assertPosition(alice, mktId1, netFillSize, 1e18, defaultLeverage, fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_FillShortTwoPartial() public {
        int256 size = -10_000;
        int256 fillSize = size / 10;
        int256 netFillSize = fillSize * 2;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder =
            Order({account: bob, market: mktId1, size: -size, limitPrice: type(uint256).max, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // First partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead);
        _assertOrderState(alice, 1, false, fillSize.abs());

        // Second partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead + 1);
        _assertOrderState(alice, 1, false, netFillSize.abs());

        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        // Position equals net fill amounts
        _assertPosition(alice, mktId1, netFillSize, 1e18, defaultLeverage, fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_FillLongTwoToFull() public {
        int256 size = 10_000;
        int256 fillSize = size / 10;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({account: bob, market: mktId1, size: -size, limitPrice: 0, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // First partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead);
        _assertOrderState(alice, 1, false, fillSize.abs());

        // Second fill to complete
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, (size - fillSize).abs(), trackingHead + 1);
        _assertOrderState(alice, 1, true, 0);

        // Position equals order amount
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size, 1e18, defaultLeverage, fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_FillShortTwoToFull() public {
        int256 size = -10_000;
        int256 fillSize = size / 10;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder =
            Order({account: bob, market: mktId1, size: -size, limitPrice: type(uint256).max, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // First partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead);
        _assertOrderState(alice, 1, false, fillSize.abs());

        // Second fill to complete
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, (size - fillSize).abs(), trackingHead + 1);
        _assertOrderState(alice, 1, true, 0);

        // Position equals order amount
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size, 1e18, defaultLeverage, fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_FillLongTwoOverSize() public {
        int256 size = 10_000;
        int256 fillSize = size / 10;
        uint256 trackingHead = _useTrackingHead();

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder = Order({account: bob, market: mktId1, size: -size, limitPrice: 0, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // First partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead);
        _assertOrderState(alice, 1, false, fillSize.abs());

        // Try to overfill - should revert
        vm.expectRevert(abi.encodeWithSelector(FillOverSize.selector));
        _fillMatchedOrder(
            makerOrder,
            makerSig,
            takerOrder,
            takerSig,
            size.abs(), // Trying to fill full size when already partially filled
            trackingHead + 1
        );
    }

    function test_FillShortTwoOverSize() public {
        int256 size = -10_000;
        int256 fillSize = size / 10;
        uint256 trackingHead = _useTrackingHead();

        Order memory makerOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: 1});
        Order memory takerOrder =
            Order({account: bob, market: mktId1, size: -size, limitPrice: type(uint256).max, nonce: 1});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // First partial fill
        _fillMatchedOrder(makerOrder, makerSig, takerOrder, takerSig, fillSize.abs(), trackingHead);
        _assertOrderState(alice, 1, false, fillSize.abs());

        // Try to overfill - should revert
        vm.expectRevert(abi.encodeWithSelector(FillOverSize.selector));
        _fillMatchedOrder(
            makerOrder,
            makerSig,
            takerOrder,
            takerSig,
            size.abs(), // Trying to fill full size when already partially filled
            trackingHead + 1
        );
    }
}
