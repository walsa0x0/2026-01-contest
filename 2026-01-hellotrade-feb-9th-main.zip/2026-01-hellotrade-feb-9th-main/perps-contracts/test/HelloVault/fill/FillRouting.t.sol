// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {OrderV2, ORDER_FLAG_ISOLATED} from "src/lib/Order.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";

/// @title Fill Routing Tests
/// @notice Tests that OrderV2 correctly routes to cross or isolated margin based on flags
contract FillRoutingTest is Test, VaultTestHelpers, IHelloVaultErrors {
    bytes32 vaultDomainSep;

    function setUp() public override {
        super.setUp();

        vm.startPrank(admin);
        helloVault.setFees(0, 0, 0, 0); // No fees for cleaner tests

        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();
    }

    /// @notice Deposit to isolated margin for a specific market
    function _depositIsolated(uint256 userKey, uint256 amount, uint32 market, uint256, uint256 trackingHead) internal {
        address user = vm.addr(userKey);
        uint256 deadline = block.timestamp + 1 hours;

        // Sign permit for USDC token
        bytes memory sig = signPermit(userKey, address(usdcMock), address(helloVault), amount, deadline);

        vm.startPrank(relayer);
        helloVault.depositWithSignatureV2(user, amount, market, ORDER_FLAG_ISOLATED, deadline, trackingHead, sig);
    }

    // ============================================================================
    // CROSS MARGIN ROUTING (flags = 0)
    // ============================================================================

    /// @notice Test that OrderV2 with flags=0 routes to cross margin successfully
    function test_CrossMarginFillV2_Success() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Create OrderV2 with flags=0 (cross margin)
        OrderV2 memory aliceLong = OrderV2({
            account: alice,
            market: mktId1,
            size: 100e2,
            limitPrice: 1e18,
            nonce: 1,
            flags: 0 // Cross margin
        });
        OrderV2 memory bobShort = OrderV2({
            account: bob,
            market: mktId1,
            size: -100e2,
            limitPrice: 0,
            nonce: 1,
            flags: 0 // Cross margin
        });

        bytes memory aliceSig = signOrderV2(aliceKey, aliceLong);
        bytes memory bobSig = signOrderV2(bobKey, bobShort);

        vm.startPrank(relayer);
        helloVault.handleMatchedFillV2(prices, aliceLong, aliceSig, bobShort, bobSig, 100e2, trackingHead + 2);

        // Verify positions were created in cross margin
        assertEq(helloVault.getPosition(alice, mktId1, false).size, 100e2, "Alice should have long position");
        assertEq(helloVault.getPosition(bob, mktId1, false).size, -100e2, "Bob should have short position");

        // Cross margin affects the shared margin
        assertTrue(helloVault.getMargin(alice) > 0, "Alice should have margin in cross margin vault");
    }

    /// @notice Test that cross margin fill fails with insufficient margin
    function test_CrossMarginFillV2_InsufficientMargin() public {
        uint256 trackingHead = _useTrackingHead();

        // Deposit minimal amount - not enough for the position
        _depositFor(aliceKey, 1e6, trackingHead); // Only 1 USDC
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Try to open a large position
        OrderV2 memory aliceLong = OrderV2({
            account: alice,
            market: mktId1,
            size: 10000e2, // Large position requiring more margin
            limitPrice: 1e18,
            nonce: 1,
            flags: 0
        });
        OrderV2 memory bobShort =
            OrderV2({account: bob, market: mktId1, size: -10000e2, limitPrice: 0, nonce: 1, flags: 0});

        bytes memory aliceSig = signOrderV2(aliceKey, aliceLong);
        bytes memory bobSig = signOrderV2(bobKey, bobShort);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin
        helloVault.handleMatchedFillV2(prices, aliceLong, aliceSig, bobShort, bobSig, 10000e2, trackingHead + 2);
    }

    // ============================================================================
    // ISOLATED MARGIN ROUTING (flags = ORDER_FLAG_ISOLATED)
    // ============================================================================

    /// @notice Test that OrderV2 with flags=1 routes to isolated margin successfully
    function test_IsolatedMarginFillV2_Success() public {
        uint256 trackingHead = _useTrackingHead();

        // Deposit to isolated margin for mktId1
        _depositIsolated(aliceKey, 1000e6, mktId1, 1, trackingHead);
        _depositIsolated(bobKey, 1000e6, mktId1, 1, trackingHead + 1);

        // Create OrderV2 with isolated flag set
        OrderV2 memory aliceLong = OrderV2({
            account: alice,
            market: mktId1,
            size: 100e2,
            limitPrice: 1e18,
            nonce: 2, // nonce 1 used by deposit
            flags: ORDER_FLAG_ISOLATED // Isolated margin
        });
        OrderV2 memory bobShort = OrderV2({
            account: bob,
            market: mktId1,
            size: -100e2,
            limitPrice: 0,
            nonce: 2,
            flags: ORDER_FLAG_ISOLATED // Isolated margin
        });

        bytes memory aliceSig = signOrderV2(aliceKey, aliceLong);
        bytes memory bobSig = signOrderV2(bobKey, bobShort);

        vm.startPrank(relayer);
        helloVault.handleMatchedFillV2(prices, aliceLong, aliceSig, bobShort, bobSig, 100e2, trackingHead + 2);

        // Verify positions were created in isolated margin
        assertEq(helloVault.getIsoPosition(alice, mktId1).size, 100e2, "Alice should have isolated long position");
        assertEq(helloVault.getIsoPosition(bob, mktId1).size, -100e2, "Bob should have isolated short position");

        // Verify isolated margin was used
        assertTrue(helloVault.getIsoMargin(alice, mktId1) > 0, "Alice should have isolated margin");
    }

    /// @notice Test that isolated margin fill fails with insufficient margin
    function test_IsolatedMarginFillV2_InsufficientMargin() public {
        uint256 trackingHead = _useTrackingHead();

        // Deposit minimal amount to isolated margin
        _depositIsolated(aliceKey, 1e6, mktId1, 1, trackingHead); // Only 1 USDC
        _depositIsolated(bobKey, 1000e6, mktId1, 1, trackingHead + 1);

        // Try to open a large isolated position
        OrderV2 memory aliceLong = OrderV2({
            account: alice, market: mktId1, size: 10000e2, limitPrice: 1e18, nonce: 2, flags: ORDER_FLAG_ISOLATED
        });
        OrderV2 memory bobShort = OrderV2({
            account: bob, market: mktId1, size: -10000e2, limitPrice: 0, nonce: 2, flags: ORDER_FLAG_ISOLATED
        });

        bytes memory aliceSig = signOrderV2(aliceKey, aliceLong);
        bytes memory bobSig = signOrderV2(bobKey, bobShort);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin
        helloVault.handleMatchedFillV2(prices, aliceLong, aliceSig, bobShort, bobSig, 10000e2, trackingHead + 2);
    }

    // ============================================================================
    // MIXED MARGIN ROUTING
    // ============================================================================

    /// @notice Test that maker can use cross while taker uses isolated
    function test_MixedMarginFillV2_MakerCross_TakerIsolated() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits to cross margin
        _depositFor(aliceKey, 1000e6, trackingHead);
        // Bob deposits to isolated margin for mktId1
        _depositIsolated(bobKey, 1000e6, mktId1, 1, trackingHead + 1);

        // Alice uses cross margin, Bob uses isolated
        OrderV2 memory aliceLong = OrderV2({
            account: alice,
            market: mktId1,
            size: 100e2,
            limitPrice: 1e18,
            nonce: 1,
            flags: 0 // Cross
        });
        OrderV2 memory bobShort = OrderV2({
            account: bob,
            market: mktId1,
            size: -100e2,
            limitPrice: 0,
            nonce: 2, // nonce 1 used by deposit
            flags: ORDER_FLAG_ISOLATED // Isolated
        });

        bytes memory aliceSig = signOrderV2(aliceKey, aliceLong);
        bytes memory bobSig = signOrderV2(bobKey, bobShort);

        vm.startPrank(relayer);
        helloVault.handleMatchedFillV2(prices, aliceLong, aliceSig, bobShort, bobSig, 100e2, trackingHead + 2);

        // Alice's position should be in cross margin
        assertEq(helloVault.getPosition(alice, mktId1, false).size, 100e2, "Alice should have cross margin position");
        // Bob's position should be in isolated margin
        assertEq(helloVault.getIsoPosition(bob, mktId1).size, -100e2, "Bob should have isolated margin position");
    }

    // ============================================================================
    // HELPER FUNCTIONS
    // ============================================================================

    /// @notice Sign an OrderV2 using EIP-712
    function signOrderV2(uint256 signerKey, OrderV2 memory order) internal view returns (bytes memory signature) {
        bytes32 structHash = order.digest();
        bytes32 eip712Digest = _hashTypedDataV4(structHash);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, eip712Digest);
        signature = abi.encodePacked(r, s, v);
    }

    /// @notice Compute EIP-712 typed data hash
    function _hashTypedDataV4(bytes32 structHash) internal view returns (bytes32) {
        return keccak256(abi.encodePacked("\x19\x01", vaultDomainSep, structHash));
    }
}

