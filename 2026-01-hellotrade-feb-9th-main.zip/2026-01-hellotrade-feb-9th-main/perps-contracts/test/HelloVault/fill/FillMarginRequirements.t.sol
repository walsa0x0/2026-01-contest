// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

import {Order} from "src/lib/Order.sol";
import {InsufficientMargin} from "src/lib/PositionMetrics.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";

import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

import {console} from "forge-std/console.sol";

contract FillMarginRequirementsTest is Test, VaultTestHelpers {
    Order aliceLongN1;
    bytes aliceLongN1Sig;
    Order bobShortN1;
    bytes bobShortN1Sig;

    Order aliceLongN2;
    bytes aliceLongN2Sig;
    Order bobShortN2;
    bytes bobShortN2Sig;

    function setUp() public override {
        super.setUp();
        vm.startPrank(admin);
        // Initialize second market
        helloVault.setMarketConfig(
            mktId2,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: defaultLeverage,
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );
        helloVault.setMarketStorkId(mktId2, storkInstId2);
        helloVault.setMarketHelloStorkId(mktId2, storkInstId2);
        // Set stork price to 1.0
        storkMock.setStorkPrice(storkInstId2, int192(1e18));

        vm.startPrank(relayer);

        // Bob deposits to act as counterparty
        _depositFor(bobKey, 100_000 * 1e6, _useTrackingHead());

        // Nonce 1 orders
        aliceLongN1 = Order({account: alice, market: mktId1, size: 1_000, limitPrice: 1e18, nonce: 1});
        aliceLongN1Sig = signOrder(aliceKey, aliceLongN1);
        bobShortN1 = Order({account: bob, market: mktId1, size: -1_000, limitPrice: 0, nonce: 1});
        bobShortN1Sig = signOrder(bobKey, bobShortN1);

        // Nonce 2 orders
        aliceLongN2 = Order({account: alice, market: mktId1, size: 1_000, limitPrice: 1e18, nonce: 2});
        aliceLongN2Sig = signOrder(aliceKey, aliceLongN2);
        bobShortN2 = Order({account: bob, market: mktId1, size: -1_000, limitPrice: 0, nonce: 2});
        bobShortN2Sig = signOrder(bobKey, bobShortN2);
    }

    function test_FillFailsWithInsufficientMargin() public {
        // Alice has no margin deposited
        uint256 trackingHead = _useTrackingHead();

        console.log("alice margin", helloVault.getMargin(alice));

        // Create prices before expectRevert
        StorkStructs.TemporalNumericValueInput[] memory prices = toArray(_createPriceInputWithPrice(mktId1, 1e18));

        vm.expectRevert(abi.encodeWithSelector(InsufficientMargin.selector, 0, 10e6));
        _fillMatchedOrder(prices, aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 1_000, trackingHead);
    }

    function test_FillInsufficientMarginOnePositionNoFunding() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits 10 USDC (just enough for one position)
        _depositFor(aliceKey, 10 * 1e6, trackingHead);

        // Alice has enough margin for a single position
        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 1_000, trackingHead + 1);

        // Alice has no margin for a second position
        uint256 trackingHead2 = _useTrackingHead();

        // Create prices before expectRevert
        StorkStructs.TemporalNumericValueInput[] memory prices = toArray(_createPriceInputWithPrice(mktId1, 1e18));

        vm.expectRevert(abi.encodeWithSelector(InsufficientMargin.selector, 10e6, 20e6));
        _fillMatchedOrder(prices, aliceLongN2, aliceLongN2Sig, bobShortN2, bobShortN2Sig, 1_000, trackingHead2);
    }

    function test_FillInsufficientMarginCrossPositionNoFunding() public {
        int256 size = 1_000;
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits 10 USDC (just enough for one position)
        _depositFor(aliceKey, 10 * 1e6, trackingHead);

        // Alice has enough margin for a single position in mkt1
        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 1_000, trackingHead + 1);

        // Alice has no margin for a position in mkt2
        uint256 trackingHead2 = _useTrackingHead();

        Order memory makerOrder = Order({account: alice, market: mktId2, size: size, limitPrice: 1e18, nonce: 2});
        Order memory takerOrder = Order({account: bob, market: mktId2, size: -size, limitPrice: 1e18, nonce: 2});

        bytes memory makerSig = signOrder(aliceKey, makerOrder);
        bytes memory takerSig = signOrder(bobKey, takerOrder);

        // Create prices before expectRevert
        StorkStructs.TemporalNumericValueInput[] memory prices = toArray(_createPriceInputWithPrice(mktId2, 1e18));

        vm.expectRevert(abi.encodeWithSelector(InsufficientMargin.selector, 10000000, 20000000));
        _fillMatchedOrder(prices, makerOrder, makerSig, takerOrder, takerSig, 1_000, trackingHead2);

        // // Order parameters
        // int256 size = 1_000;
        // int256 fillSize = 1_000;
        // uint256 limitPrice = 1e18;
        // uint256 execPrice = 1e18;

        // uint256 trackingHead = _useTrackingHead();

        // // alice deposits 10 USDC
        // bytes memory sig1 =
        //     signPermit(aliceKey, address(usdcMock), address(helloVault), 10 * 1e6, block.timestamp + 1 hours);
        // helloVault.depositWithSignature(alice, 10 * 1e6, block.timestamp + 1 hours, trackingHead, sig1);

        // int256 margin = helloVault.getMargin(alice);

        // // alice has enough margin for a single position
        // Order memory order = Order({account: alice, market: mktId1, size: size, limitPrice: limitPrice, nonce: 1});
        // bytes memory sig2 = signOrder(aliceKey, order);
        // _fillOrder(order, fillSize, execPrice, trackingHead + 1, sig2);

        // // alice has no margin for a second position
        // Order memory order2 = Order({account: alice, market: mktId2, size: size, limitPrice: limitPrice, nonce: 2});
        // bytes memory sig3 = signOrder(aliceKey, order2);

        // vm.expectRevert(abi.encodeWithSelector(InsufficientMargin.selector, 10000000, 20000000));
        // _fillOrder(order2, fillSize, execPrice, trackingHead + 2, sig3);
    }
}
