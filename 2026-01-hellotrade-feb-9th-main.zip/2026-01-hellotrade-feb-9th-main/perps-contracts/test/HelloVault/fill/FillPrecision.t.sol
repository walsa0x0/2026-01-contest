// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

import {Order} from "src/lib/Order.sol";
import {FundingInstant} from "src/price-feeds/HelloMarketDataStructs.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";

contract FillPrecisionTest is Test, VaultTestHelpers {
    // Nonce 1 orders (short/long at 1e18)
    Order aliceShortN1;
    bytes aliceShortN1Sig;
    Order bobLongN1;
    bytes bobLongN1Sig;
    Order aliceLongN1;
    bytes aliceLongN1Sig;
    Order bobShortN1;
    bytes bobShortN1Sig;

    // Nonce 2 orders (at 1e18 + 1)
    Order aliceShortN2;
    bytes aliceShortN2Sig;
    Order bobLongN2;
    bytes bobLongN2Sig;
    Order aliceLongN2;
    bytes aliceLongN2Sig;
    Order bobShortN2;
    bytes bobShortN2Sig;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        _depositFor(aliceKey, 100 * 1e6, _useTrackingHead());
        _depositFor(bobKey, 100 * 1e6, _useTrackingHead());

        // Nonce 1: Short orders at 1e18
        aliceShortN1 = Order({account: alice, market: mktId1, size: -1_000, limitPrice: 1e18, nonce: 1});
        aliceShortN1Sig = signOrder(aliceKey, aliceShortN1);
        bobLongN1 = Order({account: bob, market: mktId1, size: 1_000, limitPrice: type(uint256).max, nonce: 1});
        bobLongN1Sig = signOrder(bobKey, bobLongN1);

        // Nonce 1: Long orders at 1e18
        aliceLongN1 = Order({account: alice, market: mktId1, size: 1_000, limitPrice: 1e18, nonce: 1});
        aliceLongN1Sig = signOrder(aliceKey, aliceLongN1);
        bobShortN1 = Order({account: bob, market: mktId1, size: -1_000, limitPrice: 0, nonce: 1});
        bobShortN1Sig = signOrder(bobKey, bobShortN1);

        // Nonce 2: Short orders at 1e18 + 1
        aliceShortN2 = Order({account: alice, market: mktId1, size: -1_000, limitPrice: 1e18 + 1, nonce: 2});
        aliceShortN2Sig = signOrder(aliceKey, aliceShortN2);
        bobLongN2 = Order({account: bob, market: mktId1, size: 1_000, limitPrice: type(uint256).max, nonce: 2});
        bobLongN2Sig = signOrder(bobKey, bobLongN2);

        // Nonce 2: Long orders at 1e18 + 1
        aliceLongN2 = Order({account: alice, market: mktId1, size: 1_000, limitPrice: 1e18 + 1, nonce: 2});
        aliceLongN2Sig = signOrder(aliceKey, aliceLongN2);
        bobShortN2 = Order({account: bob, market: mktId1, size: -1_000, limitPrice: 0, nonce: 2});
        bobShortN2Sig = signOrder(bobKey, bobShortN2);
    }

    function test_ShortAverageExecPriceRoundsDown() public {
        uint256 execPrice = 1e18;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        // First short at execPrice
        _fillMatchedOrder(aliceShortN1, aliceShortN1Sig, bobLongN1, bobLongN1Sig, 1_000, trackingHead);

        // Second short at execPrice + 1
        _fillMatchedOrder(aliceShortN2, aliceShortN2Sig, bobLongN2, bobLongN2Sig, 1_000, trackingHead + 1);

        // Position equals order amounts
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, -2000, execPrice, uint128(defaultLeverage), fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }

    function test_LongAverageExecPriceRoundsUp() public {
        uint256 execPrice = 1e18;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        // First long at execPrice
        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 1_000, trackingHead);

        // Second long at execPrice + 1
        _fillMatchedOrder(aliceLongN2, aliceLongN2Sig, bobShortN2, bobShortN2Sig, 1_000, trackingHead + 1);

        // Position equals order amounts
        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, 2000, execPrice + 1, uint128(defaultLeverage), fundingIdxLast);

        // Margin should be unchanged
        _assertMarginUnchanged(alice, margin);
    }
}
