// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

// libraries
import {Math} from "src/lib/Math.sol";
import {Order} from "src/lib/Order.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {FundingInstant} from "src/price-feeds/HelloMarketDataStructs.sol";

contract FillDecreaseTest is Test, VaultTestHelpers {
    uint256 constant WAD = 1e18;
    using Math for int256;

    // Open orders (nonce 1)
    Order aliceLongN1;
    bytes aliceLongN1Sig;
    Order bobShortN1;
    bytes bobShortN1Sig;

    // Close orders (nonce 2)
    Order aliceShortN2;
    bytes aliceShortN2Sig;
    Order bobLongN2;
    bytes bobLongN2Sig;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        _depositFor(aliceKey, 100_000 * 1e6, _useTrackingHead());
        _depositFor(bobKey, 100_000 * 1e6, _useTrackingHead());

        // Nonce 1: Alice long, Bob short (open)
        aliceLongN1 = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 1});
        aliceLongN1Sig = signOrder(aliceKey, aliceLongN1);
        bobShortN1 = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 1});
        bobShortN1Sig = signOrder(bobKey, bobShortN1);

        // Nonce 2: Alice short, Bob long (close)
        aliceShortN2 = Order({account: alice, market: mktId1, size: -10_000, limitPrice: 1e18, nonce: 2});
        aliceShortN2Sig = signOrder(aliceKey, aliceShortN2);
        bobLongN2 = Order({account: bob, market: mktId1, size: 10_000, limitPrice: type(uint256).max, nonce: 2});
        bobLongN2Sig = signOrder(bobKey, bobLongN2);
    }

    function test_DecreaseLongFullPriceDeltaZero() public {
        int256 size = 10_000;
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        // Open long position
        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, trackingHead);

        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size, 1e18, defaultLeverage, fundingIdxLast);
        _assertMarginUnchanged(alice, margin);

        // Close position in full (short)
        _fillMatchedOrder(aliceShortN2, aliceShortN2Sig, bobLongN2, bobLongN2Sig, 10_000, trackingHead + 1);

        FundingInstant memory fundingInstant2 = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast2 = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, 0, 0, defaultLeverage, fundingIdxLast2);
        // PNL should be zero
        _assertMarginUnchanged(alice, margin);
    }

    function test_DecreaseLongFullPriceDeltaPositive() public {
        int256 size = 10_000;
        uint256 entryPrice = 1e18;
        uint256 exitPrice = 1e18 + 1e17; // 10% increase
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        // Open long position
        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, trackingHead);

        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size, entryPrice, defaultLeverage, fundingIdxLast);
        _assertMarginUnchanged(alice, margin);

        // Close position at higher price
        Order memory aliceClose = Order({account: alice, market: mktId1, size: -size, limitPrice: exitPrice, nonce: 2});
        Order memory bobClose =
            Order({account: bob, market: mktId1, size: size, limitPrice: type(uint256).max, nonce: 2});
        _fillMatchedOrder(
            aliceClose, signOrder(aliceKey, aliceClose), bobClose, signOrder(bobKey, bobClose), 10_000, trackingHead + 1
        );

        FundingInstant memory fundingInstant2 = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast2 = fundingInstant2.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, 0, 0, defaultLeverage, fundingIdxLast2);
        // Order notional is 100 USDC, 10% PNL is 10 USDC
        _assertMarginChange(alice, margin, 10e6);
    }

    function test_DecreaseLongFullPriceDeltaNegative() public {
        int256 size = 10_000;
        uint256 entryPrice = 1e18;
        uint256 exitPrice = 1e18 - 1e17; // 10% decrease
        uint256 trackingHead = _useTrackingHead();

        int256 margin = helloVault.getMargin(alice);

        // Open long position
        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, trackingHead);

        FundingInstant memory fundingInstant = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast = fundingInstant.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, size, entryPrice, defaultLeverage, fundingIdxLast);
        _assertMarginUnchanged(alice, margin);

        // Close position at lower price
        Order memory aliceClose = Order({account: alice, market: mktId1, size: -size, limitPrice: exitPrice, nonce: 2});
        Order memory bobClose =
            Order({account: bob, market: mktId1, size: size, limitPrice: type(uint256).max, nonce: 2});
        _fillMatchedOrder(
            aliceClose, signOrder(aliceKey, aliceClose), bobClose, signOrder(bobKey, bobClose), 10_000, trackingHead + 1
        );

        FundingInstant memory fundingInstant2 = helloVault.lastFundingInstant(mktId1);
        int192 fundingIdxLast2 = fundingInstant2.cumulativeFundingIdx;
        _assertPosition(alice, mktId1, 0, 0, defaultLeverage, fundingIdxLast2);
        // Order notional is 100 USDC, 10% PNL is -10 USDC
        _assertMarginChange(alice, margin, -10e6);
    }

    function test_FullCloseClearsActiveMarkets() public {
        uint256 trackingHead = _useTrackingHead();

        // Open position
        _fillMatchedOrder(aliceLongN1, aliceLongN1Sig, bobShortN1, bobShortN1Sig, 10_000, trackingHead);

        uint256[] memory activeMarkets = helloVault.getActiveMarkets(alice);
        assertEq(activeMarkets.length, 1);
        assertEq(activeMarkets[0], mktId1);

        // Close position
        _fillMatchedOrder(aliceShortN2, aliceShortN2Sig, bobLongN2, bobLongN2Sig, 10_000, trackingHead + 1);

        activeMarkets = helloVault.getActiveMarkets(alice);
        assertEq(activeMarkets.length, 0);
    }
}
