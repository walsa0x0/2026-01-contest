// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";

contract VaultFillZeroValidationsTest is Test, VaultTestHelpers {
    uint256 constant WAD = 1e18;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        _depositFor(aliceKey, 100_000 * 1e6, _useTrackingHead());
        _depositFor(bobKey, 100_000 * 1e6, _useTrackingHead());
    }
}
