// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Order, OrderV2, ORDER_FLAG_ISOLATED} from "src/lib/Order.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {Position} from "src/lib/Position.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {IHelloVaultEvents} from "src/interfaces/IHelloVaultEvents.sol";

/// @title Delever V2 Tests
/// @notice Tests for deleverV2 function with isolated and cross margin support
contract DeleverV2Test is Test, VaultTestHelpers, IHelloVaultErrors, IHelloVaultEvents {
    bytes32 vaultDomainSep;

    function setUp() public override {
        super.setUp();

        vm.startPrank(admin);
        helloVault.setFees(0, 0, 0, 0);

        // Set up market with 10x default leverage (1000 = 10x)
        helloVault.setMarketConfig(
            mktId1,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: 1000, // 10x leverage
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );

        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();

        uint256 trackingHead = _useTrackingHead();
        _depositFor(bobKey, 100_000e6, trackingHead);
        _depositFor(charlieKey, 100_000e6, trackingHead + 1);
    }

    // ============================================================================
    // TEST 1: CANNOT DELEVER ACCOUNT WITH POSITIVE EQUITY
    // ============================================================================

    /// @notice Test that cross margin account with positive equity cannot be delevered
    function test_CannotDeleverCrossMarginAccountWithPositiveEquity() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits with plenty of margin
        _depositFor(aliceKey, 1000e6, trackingHead);

        // Open position: Alice long, Bob short
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        // Price drops slightly but Alice still has positive equity due to excess margin
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.95e18)); // 5% drop

        // Verify Alice is NOT in liquidation (has positive equity)
        assertFalse(helloVault.accountInLiquidation(alice), "Alice should NOT be in liquidation");

        // Try to delever Alice - should fail
        OrderV2 memory closerOrder = OrderV2({
            account: charlie,
            market: mktId1,
            size: 100e2,
            limitPrice: 0.95e18,
            nonce: 1,
            flags: 0 // Cross margin
        });
        OrderV2 memory liquidatedOrder = OrderV2({
            account: alice,
            market: mktId1,
            size: -100e2,
            limitPrice: 0,
            nonce: 2,
            flags: 0 // Cross margin
        });

        vm.startPrank(relayer);
        vm.expectRevert(abi.encodeWithSelector(InvalidAccountDelever.selector, alice));
        helloVault.deleverWithPriceV2(prices, closerOrder, liquidatedOrder, 100e2, 0.95e18, trackingHead + 2);
    }

    /// @notice Test that isolated margin position with positive equity cannot be delevered
    function test_CannotDeleverIsolatedPositionWithPositiveEquity() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits to isolated margin with plenty of margin
        _depositIsolated(aliceKey, 1000e6, mktId1, 1, trackingHead);
        _depositIsolated(bobKey, 1000e6, mktId1, 2, trackingHead + 1);

        // Open isolated position
        OrderV2 memory aliceLong = OrderV2({
            account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 2, flags: ORDER_FLAG_ISOLATED
        });
        OrderV2 memory bobShort =
            OrderV2({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 3, flags: ORDER_FLAG_ISOLATED});

        bytes memory aliceSig = signOrderV2(aliceKey, aliceLong);
        bytes memory bobSig = signOrderV2(bobKey, bobShort);

        vm.startPrank(relayer);
        helloVault.handleMatchedFillV2(prices, aliceLong, aliceSig, bobShort, bobSig, 100e2, trackingHead + 2);

        // Price drops slightly but Alice still has positive equity due to excess margin
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.95e18)); // 5% drop

        // Verify Alice's isolated position is NOT in liquidation
        assertFalse(
            helloVault.isoPositionInLiquidation(alice, mktId1), "Alice's isolated position should NOT be in liquidation"
        );

        // Try to delever Alice's isolated position - should fail
        OrderV2 memory closerOrder = OrderV2({
            account: charlie,
            market: mktId1,
            size: 100e2,
            limitPrice: 0.95e18,
            nonce: 1,
            flags: 0 // Closer uses cross margin
        });
        OrderV2 memory liquidatedOrder = OrderV2({
            account: alice,
            market: mktId1,
            size: -100e2,
            limitPrice: 0,
            nonce: 3,
            flags: ORDER_FLAG_ISOLATED // Alice's isolated position
        });

        vm.expectRevert(abi.encodeWithSelector(InvalidAccountDelever.selector, alice));
        helloVault.deleverWithPriceV2(prices, closerOrder, liquidatedOrder, 100e2, 0.95e18, trackingHead + 3);
    }

    // ============================================================================
    // TEST 2: CLOSER CANNOT BE PUT INTO NEGATIVE MARGIN
    // ============================================================================

    /// @notice Test that delever reverts if closer would be put into negative margin
    function test_DeleverRevertsIfCloserWouldBeNegative() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits minimal margin (will be underwater after price drop)
        _depositFor(aliceKey, 10e6, trackingHead);

        // Charlie deposits minimal margin too
        _depositFor(charlieKey, 5e6, trackingHead + 1);

        // Open position: Alice long at $1.00
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 2
        );

        // Drop price by 11% - Alice loses $11 but only has $10, equity = -$1 (negative, can be delevered)
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.89e18));

        // Verify Alice is underwater
        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        // Charlie tries to close Alice's position but Charlie has insufficient margin
        // Charlie opening a 100 unit long at $0.89 requires ~$8.9 margin at 10x
        // Charlie only has $5
        OrderV2 memory closerOrder = OrderV2({
            account: charlie,
            market: mktId1,
            size: 100e2, // Needs to take the other side (long to close Alice's long)
            limitPrice: 0.89e18,
            nonce: 2,
            flags: 0
        });
        OrderV2 memory liquidatedOrder =
            OrderV2({account: alice, market: mktId1, size: -100e2, limitPrice: 0, nonce: 2, flags: 0});

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin for Charlie
        helloVault.deleverWithPriceV2(prices, closerOrder, liquidatedOrder, 100e2, 0.89e18, trackingHead + 3);
    }

    // ============================================================================
    // TEST 3: SUCCESSFUL DELEVER AND STATE VERIFICATION
    // ============================================================================

    /// @notice Test successful cross-margin full delever with state verification
    /// @dev ADL requires BOTH parties to reduce positions - Charlie must have existing short
    /// @dev ADL execPrice is chosen to zero out the liquidatee's equity (socialize bad debt to closer)
    function test_SuccessfulCrossMarginDelever_StateChanges() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits $10 for 100 notional at 10x
        _depositFor(aliceKey, 10e6, trackingHead);

        // Open position: Alice long, Bob short at $1.00
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        // Charlie opens a short position (he'll be the profitable closer in ADL)
        Order memory charlieSell = Order({account: charlie, market: mktId1, size: -100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobBuy = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 2});
        _fillMatchedOrder(
            charlieSell, signOrder(charlieKey, charlieSell), bobBuy, signOrder(bobKey, bobBuy), 100e2, trackingHead + 2
        );

        // Drop price by 11% - Alice has negative equity (required for ADL)
        // Alice: $10 margin - $11 unrealized loss = -$1 equity at mark
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.89e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        // Record state before delever
        Position memory alicePosBefore = helloVault.getPosition(alice, mktId1, false);
        Position memory charliePosBefore = helloVault.getPosition(charlie, mktId1, false);
        int256 charlieMarginBefore = helloVault.getMargin(charlie);

        assertEq(alicePosBefore.size, 100e2, "Alice should have 100 unit long");
        assertEq(charliePosBefore.size, -100e2, "Charlie should have 100 unit short");

        // ADL execPrice is set to zero out Alice's equity:
        // Alice loss = 100 * (1.00 - execPrice) must equal $10 margin
        // So execPrice = $0.90 (not market price $0.89)
        // Charlie absorbs the $1 bad debt by closing at 0.90 instead of 0.89
        uint256 execPrice = 0.9e18;

        OrderV2 memory closerOrder = OrderV2({
            account: charlie,
            market: mktId1,
            size: 100e2, // Charlie buys to close short
            limitPrice: execPrice,
            nonce: 2,
            flags: 0
        });
        OrderV2 memory liquidatedOrder =
            OrderV2({account: alice, market: mktId1, size: -100e2, limitPrice: 0, nonce: 2, flags: 0});

        vm.startPrank(relayer);
        helloVault.deleverWithPriceV2(prices, closerOrder, liquidatedOrder, 100e2, execPrice, trackingHead + 3);

        // Verify state after delever
        Position memory alicePosAfter = helloVault.getPosition(alice, mktId1, false);
        Position memory charliePosAfter = helloVault.getPosition(charlie, mktId1, false);
        int256 aliceMarginAfter = helloVault.getMargin(alice);
        int256 charlieMarginAfter = helloVault.getMargin(charlie);

        // Both positions fully closed
        assertEq(alicePosAfter.size, 0, "Alice's position should be closed");
        assertEq(charliePosAfter.size, 0, "Charlie's position should be closed");

        // Alice ends with exactly $0 (loss = $10, her full margin)
        assertEq(aliceMarginAfter, 0, "Alice should have $0 margin after ADL");

        // Charlie's margin increased from closing short at $0.90 (entry $1.00)
        // Profit = 100 * (1.00 - 0.90) = $10 (but would have been $11 at market price)
        assertTrue(charlieMarginAfter > charlieMarginBefore, "Charlie's margin should increase from profit");
    }

    /// @notice Test successful isolated-margin full delever with state verification
    /// @dev ADL requires BOTH parties to reduce positions - Charlie must have existing short
    /// @dev ADL execPrice is chosen to zero out the liquidatee's equity (socialize bad debt to closer)
    function test_SuccessfulIsolatedMarginDelever_StateChanges() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits $10 to isolated
        _depositIsolated(aliceKey, 10e6, mktId1, 1, trackingHead);
        // Bob deposits to isolated too
        _depositIsolated(bobKey, 1000e6, mktId1, 2, trackingHead + 1);

        // Open isolated position: Alice long at $1.00
        OrderV2 memory aliceLong = OrderV2({
            account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 2, flags: ORDER_FLAG_ISOLATED
        });
        OrderV2 memory bobShort =
            OrderV2({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 3, flags: ORDER_FLAG_ISOLATED});

        bytes memory aliceSig = signOrderV2(aliceKey, aliceLong);
        bytes memory bobSig = signOrderV2(bobKey, bobShort);

        vm.startPrank(relayer);
        helloVault.handleMatchedFillV2(prices, aliceLong, aliceSig, bobShort, bobSig, 100e2, trackingHead + 2);

        // Charlie opens a cross-margin short position (he'll be the profitable closer in ADL)
        Order memory charlieSell = Order({account: charlie, market: mktId1, size: -100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobBuyCross = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        _fillMatchedOrder(
            charlieSell,
            signOrder(charlieKey, charlieSell),
            bobBuyCross,
            signOrder(bobKey, bobBuyCross),
            100e2,
            trackingHead + 3
        );

        // Drop price by 11% - Alice has negative equity (required for ADL)
        // Alice: $10 margin - $11 unrealized loss = -$1 equity at mark
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.89e18));

        assertTrue(helloVault.isoPositionInLiquidation(alice, mktId1), "Alice's isolated position should be underwater");

        // Record state before delever
        Position memory aliceIsoBefore = helloVault.getIsoPosition(alice, mktId1);
        Position memory charliePosBefore = helloVault.getPosition(charlie, mktId1, false);
        int256 charlieMarginBefore = helloVault.getMargin(charlie);

        assertEq(aliceIsoBefore.size, 100e2, "Alice should have 100 unit isolated long");
        assertEq(charliePosBefore.size, -100e2, "Charlie should have 100 unit cross short");

        // ADL execPrice is set to zero out Alice's equity:
        // Alice loss = 100 * (1.00 - execPrice) must equal $10 margin
        // So execPrice = $0.90 (not market price $0.89)
        uint256 execPrice = 0.9e18;

        OrderV2 memory closerOrder = OrderV2({
            account: charlie,
            market: mktId1,
            size: 100e2, // Charlie buys to close short
            limitPrice: execPrice,
            nonce: 2,
            flags: 0 // Charlie uses cross margin
        });
        OrderV2 memory liquidatedOrder = OrderV2({
            account: alice,
            market: mktId1,
            size: -100e2,
            limitPrice: 0,
            nonce: 3,
            flags: ORDER_FLAG_ISOLATED // Alice's isolated position
        });

        helloVault.deleverWithPriceV2(prices, closerOrder, liquidatedOrder, 100e2, execPrice, trackingHead + 4);

        // Verify state after delever
        Position memory aliceIsoAfter = helloVault.getIsoPosition(alice, mktId1);
        Position memory charliePosAfter = helloVault.getPosition(charlie, mktId1, false);
        uint256 aliceIsoMarginAfter = helloVault.getIsoMargin(alice, mktId1);
        int256 charlieMarginAfter = helloVault.getMargin(charlie);

        // Both positions fully closed
        assertEq(aliceIsoAfter.size, 0, "Alice's isolated position should be closed");
        assertEq(charliePosAfter.size, 0, "Charlie's cross position should be closed");

        // Alice ends with exactly $0 isolated margin
        assertEq(aliceIsoMarginAfter, 0, "Alice's isolated margin should be 0 after ADL");

        // Charlie's margin increased from closing short at $0.90
        assertTrue(charlieMarginAfter > charlieMarginBefore, "Charlie's margin should increase from profit");
    }

    /// @notice Test partial delever updates positions correctly
    /// @dev ADL requires BOTH parties to reduce positions - Charlie must have existing short
    function test_PartialDelever_StateChanges() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits minimal margin
        _depositFor(aliceKey, 10e6, trackingHead);

        // Open position: Alice long, Bob short at $1.00
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        // Charlie opens a short position (he'll be the profitable closer in ADL)
        Order memory charlieSell = Order({account: charlie, market: mktId1, size: -100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobBuy = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 2});
        _fillMatchedOrder(
            charlieSell, signOrder(charlieKey, charlieSell), bobBuy, signOrder(bobKey, bobBuy), 100e2, trackingHead + 2
        );

        // Drop price by 11% - Alice loses $11 but only has $10, equity = -$1 (negative, can be delevered)
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.89e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        // Record positions before
        assertEq(helloVault.getPosition(alice, mktId1, false).size, 100e2, "Alice should have 100 long");
        assertEq(helloVault.getPosition(charlie, mktId1, false).size, -100e2, "Charlie should have 100 short");

        // Partial delever - only 50 units (ADL only partially closes both positions)
        OrderV2 memory closerOrder = OrderV2({
            account: charlie,
            market: mktId1,
            size: 50e2, // Only 50 units (Charlie buys to partially close short)
            limitPrice: 0.89e18,
            nonce: 2,
            flags: 0
        });
        OrderV2 memory liquidatedOrder =
            OrderV2({account: alice, market: mktId1, size: -50e2, limitPrice: 0, nonce: 2, flags: 0});

        vm.startPrank(relayer);
        helloVault.deleverWithPriceV2(prices, closerOrder, liquidatedOrder, 50e2, 0.89e18, trackingHead + 3);

        // Alice should still have 50 units remaining (100 - 50)
        Position memory alicePos = helloVault.getPosition(alice, mktId1, false);
        assertEq(alicePos.size, 50e2, "Alice should have 50 units remaining");

        // Charlie should have -50 units remaining (was -100, bought 50)
        Position memory charliePos = helloVault.getPosition(charlie, mktId1, false);
        assertEq(charliePos.size, -50e2, "Charlie should have 50 short units remaining");
    }

    // ============================================================================
    // HELPER FUNCTIONS
    // ============================================================================

    /// @notice Deposit to isolated margin using permit flow
    function _depositIsolated(uint256 userKey, uint256 amount, uint32 market, uint256, uint256 trackingHead) internal {
        address user = vm.addr(userKey);
        uint256 deadline = block.timestamp + 1 hours;

        // Sign permit for USDC token (same pattern as _depositFor but with V2 endpoint)
        bytes memory sig = signPermit(userKey, address(usdcMock), address(helloVault), amount, deadline);

        vm.startPrank(relayer);
        helloVault.depositWithSignatureV2(user, amount, market, ORDER_FLAG_ISOLATED, deadline, trackingHead, sig);
    }

    function signOrderV2(uint256 signerKey, OrderV2 memory order) internal view returns (bytes memory signature) {
        bytes32 structHash = order.digest();
        bytes32 eip712Digest = keccak256(abi.encodePacked("\x19\x01", vaultDomainSep, structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, eip712Digest);
        signature = abi.encodePacked(r, s, v);
    }
}

