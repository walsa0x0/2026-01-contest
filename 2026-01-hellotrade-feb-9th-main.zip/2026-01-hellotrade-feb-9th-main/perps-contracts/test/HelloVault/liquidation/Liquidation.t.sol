// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Order, Liquidation} from "src/lib/Order.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {Overflow} from "src/lib/Math.sol";
import {LiquidationResultsInNegativeMargin} from "src/vaults/VaultUtils.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {IHelloVaultEvents} from "src/interfaces/IHelloVaultEvents.sol";

contract LiquidationTest is Test, VaultTestHelpers, IHelloVaultErrors, IHelloVaultEvents {
    bytes32 vaultDomainSep;

    function setUp() public override {
        super.setUp();

        // Set no fees to make math cleaner
        vm.startPrank(admin);
        helloVault.setFees(0, 0, 0, 0);

        // Set up market with 10x default leverage (1000 = 10x)
        helloVault.setMarketConfig(
            mktId1,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: 1000, // 10x leverage
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );

        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();

        uint256 trackingHead = _useTrackingHead();
        _depositFor(bobKey, 100_000e6, trackingHead);
        _depositFor(charlieKey, 100_000e6, trackingHead + 1);
    }

    // ============================================================================
    // LIQUIDATION MECHANICS TESTS
    // ============================================================================

    /// @notice Test basic liquidation math: 10x leverage, deposit = assigned margin, 10% price drop
    /// @dev With 10x leverage and deposit = assigned margin:
    ///      - Assigned margin = notional / 10 = $10
    ///      - Maintenance margin ~= $0.50 (at 100x maxLeverage)
    ///      - At 10% price drop, equity = $0, below maintenance margin
    function test_BasicLiquidation_10xLeverage_10PercentDrop() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice opens 100 units long at $1.00 with 10x leverage
        // Notional = 100 units * $1.00 = $100
        // Assigned margin = $100 / 10 = $10
        // Alice deposits exactly $10 (assigned margin = deposit)
        _depositFor(aliceKey, 10e6, trackingHead);

        // Open position: 100 units (100e2 with basePrecision=2) at $1.00
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        // Verify Alice is NOT in liquidation at entry
        assertFalse(helloVault.accountInLiquidation(alice), "Alice should NOT be in liquidation at entry");

        // Drop price by 10% (new price = $0.90) - Alice has $0 equity, below maintenance
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.9e18));

        // Verify Alice IS in liquidation after 10% price drop
        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation after 10% price drop");
    }

    /// @notice Test that liquidation can be executed on unhealthy account
    function test_CanLiquidateUnhealthyAccount() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 10e6, trackingHead);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        assertFalse(helloVault.accountInLiquidation(alice), "Alice should NOT be in liquidation initially");

        // Drop price by 10%
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.9e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation after price drop");

        // Record Alice's position before liquidation
        int256 alicePositionBefore = helloVault.getPosition(alice, mktId1, false).size;
        assertEq(alicePositionBefore, 100e2, "Alice should have 100 unit long position");

        // Charlie liquidates Alice's position
        // Liquidator order must have SAME sign as position being liquidated (Charlie buys, Alice sells to close)
        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.9e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.9e18, trackingHead + 2
        );

        // Verify Alice's position is closed
        int256 alicePositionAfter = helloVault.getPosition(alice, mktId1, false).size;
        assertEq(alicePositionAfter, 0, "Alice's position should be closed after liquidation");
    }

    /// @notice Test that a healthy account cannot be liquidated
    function test_CannotLiquidateHealthyAccount() public {
        uint256 trackingHead = _useTrackingHead();

        // Alice deposits plenty of margin ($1000 instead of $10)
        _depositFor(aliceKey, 1000e6, trackingHead);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        // Drop price by 10%
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.9e18));

        assertFalse(helloVault.accountInLiquidation(alice), "Alice should NOT be in liquidation with excess margin");

        // Try to liquidate - should revert
        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.9e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        vm.expectRevert(InvalidAccountLiquidation.selector);
        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.9e18, trackingHead + 2
        );
    }

    /// @notice Test partial liquidation of a position
    function test_PartialLiquidation() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 10e6, trackingHead);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        // Drop price by 10%
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.9e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        // Partial liquidation - only 50 units of the 100 unit position
        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 50e2, limitPrice: 0.9e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 50e2, 0.9e18, trackingHead + 2
        );

        // Alice should still have 50 units
        assertEq(helloVault.getPosition(alice, mktId1, false).size, 50e2, "Alice should have 50 units remaining");
    }

    /// @notice Test liquidation emits correct event
    function test_LiquidationEmitsEvent() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 10e6, trackingHead);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        // Drop price by 10%
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.9e18));

        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.9e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        // Expect LiquidatedV2 event (checking account and market)
        vm.expectEmit(true, true, false, false);
        emit LiquidatedV2(alice, mktId1, 0.9e18, -100e2, 0, 0, false, trackingHead + 2);

        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.9e18, trackingHead + 2
        );
    }

    // ============================================================================
    // EDGE CASE TESTS
    // ============================================================================

    /// @notice Test that liquidation reverts when loss exceeds margin (underflow protection)
    /// @dev When price drops >10%, Alice loses more than her $10 margin, causes revert
    function test_LiquidationRevertsWhenLossExceedsMargin() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 10e6, trackingHead);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 1
        );

        // Drop price by 11% - Alice loses $11 but only has $10 margin
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.89e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.89e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        // Expect LiquidationResultsInNegativeMargin error when loss exceeds margin
        vm.expectRevert(abi.encodeWithSelector(LiquidationResultsInNegativeMargin.selector, -1e6));
        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.89e18, trackingHead + 2
        );
    }
}
