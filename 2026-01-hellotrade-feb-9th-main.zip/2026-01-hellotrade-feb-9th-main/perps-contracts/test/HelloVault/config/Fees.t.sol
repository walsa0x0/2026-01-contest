// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Order, Liquidation} from "src/lib/Order.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {Overflow} from "src/lib/Math.sol";
import {LiquidationResultsInNegativeMargin} from "src/vaults/VaultUtils.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {IHelloVaultEvents} from "src/interfaces/IHelloVaultEvents.sol";

// Import fee-related events and errors from Fees.sol
import {FeesSet, FeeRecipientSet, FeeSent, FeeOverMax} from "src/Fees.sol";

contract FeesTest is Test, VaultTestHelpers, IHelloVaultErrors, IHelloVaultEvents {
    bytes32 vaultDomainSep;

    Order aliceLong;
    bytes aliceLongSig;

    Order bobShort;
    bytes bobShortSig;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();

        // Initialize orders for position tests
        aliceLong = Order({account: alice, market: mktId1, size: 10e2, limitPrice: 1e18, nonce: 1});
        aliceLongSig = signOrder(aliceKey, aliceLong);

        bobShort = Order({account: bob, market: mktId1, size: -10e2, limitPrice: 0, nonce: 1});
        bobShortSig = signOrder(bobKey, bobShort);
    }

    // ============================================================================
    // SET FEES TESTS
    // ============================================================================

    function test_AdminCanSetFees() public {
        vm.startPrank(admin);

        vm.expectEmit(true, true, true, true);
        emit FeesSet(10, 20, 30, 1000);

        helloVault.setFees(10, 20, 30, 1000);
    }

    function test_NonAdminCannotSetFees() public {
        vm.startPrank(alice);

        vm.expectRevert();
        helloVault.setFees(10, 20, 30, 1000);
    }

    function test_CannotSetMakerFeeOverMax() public {
        vm.startPrank(admin);

        // MAKER_FEE_MAX = 500
        vm.expectRevert(abi.encodeWithSelector(FeeOverMax.selector, 501));
        helloVault.setFees(501, 20, 30, 1000);
    }

    function test_CannotSetTakerFeeOverMax() public {
        vm.startPrank(admin);

        // TAKER_FEE_MAX = 500
        vm.expectRevert(abi.encodeWithSelector(FeeOverMax.selector, 501));
        helloVault.setFees(10, 501, 30, 1000);
    }

    function test_CannotSetLiquidationFeeOverMax() public {
        vm.startPrank(admin);

        // LIQUIDATION_FEE_MAX = 500
        vm.expectRevert(abi.encodeWithSelector(FeeOverMax.selector, 501));
        helloVault.setFees(10, 20, 501, 1000);
    }

    function test_CannotSetBaseFeeOverMax() public {
        vm.startPrank(admin);

        // BASE_FEE_MAX = 1e5
        vm.expectRevert(abi.encodeWithSelector(FeeOverMax.selector, 100001));
        helloVault.setFees(10, 20, 30, 100001);
    }

    // ============================================================================
    // SET FEE RECIPIENT TESTS
    // ============================================================================

    function test_AdminCanSetFeeRecipient() public {
        vm.startPrank(admin);

        vm.expectEmit(true, true, true, true);
        emit FeeRecipientSet(charlie);

        helloVault.setFeeRecipient(charlie);
    }

    function test_NonAdminCannotSetFeeRecipient() public {
        vm.startPrank(alice);

        vm.expectRevert();
        helloVault.setFeeRecipient(charlie);
    }

    // ============================================================================
    // FEE SENT EVENT TESTS
    // ============================================================================

    function test_FeeSentEventEmittedOnFill() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 1% maker fee, 1% taker fee, no base fee
        vm.startPrank(admin);
        helloVault.setFees(100, 100, 0, 0); // 100 = 1% (100/10000)

        vm.startPrank(relayer);

        // Deposit for Alice and Bob
        _depositFor(aliceKey, 100_000e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);

        // Execute fill - should emit FeeSent for both maker and taker
        // Notional = 10 units * $1 = $10
        // Fee = $10 * 1% = $0.10 = 100000 USDC atoms per side

        /// Event emission order is sendFee -> orderFilled -> trackingHeadSet

        // Expect FeeSent for Alice (maker)
        vm.expectEmit(true, true, true, true);
        emit FeeSent(alice, address(usdcMock), feeRecipient, 100000);
        vm.expectEmit(true, false, false, false);
        // Garbage data (only checking indexed account param)
        emit OrderFilledV2(alice, 1, mktId1, 1e18, 1e18, 10e2, 10e2, 0, 100000, trackingHead + 2, false, false);

        // Expect FeeSent for Bob (taker)
        vm.expectEmit(true, true, true, true);
        emit FeeSent(bob, address(usdcMock), feeRecipient, 100000);
        vm.expectEmit(true, false, false, false);
        // Garbage data (only checking indexed account param)
        emit OrderFilledV2(bob, 1, mktId1, 1e18, 1e18, 10e2, 10e2, 0, 100000, trackingHead + 2, false, false);

        vm.expectEmit(true, false, false, false);
        emit TrackingHeadSet(trackingHead + 3);

        _fillMatchedOrder(aliceLong, aliceLongSig, bobShort, bobShortSig, 10e2, trackingHead + 2);
    }

    function test_FeeSentEventIncludesCorrectAccount() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 2% maker fee, 3% taker fee
        vm.startPrank(admin);
        helloVault.setFees(200, 300, 0, 0);

        vm.startPrank(relayer);

        _depositFor(aliceKey, 100_000e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);

        // The FeeSent event should include the account address
        // Alice is maker (first order), Bob is taker (second order)
        // Notional = 10 units * $1 = $10 = 10e6 USDC
        // Maker fee: $10 * 2% = $0.20 = 200000
        // Taker fee: $10 * 3% = $0.30 = 300000

        vm.expectEmit(true, true, true, true);
        emit FeeSent(alice, address(usdcMock), feeRecipient, 200000);

        vm.expectEmit(true, true, true, true);
        emit FeeSent(bob, address(usdcMock), feeRecipient, 300000);

        _fillMatchedOrder(aliceLong, aliceLongSig, bobShort, bobShortSig, 10e2, trackingHead + 2);
    }

    function test_FeeTransferredToRecipient() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 1% for both
        vm.startPrank(admin);
        helloVault.setFees(100, 100, 0, 0);

        vm.startPrank(relayer);

        _depositFor(aliceKey, 100_000e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);

        uint256 recipientBalanceBefore = usdcMock.balanceOf(feeRecipient);

        _fillMatchedOrder(aliceLong, aliceLongSig, bobShort, bobShortSig, 10e2, trackingHead + 2);

        uint256 recipientBalanceAfter = usdcMock.balanceOf(feeRecipient);

        // Both maker and taker pay $0.10 each (1% of $10 notional)
        // Total = 2 * $0.10 = $0.20 = 200000 USDC atoms
        assertEq(recipientBalanceAfter - recipientBalanceBefore, 200000);
    }

    // ============================================================================
    // FEE CALCULATION TESTS
    // ============================================================================

    function test_MakerFeeCalculation() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 1% maker fee (100 bps), 0% taker fee
        vm.startPrank(admin);
        helloVault.setFees(100, 0, 0, 0);

        vm.startPrank(relayer);

        _depositFor(aliceKey, 100_000e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);

        uint256 recipientBalanceBefore = usdcMock.balanceOf(feeRecipient);

        // Fill size: 10 units at price $1
        // Notional = 10 * $1 = $10
        // Maker fee = $10 * 1% = $0.10 = 100000 USDC atoms
        _fillMatchedOrder(aliceLong, aliceLongSig, bobShort, bobShortSig, 10e2, trackingHead + 2);

        uint256 recipientBalanceAfter = usdcMock.balanceOf(feeRecipient);

        // Only maker pays fee (Alice is maker as the first order)
        assertEq(recipientBalanceAfter - recipientBalanceBefore, 100000, "Maker fee should be $0.10");
    }

    function test_TakerFeeCalculation() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 0% maker fee, 2% taker fee (200 bps)
        vm.startPrank(admin);
        helloVault.setFees(0, 200, 0, 0);

        vm.startPrank(relayer);

        _depositFor(aliceKey, 100_000e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);

        uint256 recipientBalanceBefore = usdcMock.balanceOf(feeRecipient);

        // Fill size: 10 units at price $1
        // Notional = 10 * $1 = $10
        // Taker fee = $10 * 2% = $0.20 = 200000 USDC atoms
        _fillMatchedOrder(aliceLong, aliceLongSig, bobShort, bobShortSig, 10e2, trackingHead + 2);

        uint256 recipientBalanceAfter = usdcMock.balanceOf(feeRecipient);

        // Only taker pays fee (Bob is taker as the second order)
        assertEq(recipientBalanceAfter - recipientBalanceBefore, 200000, "Taker fee should be $0.20");
    }

    function test_BaseFeeAddedToPercentageFee() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 1% maker + 5000 base fee ($0.005), 1% taker + 5000 base fee
        vm.startPrank(admin);
        helloVault.setFees(100, 100, 0, 5000);

        vm.startPrank(relayer);

        _depositFor(aliceKey, 100_000e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);

        uint256 recipientBalanceBefore = usdcMock.balanceOf(feeRecipient);

        // Fill size: 10 units at price $1
        // Notional = $10
        // Percentage fee per side = $10 * 1% = $0.10 = 100000
        // Base fee per side = 5000 ($0.005)
        // Total per side = 100000 + 5000 = 105000
        _fillMatchedOrder(aliceLong, aliceLongSig, bobShort, bobShortSig, 10e2, trackingHead + 2);

        uint256 recipientBalanceAfter = usdcMock.balanceOf(feeRecipient);

        // Both sides pay: 105000 * 2 = 210000
        assertEq(recipientBalanceAfter - recipientBalanceBefore, 210000, "Fee should include base fee");
    }

    function test_LiquidationFeeCalculation() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 0% maker/taker, 5% liquidation fee (500 bps)
        vm.startPrank(admin);
        helloVault.setFees(0, 0, 500, 0);

        // Set up market with 10x leverage
        helloVault.setMarketConfig(
            mktId1,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: 1000, // 10x leverage
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );

        vm.startPrank(relayer);

        // Alice deposits $10, opens 100 units long at $1 with 10x leverage
        _depositFor(aliceKey, 10e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);
        _depositFor(charlieKey, 100_000e6, trackingHead + 2);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 3
        );

        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.901e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        // Charlie liquidates Alice (positive size since Alice is long)
        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.901e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        uint256 recipientBalanceBefore = usdcMock.balanceOf(feeRecipient);

        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.91e18, trackingHead + 4
        );

        uint256 recipientBalanceAfter = usdcMock.balanceOf(feeRecipient);

        // Liquidation fee should be charged (capped to Alice's $1 remaining margin)
        assertTrue(recipientBalanceAfter > recipientBalanceBefore, "Liquidation fee should be collected");
    }

    function test_LiquidationFeeCappedToRemainingMargin() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 0% maker/taker, 5% liquidation fee (500 bps), no base fee
        // Base fee must be 0 so Alice has exactly $10 margin after fill
        vm.startPrank(admin);
        helloVault.setFees(0, 0, 500, 0); // 500 bps liquidation fee, 0 base fee

        // Set up market with 10x leverage
        helloVault.setMarketConfig(
            mktId1,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: 1000, // 10x leverage
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );

        vm.startPrank(relayer);

        // Alice deposits $10, opens 100 units long at $1 with 10x leverage
        _depositFor(aliceKey, 10e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);
        _depositFor(charlieKey, 100_000e6, trackingHead + 2);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 3
        );

        // Drop price by 10% (equity = $0, liquidatable but no underflow)
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.9e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        // Charlie liquidates Alice (positive size since Alice is long)
        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.9e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        uint256 recipientBalanceBefore = usdcMock.balanceOf(feeRecipient);

        // Alice has $0 remaining margin after PnL loss ($10 margin - $10 loss)
        // Liquidation fee should be capped to $0
        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.9e18, trackingHead + 4
        );

        uint256 recipientBalanceAfter = usdcMock.balanceOf(feeRecipient);
        uint256 feeCollected = recipientBalanceAfter - recipientBalanceBefore;

        // Fee should be capped to remaining margin ($0)
        assertEq(feeCollected, 0, "Fee should be capped to $0 remaining margin");
    }

    /// @notice Test liquidation fee when Alice has just over $0 equity remaining
    /// @dev Price drops 9.5% leaving Alice with $0.50 equity. Fee (5% of $90.50 = $4.525) capped to $0.50
    function test_LiquidationFeeCappedToSmallRemainingMargin() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 0% maker/taker, 5% liquidation fee (500 bps), no base fee
        vm.startPrank(admin);
        helloVault.setFees(0, 0, 500, 0);

        // Set up market with 10x leverage
        helloVault.setMarketConfig(
            mktId1,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: 1000,
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );

        vm.startPrank(relayer);

        // Alice deposits $10, opens 100 units long at $1 with 10x leverage
        _depositFor(aliceKey, 10e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);
        _depositFor(charlieKey, 100_000e6, trackingHead + 2);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 3
        );

        // Drop price by 9.5% → Alice has ~$0.50 equity remaining
        // Equity = $10 - (100 * $0.095) = $10 - $9.50 = $0.50
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.901e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.901e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        uint256 recipientBalanceBefore = usdcMock.balanceOf(feeRecipient);

        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.901e18, trackingHead + 4
        );

        uint256 recipientBalanceAfter = usdcMock.balanceOf(feeRecipient);
        uint256 feeCollected = recipientBalanceAfter - recipientBalanceBefore;

        // Fee is capped
        assertEq(feeCollected, 0.1e6);
    }

    /// @notice Test liquidation fee when Alice has more equity than the fee (full fee charged, leaves dust)
    /// @dev Using 0.5% fee rate so fee < maintenance margin at liquidation boundary.
    ///      At 9.5% drop: equity = $0.50, maintenance = $0.905 (liquidatable), fee = 0.5% * $90.50 = $0.4525
    ///      Since equity ($0.50) > fee ($0.4525), full fee is charged, leaving $0.0475 dust
    function test_LiquidationFeeLeavesDust() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 0% maker/taker, 0.5% liquidation fee (50 bps), no base fee
        // Using lower fee rate so fee < maintenance margin when near liquidation
        vm.startPrank(admin);
        helloVault.setFees(0, 0, 50, 0);

        // Set up market with 10x leverage
        helloVault.setMarketConfig(
            mktId1,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: 1000,
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );

        vm.startPrank(relayer);

        // Alice deposits $10, opens 100 units long at $1 with 10x leverage
        _depositFor(aliceKey, 10e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);
        _depositFor(charlieKey, 100_000e6, trackingHead + 2);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 3
        );

        // Drop price by 9.5% → Alice has $0.50 equity, maintenance = $0.905, so liquidatable
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.904e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.904e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        uint256 recipientBalanceBefore = usdcMock.balanceOf(feeRecipient);

        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.905e18, trackingHead + 4
        );

        uint256 recipientBalanceAfter = usdcMock.balanceOf(feeRecipient);
        uint256 feeCollected = recipientBalanceAfter - recipientBalanceBefore;

        // Fee = 0.5% * $90.50 = $0.4525 = 452500
        // Alice has $0.50 equity, so full fee is charged (not capped)
        assertEq(feeCollected, 452500, "Full liquidation fee should be charged");

        // Verify Alice has dust remaining: $0.50 - $0.4525 = $0.0475 = 47500
        (int256 aliceMargin,,,) = helloVault.getAccountSummary(alice);
        assertEq(aliceMargin, 47500, "Alice should have ~$0.0475 dust remaining");
    }

    /// @notice Test liquidation reverts when Alice has negative equity
    /// @dev Price drops 11% causing loss > margin. sumSigned reverts with Overflow()
    function test_LiquidationRevertsOnNegativeEquity() public {
        uint256 trackingHead = _useTrackingHead();

        // Set fees: 0% maker/taker, 5% liquidation fee (500 bps), no base fee
        vm.startPrank(admin);
        helloVault.setFees(0, 0, 500, 0);

        // Set up market with 10x leverage
        helloVault.setMarketConfig(
            mktId1,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: 1000,
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );

        vm.startPrank(relayer);

        // Alice deposits $10, opens 100 units long at $1 with 10x leverage
        _depositFor(aliceKey, 10e6, trackingHead);
        _depositFor(bobKey, 100_000e6, trackingHead + 1);
        _depositFor(charlieKey, 100_000e6, trackingHead + 2);

        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 3
        );

        // Drop price by 11% → Alice has -$1 equity (negative!)
        // Equity = $10 - (100 * $0.11) = $10 - $11 = -$1
        vm.warp(vm.getBlockTimestamp() + 60);
        _setPricesForMarketWithPrice(mktId1, int192(0.89e18));

        assertTrue(helloVault.accountInLiquidation(alice), "Alice should be in liquidation");

        Order memory charlieLiquidatorOrder =
            Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 0.89e18, nonce: 1});
        bytes memory charlieLiquidatorSig = signOrder(charlieKey, charlieLiquidatorOrder);

        Liquidation memory aliceLiquidation = Liquidation({account: alice, market: mktId1});

        // Should revert because equity after liquidation is negative ($10 - $11 = -$1)
        vm.expectRevert(abi.encodeWithSelector(LiquidationResultsInNegativeMargin.selector, -1e6));
        helloVault.liquidateWithPrice(
            prices, charlieLiquidatorOrder, charlieLiquidatorSig, aliceLiquidation, 100e2, 0.89e18, trackingHead + 4
        );
    }
}

