// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {IHelloMarketDataEvents} from "src/interfaces/IHelloMarketDataEvents.sol";

import {VaultFixture} from "test/fixtures/VaultFixtureV1_1.sol";

contract VaultSetMarketConfigTest is Test, VaultFixture, IHelloMarketDataEvents {
    function setUp() public override {
        super.setUp();
        vm.startPrank(admin);
    }

    function test_SetNewMarketConfig_StoresStateAndEmitsEvent() public {
        MarketConfig memory newConfig = MarketConfig({
            maxLeverage: 8_000,
            defaultLeverage: 150,
            minFundingInterval: 15,
            fundingMax: 50_000_000,
            fundingMin: -25_000_000,
            pricePrecision: 18,
            basePrecision: 8,
            quotePrecision: 6
        });

        vm.expectEmit(true, false, false, true, address(helloVault));
        emit MarketConfigSet(mktId2, newConfig);

        helloVault.setMarketConfig(mktId2, newConfig);

        _assertMarketConfig(mktId2, newConfig);
    }

    function test_UpdateExistingMarketConfig_UpdatesStateAndEmitsEvent() public {
        MarketConfig memory initialConfig = MarketConfig({
            maxLeverage: 10_000,
            defaultLeverage: 200,
            minFundingInterval: 30,
            fundingMax: 100_000_000,
            fundingMin: -50_000_000,
            pricePrecision: 18,
            basePrecision: 8,
            quotePrecision: 6
        });

        vm.expectEmit(true, false, false, true, address(helloVault));
        emit MarketConfigSet(mktId1, initialConfig);

        helloVault.setMarketConfig(mktId1, initialConfig);
        _assertMarketConfig(mktId1, initialConfig);

        MarketConfig memory updatedConfig = MarketConfig({
            maxLeverage: 12_000,
            defaultLeverage: 250,
            minFundingInterval: 45,
            fundingMax: 75_000_000,
            fundingMin: -10_000_000,
            pricePrecision: 18,
            basePrecision: 4,
            quotePrecision: 6
        });

        vm.expectEmit(true, false, false, true, address(helloVault));
        emit MarketConfigSet(mktId1, updatedConfig);

        helloVault.setMarketConfig(mktId1, updatedConfig);
        _assertMarketConfig(mktId1, updatedConfig);
    }

    function _assertMarketConfig(uint32 market, MarketConfig memory expected) internal view {
        MarketConfig memory config = helloVault.marketConfig(market);

        assertEq(config.maxLeverage, expected.maxLeverage);
        assertEq(config.defaultLeverage, expected.defaultLeverage);
        assertEq(config.minFundingInterval, expected.minFundingInterval);
        assertEq(config.fundingMax, expected.fundingMax);
        assertEq(config.fundingMin, expected.fundingMin);
        assertEq(config.pricePrecision, expected.pricePrecision);
        assertEq(config.basePrecision, expected.basePrecision);
        assertEq(config.quotePrecision, expected.quotePrecision);
    }
}
