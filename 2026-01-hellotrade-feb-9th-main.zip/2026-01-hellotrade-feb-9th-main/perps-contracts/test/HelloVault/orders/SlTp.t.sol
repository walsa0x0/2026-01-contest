// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Order} from "src/lib/Order.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {IHelloVaultEvents} from "src/interfaces/IHelloVaultEvents.sol";

/// @title SL/TP Tests
/// @notice Tests for Stop Loss / Take Profit orders
/// @dev When order.size == 0, it's treated as an SL/TP order that should
///      close the entire position. The fillSize must equal the negative
///      of the current position size.
contract SlTpTest is Test, VaultTestHelpers, IHelloVaultErrors, IHelloVaultEvents {
    bytes32 vaultDomainSep;

    function setUp() public override {
        super.setUp();

        vm.startPrank(admin);
        helloVault.setFees(0, 0, 0, 0);

        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();
    }

    // ============================================================================
    // SL/TP SUCCESS CASES
    // ============================================================================

    /// @notice Test SL/TP can close a long position where the long is taker
    function test_SlTpClosesLongPositionTaker() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Alice opens a long position of 100 units
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 2
        );

        // Verify Alice has the position
        assertEq(helloVault.getPosition(alice, mktId1, false).size, 100e2, "Alice should have 100 unit long");

        // Alice creates an SL/TP order (size = 0) to close her position
        // Bob places a long order as maker, Alice's SL/TP is taker
        // makerFill = +100, takerFill = -100 (closes Alice's long)
        Order memory bobLong = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 2});
        Order memory aliceSlTp = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 2});

        helloVault.handleMatchedFill(
            prices,
            bobLong,
            signOrder(bobKey, bobLong),
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            100e2,
            trackingHead + 3
        );

        // Alice's position should be closed
        assertEq(helloVault.getPosition(alice, mktId1, false).size, 0, "Alice's position should be closed");
    }

    /// @notice Test SL/TP closes a short position where the short is taker
    function test_SlTpClosesShortPositionTaker() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Alice opens a short position of 100 units
        Order memory aliceShort = Order({account: alice, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        Order memory bobLong = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        _fillMatchedOrder(
            aliceShort, signOrder(aliceKey, aliceShort), bobLong, signOrder(bobKey, bobLong), 100e2, trackingHead + 2
        );

        // Verify Alice has the short position
        assertEq(helloVault.getPosition(alice, mktId1, false).size, -100e2, "Alice should have 100 unit short");

        // Alice creates an SL/TP order (size = 0) to close her position
        // Bob places a short order as maker, Alice's SL/TP is taker
        // makerFill = -100, takerFill = +100 (closes Alice's short)
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 2});
        Order memory aliceSlTp = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 2});

        helloVault.handleMatchedFill(
            prices,
            bobShort,
            signOrder(bobKey, bobShort),
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            100e2,
            trackingHead + 3
        );

        // Alice's position should be closed
        assertEq(helloVault.getPosition(alice, mktId1, false).size, 0, "Alice's position should be closed");
    }

    /// @notice Test SLTP closes a short position where the short is maker
    function test_SlTpClosesShortPositionMaker() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Alice opens a short position of 100 units
        Order memory aliceShort = Order({account: alice, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        Order memory bobLong = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        _fillMatchedOrder(
            aliceShort, signOrder(aliceKey, aliceShort), bobLong, signOrder(bobKey, bobLong), 100e2, trackingHead + 2
        );

        assertEq(helloVault.getPosition(alice, mktId1, false).size, -100e2, "Alice should have 100 unit short");

        // Alice creates an SL/TP order (size = 0) as MAKER to close her short
        // Bob places a sell order as taker
        // maker.size=0 → makerFill = +100 (Alice buys), takerFill = -100 (Bob sells)
        Order memory aliceSlTp = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 2});
        Order memory bobSell = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 1e18, nonce: 2});

        helloVault.handleMatchedFill(
            prices,
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            bobSell,
            signOrder(bobKey, bobSell),
            100e2,
            trackingHead + 3
        );

        assertEq(helloVault.getPosition(alice, mktId1, false).size, 0, "Alice's position should be closed");
    }

    /// @notice Maker SLTP closes a long position where the long is maker
    function test_SlTpClosesLongPositionMaker() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Alice opens a long position of 100 units
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 2
        );

        assertEq(helloVault.getPosition(alice, mktId1, false).size, 100e2, "Alice should have 100 unit long");

        // Alice tries to use SL/TP as MAKER to close her long
        Order memory aliceSlTp = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 2});
        Order memory bobBuy = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 2});

        helloVault.handleMatchedFill(
            prices,
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            bobBuy,
            signOrder(bobKey, bobBuy),
            100e2,
            trackingHead + 3
        );
    }

    // ============================================================================
    // SL/TP FAILURE CASES
    // ============================================================================

    /// @notice Test SL/TP fails if fill size doesn't match full position (partial close)
    function test_SlTpRevertsOnPartialClose() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Alice opens a long position of 100 units
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 2
        );

        // Alice creates an SL/TP order (size = 0)
        // Try to partially close (50 instead of 100) - should fail
        // Alice's SL/TP fillSize will be -50, but position is 100, so 100 != 50 → revert
        Order memory bobLong = Order({account: bob, market: mktId1, size: 50e2, limitPrice: 1e18, nonce: 2});
        Order memory aliceSlTp = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 2});

        vm.expectRevert(abi.encodeWithSelector(InvalidSlTp.selector, int256(0), int256(-50e2)));
        helloVault.handleMatchedFill(
            prices,
            bobLong,
            signOrder(bobKey, bobLong),
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            50e2,
            trackingHead + 3
        );
    }

    /// @notice Test SL/TP fails if fill direction is wrong (would increase position)
    function test_SlTpRevertsOnWrongDirection() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Alice opens a long position of 100 units
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 2
        );

        // Alice creates an SL/TP order (size = 0)
        // If Bob places a short as maker, Alice's taker fill would be +100
        // This would ADD to her long (wrong direction)
        // Check: positionSize (100) != -fillSize (-100) → 100 != -100 → revert
        Order memory bobShort2 = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 2});
        Order memory aliceSlTp = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 2});

        vm.expectRevert(abi.encodeWithSelector(InvalidSlTp.selector, int256(0), int256(100e2)));
        helloVault.handleMatchedFill(
            prices,
            bobShort2,
            signOrder(bobKey, bobShort2),
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            100e2,
            trackingHead + 3
        );
    }

    /// @notice Test SL/TP fails if user has no position
    function test_SlTpRevertsWithNoPosition() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Alice has no position but tries to use SL/TP
        // positionSize = 0, fillSize = -100
        // Check: 0 != -(-100) → 0 != 100 → revert
        Order memory bobLong = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory aliceSlTp = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 1});

        vm.expectRevert(abi.encodeWithSelector(InvalidSlTp.selector, int256(0), int256(-100e2)));
        helloVault.handleMatchedFill(
            prices,
            bobLong,
            signOrder(bobKey, bobLong),
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            100e2,
            trackingHead + 2
        );
    }

    /// @notice Test SL/TP fails if fill size overshoots position (would flip position)
    function test_SlTpRevertsOnOvershoot() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);
        _depositFor(bobKey, 1000e6, trackingHead + 1);

        // Alice opens a long position of 100 units
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 2
        );

        // Alice creates an SL/TP order (size = 0)
        // Try to overshoot (200 instead of 100) - would flip to short
        // positionSize = 100, fillSize = -200
        // Check: 100 != -(-200) → 100 != 200 → revert
        Order memory bobLong = Order({account: bob, market: mktId1, size: 200e2, limitPrice: 1e18, nonce: 2});
        Order memory aliceSlTp = Order({account: alice, market: mktId1, size: 0, limitPrice: 1e18, nonce: 2});

        vm.expectRevert(abi.encodeWithSelector(InvalidSlTp.selector, int256(0), int256(-200e2)));
        helloVault.handleMatchedFill(
            prices,
            bobLong,
            signOrder(bobKey, bobLong),
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            200e2,
            trackingHead + 3
        );
    }

    /// @notice Maker SLTP + Taker Limit reverts for non-crossing orders
    /// @dev When maker has size=0 and taker has size!=0, sizeForDirection = -taker.size
    function test_MakerSlTpTakerLimitNonCrossingOrdersRevert() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 10000e6, trackingHead);
        _depositFor(bobKey, 10000e6, trackingHead + 1);

        // Alice opens a short position (she will use SL/TP to close by buying)
        Order memory aliceShort = Order({account: alice, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        Order memory bobLong = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        _fillMatchedOrder(
            aliceShort, signOrder(aliceKey, aliceShort), bobLong, signOrder(bobKey, bobLong), 100e2, trackingHead + 2
        );

        assertEq(helloVault.getPosition(alice, mktId1, false).size, -100e2, "Alice should be short 100");

        // Alice (maker) creates SL/TP to close short: size=0, limitPrice=100
        // - Execution: maker.size=0 means Alice buys at her limitPrice
        Order memory aliceSlTp = Order({
            account: alice,
            market: mktId1,
            size: 0, // SL/TP to close short
            limitPrice: 100e18, // Max buy price
            nonce: 2
        });

        // Bob (taker) creates a sell order: size=-100, limitPrice=110
        Order memory bobSell = Order({
            account: bob,
            market: mktId1,
            size: -100e2, // Regular sell order
            limitPrice: 110e18, // Min sell price
            nonce: 2
        });

        // No cross: Alice buys at max 100, Bob sells at min 110
        vm.expectRevert(abi.encodeWithSelector(NoOrderCross.selector, uint256(100e18), uint256(110e18)));
        helloVault.handleMatchedFill(
            prices,
            aliceSlTp,
            signOrder(aliceKey, aliceSlTp),
            bobSell,
            signOrder(bobKey, bobSell),
            100e2,
            trackingHead + 3
        );
    }

    /// @notice Maker Limit + Taker SLTP reverts for non-crossing orders
    function test_MakerLimitTakerSlTpNonCrossingOrdersRevert() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 10000e6, trackingHead);
        _depositFor(bobKey, 10000e6, trackingHead + 1);

        // Bob opens a long position (he will use SL/TP to close by selling)
        Order memory bobLong = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory aliceShort = Order({account: alice, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            bobLong, signOrder(bobKey, bobLong), aliceShort, signOrder(aliceKey, aliceShort), 100e2, trackingHead + 2
        );

        assertEq(helloVault.getPosition(bob, mktId1, false).size, 100e2, "Bob should be long 100");

        // Alice (maker) creates a buy order: size=+100, limitPrice=90
        Order memory aliceBuy = Order({
            account: alice,
            market: mktId1,
            size: 100e2, // Regular buy order
            limitPrice: 90e18, // Max buy price
            nonce: 2
        });

        // Bob (taker) creates SL/TP to close long: size=0, limitPrice=110
        Order memory bobSlTp = Order({
            account: bob,
            market: mktId1,
            size: 0, // SL/TP to close long
            limitPrice: 110e18, // Min sell price
            nonce: 2
        });

        bytes memory aliceSig = signOrder(aliceKey, aliceBuy);
        bytes memory bobSig = signOrder(bobKey, bobSlTp);

        // No cross: Alice buys at max 90, Bob sells at min 110
        vm.expectRevert(abi.encodeWithSelector(NoOrderCross.selector, uint256(90e18), uint256(110e18)));
        helloVault.handleMatchedFill(prices, aliceBuy, aliceSig, bobSlTp, bobSig, 100e2, trackingHead + 3);
    }

    /// @notice Both SLTP should revert for non-crossing
    function test_BothSlTpNonCrossingOrdersShouldRevert() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 10000e6, trackingHead);
        _depositFor(bobKey, 10000e6, trackingHead + 1);
        _depositFor(charlieKey, 20000e6, trackingHead + 2);

        // Alice opens a short position (she will use SL/TP to close by buying)
        Order memory aliceShort = Order({account: alice, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        Order memory charlieLong = Order({account: charlie, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        _fillMatchedOrder(
            aliceShort,
            signOrder(aliceKey, aliceShort),
            charlieLong,
            signOrder(charlieKey, charlieLong),
            100e2,
            trackingHead + 3
        );

        // Bob opens a long position (he will use SL/TP to close by selling)
        Order memory bobLong = Order({account: bob, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory charlieShort = Order({account: charlie, market: mktId1, size: -100e2, limitPrice: 0, nonce: 2});
        _fillMatchedOrder(
            bobLong,
            signOrder(bobKey, bobLong),
            charlieShort,
            signOrder(charlieKey, charlieShort),
            100e2,
            trackingHead + 4
        );

        assertEq(helloVault.getPosition(alice, mktId1, false).size, -100e2, "Alice should be short 100");
        assertEq(helloVault.getPosition(bob, mktId1, false).size, 100e2, "Bob should be long 100");

        // Alice (maker) creates SL/TP to close short: size=0, limitPrice=100
        Order memory aliceSlTp = Order({
            account: alice,
            market: mktId1,
            size: 0, // SL/TP
            limitPrice: 100e18, // Max buy price
            nonce: 2
        });

        // Bob (taker) creates SL/TP to close long: size=0, limitPrice=110
        Order memory bobSlTp = Order({
            account: bob,
            market: mktId1,
            size: 0, // SL/TP
            limitPrice: 110e18, // Min sell price
            nonce: 2
        });

        // No cross: Alice buys at max 100, Bob sells at min 110
        bytes memory aliceSig = signOrder(aliceKey, aliceSlTp);
        bytes memory bobSig = signOrder(bobKey, bobSlTp);

        vm.expectRevert(abi.encodeWithSelector(NoOrderCross.selector, uint256(100e18), uint256(110e18)));
        helloVault.handleMatchedFill(prices, aliceSlTp, aliceSig, bobSlTp, bobSig, 100e2, trackingHead + 5);
    }
}
