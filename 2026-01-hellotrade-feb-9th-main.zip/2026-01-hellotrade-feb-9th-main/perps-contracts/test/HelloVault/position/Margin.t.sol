// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Order} from "src/lib/Order.sol";
import {Position} from "src/lib/Position.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";

/// @title MarginTest
/// @notice Tests for assigned margin calculation logic
/// @dev Assigned margin formula: abs(size) * price * LEVERAGE_EXPONENT * 10^quotePrecision / (leverage * 10^pricePrecision * 10^basePrecision)
/// @dev With basePrecision=2, quotePrecision=6, pricePrecision=18, LEVERAGE_EXPONENT=100
/// @dev At price=1e18 and leverage=100 (1x): assignedMargin = abs(size) * 1e6 / 100 (in USDC terms)
contract MarginTest is Test, VaultTestHelpers {
    bytes32 vaultDomainSep;

    uint256 constant PRICE_1USD = 1e18; // $1.00 with 18 decimals
    uint256 constant USDC_1 = 1e6; // 1 USDC with 6 decimals
    uint16 constant LEVERAGE_1X = 100; // 1x leverage (100 = 1x in the system)
    uint16 constant LEVERAGE_2X = 200; // 2x leverage
    uint16 constant LEVERAGE_10X = 1000; // 10x leverage

    // Small position orders (100 size)
    Order aliceLongSmall;
    bytes aliceLongSmallSig;
    Order bobShortSmall;
    bytes bobShortSmallSig;

    // Small short position
    Order aliceShortSmall;
    bytes aliceShortSmallSig;
    Order bobLongSmall;
    bytes bobLongSmallSig;

    // Large position orders (10000 size)
    Order aliceLongLarge;
    bytes aliceLongLargeSig;
    Order bobShortLarge;
    bytes bobShortLargeSig;

    // Orders with nonce 2 (for after leverage update)
    Order aliceLongSmallNonce2;
    bytes aliceLongSmallNonce2Sig;
    Order bobShortSmallNonce2;
    bytes bobShortSmallNonce2Sig;
    Order aliceLongLargeNonce2;
    bytes aliceLongLargeNonce2Sig;
    Order bobShortLargeNonce2;
    bytes bobShortLargeNonce2Sig;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();

        // Alice deposits 100,000 USDC
        _depositFor(aliceKey, 100_000 * USDC_1, _useTrackingHead());

        // Bob deposits 100,000 USDC to act as counterparty
        _depositFor(bobKey, 100_000 * USDC_1, _useTrackingHead());

        // Initialize small position orders (size = 100)
        aliceLongSmall = Order({account: alice, market: mktId1, size: 100, limitPrice: PRICE_1USD, nonce: 1});
        aliceLongSmallSig = signOrder(aliceKey, aliceLongSmall);

        bobShortSmall = Order({account: bob, market: mktId1, size: -100, limitPrice: 0, nonce: 1});
        bobShortSmallSig = signOrder(bobKey, bobShortSmall);

        // Small short position
        aliceShortSmall = Order({account: alice, market: mktId1, size: -100, limitPrice: PRICE_1USD, nonce: 1});
        aliceShortSmallSig = signOrder(aliceKey, aliceShortSmall);

        bobLongSmall = Order({account: bob, market: mktId1, size: 100, limitPrice: type(uint256).max, nonce: 1});
        bobLongSmallSig = signOrder(bobKey, bobLongSmall);

        // Large position orders (size = 10000)
        aliceLongLarge = Order({account: alice, market: mktId1, size: 10000, limitPrice: PRICE_1USD, nonce: 1});
        aliceLongLargeSig = signOrder(aliceKey, aliceLongLarge);

        bobShortLarge = Order({account: bob, market: mktId1, size: -10000, limitPrice: 0, nonce: 1});
        bobShortLargeSig = signOrder(bobKey, bobShortLarge);

        // Orders with nonce 2 (for tests after leverage update which uses nonce 1)
        aliceLongSmallNonce2 = Order({account: alice, market: mktId1, size: 100, limitPrice: PRICE_1USD, nonce: 2});
        aliceLongSmallNonce2Sig = signOrder(aliceKey, aliceLongSmallNonce2);

        bobShortSmallNonce2 = Order({account: bob, market: mktId1, size: -100, limitPrice: 0, nonce: 2});
        bobShortSmallNonce2Sig = signOrder(bobKey, bobShortSmallNonce2);

        aliceLongLargeNonce2 = Order({account: alice, market: mktId1, size: 10000, limitPrice: PRICE_1USD, nonce: 2});
        aliceLongLargeNonce2Sig = signOrder(aliceKey, aliceLongLargeNonce2);

        bobShortLargeNonce2 = Order({account: bob, market: mktId1, size: -10000, limitPrice: 0, nonce: 2});
        bobShortLargeNonce2Sig = signOrder(bobKey, bobShortLargeNonce2);

        prices = toArray(_createPriceInputWithPrice(mktId1, 1e18));
    }

    // ============================================================================
    // BASIC MARGIN CALCULATION TEST
    // ============================================================================

    /// @notice Test that assigned margin is zero before opening a position,
    /// and equals position_size (in USDC) when price=1 and leverage=1x
    function test_AssignedMarginBasicCase() public {
        // Verify initial state - no positions, assigned margin should be zero
        (,, uint256 assignedMarginBefore,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMarginBefore, 0, "Assigned margin should be zero before any positions");

        // Verify price is 1e18 ($1.00) as set in fixture
        uint256 markPrice = helloVault.getPrice(mktId1);
        assertEq(markPrice, PRICE_1USD, "Mark price should be $1.00");

        // Verify default leverage is 1x (100)
        Position memory posBefore = helloVault.getPosition(alice, mktId1, false);
        assertEq(posBefore.leverage, LEVERAGE_1X, "Default leverage should be 1x (100)");

        // Place an order for 100 base units (1.00 in base precision 2)
        // At price=$1 and 1x leverage, notional value = 100 * $1 / 100 = $1.00
        // Assigned margin should be $1.00 = 1e6 USDC
        _fillMatchedOrder(
            prices, aliceLongSmall, aliceLongSmallSig, bobShortSmall, bobShortSmallSig, 100, _useTrackingHead()
        );

        // Verify position was created
        Position memory pos = helloVault.getPosition(alice, mktId1, false);
        assertEq(pos.size, 100, "Position size should match order size");
        assertEq(pos.leverage, LEVERAGE_1X, "Leverage should be 1x");

        // Verify assigned margin = position_size * mark_price / leverage
        // = 100 * 1e18 * 100 * 1e6 / (100 * 1e18 * 1e2) = 1e6 USDC
        (,, uint256 assignedMarginAfter,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMarginAfter, USDC_1, "Assigned margin should be 1 USDC at price=$1, leverage=1x, size=100");
    }

    // ============================================================================
    // LEVERAGE IMPACT ON ASSIGNED MARGIN
    // ============================================================================

    /// @notice Test that assigned margin halves when leverage doubles (2x)
    function test_AssignedMarginAt2xLeverage() public {
        // Set leverage to 2x before opening position
        bytes memory leverageSig =
            signLeverageUpdate(aliceKey, alice, mktId1, LEVERAGE_2X, 1, block.timestamp + 1 hours, vaultDomainSep);
        helloVault.updateLeverageWithSignature(
            alice, mktId1, LEVERAGE_2X, 1, block.timestamp + 1 hours, _useTrackingHead(), leverageSig
        );

        // Place order for 100 base units (using nonce 2)
        _fillMatchedOrder(
            prices,
            aliceLongSmallNonce2,
            aliceLongSmallNonce2Sig,
            bobShortSmallNonce2,
            bobShortSmallNonce2Sig,
            100,
            _useTrackingHead()
        );

        // At 2x leverage, assigned margin should be half: 0.5 USDC = 500_000
        (,, uint256 assignedMargin,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMargin, USDC_1 / 2, "Assigned margin at 2x leverage should be 0.5 USDC");
    }

    /// @notice Test that assigned margin is 1/10th at 10x leverage
    function test_AssignedMarginAt10xLeverage() public {
        // Set leverage to 10x before opening position
        bytes memory leverageSig =
            signLeverageUpdate(aliceKey, alice, mktId1, LEVERAGE_10X, 1, block.timestamp + 1 hours, vaultDomainSep);
        helloVault.updateLeverageWithSignature(
            alice, mktId1, LEVERAGE_10X, 1, block.timestamp + 1 hours, _useTrackingHead(), leverageSig
        );

        // Place order for 100 base units (using nonce 2)
        _fillMatchedOrder(
            prices,
            aliceLongSmallNonce2,
            aliceLongSmallNonce2Sig,
            bobShortSmallNonce2,
            bobShortSmallNonce2Sig,
            100,
            _useTrackingHead()
        );

        // At 10x leverage, assigned margin should be 1/10th: 0.1 USDC = 100_000
        (,, uint256 assignedMargin,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMargin, USDC_1 / 10, "Assigned margin at 10x leverage should be 0.1 USDC");
    }

    // ============================================================================
    // PRICE IMPACT ON ASSIGNED MARGIN
    // ============================================================================

    /// @notice Test that assigned margin doubles when price doubles
    function test_AssignedMarginDoublesWithPrice() public {
        // Open position at $1
        _fillMatchedOrder(
            prices, aliceLongSmall, aliceLongSmallSig, bobShortSmall, bobShortSmallSig, 100, _useTrackingHead()
        );

        // Check assigned margin at $1 price
        (,, uint256 assignedMarginAt1Usd,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMarginAt1Usd, USDC_1, "Assigned margin should be 1 USDC at $1");

        // Warp time to invalidate local cache (validity period is 5 seconds)
        // This forces getMarkPrice to fall back to the Stork mock
        vm.warp(block.timestamp + 6);

        // Update Stork mock price to $2
        _setMockPrice(mktId1, int192(int256(2 * PRICE_1USD)));

        // Assigned margin should now be 2 USDC
        (,, uint256 assignedMarginAt2Usd,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMarginAt2Usd, 2 * USDC_1, "Assigned margin should double to 2 USDC when price doubles");
    }

    /// @notice Test that assigned margin halves when price halves
    function test_AssignedMarginHalvesWithPrice() public {
        // Open position at $1
        _fillMatchedOrder(
            prices, aliceLongSmall, aliceLongSmallSig, bobShortSmall, bobShortSmallSig, 100, _useTrackingHead()
        );

        // Check assigned margin at $1 price
        (,, uint256 assignedMarginAt1Usd,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMarginAt1Usd, USDC_1, "Assigned margin should be 1 USDC at $1");

        // Warp time to invalidate local cache (validity period is 5 seconds)
        // This forces getMarkPrice to fall back to the Stork mock
        vm.warp(block.timestamp + 6);

        // Update Stork mock price to $0.50
        _setMockPrice(mktId1, int192(int256(PRICE_1USD / 2)));

        // Assigned margin should now be 0.5 USDC
        (,, uint256 assignedMarginAtHalf,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMarginAtHalf, USDC_1 / 2, "Assigned margin should halve to 0.5 USDC when price halves");
    }

    // ============================================================================
    // COMBINED LEVERAGE AND PRICE CHANGES
    // ============================================================================

    /// @notice Test assigned margin with 2x leverage and $2 price
    /// @dev At 2x leverage, $2 price: margin = size * price / leverage = 100 * 2 / 2 = 1 USDC
    function test_AssignedMarginWithLeverageAndPriceChange() public {
        // Set leverage to 2x
        bytes memory leverageSig =
            signLeverageUpdate(aliceKey, alice, mktId1, LEVERAGE_2X, 1, block.timestamp + 1 hours, vaultDomainSep);
        helloVault.updateLeverageWithSignature(
            alice, mktId1, LEVERAGE_2X, 1, block.timestamp + 1 hours, _useTrackingHead(), leverageSig
        );

        // Open position at $1 (using nonce 2)
        _fillMatchedOrder(
            prices,
            aliceLongSmallNonce2,
            aliceLongSmallNonce2Sig,
            bobShortSmallNonce2,
            bobShortSmallNonce2Sig,
            100,
            _useTrackingHead()
        );

        // At 2x leverage and $1 price: margin = 0.5 USDC
        (,, uint256 assignedMarginInitial,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMarginInitial, USDC_1 / 2, "Initial margin at 2x, $1 should be 0.5 USDC");

        // Warp time to invalidate local cache (validity period is 5 seconds)
        // This forces getMarkPrice to fall back to the Stork mock
        vm.warp(block.timestamp + 6);

        // Update Stork mock price to $2
        _setMockPrice(mktId1, int192(int256(2 * PRICE_1USD)));

        // At 2x leverage and $2 price: margin = size * price / leverage = 100 * 2e18 / 200 = 1 USDC (in base terms)
        (,, uint256 assignedMarginAfter,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMarginAfter, USDC_1, "Margin at 2x leverage, $2 price should be 1 USDC");
    }

    // ============================================================================
    // SHORT POSITION MARGIN (absolute size)
    // ============================================================================

    /// @notice Test that short positions use absolute size for margin calculation
    function test_AssignedMarginForShortPosition() public {
        // Open short position: Alice short, Bob long
        _fillMatchedOrder(
            prices, aliceShortSmall, aliceShortSmallSig, bobLongSmall, bobLongSmallSig, 100, _useTrackingHead()
        );

        // Assigned margin should be same as long (absolute value)
        (,, uint256 assignedMargin,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMargin, USDC_1, "Short position assigned margin should be 1 USDC (same as long)");
    }

    // ============================================================================
    // LARGER POSITION SIZE TESTS
    // ============================================================================

    /// @notice Test assigned margin scales linearly with position size
    function test_AssignedMarginScalesWithSize() public {
        // Open position for 10000 base units (100.00 in base precision)
        _fillMatchedOrder(
            prices, aliceLongLarge, aliceLongLargeSig, bobShortLarge, bobShortLargeSig, 10000, _useTrackingHead()
        );

        // At price=$1 and 1x leverage, assigned margin = 10000 / 100 * 1e6 = 100 USDC
        (,, uint256 assignedMargin,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMargin, 100 * USDC_1, "Assigned margin should be 100 USDC for size=10000");
    }

    /// @notice Test assigned margin with large position and 10x leverage
    function test_AssignedMarginLargePositionHighLeverage() public {
        // Set leverage to 10x
        bytes memory leverageSig =
            signLeverageUpdate(aliceKey, alice, mktId1, LEVERAGE_10X, 1, block.timestamp + 1 hours, vaultDomainSep);
        helloVault.updateLeverageWithSignature(
            alice, mktId1, LEVERAGE_10X, 1, block.timestamp + 1 hours, _useTrackingHead(), leverageSig
        );

        // Open position for 10000 base units (100.00 in base precision) using nonce 2
        _fillMatchedOrder(
            prices,
            aliceLongLargeNonce2,
            aliceLongLargeNonce2Sig,
            bobShortLargeNonce2,
            bobShortLargeNonce2Sig,
            10000,
            _useTrackingHead()
        );

        // At 10x leverage: 100 USDC / 10 = 10 USDC
        (,, uint256 assignedMargin,) = helloVault.getAccountSummary(alice);
        assertEq(assignedMargin, 10 * USDC_1, "Assigned margin should be 10 USDC at 10x leverage for size=10000");
    }
}
