// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Position, PositionLib} from "src/lib/Position.sol";
import {Math} from "src/lib/Math.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";

contract PositionTest is Test {
    using PositionLib for Position;
    using Math for int256;

    // Precision constants
    uint8 constant PRICE_PRECISION = 18;
    uint8 constant QUOTE_PRECISION = 6;
    uint8 constant BASE_PRECISION = 2;

    MarketConfig private defaultMarketData;

    // Test market identifier
    uint256 constant TEST_MARKET = uint256(keccak256("TEST_MARKET"));

    function setUp() public {
        defaultMarketData = MarketConfig({
            maxLeverage: 100,
            defaultLeverage: 100,
            pricePrecision: PRICE_PRECISION,
            basePrecision: BASE_PRECISION,
            quotePrecision: QUOTE_PRECISION,
            fundingMax: 1_000_000_000,
            fundingMin: -1_000_000_000,
            minFundingInterval: 1
        });
    }

    // ============ calcTotalPnl Tests ============

    function test_calcTotalPnl_ZeroPosition() public pure {
        Position memory pos = Position({size: 0, entryFundingIdx: 0, leverage: 1, entryPrice: 0});
        int256 pnl = pos.calcTotalPnl(1000e18, 0, BASE_PRECISION);
        assertEq(pnl, 0, "Zero position should have zero PnL");
    }

    function test_calcTotalPnl_Long_Price_Increase() public pure {
        Position memory pos = Position({size: 150, entryFundingIdx: 0, leverage: 1, entryPrice: 12e18});
        int256 pnl = pos.calcTotalPnl(13e18, 0, BASE_PRECISION);
        assertGt(pnl, 0, "Long position should profit on price increase");
        assertEq(pnl, 1_500_000, "Long position PnL should be 1.5 USDC");
    }

    function test_calcTotalPnl_Short_Price_Decrease() public pure {
        Position memory pos = Position({size: 100, entryFundingIdx: 0, leverage: 1, entryPrice: 10e18});
        int256 pnl = pos.calcTotalPnl(9e18, 0, BASE_PRECISION);
        assertEq(pnl, -1_000_000, "Long position should lose 1 USDC on price decrease");
    }

    function test_Long_CalcTotalPnl_FundingPositive() public pure {
        uint128 price = 1e18; // 1 USD
        int256 positionSize = 200; // 2 units of base asset (2 USD worth)
        int192 fundingIdxLast = 1e16; // 1% in 1e18 precision times a price of 1, longs pay shorts
        int256 expectedFundingPnl = -20000; // 1% of 2 USD = 0.02 USD

        Position memory pos = Position({size: positionSize, entryFundingIdx: 0, leverage: 1, entryPrice: price});
        int256 pnl = pos.calcTotalPnl(price, fundingIdxLast, BASE_PRECISION);
        assertEq(pnl, expectedFundingPnl, "Long position should pay funding");
    }

    function test_Short_CalcTotalPnl_FundingPositive() public pure {
        uint128 price = 1e18; // 1 USD
        int256 positionSize = -200; // -2 units of base asset (-2 USD worth)
        int192 fundingIdxLast = 1e16; // 1% as 1e18 precision number times a price of 1, longs pay shorts
        int256 expectedFundingPnl = 20000; // 1% of 2 USD = 0.02 USD

        Position memory pos = Position({size: positionSize, entryFundingIdx: 0, leverage: 1, entryPrice: price});
        int256 pnl = pos.calcTotalPnl(price, fundingIdxLast, BASE_PRECISION);
        assertEq(pnl, expectedFundingPnl, "Short position should receive funding");
    }

    function test_Long_CalcTotalPnl_FundingNegative() public pure {
        uint128 price = 1e18; // 1 USD
        int256 positionSize = 200; // 2 units of base asset (2 USD worth)
        int192 fundingIdxLast = -1e16; // 1% as 1e18 precision number times a price of 1, shorts pay longs
        int256 expectedFundingPnl = 20000; // 1% of 2 USD = 0.02 USD

        Position memory pos = Position({size: positionSize, entryFundingIdx: 0, leverage: 1, entryPrice: price});
        int256 pnl = pos.calcTotalPnl(price, fundingIdxLast, BASE_PRECISION);
        assertEq(pnl, expectedFundingPnl, "Short position should pay funding");
    }

    function test_Short_CalcTotalPnl_FundingNegative() public pure {
        uint128 price = 1e18; // 1 USD
        int256 positionSize = -200; // -2 units of base asset (-2 USD worth)
        int192 fundingIdxLast = -1e16; // 1% as 1e18 precision number times a price of 1, shorts pay longs
        int256 expectedFundingPnl = -20000; // 1% of 2 USD = 0.02 USD

        Position memory pos = Position({size: positionSize, entryFundingIdx: 0, leverage: 1, entryPrice: price});
        int256 pnl = pos.calcTotalPnl(price, fundingIdxLast, BASE_PRECISION);
        assertEq(pnl, expectedFundingPnl, "Long position should pay funding");
    }

    // ============ calcNotionalPnl Tests ============

    function test_calcNotionalPnl_ZeroSize() public view {
        Position memory pos = Position({size: 0, entryFundingIdx: 0, leverage: 1, entryPrice: 1000e18});

        int256 pnlDirect = PositionLib.calcNotionalPnl(pos.size, uint256(pos.entryPrice), 1100e18, BASE_PRECISION);
        assertEq(pnlDirect, 0, "Zero size should have zero notional PnL");
    }

    function test_calcNotionalPnl_LongPriceIncrease() public view {
        Position memory pos = Position({
            size: 100, // 1.00 base units
            entryFundingIdx: 0,
            leverage: 1,
            entryPrice: 10e18 // 10.00
        });

        // Price increased to 11.00, long should profit
        int256 pnlDirect = PositionLib.calcNotionalPnl(pos.size, uint256(pos.entryPrice), 11e18, BASE_PRECISION);

        assertEq(pnlDirect, 1_000_000, "Long position should profit 1 USDC");
    }

    function test_calcNotionalPnl_LongPriceDecrease() public view {
        Position memory pos = Position({size: 100, entryFundingIdx: 0, leverage: 1, entryPrice: 10e18});

        int256 pnlDirect = PositionLib.calcNotionalPnl(pos.size, uint256(pos.entryPrice), 9e18, BASE_PRECISION);

        assertEq(pnlDirect, -1_000_000, "Long position should lose 1 USDC");
    }

    function test_calcNotionalPnl_ShortPriceIncrease() public view {
        Position memory pos = Position({
            size: -100, // 1.00 base units
            entryFundingIdx: 0,
            leverage: 1,
            entryPrice: 10e18 // 10.00
        });

        // Price increased to 11.00, short should lose

        int256 pnlDirect = PositionLib.calcNotionalPnl(pos.size, uint256(pos.entryPrice), 11e18, BASE_PRECISION);

        assertEq(pnlDirect, -1_000_000, "Short position should lose 1 USDC");
    }

    function test_calcNotionalPnl_ShortPriceDecrease() public view {
        Position memory pos = Position({size: -100, entryFundingIdx: 0, leverage: 1, entryPrice: 10e18});

        int256 pnlDirect = PositionLib.calcNotionalPnl(pos.size, uint256(pos.entryPrice), 9e18, BASE_PRECISION);

        assertEq(pnlDirect, 1_000_000, "Short position should gain 1 USDC");
    }

    // ============ calcLeverage Tests ============

    // function test_calcLeverage_ZeroSize() public view {
    //     Position memory pos = Position({
    //         size: 0,
    //         entryFundingIdx: 0,
    //         entryMargin: 1000e6,
    //         entryPrice: 1000e18
    //     });

    //     uint256 leverage = pos.calcLeverage(defaultMarketData);
    //     uint256 leverageDirect = PositionLib.calcLeverage(
    //         pos.size,
    //         pos.entryPrice,
    //         pos.entryMargin,
    //         defaultMarketData
    //     );
    //     assertEq(leverage, 0, "Zero size should have zero leverage");
    //     assertEq(
    //         leverage,
    //         leverageDirect,
    //         "Direct and position overloads should match"
    //     );
    // }

    // function test_calcLeverage_OneX() public view {
    //     // For 1x leverage: size * price / margin = 1
    //     // If size = 100 (1.00), price = 10.00, then margin should be 10.00
    //     Position memory pos = Position({
    //         size: 100, // 1.00 base units
    //         entryFundingIdx: 0,
    //         entryMargin: 10_000_000, // 10 USDC
    //         entryPrice: 10_000_000_000_000_000_000 // 10.00
    //     });

    //     uint256 leverage = pos.calcLeverage(defaultMarketData);
    //     uint256 leverageDirect = PositionLib.calcLeverage(
    //         pos.size,
    //         pos.entryPrice,
    //         pos.entryMargin,
    //         defaultMarketData
    //     );

    //     // Expected: (100 * 10e18 * 1e6 * 100) / (10e6 * 10^18 * 10^2)
    //     // = (100 * 10e18 * 1e6 * 100) / (10e6 * 10^18 * 10^2)
    //     // = (100 * 10 * 100) / (10 * 100) = 1000 / 1000 = 100 (1x in E2)
    //     assertEq(leverage, 100, "Leverage should be 1x (100 in E2)");
    //     assertEq(
    //         leverage,
    //         leverageDirect,
    //         "Direct and position overloads should match"
    //     );
    // }

    // function test_calcLeverage_TwoX() public view {
    //     Position memory pos = Position({
    //         size: 150, // 1.50 base units
    //         entryFundingIdx: 0,
    //         leverage: 2,
    //         entryPrice: 12_000_000_000_000_000_000 // 12.00
    //     });

    //     uint256 leverageDirect = PositionLib.calcLeverage(
    //         pos.size,
    //         pos.entryPrice,
    //         pos.leverage,
    //         defaultMarketData
    //     );

    // }

    // function test_calcLeverage_HighLeverage() public view {
    //     // For 10x leverage: size * price / margin = 10
    //     // If size = 100 (1.00), price = 10.00, then margin should be 1.00
    //     Position memory pos = Position({
    //         size: 100, // 1.00 base units
    //         entryFundingIdx: 0,
    //         entryMargin: 1_000_000, // 1 USDC
    //         entryPrice: 10_000_000_000_000_000_000 // 10.00
    //     });

    //     uint256 leverage = PositionLib.calcLeverage(pos, defaultMarketData);
    //     uint256 leverageDirect = PositionLib.calcLeverage(
    //         pos.size,
    //         pos.entryPrice,
    //         pos.entryMargin,
    //         defaultMarketData
    //     );

    //     // Expected: (100 * 10e18 * 1e6 * 100) / (1e6 * 10^18 * 10^2)
    //     // = (100 * 10 * 100) / (1 * 100) = 1000 / 100 = 1000 (10x in E2)
    //     assertEq(leverage, 1000, "Leverage should be 10x (1000 in E2)");
    //     assertEq(
    //         leverage,
    //         leverageDirect,
    //         "Direct and position overloads should match"
    //     );
    // }

    // ============ calcAssMargAtPrice Tests ============

    function test_calcAssMargAtPrice1x() public view {
        Position memory pos = Position({size: 100, entryFundingIdx: 0, leverage: 100, entryPrice: 1000e18});

        uint256 assMarg = pos.calcAssMargAtPrice(1000e18, defaultMarketData.basePrecision);
        assertEq(assMarg, 1000e6, "Assigned margin should be same at entry price");
    }

    function test_calcAssMargAtPrice2x() public view {
        Position memory pos = Position({size: 100, entryFundingIdx: 0, leverage: 200, entryPrice: 1000e18});

        uint256 assMarg = pos.calcAssMargAtPrice(1000e18, defaultMarketData.basePrecision);

        assertEq(assMarg, 500e6, "Assigned margin should scale with price increase");
    }

    function test_calcAssMargAtPrice_RoundsUp() public view {
        Position memory pos = Position({size: 100, entryFundingIdx: 0, leverage: 100, entryPrice: 777e18});

        uint256 assMarg = pos.calcAssMargAtPrice(77777777777e10, defaultMarketData.basePrecision);
        assertEq(assMarg, 777777778, "Assigned margin should round up");
    }

    // function test_calcAssMargAtPrice_PriceDecrease() public pure {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 10_000_000, // 10 USDC
    //         entryPrice: 10_000_000_000_000_000_000 // 10.00
    //     });

    //     // Price decreased to 8.00
    //     uint256 assMarg = pos.calcAssMargAtPrice(8_000_000_000_000_000_000);

    //     // Expected: (10_000_000 * 8e18) / 10e18 = 10_000_000 * 8 / 10 = 8_000_000
    //     assertEq(
    //         assMarg,
    //         8_000_000,
    //         "Assigned margin should scale with price decrease"
    //     );
    // }

    // // ============ calcMaintMargAtPrice Tests ============

    // function test_calcMaintMargAtPrice_ZeroSize() public view {
    //     Position memory pos = Position({
    //         size: 0,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 1000e18
    //     });

    //     uint256 maintMarg = pos.calcMaintMargAtPrice(
    //         1000e18,
    //         defaultMarketData
    //     );
    //     assertEq(maintMarg, 0, "Zero size should have zero maintenance margin");
    // }

    // function test_calcMaintMargAtPrice_LongPosition() public view {
    //     Position memory pos = Position({
    //         size: 100, // 1.00 base units (long)
    //         entryFundingIdx: 0,
    //         entryMargin: 10_000_000,
    //         entryPrice: 10_000_000_000_000_000_000 // 10.00
    //     });

    //     uint256 maintMarg = pos.calcMaintMargAtPrice(
    //         10_000_000_000_000_000_000,
    //         defaultMarketData
    //     );

    //     // Expected: (100 * 10e18 * 100 * 1e6) / (100 * 10^18 * 10^2)
    //     // = (100 * 10 * 100 * 1e6) / (100 * 100) = (100 * 10 * 1e6) / 100 = 10 * 1e6 = 10_000_000
    //     assertEq(maintMarg, 10_000_000, "Maintenance margin for long position");
    // }

    // function test_calcMaintMargAtPrice_ShortPosition() public view {
    //     Position memory pos = Position({
    //         size: -100, // -1.00 base units (short)
    //         entryFundingIdx: 0,
    //         entryMargin: 10_000_000,
    //         entryPrice: 10_000_000_000_000_000_000 // 10.00
    //     });

    //     uint256 maintMarg = pos.calcMaintMargAtPrice(
    //         10_000_000_000_000_000_000,
    //         defaultMarketData
    //     );

    //     // Uses abs(size), so should be same as long
    //     assertEq(
    //         maintMarg,
    //         10_000_000,
    //         "Maintenance margin for short position"
    //     );
    // }

    // function test_calcMaintMargAtPrice_PriceIncrease() public view {
    //     Position memory pos = Position({
    //         size: 100, // 1.00 base units
    //         entryFundingIdx: 0,
    //         entryMargin: 10_000_000,
    //         entryPrice: 10_000_000_000_000_000_000 // 10.00
    //     });

    //     // Price increased to 12.00
    //     uint256 maintMarg = pos.calcMaintMargAtPrice(
    //         12_000_000_000_000_000_000,
    //         defaultMarketData
    //     );

    //     // Expected: (100 * 12e18 * 100 * 1e6) / (100 * 10^18 * 10^2)
    //     // = (100 * 12 * 100 * 1e6) / (100 * 100) = (100 * 12 * 1e6) / 100 = 12 * 1e6 = 12_000_000
    //     assertEq(
    //         maintMarg,
    //         12_000_000,
    //         "Maintenance margin should scale with price increase"
    //     );
    // }

    // function test_calcMaintMargAtPrice_PriceDecrease() public view {
    //     Position memory pos = Position({
    //         size: 100, // 1.00 base units
    //         entryFundingIdx: 0,
    //         entryMargin: 10_000_000,
    //         entryPrice: 10_000_000_000_000_000_000 // 10.00
    //     });

    //     // Price decreased to 8.00
    //     uint256 maintMarg = pos.calcMaintMargAtPrice(
    //         8_000_000_000_000_000_000,
    //         defaultMarketData
    //     );

    //     // Expected: (100 * 8e18 * 100 * 1e6) / (100 * 10^18 * 10^2)
    //     // = (100 * 8 * 100 * 1e6) / (100 * 100) = (100 * 8 * 1e6) / 100 = 8 * 1e6 = 8_000_000
    //     assertEq(
    //         maintMarg,
    //         8_000_000,
    //         "Maintenance margin should scale with price decrease"
    //     );
    // }

    // // ============ deltaIsIncrease Tests ============

    // function test_deltaIsIncrease_LongIncrease() public pure {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool isIncrease = pos.deltaIsIncrease(50);
    //     assertTrue(
    //         isIncrease,
    //         "Positive delta on positive position should be increase"
    //     );
    // }

    // function test_deltaIsIncrease_LongDecrease() public pure {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool isIncrease = pos.deltaIsIncrease(-50);
    //     assertFalse(
    //         isIncrease,
    //         "Negative delta on positive position should not be increase"
    //     );
    // }

    // function test_deltaIsIncrease_ShortIncrease() public pure {
    //     Position memory pos = Position({
    //         size: -100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool isIncrease = pos.deltaIsIncrease(-50);
    //     assertTrue(
    //         isIncrease,
    //         "Negative delta on negative position should be increase"
    //     );
    // }

    // function test_deltaIsIncrease_ShortDecrease() public pure {
    //     Position memory pos = Position({
    //         size: -100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool isIncrease = pos.deltaIsIncrease(50);
    //     assertFalse(
    //         isIncrease,
    //         "Positive delta on negative position should not be increase"
    //     );
    // }

    // // ============ deltaCrossesZero Tests ============

    // function test_deltaCrossesZero_LongCrosses() public pure {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool crosses = pos.deltaCrossesZero(-150);
    //     assertTrue(crosses, "Large negative delta should cross zero");
    // }

    // function test_deltaCrossesZero_LongDoesNotCross() public pure {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool crosses = pos.deltaCrossesZero(-50);
    //     assertFalse(crosses, "Small negative delta should not cross zero");
    // }

    // function test_deltaCrossesZero_ShortCrosses() public pure {
    //     Position memory pos = Position({
    //         size: -100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool crosses = pos.deltaCrossesZero(150);
    //     assertTrue(crosses, "Large positive delta should cross zero");
    // }

    // function test_deltaCrossesZero_ShortDoesNotCross() public pure {
    //     Position memory pos = Position({
    //         size: -100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool crosses = pos.deltaCrossesZero(50);
    //     assertFalse(crosses, "Small positive delta should not cross zero");
    // }

    // // ============ deltaIsSimpleClose Tests ============

    // function test_deltaIsSimpleClose_IsSimpleClose() public pure {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool isSimpleClose = pos.deltaIsSimpleClose(-50, 0);
    //     assertTrue(
    //         isSimpleClose,
    //         "Partial close with no margin delta should be simple close"
    //     );
    // }

    // function test_deltaIsSimpleClose_NotSimpleClose_WithMarginDelta()
    //     public
    //     pure
    // {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool isSimpleClose = pos.deltaIsSimpleClose(-50, 100);
    //     assertFalse(
    //         isSimpleClose,
    //         "Close with margin delta should not be simple close"
    //     );
    // }

    // function test_deltaIsSimpleClose_NotSimpleClose_CrossesZero() public pure {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool isSimpleClose = pos.deltaIsSimpleClose(-150, 0);
    //     assertFalse(
    //         isSimpleClose,
    //         "Close that crosses zero should not be simple close"
    //     );
    // }

    // function test_deltaIsSimpleClose_NotSimpleClose_IsIncrease() public pure {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     bool isSimpleClose = pos.deltaIsSimpleClose(50, 0);
    //     assertFalse(isSimpleClose, "Increase should not be simple close");
    // }
}
