// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Position, PositionLib} from "src/lib/Position.sol";
import {Math} from "src/lib/Math.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";

contract PositionTest is Test {
    using PositionLib for Position;
    using Math for int256;

    // Storage mapping for testing storage-based functions
    mapping(bytes32 => Position) private positions;

    // Precision constants
    uint8 constant PRICE_PRECISION = 18;
    uint8 constant QUOTE_PRECISION = 6; // USDC precision
    uint8 constant BASE_PRECISION = 2; // Base precision

    MarketConfig private defaultMarketData;

    // Test market identifier
    bytes32 constant TEST_MARKET = keccak256("TEST_MARKET");

    function setUp() public {
        defaultMarketData = MarketConfig({
            maxLeverage: 100,
            defaultLeverage: 1,
            pricePrecision: PRICE_PRECISION,
            basePrecision: BASE_PRECISION,
            quotePrecision: QUOTE_PRECISION,
            fundingMax: 1_000_000_000,
            fundingMin: -1_000_000_000,
            minFundingInterval: 1
        });
    }

    function test_posDeltas_LongSizeIncreasePriceIncrease() public view {
        Position memory pos = Position({size: 10_000, entryFundingIdx: 0, leverage: 1, entryPrice: 100e18});
        uint256 execPrice = 110e18;
        int256 sizeDelta = 10_000;

        (Position memory newPos, int256 pnl) = pos.calcNewPosAndPnl(defaultMarketData, sizeDelta, execPrice, 0);
        assertEq(newPos.size, 20_000);
        assertEq(newPos.entryPrice, 105e18);
        assertEq(pnl, 0);
    }

    function test_posDeltas_LongSizeIncreasePriceDecrease() public view {
        Position memory pos = Position({size: 10_000, entryFundingIdx: 0, leverage: 1, entryPrice: 100e18});
        uint256 execPrice = 90e18;
        int256 sizeDelta = 10_000;

        (Position memory newPos, int256 pnl) = pos.calcNewPosAndPnl(defaultMarketData, sizeDelta, execPrice, 0);
        assertEq(newPos.size, 20_000);
        assertEq(newPos.entryPrice, 95e18);
        assertEq(pnl, 0);
    }

    function test_posDeltas_LongSizeDecreasePriceIncrease() public view {
        // 100 (100*1e2) shares of AAPL at $100
        // Notional = 100 * $100 = $10,000
        Position memory pos = Position({size: 10_000, entryFundingIdx: 0, leverage: 1, entryPrice: 100e18});
        uint256 execPrice = 110e18;
        // Close half of the position
        int256 sizeDelta = -5_000;

        (Position memory newPos, int256 pnl) = pos.calcNewPosAndPnl(defaultMarketData, sizeDelta, execPrice, 0);
        assertEq(newPos.size, 5_000);
        assertEq(newPos.entryPrice, 100e18);
        // // PNL = (110 - 100) * 50 = $500
        assertEq(pnl, 500_000_000);
    }

    function test_posDeltas_LongSizeDecreasePriceDecrease() public view {
        Position memory pos = Position({size: 10_000, entryFundingIdx: 0, leverage: 1, entryPrice: 100e18});

        uint256 execPrice = 90e18;
        int256 sizeDelta = -5_000;

        (Position memory newPos, int256 pnl) = pos.calcNewPosAndPnl(defaultMarketData, sizeDelta, execPrice, 0);
        assertEq(newPos.size, 5_000);
        assertEq(newPos.entryPrice, 100e18);
        assertEq(pnl, -500_000_000);
    }

    function test_posDeltas_ShortSizeIncreasePriceIncrease() public view {
        Position memory pos = Position({size: -10_000, entryFundingIdx: 0, leverage: 1, entryPrice: 100e18});

        uint256 execPrice = 110e18;
        int256 sizeDelta = -10_000;

        (Position memory newPos, int256 pnl) = pos.calcNewPosAndPnl(defaultMarketData, sizeDelta, execPrice, 0);
        assertEq(newPos.size, -20_000);
        assertEq(newPos.entryPrice, 105e18);
        assertEq(pnl, 0);
    }

    function test_posDeltas_ShortSizeIncreasePriceDecrease() public view {
        Position memory pos = Position({size: -10_000, entryFundingIdx: 0, leverage: 1, entryPrice: 100e18});
        uint256 execPrice = 90e18;
        int256 sizeDelta = -10_000;

        (Position memory newPos, int256 pnl) = pos.calcNewPosAndPnl(defaultMarketData, sizeDelta, execPrice, 0);
        assertEq(newPos.size, -20_000);
        assertEq(newPos.entryPrice, 95e18);
        assertEq(pnl, 0);
    }

    function test_posDeltas_ShortSizeDecreasePriceIncrease() public view {
        Position memory pos = Position({size: -10_000, entryFundingIdx: 0, leverage: 1, entryPrice: 100e18});

        uint256 execPrice = 110e18;
        int256 sizeDelta = 5_000;

        (Position memory newPos, int256 pnl) = pos.calcNewPosAndPnl(defaultMarketData, sizeDelta, execPrice, 0);
        assertEq(newPos.size, -5_000);
        assertEq(newPos.entryPrice, 100e18);
        assertEq(pnl, -500_000_000);
    }

    function test_posDeltas_ShortSizeDecreasePriceDecrease() public view {
        Position memory pos = Position({size: -10_000, entryFundingIdx: 0, leverage: 1, entryPrice: 100e18});
        uint256 execPrice = 90e18;
        int256 sizeDelta = 5_000;

        (Position memory newPos, int256 pnl) = pos.calcNewPosAndPnl(defaultMarketData, sizeDelta, execPrice, 0);
        assertEq(newPos.size, -5_000);
        assertEq(newPos.entryPrice, 100e18);
        assertEq(pnl, 500_000_000);
    }
}
