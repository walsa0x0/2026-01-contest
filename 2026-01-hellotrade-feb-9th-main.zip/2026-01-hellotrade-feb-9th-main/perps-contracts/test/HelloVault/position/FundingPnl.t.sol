// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Position, PositionLib} from "src/lib/Position.sol";
import {Math} from "src/lib/Math.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";

contract PositionTest is Test {
    using PositionLib for Position;
    using Math for int256;

    // Storage mapping for testing storage-based functions
    mapping(uint256 => Position) private positions;

    // Precision constants
    uint8 constant PRICE_PRECISION = 18;
    uint8 constant QUOTE_PRECISION = 6; // USDC precision
    uint8 constant BASE_PRECISION = 2; // Base precision

    MarketConfig private defaultMarketData;

    // Test market identifier
    uint256 constant TEST_MARKET = uint256(keccak256("TEST_MARKET"));

    function setUp() public {
        defaultMarketData = MarketConfig({
            maxLeverage: 100,
            defaultLeverage: 100,
            pricePrecision: PRICE_PRECISION,
            basePrecision: BASE_PRECISION,
            quotePrecision: QUOTE_PRECISION,
            fundingMax: 1_000_000_000,
            fundingMin: -1_000_000_000,
            minFundingInterval: 1
        });
    }

    // ============ calcFundingPnl Tests ============

    // function test_calcFundingPnl_ZeroSize() public view {
    //     Position memory pos = Position({
    //         size: 0,
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     int256 fundingPnl = pos.calcFundingPnl(1000, defaultMarketData);
    //     int256 fundingPnlDirect = PositionLib.calcFundingPnl(
    //         0,
    //         0,
    //         1000,
    //         BASE_PRECISION,
    //         QUOTE_PRECISION
    //     );
    //     assertEq(fundingPnl, 0, "Zero size should have zero funding PnL");
    //     assertEq(
    //         fundingPnl,
    //         fundingPnlDirect,
    //         "Direct and position overloads should match"
    //     );
    // }

    // function test_calcFundingPnl_NoFundingChange() public view {
    //     Position memory pos = Position({
    //         size: 100,
    //         entryFundingIdx: 1_000_000,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     // Funding index unchanged
    //     int256 fundingPnl = pos.calcFundingPnl(1_000_000, defaultMarketData);
    //     int256 fundingPnlDirect = PositionLib.calcFundingPnl(
    //         100,
    //         1_000_000,
    //         1_000_000,
    //         PRICE_PRECISION,
    //         BASE_PRECISION,
    //         QUOTE_PRECISION
    //     );

    //     assertEq(fundingPnl, 0, "No funding change should result in zero PnL");
    //     assertEq(
    //         fundingPnl,
    //         fundingPnlDirect,
    //         "Direct and position overloads should match"
    //     );
    // }

    // function test_calcFundingPnl_LongPaysFunding() public view {
    //     Position memory pos = Position({
    //         size: 100, // Long position
    //         entryFundingIdx: 0,
    //         leverage: 1,
    //         entryPrice: 0
    //     });

    //     // Funding index increased (positive funding means longs pay shorts)
    //     int192 fundingIdxLast = 1_000_000;
    //     int256 fundingPnl = pos.calcFundingPnl(
    //         fundingIdxLast,
    //         defaultMarketData
    //     );
    //     int256 fundingPnlDirect = PositionLib.calcFundingPnl(
    //         pos.size,
    //         pos.entryFundingIdx,
    //         fundingIdxLast,
    //         PRICE_PRECISION,
    //         BASE_PRECISION,
    //         QUOTE_PRECISION
    //     );

    //     console.log("fundingPnl", fundingPnl);
    //     console.log("fundingPnlDirect", fundingPnlDirect);

    //     // fundingDelta = -(1_000_000 - 0) = -1_000_000
    //     // fundingPnl = (-1_000_000 * 100 * 10^6) / (10^2 * 10^18 * 10^10)
    //     // = -1_000_000 * 100 * 10^6 / 10^30 = -100 * 10^12 / 10^30
    //     // Actually let's calculate: -1_000_000 * 100 * 10^6 / (10^2 * 10^18 * 10^10)
    //     // = -1_000_000 * 100 * 10^6 / 10^30 = -100 * 10^12 / 10^30 = -100 / 10^18
    //     // This is a very small negative number
    //     assertLt(fundingPnl, 0, "Long position should pay funding");
    //     assertEq(
    //         fundingPnl,
    //         fundingPnlDirect,
    //         "Direct and position overloads should match"
    //     );
    // }

    // function test_calcFundingPnl_ShortReceivesFunding() public view {
    //     Position memory pos = Position({
    //         size: -100, // Short position
    //         entryFundingIdx: 0,
    //         entryMargin: 0,
    //         entryPrice: 0
    //     });

    //     // Funding index increased (positive funding means shorts receive from longs)
    //     int192 fundingIdxLast = 1_000_000;
    //     int256 fundingPnl = pos.calcFundingPnl(
    //         fundingIdxLast,
    //         defaultMarketData
    //     );
    //     int256 fundingPnlDirect = PositionLib.calcFundingPnl(
    //         pos.size,
    //         pos.entryFundingIdx,
    //         fundingIdxLast,
    //         PRICE_PRECISION,
    //         BASE_PRECISION,
    //         QUOTE_PRECISION
    //     );

    //     // fundingDelta = -(1_000_000 - 0) = -1_000_000
    //     // fundingPnl = (-1_000_000 * -100 * 10^6) / (10^2 * 10^18 * 10^10)
    //     // = (1_000_000 * 100 * 10^6) / (10^2 * 10^18 * 10^10)
    //     // = positive (short receives)
    //     assertGt(fundingPnl, 0, "Short position should receive funding");
    //     assertEq(
    //         fundingPnl,
    //         fundingPnlDirect,
    //         "Direct and position overloads should match"
    //     );
    // }
}
