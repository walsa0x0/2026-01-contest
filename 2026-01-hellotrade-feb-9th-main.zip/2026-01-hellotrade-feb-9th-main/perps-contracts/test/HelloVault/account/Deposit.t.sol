// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";

contract DepositTest is Test, VaultTestHelpers, IHelloVaultErrors {
    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
    }

    function test_UserCanDepositBytes() public {
        _assertMarginUnchanged(alice, 0);

        // Alice deposits 100 USDC
        bytes memory sig =
            signPermit(aliceKey, address(usdcMock), address(helloVault), 100 * 1e6, block.timestamp + 1 hours);
        helloVault.depositWithSignature(alice, 100 * 1e6, block.timestamp + 1 hours, _useTrackingHead(), sig);

        _assertMarginChange(alice, 0, 100e6);
    }

    function test_UserCanDepositVRS() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = signPermit(aliceKey, address(usdcMock), address(helloVault), 100 * 1e6, deadline);

        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly ("memory-safe") {
            r := mload(add(sig, 0x20))
            s := mload(add(sig, 0x40))
            v := byte(0, mload(add(sig, 0x60)))
        }

        helloVault.depositWithSignature(alice, 100 * 1e6, deadline, trackingHead, v, r, s);

        _assertMarginChange(alice, 0, 100e6);
    }

    function test_UserCannotDepositWithZeroAmount() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = signPermit(aliceKey, address(usdcMock), address(helloVault), 0, deadline);

        vm.expectRevert(abi.encodeWithSelector(AmountZero.selector));
        helloVault.depositWithSignature(alice, 0, deadline, trackingHead, sig);
    }
}
