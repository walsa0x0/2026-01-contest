// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Order, OrderV2, ORDER_FLAG_ISOLATED} from "src/lib/Order.sol";
import {SignerUtils} from "src/lib/SignerUtils.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {IHelloVaultEvents} from "src/interfaces/IHelloVaultEvents.sol";

/// @title Transfer Margin Tests
/// @notice Tests for transferMarginWithSignature - moving margin between cross and isolated accounts
contract TransferMarginTest is Test, VaultTestHelpers, IHelloVaultErrors, IHelloVaultEvents {
    using SafeCastLib for uint256;

    bytes32 vaultDomainSep;

    function setUp() public override {
        super.setUp();

        vm.startPrank(admin);
        helloVault.setFees(0, 0, 0, 0); // No fees for cleaner tests

        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();
    }

    // ============================================================================
    // CROSS → ISOLATED (flags = 0)
    // ============================================================================

    /// @notice Test transfer from cross to isolated margin succeeds
    function test_TransferMargin_CrossToIsolated_Success() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 1000e6;
        uint256 transferAmount = 400e6;

        // Setup: deposit to cross margin
        _depositFor(aliceKey, depositAmount, trackingHead);

        int256 crossBefore = helloVault.getMargin(alice);
        uint256 isoBefore = helloVault.getIsoMargin(alice, mktId1);

        // Transfer cross → isolated (flags = 0 means source is cross)
        _transferMargin(aliceKey, transferAmount, mktId1, 0, 1, trackingHead + 1);

        // Verify balances changed correctly
        assertEq(helloVault.getMargin(alice), crossBefore - transferAmount.toInt256(), "Cross margin should decrease");
        assertEq(helloVault.getIsoMargin(alice, mktId1), isoBefore + transferAmount, "Isolated margin should increase");
    }

    /// @notice Test transfer full cross balance to isolated
    function test_TransferMargin_CrossToIsolated_FullBalance() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 500e6;

        _depositFor(aliceKey, depositAmount, trackingHead);

        // Transfer entire cross balance
        _transferMargin(aliceKey, depositAmount, mktId1, 0, 1, trackingHead + 1);

        assertEq(helloVault.getMargin(alice), 0, "Cross margin should be zero");
        assertEq(helloVault.getIsoMargin(alice, mktId1), depositAmount, "Isolated margin should have full amount");
    }

    /// @notice Test transfer to different isolated markets
    function test_TransferMargin_CrossToMultipleIsolatedMarkets() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 1000e6;

        // Setup market 2
        vm.startPrank(admin);
        helloVault.setMarketStorkId(mktId2, storkInstId2);
        helloVault.setMarketHelloStorkId(mktId2, storkInstId2);
        storkMock.setStorkPrice(storkInstId2, int192(1e18));
        vm.stopPrank();

        vm.startPrank(relayer);
        _depositFor(aliceKey, depositAmount, trackingHead);

        // Transfer to mktId1
        _transferMargin(aliceKey, 300e6, mktId1, 0, 1, trackingHead + 1);
        // Transfer to mktId2
        _transferMargin(aliceKey, 400e6, mktId2, 0, 2, trackingHead + 2);

        assertEq(helloVault.getMargin(alice), 300e6, "Cross margin should have remainder");
        assertEq(helloVault.getIsoMargin(alice, mktId1), 300e6, "mktId1 isolated margin correct");
        assertEq(helloVault.getIsoMargin(alice, mktId2), 400e6, "mktId2 isolated margin correct");
    }

    /// @notice Test event is emitted correctly for cross to isolated
    function test_TransferMargin_CrossToIsolated_EmitsEvent() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 transferAmount = 500e6;

        _depositFor(aliceKey, 1000e6, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, transferAmount, mktId1, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectEmit(true, true, true, true);
        emit MarginTransferred(alice, transferAmount, mktId1, true); // toIsolated = true
        helloVault.transferMarginWithSignature(alice, transferAmount, mktId1, 0, 1, deadline, trackingHead + 1, sig);
    }

    // ============================================================================
    // ISOLATED → CROSS (flags = ORDER_FLAG_ISOLATED)
    // ============================================================================

    /// @notice Test transfer from isolated to cross margin succeeds
    function test_TransferMargin_IsolatedToCross_Success() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 1000e6;
        uint256 transferAmount = 400e6;

        // Setup: deposit to isolated margin
        _depositV2(aliceKey, depositAmount, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        int256 crossBefore = helloVault.getMargin(alice);
        uint256 isoBefore = helloVault.getIsoMargin(alice, mktId1);

        // Transfer isolated → cross (flags = ORDER_FLAG_ISOLATED means source is isolated)
        _transferMargin(aliceKey, transferAmount, mktId1, ORDER_FLAG_ISOLATED, 2, trackingHead + 1);

        // Verify balances changed correctly
        assertEq(helloVault.getMargin(alice), crossBefore + transferAmount.toInt256(), "Cross margin should increase");
        assertEq(helloVault.getIsoMargin(alice, mktId1), isoBefore - transferAmount, "Isolated margin should decrease");
    }

    /// @notice Test transfer full isolated balance to cross
    function test_TransferMargin_IsolatedToCross_FullBalance() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 500e6;

        _depositV2(aliceKey, depositAmount, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        // Transfer entire isolated balance
        _transferMargin(aliceKey, depositAmount, mktId1, ORDER_FLAG_ISOLATED, 2, trackingHead + 1);

        assertEq(helloVault.getIsoMargin(alice, mktId1), 0, "Isolated margin should be zero");
        assertEq(helloVault.getMargin(alice), depositAmount.toInt256(), "Cross margin should have full amount");
    }

    /// @notice Test event is emitted correctly for isolated to cross
    function test_TransferMargin_IsolatedToCross_EmitsEvent() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 transferAmount = 500e6;

        _depositV2(aliceKey, 1000e6, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, transferAmount, mktId1, ORDER_FLAG_ISOLATED, 2, deadline);

        vm.startPrank(relayer);
        vm.expectEmit(true, true, true, true);
        emit MarginTransferred(alice, transferAmount, mktId1, false); // toIsolated = false
        helloVault.transferMarginWithSignature(
            alice, transferAmount, mktId1, ORDER_FLAG_ISOLATED, 2, deadline, trackingHead + 1, sig
        );
    }

    // ============================================================================
    // SAD PATHS - INSUFFICIENT MARGIN
    // ============================================================================

    /// @notice Test transfer fails when cross margin insufficient
    function test_TransferMargin_FailsWithInsufficientCrossMargin() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 100e6, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, 200e6, mktId1, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin
        helloVault.transferMarginWithSignature(alice, 200e6, mktId1, 0, 1, deadline, trackingHead + 1, sig);
    }

    /// @notice Test transfer fails when isolated margin insufficient
    function test_TransferMargin_FailsWithInsufficientIsolatedMargin() public {
        uint256 trackingHead = _useTrackingHead();

        _depositV2(aliceKey, 100e6, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, 200e6, mktId1, ORDER_FLAG_ISOLATED, 2, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin
        helloVault.transferMarginWithSignature(
            alice, 200e6, mktId1, ORDER_FLAG_ISOLATED, 2, deadline, trackingHead + 1, sig
        );
    }

    /// @notice Test transfer fails when cross margin is needed for open positions
    function test_TransferMargin_FailsWhenCrossMarginNeededForPositions() public {
        uint256 trackingHead = _useTrackingHead();

        // Setup: Alice and Bob deposit and open positions
        _depositFor(aliceKey, 100e6, trackingHead);
        _depositFor(bobKey, 100e6, trackingHead + 1);

        // Open a position that uses margin
        Order memory aliceLong = Order({account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 1});
        Order memory bobShort = Order({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 1});
        _fillMatchedOrder(
            aliceLong, signOrder(aliceKey, aliceLong), bobShort, signOrder(bobKey, bobShort), 100e2, trackingHead + 2
        );

        // Try to transfer all margin out - should fail as position needs it
        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, 100e6, mktId1, 0, 2, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin - position needs the margin
        helloVault.transferMarginWithSignature(alice, 100e6, mktId1, 0, 2, deadline, trackingHead + 3, sig);
    }

    /// @notice Test transfer fails when isolated margin is needed for open positions
    function test_TransferMargin_FailsWhenIsolatedMarginNeededForPositions() public {
        uint256 trackingHead = _useTrackingHead();

        // Setup: deposit to isolated and open position
        _depositV2(aliceKey, 100e6, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);
        _depositV2(bobKey, 100e6, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead + 1);

        // Open isolated positions
        OrderV2 memory aliceLong = OrderV2({
            account: alice, market: mktId1, size: 100e2, limitPrice: 1e18, nonce: 2, flags: ORDER_FLAG_ISOLATED
        });
        OrderV2 memory bobShort =
            OrderV2({account: bob, market: mktId1, size: -100e2, limitPrice: 0, nonce: 2, flags: ORDER_FLAG_ISOLATED});

        bytes memory aliceSig = _signOrderV2(aliceKey, aliceLong);
        bytes memory bobSig = _signOrderV2(bobKey, bobShort);

        vm.startPrank(relayer);
        helloVault.handleMatchedFillV2(prices, aliceLong, aliceSig, bobShort, bobSig, 100e2, trackingHead + 2);

        // Try to transfer all isolated margin out - should fail
        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, 100e6, mktId1, ORDER_FLAG_ISOLATED, 3, deadline);

        vm.expectRevert(); // InsufficientMargin - position needs the margin
        helloVault.transferMarginWithSignature(
            alice, 100e6, mktId1, ORDER_FLAG_ISOLATED, 3, deadline, trackingHead + 3, sig
        );
    }

    // ============================================================================
    // SAD PATHS - VALIDATION ERRORS
    // ============================================================================

    /// @notice Test transfer fails with expired deadline
    function test_TransferMargin_FailsWithExpiredDeadline() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);

        uint256 expiredDeadline = block.timestamp - 1;
        bytes memory sig = _signTransferMargin(aliceKey, 500e6, mktId1, 0, 1, expiredDeadline);

        vm.startPrank(relayer);
        vm.expectRevert(DeadlineExpired.selector);
        helloVault.transferMarginWithSignature(alice, 500e6, mktId1, 0, 1, expiredDeadline, trackingHead + 1, sig);
    }

    /// @notice Test transfer fails with zero amount
    function test_TransferMargin_FailsWithZeroAmount() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, 0, mktId1, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(AmountZero.selector);
        helloVault.transferMarginWithSignature(alice, 0, mktId1, 0, 1, deadline, trackingHead + 1, sig);
    }

    /// @notice Test transfer fails with invalid signer
    function test_TransferMargin_FailsWithInvalidSigner() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        // Bob signs for Alice's account
        bytes memory sig = _signTransferMarginAs(bobKey, alice, 500e6, mktId1, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(abi.encodeWithSelector(InvalidSigner.selector, alice, bob));
        helloVault.transferMarginWithSignature(alice, 500e6, mktId1, 0, 1, deadline, trackingHead + 1, sig);
    }

    /// @notice Test transfer fails with used nonce
    function test_TransferMargin_FailsWithUsedNonce() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);

        // First transfer succeeds
        _transferMargin(aliceKey, 200e6, mktId1, 0, 1, trackingHead + 1);

        // Second transfer with same nonce fails
        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, 200e6, mktId1, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(NonceUsed.selector);
        helloVault.transferMarginWithSignature(alice, 200e6, mktId1, 0, 1, deadline, trackingHead + 2, sig);
    }

    // ============================================================================
    // HELPER FUNCTIONS
    // ============================================================================

    function _depositV2(
        uint256 userKey,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256, // nonce - unused, permit nonce is managed by token
        uint256 trackingHead
    ) internal {
        address user = vm.addr(userKey);
        uint256 deadline = block.timestamp + 1 hours;

        // Sign permit for USDC token
        bytes memory sig = signPermit(userKey, address(usdcMock), address(helloVault), amount, deadline);

        vm.startPrank(relayer);
        helloVault.depositWithSignatureV2(user, amount, market, flags, deadline, trackingHead, sig);
    }

    function _transferMargin(
        uint256 userKey,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 trackingHead
    ) internal {
        address user = vm.addr(userKey);
        uint256 deadline = block.timestamp + 1 hours;

        bytes memory sig = _signTransferMargin(userKey, amount, market, flags, nonce, deadline);

        vm.startPrank(relayer);
        helloVault.transferMarginWithSignature(user, amount, market, flags, nonce, deadline, trackingHead, sig);
    }

    function _signTransferMargin(
        uint256 signerKey,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 deadline
    ) internal view returns (bytes memory) {
        address signer = vm.addr(signerKey);
        bytes32 structHash = SignerUtils._buildTransferMarginHash(signer, amount, market, flags, nonce, deadline);
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", vaultDomainSep, structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }

    /// @notice Sign transfer margin with a different account than the signer (for invalid signer tests)
    function _signTransferMarginAs(
        uint256 signerKey,
        address account,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 deadline
    ) internal view returns (bytes memory) {
        bytes32 structHash = SignerUtils._buildTransferMarginHash(account, amount, market, flags, nonce, deadline);
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", vaultDomainSep, structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }

    function _signOrderV2(uint256 signerKey, OrderV2 memory order) internal view returns (bytes memory) {
        bytes32 structHash = order.digest();
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", vaultDomainSep, structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }
}

