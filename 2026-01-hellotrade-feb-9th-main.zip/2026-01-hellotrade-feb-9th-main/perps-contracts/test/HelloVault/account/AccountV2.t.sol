// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {ORDER_FLAG_ISOLATED} from "src/lib/Order.sol";
import {SignerUtils} from "src/lib/SignerUtils.sol";
import {SafeCastLib} from "solady/utils/SafeCastLib.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";

/// @title Account V2 Tests
/// @notice Tests for depositWithSignatureV2, withdrawWithSignatureV2, updateLeverageWithSignatureV2, and transferMarginWithSignature
contract AccountV2Test is Test, VaultTestHelpers, IHelloVaultErrors {
    using SafeCastLib for uint256;

    bytes32 vaultDomainSep;

    function setUp() public override {
        super.setUp();

        vm.startPrank(admin);
        helloVault.setFees(0, 0, 0, 0); // No fees for cleaner tests

        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();
    }

    // ============================================================================
    // DEPOSIT V2 TESTS
    // ============================================================================

    /// @notice Test deposit to cross margin (flags=0)
    function test_DepositV2_CrossMargin() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 amount = 1000e6;

        int256 balanceBefore = helloVault.getMargin(alice);

        _depositV2(aliceKey, amount, mktId1, 0, 1, trackingHead);

        assertEq(helloVault.getMargin(alice), balanceBefore + amount.toInt256(), "Cross margin should increase");
        assertEq(helloVault.getIsoMargin(alice, mktId1), 0, "Isolated margin should be unchanged");
    }

    /// @notice Test deposit to isolated margin (flags=ORDER_FLAG_ISOLATED)
    function test_DepositV2_IsolatedMargin() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 amount = 1000e6;

        _depositV2(aliceKey, amount, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        assertEq(helloVault.getIsoMargin(alice, mktId1), amount, "Isolated margin should increase");
        assertEq(helloVault.getMargin(alice), 0, "Cross margin should be unchanged");
    }

    /// @notice Test deposit fails with expired deadline
    function test_DepositV2_FailsWithExpiredDeadline() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 amount = 1000e6;
        uint256 expiredDeadline = block.timestamp - 1;

        // Sign permit with expired deadline
        bytes memory sig = signPermit(aliceKey, address(usdcMock), address(helloVault), amount, expiredDeadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // Permit will fail due to expired deadline
        helloVault.depositWithSignatureV2(alice, amount, mktId1, 0, expiredDeadline, trackingHead, sig);
    }

    /// @notice Test deposit fails with invalid signer
    function test_DepositV2_FailsWithInvalidSigner() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 amount = 1000e6;
        uint256 deadline = block.timestamp + 1 hours;

        // Bob signs a permit for Alice's tokens (invalid - only Alice can sign)
        bytes memory sig = signPermit(bobKey, address(usdcMock), address(helloVault), amount, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // Permit will fail due to invalid signer
        helloVault.depositWithSignatureV2(alice, amount, mktId1, 0, deadline, trackingHead, sig);
    }

    /// @notice Test deposit fails with zero amount
    function test_DepositV2_FailsWithZeroAmount() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 deadline = block.timestamp + 1 hours;

        bytes memory sig = signPermit(aliceKey, address(usdcMock), address(helloVault), 0, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(AmountZero.selector);
        helloVault.depositWithSignatureV2(alice, 0, mktId1, 0, deadline, trackingHead, sig);
    }

    // ============================================================================
    // WITHDRAW V2 TESTS
    // ============================================================================

    /// @notice Test withdraw from cross margin (flags=0)
    function test_WithdrawV2_CrossMargin() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 1000e6;
        uint256 withdrawAmount = 500e6;

        // First deposit to cross margin
        _depositFor(aliceKey, depositAmount, trackingHead);

        int256 balanceBefore = helloVault.getMargin(alice);

        // Withdraw from cross margin
        _withdrawV2(aliceKey, withdrawAmount, mktId1, 0, 1, trackingHead + 1);

        assertEq(helloVault.getMargin(alice), balanceBefore - withdrawAmount.toInt256(), "Cross margin should decrease");
    }

    /// @notice Test withdraw from isolated margin (flags=ORDER_FLAG_ISOLATED)
    function test_WithdrawV2_IsolatedMargin() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 1000e6;
        uint256 withdrawAmount = 500e6;

        // First deposit to isolated margin
        _depositV2(aliceKey, depositAmount, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        uint256 isoBalanceBefore = helloVault.getIsoMargin(alice, mktId1);

        // Withdraw from isolated margin
        _withdrawV2(aliceKey, withdrawAmount, mktId1, ORDER_FLAG_ISOLATED, 2, trackingHead + 1);

        assertEq(
            helloVault.getIsoMargin(alice, mktId1), isoBalanceBefore - withdrawAmount, "Isolated margin should decrease"
        );
    }

    /// @notice Test withdraw fails with insufficient cross margin
    function test_WithdrawV2_FailsWithInsufficientCrossMargin() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 100e6;
        uint256 withdrawAmount = 200e6;

        _depositFor(aliceKey, depositAmount, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signWithdrawV2(aliceKey, withdrawAmount, mktId1, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin
        helloVault.withdrawWithSignatureV2(alice, withdrawAmount, mktId1, 0, 1, deadline, trackingHead + 1, sig);
    }

    /// @notice Test withdraw fails with insufficient isolated margin
    function test_WithdrawV2_FailsWithInsufficientIsolatedMargin() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 100e6;
        uint256 withdrawAmount = 200e6;

        _depositV2(aliceKey, depositAmount, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signWithdrawV2(aliceKey, withdrawAmount, mktId1, ORDER_FLAG_ISOLATED, 2, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin
        helloVault.withdrawWithSignatureV2(
            alice, withdrawAmount, mktId1, ORDER_FLAG_ISOLATED, 2, deadline, trackingHead + 1, sig
        );
    }

    /// @notice Test withdraw fails with expired deadline
    function test_WithdrawV2_FailsWithExpiredDeadline() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);

        uint256 expiredDeadline = block.timestamp - 1;
        bytes memory sig = _signWithdrawV2(aliceKey, 500e6, mktId1, 0, 1, expiredDeadline);

        vm.startPrank(relayer);
        vm.expectRevert(DeadlineExpired.selector);
        helloVault.withdrawWithSignatureV2(alice, 500e6, mktId1, 0, 1, expiredDeadline, trackingHead + 1, sig);
    }

    // ============================================================================
    // UPDATE LEVERAGE V2 TESTS
    // ============================================================================

    /// @notice Test update leverage for cross margin position (flags=0)
    function test_UpdateLeverageV2_CrossMargin() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);

        uint32 newLeverage = 500; // 5x

        _updateLeverageV2(aliceKey, mktId1, newLeverage, 0, 1, trackingHead + 1);

        assertEq(
            helloVault.getPosition(alice, mktId1, false).leverage,
            newLeverage,
            "Cross position leverage should be updated"
        );
    }

    /// @notice Test update leverage for isolated margin position (flags=ORDER_FLAG_ISOLATED)
    function test_UpdateLeverageV2_IsolatedMargin() public {
        uint256 trackingHead = _useTrackingHead();

        _depositV2(aliceKey, 1000e6, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        uint32 newLeverage = 500; // 5x

        _updateLeverageV2(aliceKey, mktId1, newLeverage, ORDER_FLAG_ISOLATED, 2, trackingHead + 1);

        assertEq(
            helloVault.getIsoPosition(alice, mktId1).leverage,
            newLeverage,
            "Isolated position leverage should be updated"
        );
    }

    /// @notice Test update leverage fails with leverage over max
    function test_UpdateLeverageV2_FailsWithLeverageOverMax() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);

        uint32 invalidLeverage = 20000; // 200x (over max of 100x)
        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signLeverageUpdateV2(aliceKey, mktId1, invalidLeverage, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(abi.encodeWithSelector(LeverageOverMax.selector, invalidLeverage, maxLeverage));
        helloVault.updateLeverageWithSignatureV2(alice, mktId1, invalidLeverage, 0, 1, deadline, trackingHead + 1, sig);
    }

    /// @notice Test update leverage fails with zero leverage
    function test_UpdateLeverageV2_FailsWithZeroLeverage() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 1000e6, trackingHead);

        uint32 invalidLeverage = 0;
        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signLeverageUpdateV2(aliceKey, mktId1, invalidLeverage, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(LeverageZero.selector);
        helloVault.updateLeverageWithSignatureV2(alice, mktId1, invalidLeverage, 0, 1, deadline, trackingHead + 1, sig);
    }

    // ============================================================================
    // TRANSFER MARGIN TESTS
    // ============================================================================

    /// @notice Test transfer margin from cross to isolated (flags=0)
    function test_TransferMargin_CrossToIsolated() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 1000e6;
        uint256 transferAmount = 500e6;

        _depositFor(aliceKey, depositAmount, trackingHead);

        int256 crossBefore = helloVault.getMargin(alice);
        uint256 isoBefore = helloVault.getIsoMargin(alice, mktId1);

        _transferMargin(aliceKey, transferAmount, mktId1, 0, 1, trackingHead + 1);

        assertEq(helloVault.getMargin(alice), crossBefore - transferAmount.toInt256(), "Cross margin should decrease");
        assertEq(helloVault.getIsoMargin(alice, mktId1), isoBefore + transferAmount, "Isolated margin should increase");
    }

    /// @notice Test transfer margin from isolated to cross (flags=ORDER_FLAG_ISOLATED)
    function test_TransferMargin_IsolatedToCross() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 depositAmount = 1000e6;
        uint256 transferAmount = 500e6;

        _depositV2(aliceKey, depositAmount, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        int256 crossBefore = helloVault.getMargin(alice);
        uint256 isoBefore = helloVault.getIsoMargin(alice, mktId1);

        _transferMargin(aliceKey, transferAmount, mktId1, ORDER_FLAG_ISOLATED, 2, trackingHead + 1);

        assertEq(helloVault.getMargin(alice), crossBefore + transferAmount.toInt256(), "Cross margin should increase");
        assertEq(helloVault.getIsoMargin(alice, mktId1), isoBefore - transferAmount, "Isolated margin should decrease");
    }

    /// @notice Test transfer margin fails with insufficient cross margin
    function test_TransferMargin_FailsWithInsufficientCrossMargin() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 100e6, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, 200e6, mktId1, 0, 1, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin
        helloVault.transferMarginWithSignature(alice, 200e6, mktId1, 0, 1, deadline, trackingHead + 1, sig);
    }

    /// @notice Test transfer margin fails with insufficient isolated margin
    function test_TransferMargin_FailsWithInsufficientIsolatedMargin() public {
        uint256 trackingHead = _useTrackingHead();

        _depositV2(aliceKey, 100e6, mktId1, ORDER_FLAG_ISOLATED, 1, trackingHead);

        uint256 deadline = block.timestamp + 1 hours;
        bytes memory sig = _signTransferMargin(aliceKey, 200e6, mktId1, ORDER_FLAG_ISOLATED, 2, deadline);

        vm.startPrank(relayer);
        vm.expectRevert(); // InsufficientMargin
        helloVault.transferMarginWithSignature(
            alice, 200e6, mktId1, ORDER_FLAG_ISOLATED, 2, deadline, trackingHead + 1, sig
        );
    }

    // ============================================================================
    // HELPER FUNCTIONS
    // ============================================================================

    function _depositV2(
        uint256 userKey,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256, // nonce - unused, permit nonce is managed by token
        uint256 trackingHead
    ) internal {
        address user = vm.addr(userKey);
        uint256 deadline = block.timestamp + 1 hours;

        // Sign permit for USDC token
        bytes memory sig = signPermit(userKey, address(usdcMock), address(helloVault), amount, deadline);

        vm.startPrank(relayer);
        helloVault.depositWithSignatureV2(user, amount, market, flags, deadline, trackingHead, sig);
    }

    function _withdrawV2(
        uint256 userKey,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 trackingHead
    ) internal {
        address user = vm.addr(userKey);
        uint256 deadline = block.timestamp + 1 hours;

        bytes memory sig = _signWithdrawV2(userKey, amount, market, flags, nonce, deadline);

        vm.startPrank(relayer);
        helloVault.withdrawWithSignatureV2(user, amount, market, flags, nonce, deadline, trackingHead, sig);
    }

    function _updateLeverageV2(
        uint256 userKey,
        uint32 market,
        uint32 leverage,
        uint256 flags,
        uint256 nonce,
        uint256 trackingHead
    ) internal {
        address user = vm.addr(userKey);
        uint256 deadline = block.timestamp + 1 hours;

        bytes memory sig = _signLeverageUpdateV2(userKey, market, leverage, flags, nonce, deadline);

        vm.startPrank(relayer);
        helloVault.updateLeverageWithSignatureV2(user, market, leverage, flags, nonce, deadline, trackingHead, sig);
    }

    function _transferMargin(
        uint256 userKey,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 trackingHead
    ) internal {
        address user = vm.addr(userKey);
        uint256 deadline = block.timestamp + 1 hours;

        bytes memory sig = _signTransferMargin(userKey, amount, market, flags, nonce, deadline);

        vm.startPrank(relayer);
        helloVault.transferMarginWithSignature(user, amount, market, flags, nonce, deadline, trackingHead, sig);
    }

    function _signWithdrawV2(
        uint256 signerKey,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 deadline
    ) internal view returns (bytes memory) {
        address signer = vm.addr(signerKey);
        bytes32 structHash = SignerUtils._buildWithdrawV2Hash(signer, amount, market, flags, nonce, deadline);
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", vaultDomainSep, structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }

    function _signLeverageUpdateV2(
        uint256 signerKey,
        uint32 market,
        uint32 leverage,
        uint256 flags,
        uint256 nonce,
        uint256 deadline
    ) internal view returns (bytes memory) {
        address signer = vm.addr(signerKey);
        bytes32 structHash = SignerUtils._buildLeverageUpdateV2Hash(signer, market, leverage, flags, nonce, deadline);
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", vaultDomainSep, structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }

    function _signTransferMargin(
        uint256 signerKey,
        uint256 amount,
        uint32 market,
        uint256 flags,
        uint256 nonce,
        uint256 deadline
    ) internal view returns (bytes memory) {
        address signer = vm.addr(signerKey);
        bytes32 structHash = SignerUtils._buildTransferMarginHash(signer, amount, market, flags, nonce, deadline);
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", vaultDomainSep, structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }
}

