// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Math} from "src/lib/Math.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {IHelloVaultEvents} from "src/interfaces/IHelloVaultEvents.sol";
import {InsufficientMargin} from "src/lib/PositionMetrics.sol";
import {GlobalState} from "src/HelloVaultV1_6.sol";

contract HeartbeatTest is Test, VaultTestHelpers, IHelloVaultErrors, IHelloVaultEvents {
    using Math for int256;

    uint256 constant HEARTBEAT_PERIOD = 60 * 60 * 24 * 7; // One week

    function setUp() public override {
        super.setUp();
    }

    function test_Heartbeat_ReturnsTrueWhenFresh() public view {
        // Heartbeat is updated in setUp via updateFundingInstant
        bool result = helloVault.heartbeat();
        assertTrue(result, "Heartbeat should be fresh immediately after setup");
    }

    function test_Heartbeat_ReturnsTrueJustBeforeExpiry() public {
        // Warp to just before the heartbeat period expires
        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD - 1);

        bool result = helloVault.heartbeat();
        assertTrue(result, "Heartbeat should still be fresh just before expiry");
    }

    function test_Heartbeat_ReturnsFalseWhenExpired() public {
        // Warp past the heartbeat period
        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD);

        bool result = helloVault.heartbeat();
        assertFalse(result, "Heartbeat should be expired after period");
    }

    function test_Heartbeat_UpdatesOnRelayerAction() public {
        // Warp to just before expiry
        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD - 100);
        assertTrue(helloVault.heartbeat());

        // Relayer performs an action that updates heartbeat (setTrackingHead)
        helloVault.setTrackingHead(helloVault.trackingHead() + 1);

        // Warp another period - 50 seconds (total would be 2*period - 150 from original)
        // But heartbeat was just updated, so only period - 50 has passed since last update
        vm.warp(block.timestamp + HEARTBEAT_PERIOD - 50);
        assertTrue(helloVault.heartbeat(), "Heartbeat should still be fresh after relayer action");
    }

    function test_EmergencyWithdraw_RevertsWhenHeartbeatNotExpired() public {
        // Deposit funds for alice
        _depositFor(aliceKey, 100e6, _useTrackingHead());

        // Emergency withdraw should revert when heartbeat is not expired
        vm.expectRevert(HeartbeatNotExpired.selector);
        helloVault.emergencyWithdrawCross();

        // Emergency withdraw should revert at boundary
        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD - 1);
        vm.expectRevert(HeartbeatNotExpired.selector);
        helloVault.emergencyWithdrawCross();
    }

    function test_EmergencyWithdraw_SetsBreakGlass() public {
        // Deposit funds for alice
        _depositFor(aliceKey, 100e6, _useTrackingHead());

        GlobalState memory state = helloVault.globalState();
        // Warp past heartbeat period
        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD);

        // Emergency withdraw
        vm.startPrank(alice);
        helloVault.emergencyWithdrawCross();

        state = helloVault.globalState();
        assertTrue(state.breakGlass, "breakGlass should be set");

        // Verify breakGlass is set (subsequent relayer actions should fail)
        vm.startPrank(relayer);
        vm.expectRevert(BreakGlass.selector);
        helloVault.setTrackingHead(42069);
    }

    function test_EmergencyWithdraw_RevertsOnNegativeMargin() public {
        vm.skip(true);

        // TODO: DebugSetMargin was removed, so this test must be validated a different way.
        // Alice has no margin deposited, margin is 0

        vm.startPrank(admin);
        // helloVault.debugSetMargin(alice, -100e6);

        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD);

        // Emergency withdraw should revert for negative margin
        vm.startPrank(alice);
        vm.expectRevert(abi.encodeWithSelector(InsufficientMargin.selector, -100e6, 0));
        helloVault.emergencyWithdrawCross();
    }

    function test_EmergencyWithdraw_RevertsWithZeroMargin() public {
        // Alice has no margin deposited (margin is 0)
        assertEq(helloVault.getMargin(alice), 0);

        uint256 balanceBefore = usdcMock.balanceOf(alice);

        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD);

        // Emergency withdraw with zero margin should revert
        vm.startPrank(alice);
        vm.expectRevert(abi.encodeWithSelector(InsufficientMargin.selector, 0, 0));
        helloVault.emergencyWithdrawCross();
    }

    function test_EmergencyWithdraw_MultipleUsersCanWithdraw() public {
        // Deposit funds for alice and bob
        _depositFor(aliceKey, 100e6, _useTrackingHead());
        _depositFor(bobKey, 200e6, _useTrackingHead());

        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD);

        // Alice withdraws first (this sets breakGlass)
        vm.startPrank(alice);
        helloVault.emergencyWithdrawCross();

        // Bob can still withdraw even after breakGlass is set
        // (emergencyWithdraw doesn't check breakGlass modifier)
        vm.startPrank(bob);
        helloVault.emergencyWithdrawCross();

        // Verify both have withdrawn
        assertEq(helloVault.getMargin(alice), 0);
        assertEq(helloVault.getMargin(bob), 0);
    }

    function test_EmergencyWithdraw_BreakGlassBlocksRelayerFunctions() public {
        _depositFor(aliceKey, 100e6, _useTrackingHead());

        vm.warp(vm.getBlockTimestamp() + HEARTBEAT_PERIOD);

        // Emergency withdraw (sets breakGlass)
        vm.startPrank(alice);
        helloVault.emergencyWithdrawCross();

        // All relayer functions with notBreakGlass modifier should revert
        vm.startPrank(relayer);

        // setTrackingHead
        vm.expectRevert(BreakGlass.selector);
        helloVault.setTrackingHead(1);

        // updateFundingInstant
        vm.expectRevert(BreakGlass.selector);
        helloVault.updateFundingInstant(mktId1, 0, 1e18, 1);

        // depositWithSignature
        bytes memory sig =
            signPermit(bobKey, address(usdcMock), address(helloVault), 100e6, vm.getBlockTimestamp() + 1 hours);
        vm.expectRevert(BreakGlass.selector);
        helloVault.depositWithSignature(bob, 100e6, vm.getBlockTimestamp() + 1 hours, 1, sig);
    }
}

