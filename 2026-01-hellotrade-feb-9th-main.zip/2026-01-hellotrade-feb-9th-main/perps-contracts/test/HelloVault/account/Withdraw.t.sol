// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Order} from "src/lib/Order.sol";
import {Math} from "src/lib/Math.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";
import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";
import {InsufficientMargin} from "src/lib/PositionMetrics.sol";

contract WithdrawTest is Test, VaultTestHelpers, IHelloVaultErrors {
    bytes32 vaultDomainSep;

    using Math for uint256;
    using Math for int256;

    Order aliceLong;
    bytes aliceLongSig;

    Order bobShort;
    bytes bobShortSig;

    Order aliceClose;
    bytes aliceCloseSig;

    Order bobClose;
    bytes bobCloseSig;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();

        // Initialize orders for position tests
        aliceLong = Order({account: alice, market: mktId1, size: 10e2, limitPrice: 1e18, nonce: 1});
        aliceLongSig = signOrder(aliceKey, aliceLong);

        bobShort = Order({account: bob, market: mktId1, size: -10e2, limitPrice: 0, nonce: 1});
        bobShortSig = signOrder(bobKey, bobShort);

        // Close orders at 2e18 price
        aliceClose = Order({account: alice, market: mktId1, size: -10e2, limitPrice: 2e18, nonce: 2});
        aliceCloseSig = signOrder(aliceKey, aliceClose);

        bobClose = Order({account: bob, market: mktId1, size: 10e2, limitPrice: type(uint256).max, nonce: 2});
        bobCloseSig = signOrder(bobKey, bobClose);
    }

    // ============================================================================
    // WITHDRAWAL TESTS - NO POSITION
    // ============================================================================

    function test_UserCanWithdrawFreeMargin() public {
        _assertMarginUnchanged(alice, 0);
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 100e6, trackingHead);
        _assertMarginChange(alice, 0, 100e6);

        int256 freeMargin = helloVault.getFreeMargin(alice);
        assertEq(freeMargin, 100e6);

        bytes memory wsig = signWithdraw(aliceKey, 100e6, 1, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
        helloVault.withdrawWithSignature(alice, 100e6, 1, vm.getBlockTimestamp() + 1 hours, trackingHead + 1, wsig);

        _assertMarginChange(alice, 100e6, -100e6);
    }

    // function test_UserCannotWithdrawMoreThanDepositWithZeroPosition() public {
    //     uint256 trackingHead = _useTrackingHead();

    //     _depositFor(aliceKey, 100e6, trackingHead);

    //     bytes memory wsig = signWithdraw(aliceKey, 101e6, 1, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
    //     vm.expectRevert(abi.encodeWithSelector(InsufficientMargin.selector, -1, 0));
    //     helloVault.withdrawWithSignature(alice, 101e6, 1, vm.getBlockTimestamp() + 1 hours, trackingHead + 1, wsig);
    // }

    function test_UserCannotWithdrawZeroAmount() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 100e6, trackingHead);

        bytes memory wsig = signWithdraw(aliceKey, 0, 1, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
        vm.expectRevert(abi.encodeWithSelector(AmountZero.selector));
        helloVault.withdrawWithSignature(alice, 0, 1, vm.getBlockTimestamp() + 1 hours, trackingHead + 1, wsig);
    }

    function test_UserCannotWithdrawWithExpiredDeadline() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 100e6, trackingHead);

        // Sign with a deadline in the past
        uint256 expiredDeadline = vm.getBlockTimestamp() - 1;
        bytes memory wsig = signWithdraw(aliceKey, 50e6, 1, expiredDeadline, vaultDomainSep);

        vm.expectRevert(abi.encodeWithSelector(DeadlineExpired.selector));
        helloVault.withdrawWithSignature(alice, 50e6, 1, expiredDeadline, trackingHead + 1, wsig);
    }

    function test_UserCannotWithdrawWithInvalidSigner() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 100e6, trackingHead);

        // Bob signs a withdrawal for Alice's account (should fail)
        bytes memory wsig = signWithdraw(bobKey, 50e6, 1, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);

        vm.expectPartialRevert(InvalidSigner.selector);
        helloVault.withdrawWithSignature(alice, 50e6, 1, vm.getBlockTimestamp() + 1 hours, trackingHead + 1, wsig);
    }

    function test_UserCannotReuseNonce() public {
        uint256 trackingHead = _useTrackingHead();

        _depositFor(aliceKey, 100e6, trackingHead);

        // First withdraw should succeed
        bytes memory wsig = signWithdraw(aliceKey, 100e6, 1, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
        helloVault.withdrawWithSignature(alice, 100e6, 1, vm.getBlockTimestamp() + 1 hours, trackingHead + 1, wsig);

        // Try to reuse nonce, withdraw should revert
        bytes memory wsig2 = signWithdraw(aliceKey, 100e6, 1, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
        vm.expectRevert(abi.encodeWithSelector(NonceUsed.selector, 1));
        helloVault.withdrawWithSignature(alice, 100e6, 1, vm.getBlockTimestamp() + 1 hours, trackingHead + 2, wsig2);
    }

    // ============================================================================
    // WITHDRAWAL TESTS - WITH POSITION PNL
    // ============================================================================

    function test_PnlCreditsWithdraw() public {
        uint256 trackingHead = _useTrackingHead();
        _fundVault(20e6); // Fund an extra 20 for balance testing

        // Alice deposits $100
        _depositFor(aliceKey, 100e6, trackingHead);
        // Bob deposits $100 to act as counterparty
        _depositFor(bobKey, 100e6, trackingHead + 1);

        // Open position: Alice goes long 10.00 @ 1.0, Bob is the counterparty (short)
        _fillMatchedOrder(aliceLong, aliceLongSig, bobShort, bobShortSig, 10e2, trackingHead + 2);

        // Close position: Alice closes at 2.0 for profit
        // PnL = (2.0 - 1.0) * 10.00 = 10.00 USDC
        _fillMatchedOrder(aliceClose, aliceCloseSig, bobClose, bobCloseSig, 10e2, trackingHead + 3);

        // Alice should be able to withdraw $110 (original $100 + $10 profit, minus fees)
        vm.startPrank(relayer);
        bytes memory wsig = signWithdraw(aliceKey, 110e6, 3, block.timestamp + 1 hours, vaultDomainSep);
        helloVault.withdrawWithSignature(alice, 110e6, 3, block.timestamp + 1 hours, trackingHead + 4, wsig);
    }

    function test_UserCannotWithdrawMoreThanEquity() public {
        uint256 trackingHead = _useTrackingHead();
        _fundVault(20e6); // Fund an extra 20 for balance testing

        // Alice deposits $100
        _depositFor(aliceKey, 100e6, trackingHead);
        // Bob deposits $100 to act as counterparty
        _depositFor(bobKey, 100e6, trackingHead + 1);

        // Open position: Alice goes long 10.00 @ 1.0
        _fillMatchedOrder(aliceLong, aliceLongSig, bobShort, bobShortSig, 10e2, trackingHead + 2);

        // Close position: Alice closes at 2.0 for profit
        _fillMatchedOrder(aliceClose, aliceCloseSig, bobClose, bobCloseSig, 10e2, trackingHead + 3);

        // Try to withdraw more than equity ($111 when equity should be ~$110), should revert
        vm.startPrank(relayer);
        bytes memory wsig = signWithdraw(aliceKey, 111e6, 3, vm.getBlockTimestamp() + 1 hours, vaultDomainSep);
        vm.expectRevert(abi.encodeWithSelector(InsufficientMargin.selector, 110e6, 0));
        helloVault.withdrawWithSignature(alice, 111e6, 3, vm.getBlockTimestamp() + 1 hours, trackingHead + 4, wsig);
    }
}
