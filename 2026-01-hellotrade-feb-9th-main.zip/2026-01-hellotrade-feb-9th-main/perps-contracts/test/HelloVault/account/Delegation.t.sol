// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

import {MessageHashUtils} from "@openzeppelin-contracts/utils/cryptography/MessageHashUtils.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

import {Order} from "src/lib/Order.sol";
import {SignerUtils} from "src/lib/SignerUtils.sol";

import {IHelloVaultErrors} from "src/interfaces/IHelloVaultErrors.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";

contract DelegationTest is Test, VaultTestHelpers, IHelloVaultErrors {
    bytes32 vaultDomainSep;

    function setUp() public override {
        super.setUp();
        vm.startPrank(relayer);
        vaultDomainSep = helloVault.domainSeparatorV4();

        // Deposit for Alice so she can trade
        _depositFor(aliceKey, 100_000 * 1e6, _useTrackingHead());
        // Deposit for Bob as counterparty
        _depositFor(bobKey, 100_000 * 1e6, _useTrackingHead());
    }

    //
    // Helper functions
    //

    function signSetDelegator(
        uint256 signerKey,
        address account,
        address delegator,
        uint256 until,
        uint256 nonce,
        uint256 deadline
    ) internal view returns (bytes memory) {
        bytes32 structHash = SignerUtils._buildSetDelegatorHash(account, delegator, until, nonce, deadline);
        bytes32 digest = MessageHashUtils.toTypedDataHash(vaultDomainSep, structHash);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerKey, digest);
        return abi.encodePacked(r, s, v);
    }

    // ============================================================================
    // SET DELEGATOR TESTS
    // ============================================================================

    function test_SetDelegator() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 nonce = 1;
        uint256 deadline = vm.getBlockTimestamp() + 1 hours;
        uint256 until = vm.getBlockTimestamp() + 1 days;

        // Alice delegates to Charlie
        bytes memory sig = signSetDelegator(aliceKey, alice, charlie, until, nonce, deadline);

        helloVault.setDelegatorWithSignature(alice, charlie, until, nonce, deadline, trackingHead, sig);

        // Check delegation was set
        assertEq(helloVault.getDelegatorExpiry(alice, charlie), until);
        // Check nonce was burned
        assertTrue(helloVault.nonceUsed(alice, nonce));
    }

    function test_SetDelegatorEmitsEvent() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 nonce = 1;
        uint256 deadline = vm.getBlockTimestamp() + 1 hours;
        uint256 until = vm.getBlockTimestamp() + 1 days;

        bytes memory sig = signSetDelegator(aliceKey, alice, charlie, until, nonce, deadline);

        vm.expectEmit(true, true, false, true);
        emit DelegatorSet(alice, charlie, until);

        helloVault.setDelegatorWithSignature(alice, charlie, until, nonce, deadline, trackingHead, sig);
    }

    function test_SetDelegatorFailsWithWrongSigner() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 nonce = 1;
        uint256 deadline = vm.getBlockTimestamp() + 1 hours;
        uint256 until = vm.getBlockTimestamp() + 1 days;

        // Bob signs for Alice (should fail)
        bytes memory sig = signSetDelegator(bobKey, alice, charlie, until, nonce, deadline);

        vm.expectPartialRevert(InvalidSigner.selector);
        helloVault.setDelegatorWithSignature(alice, charlie, until, nonce, deadline, trackingHead, sig);
    }

    function test_SetDelegatorFailsWithUsedNonce() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 nonce = 1;
        uint256 deadline = vm.getBlockTimestamp() + 1 hours;
        uint256 until = vm.getBlockTimestamp() + 1 days;

        bytes memory sig = signSetDelegator(aliceKey, alice, charlie, until, nonce, deadline);

        // First call succeeds
        helloVault.setDelegatorWithSignature(alice, charlie, until, nonce, deadline, trackingHead, sig);

        // Second call with same nonce fails
        vm.expectRevert(NonceUsed.selector);
        helloVault.setDelegatorWithSignature(alice, charlie, until, nonce, deadline, trackingHead + 1, sig);
    }

    function test_DelegatorCanSignOrders() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 until = vm.getBlockTimestamp() + 1 days;

        // Alice delegates to Charlie
        bytes memory delegateSig =
            signSetDelegator(aliceKey, alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours);

        helloVault.setDelegatorWithSignature(
            alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours, trackingHead, delegateSig
        );

        // Charlie signs an order for Alice
        Order memory aliceOrder = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 2});

        // Sign with Charlie's key but for Alice's account
        bytes32 structHash = aliceOrder.digest();
        bytes32 digest = MessageHashUtils.toTypedDataHash(vaultDomainSep, structHash);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(charlieKey, digest);
        bytes memory aliceOrderSig = abi.encodePacked(r, s, v);

        // Bob as counterparty
        Order memory bobOrder = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 1});
        bytes memory bobOrderSig = signOrder(bobKey, bobOrder);

        // Fill should succeed with Charlie signing for Alice
        _fillMatchedOrder(aliceOrder, aliceOrderSig, bobOrder, bobOrderSig, 10_000, _useTrackingHead());

        // Verify Alice has the position
        assertEq(helloVault.getPosition(alice, mktId1, false).size, 10_000);
    }

    // function test_DelegationExpiresAfterTimestamp() public {
    //     uint256 trackingHead = _useTrackingHead();
    //     uint256 until = vm.getBlockTimestamp() + 1 hours;

    //     // Alice delegates to Charlie for 1 hour
    //     bytes memory delegateSig =
    //         signSetDelegator(aliceKey, alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours);

    //     helloVault.setDelegatorWithSignature(
    //         alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours, trackingHead, delegateSig
    //     );

    //     // Warp past expiration
    //     vm.warp(until + 1);

    //     // Charlie signs an order for Alice
    //     Order memory aliceOrder = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 2});

    //     bytes32 structHash = aliceOrder.digest();
    //     bytes32 digest = MessageHashUtils.toTypedDataHash(vaultDomainSep, structHash);
    //     (uint8 v, bytes32 r, bytes32 s) = vm.sign(charlieKey, digest);
    //     bytes memory aliceOrderSig = abi.encodePacked(r, s, v);

    //     Order memory bobOrder = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 1});
    //     bytes memory bobOrderSig = signOrder(bobKey, bobOrder);

    //     // Fill should fail because delegation expired
    //     vm.expectPartialRevert(InvalidSigner.selector);
    //     _fillMatchedOrder(aliceOrder, aliceOrderSig, bobOrder, bobOrderSig, 10_000, _useTrackingHead());
    // }

    function test_NonDelegatedSignerCannotSign() public {
        // Charlie tries to sign for Alice without delegation
        Order memory aliceOrder = Order({account: alice, market: mktId1, size: 10_000, limitPrice: 1e18, nonce: 1});
        uint256 trackingHead = _useTrackingHead();

        bytes32 structHash = aliceOrder.digest();
        bytes32 digest = MessageHashUtils.toTypedDataHash(vaultDomainSep, structHash);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(charlieKey, digest);
        bytes memory aliceOrderSig = abi.encodePacked(r, s, v);

        Order memory bobOrder = Order({account: bob, market: mktId1, size: -10_000, limitPrice: 0, nonce: 1});
        bytes memory bobOrderSig = signOrder(bobKey, bobOrder);

        // Create prices before expectRevert
        StorkStructs.TemporalNumericValueInput[] memory prices = toArray(_createPriceInputWithPrice(mktId1, 1e18));

        // Fill should fail
        vm.expectPartialRevert(InvalidSigner.selector);
        _fillMatchedOrder(prices, aliceOrder, aliceOrderSig, bobOrder, bobOrderSig, 10_000, trackingHead);
    }

    function test_CanRevokeDelegation() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 until = vm.getBlockTimestamp() + 1 days;

        // Alice delegates to Charlie
        bytes memory delegateSig =
            signSetDelegator(aliceKey, alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours);

        helloVault.setDelegatorWithSignature(
            alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours, trackingHead, delegateSig
        );

        // Verify delegation is active
        assertEq(helloVault.getDelegatorExpiry(alice, charlie), until);

        // Alice revokes by setting until to 0 (or past timestamp)
        bytes memory revokeSig = signSetDelegator(
            aliceKey,
            alice,
            charlie,
            0, // Set to 0 to revoke
            2,
            vm.getBlockTimestamp() + 1 hours
        );

        helloVault.setDelegatorWithSignature(
            alice, charlie, 0, 2, vm.getBlockTimestamp() + 1 hours, _useTrackingHead(), revokeSig
        );

        // Verify delegation is revoked
        assertEq(helloVault.getDelegatorExpiry(alice, charlie), 0);
    }

    function test_MultipleDelegators() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 until = vm.getBlockTimestamp() + 1 days;

        // Alice delegates to Charlie
        bytes memory delegateSig1 =
            signSetDelegator(aliceKey, alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours);

        helloVault.setDelegatorWithSignature(
            alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours, trackingHead, delegateSig1
        );

        // Alice also delegates to Bob
        bytes memory delegateSig2 = signSetDelegator(aliceKey, alice, bob, until, 2, vm.getBlockTimestamp() + 1 hours);

        helloVault.setDelegatorWithSignature(
            alice, bob, until, 2, vm.getBlockTimestamp() + 1 hours, _useTrackingHead(), delegateSig2
        );

        // Both delegations should be active
        assertEq(helloVault.getDelegatorExpiry(alice, charlie), until);
        assertEq(helloVault.getDelegatorExpiry(alice, bob), until);
    }

    function test_DelegatorCannotExtendOwnDelegation() public {
        uint256 trackingHead = _useTrackingHead();
        uint256 until = vm.getBlockTimestamp() + 1 days;

        // Alice delegates to Charlie
        bytes memory delegateSig =
            signSetDelegator(aliceKey, alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours);

        helloVault.setDelegatorWithSignature(
            alice, charlie, until, 1, vm.getBlockTimestamp() + 1 hours, trackingHead, delegateSig
        );

        // Verify delegation is active
        assertEq(helloVault.getDelegatorExpiry(alice, charlie), until);

        // Charlie tries to extend their own delegation by signing as delegator
        uint256 extendedUntil = vm.getBlockTimestamp() + 30 days;
        bytes memory extendSig =
            signSetDelegator(charlieKey, alice, charlie, extendedUntil, 2, vm.getBlockTimestamp() + 1 hours);

        // Should fail - delegators cannot modify delegation settings
        vm.expectPartialRevert(InvalidSigner.selector);
        helloVault.setDelegatorWithSignature(
            alice, charlie, extendedUntil, 2, vm.getBlockTimestamp() + 1 hours, trackingHead + 1, extendSig
        );

        // Verify delegation was not extended
        assertEq(helloVault.getDelegatorExpiry(alice, charlie), until);
    }

    // Event declaration for testing
    event DelegatorSet(address indexed account, address indexed delegator, uint256 until);
}
