// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {HelloVaultV1_6} from "src/HelloVaultV1_6.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {Order} from "src/lib/Order.sol";

import {UsdcMock} from "src/mocks/UsdcMock.sol";

import {VaultSignerUtils} from "test/utils/SignerUtils.sol";
import {StorkMockWithTestHelpers} from "test/mocks/StorkMockTest.sol";

import {Test} from "forge-std/Test.sol";
import {StdCheatsSafe} from "forge-std/StdCheats.sol";

abstract contract VaultFixture is StdCheatsSafe, Test, VaultSignerUtils {
    // Users
    uint256 adminKey;
    address admin;

    uint256 relayerKey;
    address relayer;

    uint256 aliceKey;
    address alice;

    uint256 bobKey;
    address bob;

    uint256 charlieKey;
    address charlie;

    uint256 feeRecipientKey;
    address feeRecipient;

    uint256 storkKey;

    // External contracts
    UsdcMock usdcMock;
    StorkMockWithTestHelpers storkMock;

    // Core contracts
    HelloVaultV1_6 helloVault;

    // Market fixtures
    uint32 mktId1 = uint32(1);
    bytes32 storkInstId1 = bytes32(uint256(mktId1));
    uint32 mktId2 = uint32(2);
    bytes32 storkInstId2 = bytes32(uint256(mktId2));

    uint16 maxLeverage = 10000; // 100x
    uint8 pricePrecision = 18;
    uint8 basePrecision = 2;
    uint8 quotePrecision = 6;
    uint16 defaultLeverage = 100;

    int256 constant FUNDING_RATE_IDX0 = 10_000_000;
    int256 constant FUNDING_PRICE_IDX0 = 1e18;

    function setUp() public virtual {
        (admin, adminKey) = makeAddrAndKey("ADMIN");
        (relayer, relayerKey) = makeAddrAndKey("RELAYER");
        (alice, aliceKey) = makeAddrAndKey("ALICE");
        (bob, bobKey) = makeAddrAndKey("BOB");
        (charlie, charlieKey) = makeAddrAndKey("CHARLIE");
        (, storkKey) = makeAddrAndKey("STORK");
        (feeRecipient, feeRecipientKey) = makeAddrAndKey("FEE_RECIPIENT");

        vm.chainId(6342);

        vm.startPrank(admin);

        // Deployments
        usdcMock = new UsdcMock();
        storkMock = new StorkMockWithTestHelpers();
        helloVault = new HelloVaultV1_6();

        // Seed accounts with USDC
        usdcMock.mint(alice, 1_000_000e6);
        usdcMock.mint(bob, 1_000_000e6);
        usdcMock.mint(charlie, 1_000_000e6);
        usdcMock.mint(relayer, 1_000_000e6);

        // Initialize market params
        helloVault.initialize(admin, relayer, address(usdcMock), address(storkMock));

        helloVault.setMarketConfig(
            mktId1,
            MarketConfig({
                maxLeverage: maxLeverage,
                defaultLeverage: defaultLeverage,
                pricePrecision: pricePrecision,
                basePrecision: basePrecision,
                quotePrecision: quotePrecision,
                fundingMax: 100_000_000,
                fundingMin: -100_000_000,
                minFundingInterval: 1
            })
        );

        // Fees are set in another test
        helloVault.setFeeRecipient(feeRecipient);

        helloVault.setMarketStorkId(mktId1, storkInstId1);
        helloVault.setMarketHelloStorkId(mktId1, storkInstId1);

        // Create oracle price values
        storkMock.initializeWithKey(30, 0, storkKey);
        // Stork fallback price
        storkMock.setStorkPrice(storkInstId1, int192(1e18));

        // TODO: This should move elsewhere.
        // Funding instant at 1e18 mark price, .1% (.1% of 10B)
        // vm.startPrank(relayer);
        // helloVault.updateFundingInstant(mktId1, FUNDING_RATE_IDX0, FUNDING_PRICE_IDX0, 0);
    }

    function signOrder(uint256 signer, Order memory order) public view returns (bytes memory signature) {
        bytes32 structHash = order.digest();

        bytes32 eip712Digest = vaultHashTypedDataV4(address(helloVault), structHash);

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signer, eip712Digest);
        signature = abi.encodePacked(r, s, v);
    }

    function _fundVault(uint256 amount) internal {
        vm.startPrank(relayer);
        usdcMock.transfer(address(helloVault), amount);
    }
}
