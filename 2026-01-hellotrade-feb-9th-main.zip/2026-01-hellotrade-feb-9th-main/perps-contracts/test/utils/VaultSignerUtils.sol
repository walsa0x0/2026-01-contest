// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";

import {MessageHashUtils} from "@openzeppelin-contracts/utils/cryptography/MessageHashUtils.sol";

contract VaultSignerUtils is Test {
    bytes32 private constant TYPE_HASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");

    function _getHelloVaultDomainSep(address addr) public view returns (bytes32) {
        return
            keccak256(abi.encode(TYPE_HASH, keccak256(bytes("HelloVault")), keccak256(bytes("1")), block.chainid, addr));
    }

    function vaultHashTypedDataV4(address addr, bytes32 structHash) internal view returns (bytes32) {
        return MessageHashUtils.toTypedDataHash(_getHelloVaultDomainSep(addr), structHash);
    }
}
