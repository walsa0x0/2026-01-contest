// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {MessageHashUtils} from "@openzeppelin-contracts/utils/cryptography/MessageHashUtils.sol";
import {IUsdcMock} from "src/mocks/interface/IUsdcMock.sol";

contract UsdcPermitSignerUtils is Test {
    bytes32 private constant TYPE_HASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");

    bytes32 private constant PERMIT_TYPEHASH =
        keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)");

    function signPermit(uint256 signer, address token, address spender, uint256 value, uint256 deadline)
        public
        view
        returns (bytes memory)
    {
        address signerAddress = vm.addr(signer);
        uint256 nonce = IUsdcMock(token).nonces(signerAddress);
        bytes32 permitHash = keccak256(abi.encode(PERMIT_TYPEHASH, signerAddress, spender, value, nonce, deadline));

        bytes32 digest = IUsdcMock(token).hashTypedDataV4(permitHash);

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signer, digest);
        return abi.encodePacked(r, s, v);
    }
}

contract VaultSignerUtils is Test {
    bytes32 private constant TYPE_HASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");

    bytes32 constant WITHDRAW_TYPEHASH =
        keccak256("Withdraw(address account,uint256 amount,uint256 nonce,uint256 deadline)");

    function signWithdraw(uint256 signer, uint256 amount, uint256 nonce, uint256 deadline, bytes32 domainSep)
        public
        pure
        returns (bytes memory)
    {
        address owner = vm.addr(signer);
        bytes32 withdrawHash = keccak256(abi.encode(WITHDRAW_TYPEHASH, owner, amount, nonce, deadline));
        bytes32 digest = MessageHashUtils.toTypedDataHash(domainSep, withdrawHash);

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signer, digest);
        return abi.encodePacked(r, s, v);
    }

    bytes32 constant UPDATE_LEVERAGE_TYPEHASH =
        keccak256("UpdateLeverage(address account,uint32 mkt,uint32 leverage,uint256 nonce,uint256 deadline)");

    bytes32 constant CANCEL_ORDER_TYPEHASH = keccak256("CancelOrder(address account,uint256 nonce,uint256 deadline)");

    function signCancelOrder(uint256 signer, uint256 nonce, uint256 deadline, bytes32 domainSep)
        public
        pure
        returns (bytes memory)
    {
        address account = vm.addr(signer);
        bytes32 cancelHash = keccak256(abi.encode(CANCEL_ORDER_TYPEHASH, account, nonce, deadline));
        bytes32 digest = MessageHashUtils.toTypedDataHash(domainSep, cancelHash);

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signer, digest);
        return abi.encodePacked(r, s, v);
    }

    function signLeverageUpdate(
        uint256 signer,
        address account,
        uint32 mkt,
        uint32 leverage,
        uint256 nonce,
        uint256 deadline,
        bytes32 domainSep
    ) public pure returns (bytes memory) {
        bytes32 leverageUpdateHash =
            keccak256(abi.encode(UPDATE_LEVERAGE_TYPEHASH, account, mkt, leverage, nonce, deadline));
        bytes32 digest = MessageHashUtils.toTypedDataHash(domainSep, leverageUpdateHash);

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signer, digest);
        return abi.encodePacked(r, s, v);
    }

    function _getHelloVaultDomainSep(address addr) public view returns (bytes32) {
        return
            keccak256(abi.encode(TYPE_HASH, keccak256(bytes("HelloVault")), keccak256(bytes("1")), block.chainid, addr));
    }

    function vaultHashTypedDataV4(address addr, bytes32 structHash) internal view returns (bytes32) {
        return MessageHashUtils.toTypedDataHash(_getHelloVaultDomainSep(addr), structHash);
    }
}
