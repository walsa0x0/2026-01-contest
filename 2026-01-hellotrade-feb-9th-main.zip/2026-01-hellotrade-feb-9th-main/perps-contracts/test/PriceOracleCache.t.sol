// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {PriceOracleCache} from "src/price-feeds/PriceOracleCache.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";
import {StorkErrors} from "@storknetwork/stork-evm-sdk/StorkErrors.sol";
import {IStorkEvents} from "@storknetwork/stork-evm-sdk/IStorkEvents.sol";
import {StorkMockWithTestHelpers} from "test/mocks/StorkMockTest.sol";
import {AllOraclesFailed, NegativePrice, UnknownHelloStorkId} from "src/price-feeds/PriceOracleCache.sol";

import {console} from "forge-std/console.sol";

contract PriceOracleCacheHarness is PriceOracleCache {
    function initialize(address stork_) external initializer {
        __PriceOracleCache_init(stork_);
    }

    function setMarketHelloStorkId(uint32 marketId, bytes32 helloStorkId) external {
        _setMarketHelloStorkId(marketId, helloStorkId);
    }

    function clearMarketHelloStorkId(uint32 marketId, bytes32 helloStorkId) external {
        _clearMarketHelloStorkId(marketId, helloStorkId);
    }

    function setMarketStorkId(uint32 marketId, bytes32 storkId) external {
        _setMarketStorkId(marketId, storkId);
    }

    function setValidTimePeriodNs(uint256 period) external {
        _setValidTimePeriodNs(period);
    }

    function updatePrices(StorkStructs.TemporalNumericValueInput[] calldata inputs) external {
        _updatePrices(inputs);
    }

    function updatePricesWithCache(StorkStructs.TemporalNumericValueInput[] calldata inputs) external {
        _updatePricesWithCache(inputs);
    }

    function updatePricesWithCacheCheckTstore(StorkStructs.TemporalNumericValueInput[] calldata inputs)
        external
        returns (int192 storedPrice, uint64 storedTimestamp, uint256 fetchedPrice)
    {
        _updatePricesWithCache(inputs);
        uint32 marketId = _helloStorkIdToMarket(inputs[0].id);
        (storedPrice, storedTimestamp) = localPrices(marketId);
        _setLocalPrice(marketId, CachedPrice({price: -1, timestampNs: storedTimestamp}));
        fetchedPrice = _getPrice(marketId);
    }

    function getPriceAfterGetPriceAndCache(uint32 marketId) external returns (uint256 cachedPrice, uint256 fetched) {
        cachedPrice = _getPriceAndCache(marketId);
        (, uint64 ts) = localPrices(marketId);
        _setLocalPrice(marketId, CachedPrice({price: -1, timestampNs: ts}));
        fetched = _getPrice(marketId);
    }

    function getPriceAndCacheTwice(uint32 marketId) external returns (uint256 first, uint256 second) {
        first = _getPriceAndCache(marketId);
        (, uint64 ts) = localPrices(marketId);
        _setLocalPrice(marketId, CachedPrice({price: -1, timestampNs: ts}));
        second = _getPriceAndCache(marketId);
    }

    function setLocalPrice(uint32 marketId, int192 price, uint64 timestampNs) external {
        _setLocalPrice(marketId, CachedPrice({price: price, timestampNs: timestampNs}));
    }
}

contract PriceOracleCacheTest is Test {
    uint32 private constant MARKET_ID = 1;
    uint32 private constant MARKET_ID_2 = 2;
    bytes32 private constant HELLO_STORK_ID = keccak256("hello-stork-id");
    bytes32 private constant HELLO_STORK_ID_2 = keccak256("hello-stork-id-2");
    bytes32 private constant STORK_ID = keccak256("stork-id");
    uint256 private constant STORK_VALID_TIME_SECONDS = 1 days;

    PriceOracleCacheHarness private cache;
    StorkMockWithTestHelpers private storkMock;

    uint256 private signerKey;

    StorkStructs.TemporalNumericValueInput private price1;
    StorkStructs.TemporalNumericValueInput private price2;
    StorkStructs.TemporalNumericValueInput private negativePrice;

    StorkStructs.TemporalNumericValueInput private fallbackHelloStorkInput;
    StorkStructs.TemporalNumericValueInput private fallbackStorkInput;

    function setUp() public {
        signerKey = uint256(keccak256("signer-key"));
        storkMock = new StorkMockWithTestHelpers();
        storkMock.initializeWithKey(STORK_VALID_TIME_SECONDS, 0, signerKey);

        cache = new PriceOracleCacheHarness();
        cache.initialize(address(storkMock));

        uint64 timestampNs = uint64(block.timestamp * 1e9);
        int192 basePrice = 2000e18;

        price1 = _makeInput(HELLO_STORK_ID, timestampNs, basePrice);
        price2 = _makeInput(HELLO_STORK_ID_2, timestampNs, basePrice + 500e18);
        negativePrice = _makeInput(HELLO_STORK_ID, timestampNs, -1500e18);

        fallbackHelloStorkInput = _makeInput(HELLO_STORK_ID, timestampNs, basePrice + 123e18);
        fallbackStorkInput = _makeInput(HELLO_STORK_ID, timestampNs + 1, basePrice);
    }

    function test_InitializationDefaults() public view {
        assertEq(cache.validTimePeriodNs(), 5e9);
        assertEq(address(cache.stork()), address(storkMock));
    }

    function test_Setters() public {
        bytes32 newHelloId = keccak256("hello-stork-id-2");

        cache.setMarketHelloStorkId(MARKET_ID, HELLO_STORK_ID);
        assertEq(cache.marketToHelloStorkId(MARKET_ID), HELLO_STORK_ID);
        assertEq(cache.helloStorkIdToMarket(HELLO_STORK_ID), MARKET_ID);
        cache.clearMarketHelloStorkId(MARKET_ID, HELLO_STORK_ID);

        cache.setMarketHelloStorkId(MARKET_ID, newHelloId);
        assertEq(cache.marketToHelloStorkId(MARKET_ID), newHelloId);
        assertEq(cache.helloStorkIdToMarket(newHelloId), MARKET_ID);
        assertEq(cache.helloStorkIdToMarket(HELLO_STORK_ID), 0);

        cache.setMarketStorkId(MARKET_ID, STORK_ID);
        assertEq(cache.marketToStorkId(MARKET_ID), STORK_ID);

        cache.setValidTimePeriodNs(42);
        assertEq(cache.validTimePeriodNs(), 42);
    }

    function test_UpdatePrices_UpdatesLocalPricesAndEmits() public {
        cache.setMarketHelloStorkId(MARKET_ID, HELLO_STORK_ID);

        StorkStructs.TemporalNumericValueInput[] memory inputs = _toArray(price1);

        vm.expectEmit(true, true, true, true);
        emit IStorkEvents.ValueUpdate(
            price1.id, price1.temporalNumericValue.timestampNs, price1.temporalNumericValue.quantizedValue
        );
        cache.updatePrices(inputs);

        (int192 storedPrice, uint64 storedTimestamp) = cache.localPrices(MARKET_ID);
        assertEq(storedPrice, price1.temporalNumericValue.quantizedValue);
        assertEq(storedTimestamp, price1.temporalNumericValue.timestampNs);
    }

    function test_UpdatePrices_RevertsOnUnknownHelloId() public {
        StorkStructs.TemporalNumericValueInput[] memory inputs = _toArray(fallbackHelloStorkInput);

        vm.expectRevert(abi.encodeWithSelector(UnknownHelloStorkId.selector, HELLO_STORK_ID));
        cache.updatePrices(inputs);
    }

    function test_UpdatePrices_RevertsOnStaleValue() public {
        cache.setMarketHelloStorkId(MARKET_ID, HELLO_STORK_ID);

        uint64 newerTimestamp = price1.temporalNumericValue.timestampNs;
        cache.setLocalPrice(MARKET_ID, 100e18, newerTimestamp);

        uint64 olderTimestamp = newerTimestamp - 1;
        StorkStructs.TemporalNumericValueInput memory input = _makeInput(HELLO_STORK_ID, olderTimestamp, 120e18);
        StorkStructs.TemporalNumericValueInput[] memory inputs = _toArray(input);

        vm.expectRevert(StorkErrors.StaleValue.selector);
        cache.updatePrices(inputs);
    }

    function test_UpdatePricesWithCache_UpdatesLocalPricesAndTstore() public {
        cache.setMarketHelloStorkId(MARKET_ID, HELLO_STORK_ID);

        StorkStructs.TemporalNumericValueInput[] memory inputs = _toArray(negativePrice);

        vm.expectEmit(true, true, true, true);
        emit IStorkEvents.ValueUpdate(
            negativePrice.id,
            negativePrice.temporalNumericValue.timestampNs,
            negativePrice.temporalNumericValue.quantizedValue
        );
        (int192 storedPrice, uint64 storedTimestamp, uint256 fetchedPrice) =
            cache.updatePricesWithCacheCheckTstore(inputs);
        assertEq(storedPrice, negativePrice.temporalNumericValue.quantizedValue);
        assertEq(storedTimestamp, negativePrice.temporalNumericValue.timestampNs);
        assertEq(fetchedPrice, _abs(negativePrice.temporalNumericValue.quantizedValue));
    }

    function test_UpdatePrices_UpdatesMultipleMarkets() public {
        cache.setMarketHelloStorkId(MARKET_ID, HELLO_STORK_ID);
        cache.setMarketHelloStorkId(MARKET_ID_2, HELLO_STORK_ID_2);

        StorkStructs.TemporalNumericValueInput[] memory inputs = new StorkStructs.TemporalNumericValueInput[](2);
        inputs[0] = price1;
        inputs[1] = price2;

        vm.expectEmit(true, true, true, true);
        emit IStorkEvents.ValueUpdate(
            price1.id, price1.temporalNumericValue.timestampNs, price1.temporalNumericValue.quantizedValue
        );
        vm.expectEmit(true, true, true, true);
        emit IStorkEvents.ValueUpdate(
            price2.id, price2.temporalNumericValue.timestampNs, price2.temporalNumericValue.quantizedValue
        );

        cache.updatePrices(inputs);

        (int192 storedPrice1, uint64 storedTimestamp1) = cache.localPrices(MARKET_ID);
        assertEq(storedPrice1, price1.temporalNumericValue.quantizedValue);
        assertEq(storedTimestamp1, price1.temporalNumericValue.timestampNs);

        (int192 storedPrice2, uint64 storedTimestamp2) = cache.localPrices(MARKET_ID_2);
        assertEq(storedPrice2, price2.temporalNumericValue.quantizedValue);
        assertEq(storedTimestamp2, price2.temporalNumericValue.timestampNs);
    }

    function test_GetPrice_ReturnsTstorePriceFirst() public {
        cache.setLocalPrice(MARKET_ID, 111e18, uint64(block.timestamp * 1e9));
        (uint256 cachedPrice, uint256 fetched) = cache.getPriceAfterGetPriceAndCache(MARKET_ID);
        assertEq(fetched, cachedPrice);
    }

    function test_GetPrice_ReturnsLocalPriceWhenValid() public {
        uint64 timestampNs = uint64(block.timestamp * 1e9);
        int192 price = 321e18;
        cache.setLocalPrice(MARKET_ID, price, timestampNs);

        uint256 fetched = cache.getPrice(MARKET_ID);
        assertEq(fetched, _abs(price));
    }

    function test_GetPrice_FallsBackToStork() public {
        vm.warp(100); // Ensure block.timestamp is large enough to avoid underflow
        cache.setMarketStorkId(MARKET_ID, STORK_ID);

        uint64 expiredTimestamp = uint64(block.timestamp * 1e9) - uint64(cache.validTimePeriodNs()) - 1;
        cache.setLocalPrice(MARKET_ID, 100e18, expiredTimestamp);

        storkMock.setStorkPrice(STORK_ID, 222e18);
        uint256 fetched = cache.getPrice(MARKET_ID);
        assertEq(fetched, 222e18);
    }

    function test_GetPrice_RevertsOnNegativeLocalPrice() public {
        uint64 timestampNs = uint64(block.timestamp * 1e9);
        cache.setLocalPrice(MARKET_ID, -1, timestampNs);

        vm.expectRevert(NegativePrice.selector);
        cache.getPrice(MARKET_ID);
    }

    function test_GetPrice_RevertsOnNegativeStorkPrice() public {
        vm.warp(100); // Ensure block.timestamp is large enough to avoid underflow
        cache.setMarketStorkId(MARKET_ID, STORK_ID);

        uint64 expiredTimestamp = uint64(block.timestamp * 1e9) - uint64(cache.validTimePeriodNs()) - 1;
        cache.setLocalPrice(MARKET_ID, 10e18, expiredTimestamp);

        storkMock.setStorkPrice(STORK_ID, -2e18);

        vm.expectRevert(NegativePrice.selector);
        cache.getPrice(MARKET_ID);
    }

    function test_GetPrice_RevertsWhenAllOraclesFail() public {
        vm.expectRevert(AllOraclesFailed.selector);
        cache.getPrice(MARKET_ID);
    }

    function test_GetPriceAndCache_ReturnsTstoredPrice() public {
        cache.setLocalPrice(MARKET_ID, 999e18, uint64(block.timestamp * 1e9));

        (uint256 first, uint256 second) = cache.getPriceAndCacheTwice(MARKET_ID);
        assertEq(second, first);
    }

    function test_GetPriceAndCache_CachesOnMiss() public {
        int192 price = 456e18;
        cache.setLocalPrice(MARKET_ID, price, uint64(block.timestamp * 1e9));

        (uint256 cachedPrice, uint256 fetched) = cache.getPriceAfterGetPriceAndCache(MARKET_ID);
        assertEq(cachedPrice, _abs(price));
        assertEq(fetched, _abs(price));
    }

    function test_IsPriceValid_PassesBeforeBoundary() public {
        cache.setValidTimePeriodNs(10e9);
        vm.warp(100);

        uint64 timestampNs = uint64(100 * 1e9 - 10e9 + 1);
        cache.setLocalPrice(MARKET_ID, 11e18, timestampNs);

        uint256 fetched = cache.getPrice(MARKET_ID);
        assertEq(fetched, 11e18);
    }

    function test_IsPriceValid_PassesAtBoundary() public {
        cache.setValidTimePeriodNs(10e9);
        vm.warp(200);

        uint64 timestampNs = uint64(200 * 1e9 - 10e9);
        cache.setLocalPrice(MARKET_ID, 22e18, timestampNs);

        uint256 fetched = cache.getPrice(MARKET_ID);
        assertEq(fetched, 22e18);
    }

    function test_IsPriceValid_FailsBeyondBoundary() public {
        cache.setValidTimePeriodNs(10e9);
        vm.warp(300);

        uint64 timestampNs = uint64(300 * 1e9 - 10e9 - 1);
        cache.setLocalPrice(MARKET_ID, 33e18, timestampNs);

        vm.expectRevert(AllOraclesFailed.selector);
        cache.getPrice(MARKET_ID);
    }

    function test_VerifyStorkSignature_WorksAndRejectsInvalid() public {
        cache.setMarketHelloStorkId(MARKET_ID, HELLO_STORK_ID);

        console.log(storkMock.storkPublicKey());
        console.log(vm.addr(signerKey));

        StorkStructs.TemporalNumericValueInput[] memory inputs = _toArray(price1);

        cache.updatePrices(inputs);

        StorkStructs.TemporalNumericValueInput memory badInput = fallbackStorkInput;
        badInput.r = bytes32(uint256(badInput.r) ^ 0x01);
        StorkStructs.TemporalNumericValueInput[] memory badInputs = _toArray(badInput);

        vm.expectRevert();
        cache.updatePrices(badInputs);
    }

    function _makeInput(bytes32 id, uint64 timestampNs, int192 price)
        internal
        view
        returns (StorkStructs.TemporalNumericValueInput memory input)
    {
        StorkStructs.TemporalNumericValue memory value =
            StorkStructs.TemporalNumericValue({timestampNs: timestampNs, quantizedValue: price});
        return storkMock.signTemporalNumericValueInput(id, value);
    }

    function _toArray(StorkStructs.TemporalNumericValueInput memory input)
        internal
        pure
        returns (StorkStructs.TemporalNumericValueInput[] memory inputs)
    {
        inputs = new StorkStructs.TemporalNumericValueInput[](1);
        inputs[0] = input;
    }

    function _abs(int192 value) internal pure returns (uint256) {
        int256 signed = int256(value);
        return signed < 0 ? uint256(-signed) : uint256(signed);
    }
}
