// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {console} from "forge-std/console.sol";

import {VaultTestHelpers} from "test/VaultTestHelpers.sol";

import {Math} from "src/lib/Math.sol";
import {Order} from "src/lib/Order.sol";
import {MarketConfig} from "src/price-feeds/HelloMarketData.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

/// @title FillMatchGasTest
/// @notice Gas metering tests for filling matched orders
/// @dev Tests gas consumption when users have multiple open positions
contract FillMatchGasTest is Test, VaultTestHelpers {
    using Math for int256;

    uint256 constant WAD = 1e18;
    uint256 constant NUM_MARKETS = 16;

    // Market IDs for the 16 markets
    uint32[] marketIds;
    bytes32[] storkInstIds;

    function setUp() public override {
        super.setUp();

        // Initialize 16 markets (market 1 is already initialized in VaultFixture)
        vm.startPrank(admin);

        for (uint32 i = 1; i <= NUM_MARKETS; i++) {
            marketIds.push(i);
            storkInstIds.push(bytes32(uint256(i)));

            // Skip market 1 as it's already configured in the base fixture
            if (i == 1) continue;

            helloVault.setMarketConfig(
                i,
                MarketConfig({
                    maxLeverage: maxLeverage,
                    defaultLeverage: defaultLeverage,
                    pricePrecision: pricePrecision,
                    basePrecision: basePrecision,
                    quotePrecision: quotePrecision,
                    fundingMax: 100_000_000,
                    fundingMin: -100_000_000,
                    minFundingInterval: 1
                })
            );

            helloVault.setMarketStorkId(i, bytes32(uint256(i)));
            helloVault.setMarketHelloStorkId(i, bytes32(uint256(i)));
            storkMock.setStorkPrice(bytes32(uint256(i)), int192(1e18));
        }
        // prices is initialized by VaultTestHelpers.setUp() for mktId1

        vm.stopPrank();

        // Initialize funding for all markets
        vm.startPrank(relayer);
        for (uint32 i = 2; i <= NUM_MARKETS; i++) {
            helloVault.updateFundingInstant(i, FUNDING_RATE_IDX0, FUNDING_PRICE_IDX0, 0);
        }

        // Deposit for Alice and Bob - large amounts to support many positions
        _depositFor(aliceKey, 1_000_000 * 1e6, _useTrackingHead());
        _depositFor(bobKey, 1_000_000 * 1e6, _useTrackingHead());

        vm.stopPrank();
    }

    /// @notice Helper to open a position in a specific market
    function _openPositionInMarket(uint32 marketId, uint256 aliceNonce, uint256 bobNonce) internal {
        int256 size = 1_000; // Small size to not exhaust margin

        Order memory aliceOrder =
            Order({account: alice, market: marketId, size: size, limitPrice: 1e18, nonce: aliceNonce});
        Order memory bobOrder = Order({account: bob, market: marketId, size: -size, limitPrice: 0, nonce: bobNonce});

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
        bytes memory bobSig = signOrder(bobKey, bobOrder);

        // Update prices for this market
        _setPricesForMarketWithPrice(marketId, 1e18);
        _fillMatchedOrder(aliceOrder, aliceSig, bobOrder, bobSig, size.abs(), _useTrackingHead());
    }

    /// @notice Test gas usage when filling a match with user having 16 open positions
    /// @dev Opens 16 positions first, then measures gas for the 17th fill
    function test_GasFillMatchWith16OpenPositions() public {
        vm.startPrank(relayer);

        // Warp time to ensure fresh prices vs setUp initialization
        vm.warp(block.timestamp + 1);

        // Open positions in 16 different markets
        // Using sequential nonces for Alice and Bob
        for (uint32 i = 0; i < NUM_MARKETS; i++) {
            uint32 marketId = marketIds[i];
            uint256 nonce = i + 1; // Nonces start at 1
            _openPositionInMarket(marketId, nonce, nonce);
        }

        // Now measure gas for filling another order when user has 16 open positions
        // This will INCREASE the position in market 1
        uint32 targetMarket = marketIds[0];
        int256 size = 1_000;
        uint256 nonce = NUM_MARKETS + 1;

        Order memory aliceOrder =
            Order({account: alice, market: targetMarket, size: size, limitPrice: 1e18, nonce: nonce});
        Order memory bobOrder = Order({account: bob, market: targetMarket, size: -size, limitPrice: 0, nonce: nonce});

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
        bytes memory bobSig = signOrder(bobKey, bobOrder);

        // Create fresh price updates for all markets (cross-margin needs all prices for equity calc)
        StorkStructs.TemporalNumericValueInput[] memory priceUpdates = _createPriceUpdates(true);

        uint256 gasBefore = gasleft();
        helloVault.handleMatchedFill(
            priceUpdates, aliceOrder, aliceSig, bobOrder, bobSig, size.abs(), _useTrackingHead()
        );
        uint256 gasUsed = gasBefore - gasleft();

        console.log("Gas used for fill with 16 open positions (increase existing):", gasUsed);

        vm.stopPrank();
    }

    /// @notice Test gas usage when opening the 16th (max) position with 15 existing positions
    function test_GasFillMatchOpenNewPositionWith15Existing() public {
        vm.startPrank(relayer);

        // Warp time to ensure fresh prices vs setUp initialization
        vm.warp(block.timestamp + 1);

        // Open positions in first 15 markets (markets 1-15)
        for (uint32 i = 0; i < NUM_MARKETS - 1; i++) {
            uint32 marketId = marketIds[i];
            uint256 nonce = i + 1;
            _openPositionInMarket(marketId, nonce, nonce);
        }

        // Advance time again for fresh price update on final fill
        vm.warp(block.timestamp + 1);

        // Measure gas for opening the 16th position (market 16) - the maximum allowed
        uint32 market16 = marketIds[NUM_MARKETS - 1];
        int256 size = 1_000;
        uint256 nonce = NUM_MARKETS;

        Order memory aliceOrder = Order({account: alice, market: market16, size: size, limitPrice: 1e18, nonce: nonce});
        Order memory bobOrder = Order({account: bob, market: market16, size: -size, limitPrice: 0, nonce: nonce});

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
        bytes memory bobSig = signOrder(bobKey, bobOrder);

        // Use fresh price update instead of empty array
        _setPricesForMarketWithPrice(market16, 1e18);

        uint256 gasBefore = gasleft();
        helloVault.handleMatchedFill(prices, aliceOrder, aliceSig, bobOrder, bobSig, size.abs(), _useTrackingHead());
        uint256 gasUsed = gasBefore - gasleft();

        console.log("Gas used for opening 16th (max) position with 15 existing:", gasUsed);

        vm.stopPrank();
    }

    /// @notice Test gas usage when opening the 16th position with 15 existing AND 16 price updates
    /// forge-config: default.isolate = true
    function test_GasFillMatchOpen16thPositionWithPriceUpdates() public {
        vm.startPrank(relayer);

        // Warp time to ensure fresh prices vs setUp initialization
        vm.warp(block.timestamp + 1);

        // Open positions in first 15 markets (markets 1-15)
        for (uint32 i = 0; i < NUM_MARKETS - 1; i++) {
            uint32 marketId = marketIds[i];
            uint256 nonce = i + 1;
            _openPositionInMarket(marketId, nonce, nonce);
        }

        // Create price updates for all 16 markets (advance time for fresh timestamps)
        StorkStructs.TemporalNumericValueInput[] memory priceUpdates = _createPriceUpdates(true);

        // Measure gas for opening the 16th position with price updates
        uint32 market16 = marketIds[NUM_MARKETS - 1];
        int256 size = 1_000;
        uint256 nonce = NUM_MARKETS;

        Order memory aliceOrder =
            Order({account: alice, market: market16, size: size, limitPrice: 1e18 + 100, nonce: nonce});
        Order memory bobOrder = Order({account: bob, market: market16, size: -size, limitPrice: 0, nonce: nonce});

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
        bytes memory bobSig = signOrder(bobKey, bobOrder);

        uint256 trackingHead = _useTrackingHead();
        vm.startSnapshotGas("GasFillMatchOpen16thPositionWithPriceUpdates");
        helloVault.handleMatchedFill(priceUpdates, aliceOrder, aliceSig, bobOrder, bobSig, size.abs(), trackingHead);
        uint256 gasUsedLastCall = vm.snapshotGasLastCall("GasFillLastCall");
        uint256 gasUsed = vm.stopSnapshotGas();

        bytes memory fillBytes = abi.encode(priceUpdates);
        uint256 count = 0;
        for (uint256 i = 0; i < fillBytes.length; i++) {
            if (fillBytes[i] == 0x00) {
                count++;
            }
        }

        console.log("Sent", priceUpdates.length, "price updates");
        console.log("Gas used:", gasUsed);
        console.log("Number of 0x00 bytes in fillBytes:", count, "empty bytes", fillBytes.length - count);
        console.log("Calldata cost:", count * 40);
        console.log("Empty bytes cost:", (fillBytes.length - count) * 16);

        vm.stopPrank();
    }

    /// @notice baseline test
    function test_GasFillMatchBaseline() public {
        vm.startPrank(relayer);

        int256 size = 1_000;
        uint256 nonce = 1;

        Order memory aliceOrder = Order({account: alice, market: mktId1, size: size, limitPrice: 1e18, nonce: nonce});
        Order memory bobOrder = Order({account: bob, market: mktId1, size: -size, limitPrice: 0, nonce: nonce});

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
        bytes memory bobSig = signOrder(bobKey, bobOrder);

        StorkStructs.TemporalNumericValueInput[] memory emptyPrices = new StorkStructs.TemporalNumericValueInput[](0);

        uint256 gasBefore = gasleft();
        helloVault.handleMatchedFill(
            emptyPrices, aliceOrder, aliceSig, bobOrder, bobSig, size.abs(), _useTrackingHead()
        );
        uint256 gasUsed = gasBefore - gasleft();

        console.log("Gas used for fill with NO existing positions (baseline):", gasUsed);

        vm.stopPrank();
    }

    /// @notice Helper to create price updates for all markets
    /// @dev Each price is 1 wei higher than the last, starting from 1e18
    /// @param advanceTime If true, warps time forward to ensure fresh timestamps
    function _createPriceUpdates(bool advanceTime) internal returns (StorkStructs.TemporalNumericValueInput[] memory) {
        if (advanceTime) {
            vm.warp(block.timestamp + 1);
        }

        StorkStructs.TemporalNumericValueInput[] memory prices =
            new StorkStructs.TemporalNumericValueInput[](NUM_MARKETS);

        uint64 timestamp = uint64(block.timestamp) * 1e9; // Current timestamp in nanoseconds

        for (uint256 i = 0; i < NUM_MARKETS; i++) {
            bytes32 storkId = storkInstIds[i]; // Use actual registered stork IDs
            int192 price = int192(int256(111_111_111_111_111_111)); // Each price is 1 wei higher than the last

            StorkStructs.TemporalNumericValue memory temporalValue =
                StorkStructs.TemporalNumericValue({timestampNs: timestamp, quantizedValue: price});

            prices[i] = storkMock.signTemporalNumericValueInput(storkId, temporalValue);
        }

        return prices;
    }

    /// @notice Test gas usage when filling with price updates for all markets
    /// @dev Opens positions in all markets, then fills with calldata containing price updates
    function test_GasFillMatchWithPriceUpdatesForAllMarkets() public {
        vm.startPrank(relayer);

        // Warp time to ensure fresh prices vs setUp initialization
        vm.warp(block.timestamp + 1);

        // Open positions in all markets first
        for (uint32 i = 0; i < NUM_MARKETS; i++) {
            uint32 marketId = marketIds[i];
            uint256 nonce = i + 1;
            _openPositionInMarket(marketId, nonce, nonce);
        }

        // Create price updates for all markets (each 1 wei higher than the last, advance time for fresh timestamps)
        StorkStructs.TemporalNumericValueInput[] memory priceUpdates = _createPriceUpdates(true);

        // Now measure gas for filling with price updates
        uint256 targetMarket = marketIds[0];
        int256 size = 1_000;
        uint256 nonce = NUM_MARKETS + 1;

        Order memory aliceOrder =
            Order({account: alice, market: uint32(targetMarket), size: size, limitPrice: 1e18 + 100, nonce: nonce});
        Order memory bobOrder =
            Order({account: bob, market: uint32(targetMarket), size: -size, limitPrice: 0, nonce: nonce});

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
        bytes memory bobSig = signOrder(bobKey, bobOrder);

        uint256 gasBefore = gasleft();
        helloVault.handleMatchedFill(
            priceUpdates, aliceOrder, aliceSig, bobOrder, bobSig, size.abs(), _useTrackingHead()
        );
        uint256 gasUsed = gasBefore - gasleft();

        console.log("Gas used for fill with price updates for all", NUM_MARKETS, "markets:", gasUsed);

        vm.stopPrank();
    }

    /// @notice Test gas usage baseline with price updates but NO existing positions
    /// @dev Measures overhead of price updates alone
    function test_GasFillMatchBaselineWithPriceUpdates() public {
        vm.startPrank(relayer);

        // Create price updates for all markets (advance time for fresh timestamps)
        StorkStructs.TemporalNumericValueInput[] memory priceUpdates = _createPriceUpdates(true);

        int256 size = 1_000;
        uint256 nonce = 1;

        Order memory aliceOrder =
            Order({account: alice, market: mktId1, size: size, limitPrice: 1e18 + 100, nonce: nonce});
        Order memory bobOrder = Order({account: bob, market: mktId1, size: -size, limitPrice: 0, nonce: nonce});

        bytes memory aliceSig = signOrder(aliceKey, aliceOrder);
        bytes memory bobSig = signOrder(bobKey, bobOrder);

        uint256 gasBefore = gasleft();
        helloVault.handleMatchedFill(
            priceUpdates, aliceOrder, aliceSig, bobOrder, bobSig, size.abs(), _useTrackingHead()
        );

        uint256 gasUsed = gasBefore - gasleft();

        console.log("Gas used for fill with", NUM_MARKETS, "price updates (no existing positions):", gasUsed);

        vm.stopPrank();
    }
}

