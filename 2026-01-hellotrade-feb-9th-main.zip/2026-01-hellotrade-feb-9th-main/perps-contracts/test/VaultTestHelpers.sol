// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {VaultFixture} from "test/fixtures/VaultFixtureV1_1.sol";
import {UsdcPermitSignerUtils} from "test/utils/SignerUtils.sol";
import {Test} from "forge-std/Test.sol";

// libraries
import {Math} from "src/lib/Math.sol";
import {Order} from "src/lib/Order.sol";
import {Position} from "src/lib/Position.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

/// @notice Helper contract for fill-related tests
/// @dev Inherits from VaultFixture for access to vault and test accounts
abstract contract VaultTestHelpers is Test, UsdcPermitSignerUtils, VaultFixture {
    using Math for int256;
    using Math for uint256;

    mapping(address => uint256) userNonces;

    /// @notice Stored price inputs - set in setUp, used by convenience _fillMatchedOrder overload
    StorkStructs.TemporalNumericValueInput[] prices;

    function setUp() public virtual override {
        super.setUp();
        // Initialize default prices for mktId1
        prices = toArray(_createPriceInputWithPrice(mktId1, 1e18));
    }

    /// @notice Returns incremented tracking head
    function _useTrackingHead() internal view returns (uint256) {
        return uint256(helloVault.trackingHead() + 1);
    }

    /// @notice Update stored prices on the stork mock for a market with a custom price
    function _setPricesForMarketWithPrice(uint32 market, int192 price) internal {
        prices = toArray(_createPriceInputWithPrice(market, price));
        // Also update the stork mock for fallback
        storkMock.setStorkPrice(bytes32(uint256(market)), price);
    }

    /// @notice Creates signed price input for a market with a custom price
    function _createPriceInputWithPrice(uint32 market, int192 price)
        internal
        view
        returns (StorkStructs.TemporalNumericValueInput memory)
    {
        bytes32 storkId = bytes32(uint256(market));
        StorkStructs.TemporalNumericValue memory storkValue = StorkStructs.TemporalNumericValue({
            timestampNs: uint64(vm.getBlockTimestamp()) * 1000000000, quantizedValue: price
        });
        return storkMock.signTemporalNumericValueInput(storkId, storkValue);
    }

    /// @notice Converts a single price input to an array
    function toArray(StorkStructs.TemporalNumericValueInput memory price)
        internal
        view
        returns (StorkStructs.TemporalNumericValueInput[] memory)
    {
        StorkStructs.TemporalNumericValueInput[] memory prices = new StorkStructs.TemporalNumericValueInput[](1);
        prices[0] = price;
        return prices;
    }

    /// @notice Update the Stork mock price for a market
    /// @dev After calling this, warp time by 6+ seconds to invalidate the local cache,
    ///      then getMarkPrice will fall back to the Stork mock
    function _setMockPrice(uint32 market, int192 price) internal {
        storkMock.setStorkPrice(bytes32(uint256(market)), price);
    }

    /// @notice Executes a matched fill between maker and taker orders (explicit prices)
    function _fillMatchedOrder(
        StorkStructs.TemporalNumericValueInput[] memory prices_,
        Order memory makerOrder,
        bytes memory makerSignature,
        Order memory takerOrder,
        bytes memory takerSignature,
        uint256 fillSize,
        uint256 trackingHead
    ) internal {
        vm.startPrank(relayer);
        helloVault.handleMatchedFill(
            prices_, makerOrder, makerSignature, takerOrder, takerSignature, fillSize, trackingHead
        );
    }

    /// @notice Executes a matched fill using stored prices array
    /// @dev Uses the `prices` storage variable - call _setPricesForMarket() first if needed
    function _fillMatchedOrder(
        Order memory makerOrder,
        bytes memory makerSignature,
        Order memory takerOrder,
        bytes memory takerSignature,
        uint256 fillSize,
        uint256 trackingHead
    ) internal {
        vm.startPrank(relayer);
        helloVault.handleMatchedFill(
            prices, makerOrder, makerSignature, takerOrder, takerSignature, fillSize, trackingHead
        );
    }

    function _depositFor(uint256 userKey, uint256 amount, uint256 trackingHead) internal {
        address user = vm.addr(userKey);
        bytes memory sig =
            signPermit(userKey, address(usdcMock), address(helloVault), amount, vm.getBlockTimestamp() + 1 hours);
        helloVault.depositWithSignature(user, amount, vm.getBlockTimestamp() + 1 hours, trackingHead, sig);
    }

    /// @notice Asserts the state of order accumulator (nonce usage and partial fills)
    /// @param user The user who placed the order
    /// @param nonce The order nonce
    /// @param shouldBeUsed Whether the nonce should be used (true for full fills, false for partial fills)
    /// @param expectedAccumulatorValue The expected value in the order fill accumulator (0 for full fills)
    function _assertOrderState(address user, uint256 nonce, bool shouldBeUsed, uint256 expectedAccumulatorValue)
        internal
        view
    {
        assertEq(helloVault.nonceUsed(user, nonce), shouldBeUsed);
        bytes32 orderId = keccak256(abi.encode(user, nonce));
        uint256 orderFill = helloVault.orderFills(orderId);
        assertEq(orderFill, expectedAccumulatorValue);
    }

    /// @notice Asserts the position state matches expected values
    /// @param user The user whose position to check
    /// @param market The market ID
    /// @param expectedSize The expected position size
    /// @param expectedEntryPrice The expected entry price
    /// @param expectedLeverage The expected leverage
    function _assertPosition(
        address user,
        uint256 market,
        int256 expectedSize,
        uint256 expectedEntryPrice,
        uint128 expectedLeverage,
        int192 fundingIdxLast
    ) internal view {
        Position memory position = helloVault.getPosition(user, market, false);

        assertEq(position.size, expectedSize);
        assertEq(position.leverage, expectedLeverage);
        assertEq(position.entryPrice, expectedEntryPrice);
        assertEq(position.entryFundingIdx, fundingIdxLast);
    }

    /// @notice Asserts that margin remains unchanged after an operation
    /// @param user The user whose margin to check
    /// @param marginBefore The margin value before the operation
    function _assertMarginUnchanged(address user, int256 marginBefore) internal view {
        assertEq(helloVault.getMargin(user), marginBefore);
    }

    /// @notice Asserts that margin changes by the expected amount
    /// @param user The user whose margin to check
    /// @param marginBefore The margin value before the operation
    /// @param expectedChange The expected change in margin
    function _assertMarginChange(address user, int256 marginBefore, int256 expectedChange) internal view {
        assertEq(helloVault.getMargin(user), marginBefore += expectedChange);
    }

    function _useNonce(address user) internal returns (uint256) {
        unchecked {
            return userNonces[user]++;
        }
    }
}
