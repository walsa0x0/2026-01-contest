// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {Math, DivFailed} from "../src/lib/Math.sol";

bytes32 constant L_BIT = 0x8000000000000000000000000000000000000000000000000000000000000000;

contract MathWrapper {
    function abs(int256 x) external pure returns (uint256) {
        return Math.abs(x);
    }
}

contract test_Math is Test {
    MathWrapper private mathWrapper = new MathWrapper();

    // Test abs
    function test_abs() public view {
        assertEq(mathWrapper.abs(-5), 5);
        assertEq(mathWrapper.abs(5), 5);
        assertEq(mathWrapper.abs(0), 0);

        // For gas measurement
        int256 minInt = type(int256).min;
        mathWrapper.abs(minInt);
    }

    function test_signCmp() public pure {
        assertFalse(Math.signCmp(-5, 5));
        assertFalse(Math.signCmp(5, -5));
        assertTrue(Math.signCmp(5, 5));
        assertTrue(Math.signCmp(-5, -5));
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(0, 0);
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(5, 0);
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(0, 5);
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(-5, 0);
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(0, -5);

        // Large values
        assertFalse(Math.signCmp(type(int256).min, type(int256).max));
        assertFalse(Math.signCmp(type(int256).max, type(int256).min));
        assertTrue(Math.signCmp(type(int256).max, type(int256).max));
        assertTrue(Math.signCmp(type(int256).min, type(int256).min));

        // Large and zeroes
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(type(int256).min, 0);
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(type(int256).max, 0);
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(0, type(int256).min);
        // vm.expectRevert("ZeroCmp");
        // Math.signCmp(0, type(int256).max);
    }

    function test_divDown() public pure {
        assertEq(Math.divDown(-5, 2), -3);
        assertEq(Math.divDown(5, 2), 2);
        assertEq(Math.divDown(0, 2), 0);

        assertEq(Math.divDown(type(int256).min, type(int256).max), -2);
        assertEq(Math.divDown(type(int256).min, 1), type(int256).min);
    }

    function test_divDownWholeNumbers() public pure {
        assertEq(Math.divDown(777, 111), 7);
        assertEq(Math.divDown(-777, 111), -7);
        assertEq(Math.divDown(777, -111), -7);
        assertEq(Math.divDown(-777, -111), 7);
    }

    function test_divDownWithRemainder() public pure {
        assertEq(Math.divDown(777, 110), 7);
        assertEq(Math.divDown(-777, 110), -8);
        assertEq(Math.divDown(777, -110), -8);
        assertEq(Math.divDown(-777, -110), 7);

        assertEq(Math.divDown(777, 112), 6);
        assertEq(Math.divDown(-777, 112), -7);
        assertEq(Math.divDown(777, -112), -7);
        assertEq(Math.divDown(-777, -112), 6);
    }

    function test_divUpFromMin() public pure {
        assertEq(Math.divDown(type(int256).min + 1, type(int256).max), -1);
        assertEq(Math.divDown(type(int256).min, type(int256).max), -2);
        assertEq(Math.divDown(type(int256).min, type(int256).max - 1), -2);
        assertEq(Math.divDown(type(int256).min, type(int256).max - 2), -2);
        assertEq(Math.divDown(type(int256).min, type(int256).max - 3), -2);
    }

    function test_divDownFromMax() public pure {
        assertEq(Math.divDown(type(int256).max, type(int256).min), 0);
        assertEq(Math.divDown(type(int256).max, type(int256).min + 1), -1);
        assertEq(Math.divDown(type(int256).max, type(int256).min + 2), -2);
        assertEq(Math.divDown(type(int256).max, type(int256).min + 3), -2);

        assertEq(Math.divDown(type(int256).max, type(int256).max), 1);
        assertEq(Math.divDown(type(int256).max, type(int256).max - 1), 1);
        assertEq(Math.divDown(type(int256).max, type(int256).max - 2), 1);
        assertEq(Math.divDown(type(int256).max, type(int256).max - 3), 1);

        assertEq(Math.divDown(type(int256).max, 1), type(int256).max);

        assertEq(Math.divDown(type(int256).max, -1), -type(int256).max);
    }

    function test_divDownRevertsOnDivideByZero() public {
        vm.expectRevert(abi.encodeWithSelector(DivFailed.selector));
        Math.divDown(5, 0);
    }

    function test_divDownRevertsOnOverflowFromMin() public {
        vm.expectRevert(abi.encodeWithSelector(DivFailed.selector));
        Math.divDown(type(int256).min, -1);
    }
}
