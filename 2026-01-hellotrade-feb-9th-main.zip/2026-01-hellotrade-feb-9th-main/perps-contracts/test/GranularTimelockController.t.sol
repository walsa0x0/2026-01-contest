// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {GranularTimelockController} from "src/governor/GranularTimelockController.sol";

/// @title WuTest
/// @notice Test target contract for GranularTimelockController tests
contract WuTest {
    bool public isForever;
    bool public isForTheChildren;
    uint256 public memberCount;
    uint256 public balance;

    event WutangIsForever();
    event WutangIsForTheChildren(uint256 memberCount);

    function wutangIsForever() external {
        isForever = true;
    }

    function wutangIsForTheChildren(uint256 _memberCount) external {
        isForTheChildren = true;
        memberCount = _memberCount;
    }

    function dollarDollarBillYall() external payable {
        balance += msg.value;
    }
}

contract GranularTimelockControllerTest is Test {
    GranularTimelockController public timelock;
    WuTest public wutang;

    address public admin = makeAddr("admin");
    address public proposer = makeAddr("proposer");
    address public executor = makeAddr("executor");
    address public canceller = makeAddr("canceller");
    address public nobody = makeAddr("nobody");

    uint256 public constant DEFAULT_MIN_DELAY = 1 days;
    uint256 public constant CUSTOM_DELAY = 2 days;

    bytes32 public constant PROPOSER_ROLE = keccak256("PROPOSER_ROLE");
    bytes32 public constant EXECUTOR_ROLE = keccak256("EXECUTOR_ROLE");
    bytes32 public constant CANCELLER_ROLE = keccak256("CANCELLER_ROLE");

    function setUp() public {
        address[] memory proposers = new address[](1);
        proposers[0] = proposer;

        address[] memory executors = new address[](1);
        executors[0] = executor;

        timelock = new GranularTimelockController(DEFAULT_MIN_DELAY, proposers, executors, admin);
        wutang = new WuTest();

        // Grant canceller role separately (proposers get it by default, but let's add explicit one)
        vm.startPrank(admin);
        timelock.grantRole(CANCELLER_ROLE, canceller);
    }

    // ============ Initialization Tests ============

    function test_Initialization() public view {
        assertEq(timelock.defaultMinDelay(), DEFAULT_MIN_DELAY);
        assertTrue(timelock.hasRole(PROPOSER_ROLE, proposer));
        assertTrue(timelock.hasRole(EXECUTOR_ROLE, executor));
        assertTrue(timelock.hasRole(CANCELLER_ROLE, proposer)); // proposers get canceller by default
        assertTrue(timelock.hasRole(CANCELLER_ROLE, canceller));
        assertTrue(timelock.hasRole(timelock.DEFAULT_ADMIN_ROLE(), admin));
        assertTrue(timelock.hasRole(timelock.DEFAULT_ADMIN_ROLE(), address(timelock)));
    }

    // ============ Schedule Tests ============

    function test_Schedule_SingleOperation() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 predecessor = bytes32(0);
        bytes32 salt = keccak256("test-salt");

        bytes32 id = timelock.hashOperation(address(wutang), 0, data, predecessor, salt);

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, predecessor, salt, DEFAULT_MIN_DELAY);

        assertTrue(timelock.isOperation(id));
        assertTrue(timelock.isOperationPending(id));
        assertFalse(timelock.isOperationReady(id));
        assertFalse(timelock.isOperationDone(id));
        assertEq(uint256(timelock.getOperationState(id)), uint256(GranularTimelockController.OperationState.Waiting));
    }

    function test_Schedule_RevertsIfNotProposer() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());

        vm.startPrank(nobody);
        vm.expectRevert();
        timelock.schedule(address(wutang), 0, data, bytes32(0), bytes32(0), DEFAULT_MIN_DELAY);
    }

    function test_Schedule_RevertsIfDelayTooShort() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        uint256 tooShortDelay = DEFAULT_MIN_DELAY - 1;

        vm.startPrank(proposer);
        vm.expectRevert(
            abi.encodeWithSelector(
                GranularTimelockController.TimelockInsufficientDelay.selector, tooShortDelay, DEFAULT_MIN_DELAY
            )
        );
        timelock.schedule(address(wutang), 0, data, bytes32(0), bytes32(0), tooShortDelay);
    }

    function test_Schedule_RevertsIfAlreadyScheduled() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("duplicate-test");

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        vm.expectRevert();
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);
    }

    // ============ Execute Tests ============

    function test_Execute_AfterDelay() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("execute-test");

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        bytes32 id = timelock.hashOperation(address(wutang), 0, data, bytes32(0), salt);

        // Warp past the delay
        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        assertTrue(timelock.isOperationReady(id));

        vm.startPrank(executor);
        timelock.execute(address(wutang), 0, data, bytes32(0), salt);

        assertTrue(timelock.isOperationDone(id));
        assertTrue(wutang.isForever());
    }

    function test_Execute_WithParameters() public {
        uint256 memberCount = 9; // Wu-Tang has 9 original members
        bytes memory data = abi.encodeCall(WuTest.wutangIsForTheChildren, (memberCount));
        bytes32 salt = keccak256("children-test");

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        vm.startPrank(executor);
        timelock.execute(address(wutang), 0, data, bytes32(0), salt);

        assertTrue(wutang.isForTheChildren());
        assertEq(wutang.memberCount(), memberCount);
    }

    function test_Execute_RevertsIfNotReady() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("not-ready-test");

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        vm.startPrank(executor);
        vm.expectRevert();
        timelock.execute(address(wutang), 0, data, bytes32(0), salt);
    }

    function test_Execute_RevertsIfNotExecutor() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("no-role-test");

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        vm.startPrank(nobody);
        vm.expectRevert();
        timelock.execute(address(wutang), 0, data, bytes32(0), salt);
    }

    // ============ Cancel Tests ============

    function test_Cancel_PendingOperation() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("cancel-test");

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        bytes32 id = timelock.hashOperation(address(wutang), 0, data, bytes32(0), salt);

        vm.startPrank(canceller);
        timelock.cancel(id);

        assertFalse(timelock.isOperation(id));
        assertEq(uint256(timelock.getOperationState(id)), uint256(GranularTimelockController.OperationState.Unset));
    }

    function test_Cancel_RevertsIfNotCanceller() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("cancel-role-test");

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        bytes32 id = timelock.hashOperation(address(wutang), 0, data, bytes32(0), salt);

        vm.startPrank(nobody);
        vm.expectRevert();
        timelock.cancel(id);
    }

    function test_Cancel_RevertsIfNotPending() public {
        bytes32 fakeId = keccak256("fake-operation");

        vm.startPrank(canceller);
        vm.expectRevert();
        timelock.cancel(fakeId);
    }

    // ============ Batch Operation Tests ============

    function test_ScheduleBatch_AndExecute() public {
        address[] memory targets = new address[](2);
        targets[0] = address(wutang);
        targets[1] = address(wutang);

        uint256[] memory values = new uint256[](2);
        values[0] = 0;
        values[1] = 0;

        bytes[] memory payloads = new bytes[](2);
        payloads[0] = abi.encodeCall(WuTest.wutangIsForever, ());
        payloads[1] = abi.encodeCall(WuTest.wutangIsForTheChildren, (36)); // 36 chambers

        bytes32 salt = keccak256("batch-test");

        vm.startPrank(proposer);
        timelock.scheduleBatch(targets, values, payloads, bytes32(0), salt, DEFAULT_MIN_DELAY);

        bytes32 id = timelock.hashOperationBatch(targets, values, payloads, bytes32(0), salt);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        vm.startPrank(executor);
        timelock.executeBatch(targets, values, payloads, bytes32(0), salt);

        assertTrue(timelock.isOperationDone(id));
        assertTrue(wutang.isForever());
        assertTrue(wutang.isForTheChildren());
        assertEq(wutang.memberCount(), 36);
    }

    function test_ScheduleBatch_RevertsOnLengthMismatch() public {
        address[] memory targets = new address[](2);
        uint256[] memory values = new uint256[](1); // mismatched length
        bytes[] memory payloads = new bytes[](2);

        vm.startPrank(proposer);
        vm.expectRevert(
            abi.encodeWithSelector(GranularTimelockController.TimelockInvalidOperationLength.selector, 2, 2, 1)
        );
        timelock.scheduleBatch(targets, values, payloads, bytes32(0), bytes32(0), DEFAULT_MIN_DELAY);
    }

    // ============ Custom Delay Tests ============

    function test_UpdateCallDelay() public {
        bytes4 selector = WuTest.wutangIsForever.selector;
        bytes32 opSig = keccak256(abi.encode(address(wutang), selector));

        // Schedule the updateCallDelay call through the timelock itself
        bytes memory updateDelayData =
            abi.encodeCall(GranularTimelockController.updateCallDelay, (address(wutang), selector, CUSTOM_DELAY));

        vm.startPrank(proposer);
        timelock.schedule(address(timelock), 0, updateDelayData, bytes32(0), bytes32(0), DEFAULT_MIN_DELAY);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        vm.startPrank(executor);
        timelock.execute(address(timelock), 0, updateDelayData, bytes32(0), bytes32(0));

        assertEq(timelock.getMinDelay(opSig), CUSTOM_DELAY);
    }

    function test_UpdateCallDelay_RevertsIfNotSelf() public {
        vm.startPrank(admin);
        vm.expectRevert(abi.encodeWithSelector(GranularTimelockController.TimelockUnauthorizedCaller.selector, admin));
        timelock.updateCallDelay(address(wutang), WuTest.wutangIsForever.selector, CUSTOM_DELAY);
    }

    function test_Schedule_RespectsCustomDelay() public {
        bytes4 selector = WuTest.wutangIsForever.selector;

        // First set custom delay via timelock
        bytes memory updateDelayData =
            abi.encodeCall(GranularTimelockController.updateCallDelay, (address(wutang), selector, CUSTOM_DELAY));

        vm.startPrank(proposer);
        timelock.schedule(address(timelock), 0, updateDelayData, bytes32(0), keccak256("set-delay"), DEFAULT_MIN_DELAY);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        vm.startPrank(executor);
        timelock.execute(address(timelock), 0, updateDelayData, bytes32(0), keccak256("set-delay"));

        // Get the custom delay
        bytes32 opSig = keccak256(abi.encode(address(wutang), selector));
        uint256 customDelay = timelock.getMinDelay(opSig);
        assertEq(customDelay, CUSTOM_DELAY);

        // Now try to schedule wutangIsForever with less than custom delay
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());

        vm.startPrank(proposer);
        vm.expectRevert(
            abi.encodeWithSelector(
                GranularTimelockController.TimelockInsufficientDelay.selector, DEFAULT_MIN_DELAY, CUSTOM_DELAY
            )
        );
        timelock.schedule(address(wutang), 0, data, bytes32(0), keccak256("should-fail"), DEFAULT_MIN_DELAY);
        // But scheduling with custom delay should work
        timelock.schedule(address(wutang), 0, data, bytes32(0), keccak256("should-work"), CUSTOM_DELAY);

        // Execute it for good measure
        vm.warp(block.timestamp + CUSTOM_DELAY);
        vm.startPrank(executor);
        timelock.execute(address(wutang), 0, data, bytes32(0), keccak256("should-work"));
        assertTrue(wutang.isForever());
    }

    function test_UpdateDefaultDelay() public {
        uint256 newDefaultDelay = 3 days;

        bytes memory updateDelayData = abi.encodeCall(GranularTimelockController.updateDefaultDelay, (newDefaultDelay));

        vm.startPrank(proposer);
        timelock.schedule(address(timelock), 0, updateDelayData, bytes32(0), bytes32(0), DEFAULT_MIN_DELAY);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        vm.startPrank(executor);
        timelock.execute(address(timelock), 0, updateDelayData, bytes32(0), bytes32(0));

        assertEq(timelock.defaultMinDelay(), newDefaultDelay);
    }

    function test_UpdateDefaultDelay_RevertsIfNotSelf() public {
        vm.startPrank(admin);
        vm.expectRevert(abi.encodeWithSelector(GranularTimelockController.TimelockUnauthorizedCaller.selector, admin));
        timelock.updateDefaultDelay(3 days);
    }

    // ============ Predecessor Tests ============

    function test_Execute_WithPredecessor() public {
        bytes memory data1 = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes memory data2 = abi.encodeCall(WuTest.wutangIsForTheChildren, (9));

        bytes32 salt1 = keccak256("first-op");
        bytes32 salt2 = keccak256("second-op");

        bytes32 id1 = timelock.hashOperation(address(wutang), 0, data1, bytes32(0), salt1);

        // Schedule first operation
        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data1, bytes32(0), salt1, DEFAULT_MIN_DELAY);
        // Schedule second operation with first as predecessor
        timelock.schedule(address(wutang), 0, data2, id1, salt2, DEFAULT_MIN_DELAY);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        // Can't execute second before first
        vm.startPrank(executor);
        vm.expectRevert(abi.encodeWithSelector(GranularTimelockController.TimelockUnexecutedPredecessor.selector, id1));
        timelock.execute(address(wutang), 0, data2, id1, salt2);

        // Execute first
        timelock.execute(address(wutang), 0, data1, bytes32(0), salt1);

        // Now second can execute
        timelock.execute(address(wutang), 0, data2, id1, salt2);

        assertTrue(wutang.isForever());
        assertTrue(wutang.isForTheChildren());
    }

    // ============ Open Role Tests ============

    function test_Execute_OpenRole() public {
        // Grant executor role to address(0) - makes it open to everyone
        vm.startPrank(admin);
        timelock.grantRole(EXECUTOR_ROLE, address(0));

        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("open-role-test");

        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        // Anyone can execute now
        vm.startPrank(nobody);
        timelock.execute(address(wutang), 0, data, bytes32(0), salt);

        assertTrue(wutang.isForever());
    }

    // ============ View Function Tests ============

    function test_GetMinDelay_ReturnsDefaultForUnsetCalls() public view {
        bytes32 randomOpSig = keccak256(abi.encode(address(0x1234), bytes4(0x12345678)));
        assertEq(timelock.getMinDelay(randomOpSig), DEFAULT_MIN_DELAY);
    }

    function test_GetMinDelay_ReturnsDefaultForZeroBytes32() public view {
        assertEq(timelock.getMinDelay(bytes32(0)), DEFAULT_MIN_DELAY);
    }

    function test_HashOperation_Deterministic() public view {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("deterministic-test");

        bytes32 hash1 = timelock.hashOperation(address(wutang), 0, data, bytes32(0), salt);
        bytes32 hash2 = timelock.hashOperation(address(wutang), 0, data, bytes32(0), salt);

        assertEq(hash1, hash2);
    }

    function test_GetTimestamp() public {
        bytes memory data = abi.encodeCall(WuTest.wutangIsForever, ());
        bytes32 salt = keccak256("timestamp-test");

        bytes32 id = timelock.hashOperation(address(wutang), 0, data, bytes32(0), salt);

        // Before scheduling
        assertEq(timelock.getTimestamp(id), 0);

        uint256 scheduledAt = block.timestamp;
        vm.startPrank(proposer);
        timelock.schedule(address(wutang), 0, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        // After scheduling
        assertEq(timelock.getTimestamp(id), scheduledAt + DEFAULT_MIN_DELAY);

        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        vm.startPrank(executor);
        timelock.execute(address(wutang), 0, data, bytes32(0), salt);

        // After execution (DONE_TIMESTAMP = 1)
        assertEq(timelock.getTimestamp(id), 1);
    }

    // ============ ETH Transfer Tests ============

    function test_Execute_WithEthValue() public {
        uint256 ethAmount = 1 ether;
        bytes memory data = abi.encodeCall(WuTest.dollarDollarBillYall, ());
        bytes32 salt = keccak256("cash-rules-everything-around-me");

        // Schedule operation with ETH value
        vm.startPrank(proposer);
        timelock.schedule(address(wutang), ethAmount, data, bytes32(0), salt, DEFAULT_MIN_DELAY);

        bytes32 id = timelock.hashOperation(address(wutang), ethAmount, data, bytes32(0), salt);
        assertTrue(timelock.isOperationPending(id));

        // Warp past delay
        vm.warp(block.timestamp + DEFAULT_MIN_DELAY);

        // Fund the executor and execute with ETH forwarded from caller
        vm.deal(executor, ethAmount);
        vm.startPrank(executor);
        timelock.execute{value: ethAmount}(address(wutang), ethAmount, data, bytes32(0), salt);

        // Verify state
        assertTrue(timelock.isOperationDone(id), "Operation should be done");
        assertEq(wutang.balance(), ethAmount, "WuTest should have received ETH");
        assertEq(address(wutang).balance, ethAmount, "WuTest contract balance should match");
        assertEq(address(timelock).balance, 0, "Timelock should not hold ETH");
        assertEq(executor.balance, 0, "Executor should have sent all ETH");
    }
}
