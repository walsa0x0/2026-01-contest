// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {StorkMockWithTestHelpers} from "./StorkMockTest.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";

contract StorkMockUnitTest is Test {
    StorkMockWithTestHelpers public storkMock;

    uint256 public signerKey;
    address public signerAddress;
    address public storkPublicKey;
    uint256 constant VALID_TIME_PERIOD = 86400; // 1 day
    uint256 constant SINGLE_UPDATE_FEE = 1; // 1 wei

    function setUp() public {
        signerKey = uint256(keccak256("You may find yourself"));
        signerAddress = vm.addr(signerKey);
        storkPublicKey = signerAddress;

        storkMock = new StorkMockWithTestHelpers();
        storkMock.initializeWithKey(VALID_TIME_PERIOD, SINGLE_UPDATE_FEE, signerKey);
    }

    function test_Initialization() public view {
        assertEq(storkMock.signerKey(), signerKey);
        assertEq(storkMock.signerAddress(), signerAddress);
        assertEq(storkMock.storkPublicKey(), storkPublicKey);
        assertEq(storkMock.validTimePeriodSeconds(), VALID_TIME_PERIOD);
        assertEq(storkMock.singleUpdateFeeInWei(), SINGLE_UPDATE_FEE);
    }

    function test_SetSignerKey() public {
        uint256 newKey = uint256(keccak256("Living in a shotgun shack"));
        storkMock.setSignerKey(newKey);

        assertEq(storkMock.signerKey(), newKey);
        assertEq(storkMock.signerAddress(), vm.addr(newKey));
    }

    function test_UpdateValidTimePeriodSeconds() public {
        uint256 newPeriod = VALID_TIME_PERIOD + 1;
        storkMock.updateValidTimePeriodSeconds(newPeriod);

        assertEq(storkMock.validTimePeriodSeconds(), newPeriod);
    }

    function test_UpdateSingleUpdateFeeInWei() public {
        uint256 newFee = SINGLE_UPDATE_FEE + 1;
        storkMock.updateSingleUpdateFeeInWei(newFee);

        assertEq(storkMock.singleUpdateFeeInWei(), newFee);
    }

    function test_UpdateStorkPublicKey() public {
        address newPublicKey = address(0x123);
        storkMock.updateStorkPublicKey(newPublicKey);

        assertEq(storkMock.storkPublicKey(), newPublicKey);
    }

    function test_SignStorkPayload() public view {
        bytes32 id = keccak256("And you may find yourself");
        uint256 recvTime = uint256(block.timestamp) * 1e9; // Convert to nanoseconds
        int256 quantizedValue = 2000e18;
        bytes32 publisherMerkleRoot = keccak256("In another part of the world");
        bytes32 valueComputeAlgHash = keccak256("And you may find yourself");

        (bytes32 r, bytes32 s, uint8 v) =
            storkMock.signStorkPayload(id, recvTime, quantizedValue, publisherMerkleRoot, valueComputeAlgHash);

        // Verify signature components are non-zero
        assertTrue(r != bytes32(0));
        assertTrue(s != bytes32(0));
        assertTrue(v != 0);
    }

    function test_SignTemporalNumericValueInput() public view {
        bytes32 id = keccak256("Behind the wheel of a large automobile");
        StorkStructs.TemporalNumericValue memory temporalValue =
            StorkStructs.TemporalNumericValue({timestampNs: uint64(block.timestamp * 1e9), quantizedValue: 2000e18});

        StorkStructs.TemporalNumericValueInput memory input = storkMock.signTemporalNumericValueInput(id, temporalValue);

        // Verify the input structure
        assertEq(input.id, id);
        assertEq(input.temporalNumericValue.timestampNs, temporalValue.timestampNs);
        assertEq(input.temporalNumericValue.quantizedValue, temporalValue.quantizedValue);
        assertTrue(input.r != bytes32(0));
        assertTrue(input.s != bytes32(0));
        assertTrue(input.v != 0);
    }

    function test_VerifySignature() public view {
        bytes32 id = keccak256("And you may find yourself in a beautiful house");
        StorkStructs.TemporalNumericValue memory temporalValue =
            StorkStructs.TemporalNumericValue({timestampNs: uint64(block.timestamp * 1e9), quantizedValue: 50000e18});

        // Create signed input
        StorkStructs.TemporalNumericValueInput memory input = storkMock.signTemporalNumericValueInput(id, temporalValue);

        // Verify the signature using Stork's verification
        bool verified = storkMock.verifyStorkSignatureV1(
            storkPublicKey,
            input.id,
            input.temporalNumericValue.timestampNs,
            input.temporalNumericValue.quantizedValue,
            input.publisherMerkleRoot,
            input.valueComputeAlgHash,
            input.r,
            input.s,
            input.v
        );

        assertTrue(verified);
    }

    function test_UpdateTemporalNumericValues() public payable {
        bytes32 id = keccak256("With a beautiful wife");
        StorkStructs.TemporalNumericValue memory temporalValue =
            StorkStructs.TemporalNumericValue({timestampNs: uint64(block.timestamp * 1e9), quantizedValue: 2000e18});

        // Create signed input
        StorkStructs.TemporalNumericValueInput memory input = storkMock.signTemporalNumericValueInput(id, temporalValue);

        // Update the temporal value
        StorkStructs.TemporalNumericValueInput[] memory inputs = new StorkStructs.TemporalNumericValueInput[](1);
        inputs[0] = input;

        uint256 fee = storkMock.getUpdateFeeV1(inputs);
        storkMock.updateTemporalNumericValuesV1{value: fee}(inputs);

        // Retrieve the stored value
        StorkStructs.TemporalNumericValue memory retrieved = storkMock.getTemporalNumericValueUnsafeV1(id);

        assertEq(retrieved.timestampNs, temporalValue.timestampNs);
        assertEq(retrieved.quantizedValue, temporalValue.quantizedValue);
    }

    function test_GetTemporalNumericValue() public payable {
        bytes32 id = keccak256("And you may ask yourself");
        uint64 timestampNs = uint64(block.timestamp * 1e9);

        StorkStructs.TemporalNumericValue memory temporalValue =
            StorkStructs.TemporalNumericValue({timestampNs: timestampNs, quantizedValue: 15e18});

        StorkStructs.TemporalNumericValueInput memory input = storkMock.signTemporalNumericValueInput(id, temporalValue);

        StorkStructs.TemporalNumericValueInput[] memory inputs = new StorkStructs.TemporalNumericValueInput[](1);
        inputs[0] = input;

        uint256 fee = storkMock.getUpdateFeeV1(inputs);
        storkMock.updateTemporalNumericValuesV1{value: fee}(inputs);

        StorkStructs.TemporalNumericValue memory retrieved = storkMock.getTemporalNumericValueV1(id);

        assertEq(retrieved.timestampNs, timestampNs);
        assertEq(retrieved.quantizedValue, 15e18);
    }

    function test_SignerAddressMatchesPublicKey() public view {
        // Well, how did I get here?
        address signerAddr = storkMock.signerAddress();
        address pubKey = storkMock.storkPublicKey();

        assertEq(signerAddr, pubKey);
    }
}
