// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {StdCheatsSafe} from "forge-std/StdCheats.sol";
import {IStork} from "@storknetwork/stork-evm-sdk/IStork.sol";
import {StorkStructs} from "@storknetwork/stork-evm-sdk/StorkStructs.sol";
import {MessageHashUtils} from "@openzeppelin-contracts/utils/cryptography/MessageHashUtils.sol";

import {StorkMock} from "src/mocks/StorkMock.sol";

/// @title StorkMockWithTestHelpers
/// @notice Extended StorkMock with test-only signing helpers that require forge-std vm
/// @dev This contract inherits from Test and can only be used in Foundry tests, not deployed
contract StorkMockWithTestHelpers is StorkMock, StdCheatsSafe, Test {
    using MessageHashUtils for bytes32;

    uint256 public signerKey;

    /// @notice Initialize with a private key for signing (test-only)
    function initializeWithKey(uint256 validTimePeriodSeconds_, uint256 singleUpdateFeeInWei_, uint256 signerKey_)
        public
    {
        signerKey = signerKey_;
        address publicKey = vm.addr(signerKey_);
        initialize(publicKey, validTimePeriodSeconds_, singleUpdateFeeInWei_);
    }

    /// @notice Get the signer address derived from the signer key (test-only)
    function signerAddress() public view returns (address) {
        return vm.addr(signerKey);
    }

    /// @notice Set the signer key (test-only)
    function setSignerKey(uint256 signerKey_) public {
        signerKey = signerKey_;
    }

    /// @notice Sets stork price with dummy publisherMerkleRoot and valueComputeAlgHash (test-only)
    /// @dev Bypasses signature verification and sets a price directly using vm.sign
    function setStorkPrice(bytes32 market, int192 price) public {
        StorkStructs.TemporalNumericValue memory storkValue = StorkStructs.TemporalNumericValue({
            timestampNs: uint64(vm.getBlockTimestamp()) * 1000000000, quantizedValue: price
        });

        StorkStructs.TemporalNumericValueInput memory storkPricePayload =
            signTemporalNumericValueInput(market, storkValue, bytes32(uint256(1)), bytes32(uint256(1)));

        StorkStructs.TemporalNumericValueInput[] memory storkPricePayloads =
            new StorkStructs.TemporalNumericValueInput[](1);
        storkPricePayloads[0] = storkPricePayload;
        IStork(address(this)).updateTemporalNumericValuesV1(storkPricePayloads);
    }

    /// @notice Signs a temporal numeric value payload for verification (test-only)
    /// @param id The bytes32 ID of the data feed
    /// @param recvTime The timestamp in nanoseconds
    /// @param quantizedValue Price value padded to 18 decimals
    /// @param publisherMerkleRoot Merkle root
    /// @param valueComputeAlgHash The hash of the compute algorithm
    /// @return r The r signature component
    /// @return s The s signature component
    /// @return v The v signature component
    function signStorkPayload(
        bytes32 id,
        uint256 recvTime,
        int256 quantizedValue,
        bytes32 publisherMerkleRoot,
        bytes32 valueComputeAlgHash
    ) public view returns (bytes32 r, bytes32 s, uint8 v) {
        // Recover the stork public key from the signer key
        address storkPubKey = vm.addr(signerKey);

        // Create message hash using same logic as getStorkMessageHashV1
        bytes32 msgHash = keccak256(
            abi.encodePacked(storkPubKey, id, recvTime, quantizedValue, publisherMerkleRoot, valueComputeAlgHash)
        );

        // Get Ethereum signed message hash (adds "\x19Ethereum Signed Message:\n32" prefix)
        bytes32 signedMessageHash = MessageHashUtils.toEthSignedMessageHash(msgHash);

        (v, r, s) = vm.sign(signerKey, signedMessageHash);
    }

    /// @notice Convenience overload with default merkle root and alg hash (test-only)
    function signTemporalNumericValueInput(bytes32 id, StorkStructs.TemporalNumericValue memory temporalValue)
        public
        view
        returns (StorkStructs.TemporalNumericValueInput memory input)
    {
        bytes32 publisherMerkleRoot = bytes32(uint256(1));
        bytes32 valueComputeAlgHash = bytes32(uint256(1));
        return signTemporalNumericValueInput(id, temporalValue, publisherMerkleRoot, valueComputeAlgHash);
    }

    /// @notice Creates a complete TemporalNumericValueInput struct with signature (test-only)
    /// @param id The bytes32 ID of the data feed
    /// @param temporalValue The temporal numeric value
    /// @param publisherMerkleRoot The merkle root from publishers
    /// @param valueComputeAlgHash The hash of the compute algorithm
    /// @return input The complete TemporalNumericValueInput struct with signature
    function signTemporalNumericValueInput(
        bytes32 id,
        StorkStructs.TemporalNumericValue memory temporalValue,
        bytes32 publisherMerkleRoot,
        bytes32 valueComputeAlgHash
    ) public view returns (StorkStructs.TemporalNumericValueInput memory input) {
        // Sign the payload
        (bytes32 r, bytes32 s, uint8 v) = signStorkPayload(
            id,
            temporalValue.timestampNs,
            int256(temporalValue.quantizedValue),
            publisherMerkleRoot,
            valueComputeAlgHash
        );

        // Create and return the complete input struct
        input = StorkStructs.TemporalNumericValueInput({
            temporalNumericValue: temporalValue,
            id: id,
            publisherMerkleRoot: publisherMerkleRoot,
            valueComputeAlgHash: valueComputeAlgHash,
            r: r,
            s: s,
            v: v
        });
    }
}

