// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {NonceBitmap} from "../src/lib/NonceBitmap.sol";
import {NonceBitmapWrapper} from "./NonceBitmapWrapper.sol";

contract NonceBitmapTest is Test {
    NonceBitmapWrapper private bitmap;
    address private testAddress = address(0x123);

    function setUp() public {
        bitmap = new NonceBitmapWrapper();
    }

    function test_InitialState() public view {
        // Initially no nonces should be used
        assertFalse(bitmap.isUsed(0));
        assertFalse(bitmap.isUsed(255));
        assertFalse(bitmap.isUsed(256));
    }

    function test_UseSingleNonce() public {
        bitmap.burnNonce(42);

        assertTrue(bitmap.isUsed(42));
        assertFalse(bitmap.isUsed(41));
        assertFalse(bitmap.isUsed(43));
    }

    function test_useMultipleSequentialNonces() public {
        bitmap.burnNonce(0);
        bitmap.burnNonce(1);
        bitmap.burnNonce(2);

        assertTrue(bitmap.isUsed(0));
        assertTrue(bitmap.isUsed(1));
        assertTrue(bitmap.isUsed(2));
        assertFalse(bitmap.isUsed(3));
    }

    function test_UseMultipleNonces() public {
        bitmap.burnNonce(0);
        bitmap.burnNonce(255);
        bitmap.burnNonce(256);
        bitmap.burnNonce(511);

        assertTrue(bitmap.isUsed(0));
        assertTrue(bitmap.isUsed(255));
        assertTrue(bitmap.isUsed(256));
        assertTrue(bitmap.isUsed(511));
        assertFalse(bitmap.isUsed(1));
        assertFalse(bitmap.isUsed(254));
        assertFalse(bitmap.isUsed(257));
        assertFalse(bitmap.isUsed(510));
    }

    function test_UseNonceTwiceReverts() public {
        bitmap.burnNonce(42);
        vm.expectRevert(abi.encodeWithSelector(NonceBitmap.NonceAlreadyUsed.selector, 42));
        bitmap.burnNonce(42);
    }

    function test_LargeNonce() public {
        uint256 largeNonce = type(uint256).max - 100;
        bitmap.burnNonce(largeNonce);

        assertTrue(bitmap.isUsed(largeNonce));
        assertFalse(bitmap.isUsed(largeNonce - 1));
        assertFalse(bitmap.isUsed(largeNonce + 1));
    }

    function test_RevertOnDuplicateUse() public {
        bitmap.burnNonce(42);

        vm.expectRevert(abi.encodeWithSelector(NonceBitmap.NonceAlreadyUsed.selector, 42));
        bitmap.burnNonce(42);
    }

    function test_ComplexScenario() public {
        // Simulate a complex scenario with many nonces used out of order
        uint256[] memory nonces = new uint256[](10);
        nonces[0] = 0;
        nonces[1] = 255;
        nonces[2] = 256;
        nonces[3] = 100;
        nonces[4] = 511;
        nonces[5] = 512;
        nonces[6] = 50;
        nonces[7] = 1023;
        nonces[8] = 25;
        nonces[9] = 2047;

        for (uint256 i = 0; i < nonces.length; i++) {
            bitmap.burnNonce(nonces[i]);
        }

        // Test that all used nonces are marked as used
        for (uint256 i = 0; i < nonces.length; i++) {
            assertTrue(bitmap.isUsed(nonces[i]));
        }

        // Test that some unused nonces are not marked
        assertFalse(bitmap.isUsed(1));
        assertFalse(bitmap.isUsed(254));
        assertFalse(bitmap.isUsed(257));
        assertFalse(bitmap.isUsed(510));
    }
}
