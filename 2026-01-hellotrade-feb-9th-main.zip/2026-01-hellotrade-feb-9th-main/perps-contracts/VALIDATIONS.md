1. Signature payload
  - No deadline for fill signature means potentially playing signature long after submission. Ex flow:
    1. User submits 10,000 LONG BTC (Sufficient margin @ posting)
    2. Platform fails to post order to chain
    3. User re-posts order with new nonce
    4. Platform posts both orders (or platform posts order at a much later date)
    5. User is now heavily undercollateralized onchain, triggers liquidation
  - Mitigation:
    1. Display / handle order finalization in UI, trigger warning if attempting to create order when unfinalized order is on book
    2. Reasonable deadline for initial order submission, allow fills to accumulate up to order max onchain

Auto-Deleverage
  - As accounts are stored in terms of net only, no leverage-specific data is stored onchain. Auto-deleverage must be an authority-trusted action until some sort of proof system can be implemented.

Liquidation
  - Validating cross-margin account equity is O(n) time where n = number of markets entered, and MUST be stored on-chain for proper account equity calculation from onchain price feeds. Managing this data can potentially get very expensive if a user frequently opens and closes positions fully (0-1-0 sstores).
  - DxTrade may be reserving margin PER-ORDER, not PER-MARKET-NET! If so, users holding both long and short for the same market on DXtrade may have higher margin requirements than onchain. If DxTrade is our source of truth for liqudations this is fine, but those liqudations cannot be validated onchain. 
