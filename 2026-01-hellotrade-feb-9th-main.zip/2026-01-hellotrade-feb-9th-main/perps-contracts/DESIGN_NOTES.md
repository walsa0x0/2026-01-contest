## Genreral structure
This smart contract system functionally serves as both the capital vault, canonical position ledger, and margin validation / liquidation execution system for HelloTrade. 

### The system is designed with the following considerations:

1. The matching system is strictly CLOB / no liquidity-pool backed AMM. Accounts are cross-margin by default.

2. Order storage and matching happens offchain, and is validated / settled onchain. The contract acts as the cannonical source of truth for user margin and positions, and has no knowedge of the offchain order book. As such, any two crossing orders are considered valid, and the contract makes no garauntees for best-price execution.

3. The order book must minimize unfillable orders. Resting orders are validated against / applied to an offchain ledger prior to broadcast to ensure that the user has sufficient margin to fill it; due to the nature of leverage and margin, this is a constantly moving target. In the event that an order is sent to the chain but fails onchain validation, it is busted offchain and the ledger is reconciled.

4. Onchain components should prevent any movements of user funds not explicitly user-authorized, with the following exceptions:
  - Underwater/undercollateralized accounts may be subject to liqudation without the owner's signature
  - In the event an order was unable to clear prior to the account going into negative margin, an opposing high-profit position may be closed at a worse execution price in order to clear the book imbalance (ADL)

5. Margin requirements must be validated against an signed mark price feed. Because HelloTrade implements custom risk management strategies and logic for mark price calculation, there is currently inherent centralization risk, although there are plans to decentralize this in the future.

6. Ordering consistent with the offchain book is vitally important to maintaining a (relatively) bust-free order book and to prevent self-frontrun deposit grief. The contract implements a tracking head which can double as order preservation and global nonce (although this may want reconsidering)

### General position lifecycle:

1. The contract accepts and validates deposits and withdrawals of a single ERC20 token as the margin currency via the relayer.

2. A user signs an order payload which is validated by the ledger and accepted by the matching engine.

3. When a match is found, the relayer will broadcast the signed pair. The order cross and margin requirements are updated, and position and margin are updated when necessary. Partial fills are stored in an accumulator. When an order is fully filled, its nonce is burned. Simple order closures (order is contra position and does not cross zero into opposite side) always reduce the margin requirements, and as such they skip this validation.
3.1. Realized PNL from position close is calculated against the real execution price of a match, not the asset mark price. Mark price is strictly used for margin requirement validation and liquidation checks.

4. Funding payments are processed as a cumulative funding index and realized on position update, consistent with several well established perp DEX patterns.

5. A user may withdraw against any available margin, which is the sum of deposits and any position @ mark-price derived PNL.

### Nonce management

This contract uses a nonsequential nonce management system for withdrawals, user configuration and order processing -- unlike the nonce convention of ERC20Permit which is monotonic, we cannot garauntee the order of order execution and as such nonces do not automatically expire lesser nonces.

Deposits rely on the standard ERC20Permit flow, but may be abstracted to a router contract in the future.

## Nonstandard elements

### Contract size

The current smart contracts are larger than the maximum contract size limit for Ethereum Mainnet -- as the contracts are designed for MegaEth, which has a vastly increased smart contract size cap, this is currently a non-issue. If this does need to be addressed, will attempt simple multicontract, possibly a diamond pattern.

### Accounting model

Unlike many perp dexes, the accounting model tracks position and margin with signed integers. Arithmetically, any combintaion of short and long positions will net to a single position -- as such, we store a single net position per user per market where the sign indicates negative for short and positive for long. Orders may increase or decrease, or cross zero to create a new position. Liquidations may not cross zero and must be a "Simple Close."

Margin / deposited margin is similarly tracked as a signed integer, as there is no pool backfill available and the only practical guard against a negative position is a keeper/releayer-provided liquidation order fill or an ADL action. The stored margin account value is debited / credited on position update per-market, and "real" margin is the sum of the margin account value and PnL of all open positions. In the event that a price movement is so drastic that an account is closed with resulting negative margin, the negative balance must be offset with deposits before the account can be reopened, although starting a new account is trivial. It also remains useful for accouniting posterity.

### Dirty storage for closed positions

When a position is closed, its storage is left dirty as an optimization for later opens (1 -> 1 SSTORE instead of 1 -> 0 | 0 -> 1)

### Structural notes / misc considerations / known issues

- The contract currently uses a UUPS proxy pattern that entirely bypasses upgrade validation. This is primarily for rapid testnet development, and will be validated against properly pre-mainnet.

- Some events and errors may be unused / legacy values which require cleanup. They may still change if requirements shift.

- The current iteration makes substantial use of library functions with mapping stack ops for convenience, though it is not entirely consistent; some objects with shared keys (`accounts` and `crossMarginAccounts`, for example) are not grouped, some library methods are unused, several functions may delegate unnecessarily. These may benefit from both some cleanup and gas golfing, as generally the functions are marginally cheaper when called directly instead of the `struct.method` calls from what I've found.

- Some functions which were previously functional are commented (such as the batch processor.)

- Certain operations can be reworked for more flexibility, such as allowing account action delegation in the signature verification logic, or verifying an attestation in lieu of a role check for msg.sender,  which would allow for more flexible batching.

- Funding payments currently use a mark price directly from a relayer call as opposed to a signed stork price. This should be migrated either to the stork pull oracle system, or take from the push oracle price.

- I have consdidered moving to a diamond/namespace storage pattern, but have yet to actually decide if it's a net improvement over the current state.

- CI needs overhaul.

- Some other potential error sites need additional checking / bounds:
  - casting between ints / uints / int-uint needs some thorough looking at
  - bounds on number of market positions / cross-margin array length cap

- Several things need optimization, such as:
  - Revisiting some value uint sizes
  - Struct packing
  - uint16 enumerable set to save on storage for user active market set
